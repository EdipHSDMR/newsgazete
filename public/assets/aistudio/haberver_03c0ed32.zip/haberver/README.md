# Haber Keşif

Çizgi, Türkçe ve Android öncelikli bir haber keşif uygulamasıdır. Ticari marka ve alan adı uygunluğu yayın öncesinde doğrulanmalıdır.

Uygulama başka sitenin haberini kopyalamaz. Editörün özgün özetini gösterir ve okuru kaynağın kendi sayfasına gönderir. Kaynak göstermek yeniden kullanım izni değildir. Gerçek yayıncı sözleşmesi yokken yüklenen kayıtlar sentetiktir ve öyle etiketlenir.

## Bu makinede doğrulanan

`backend` içinde 27 test geçti. Ayrıntı `docs/acceptance/rapor.md`.

Android projesi yazıldı fakat burada derlenemedi: kurulu Java 8, JDK 17 ve Android SDK yok.

## Sunucuyu çalıştırma

```powershell
cd backend
copy .env.example .env
python -m app.demo.seed
python -m uvicorn app.main:app --reload
```

Gerçek PHA bültenlerini canlı akışa almak için `PHA_API_KEY` değerini yalnızca `backend/.env` içinde tutun ve ikinci terminalde tek bir yenileme işçisi başlatın:

```powershell
cd backend
python -m app.pha_worker
```

İşçi, PHA'nın yayımladığı kullanım koşullarındaki kaynak gösterme şartına göre yeni başlıkları beş dakikada bir alır ve tekrarları PHA haber kimliğiyle eler. API anahtarı Android uygulamasına veya tarayıcıya gönderilmez. Tek seferlik yenileme için `python -m app.pha_worker --once` kullanın. Aynı veritabanına yalnızca bir yenileme işçisi bağlayın.

Spor ekranı gerçek Türkiye Süper Lig fikstürü ve tablosu için API-Football kullanır. Ücretsiz anahtarınızı [API-Football hesabından](https://dashboard.api-football.com/) alın ve `backend/.env` içindeki `API_FOOTBALL_KEY` alanına ekleyin. Uygulama bu anahtarı istemciye göndermez; günlük ücretsiz kotayı korumak için günün maçları 20 dakikada, puan tablosu 3 saatte bir sunucu önbelleğinden yenilenir. Sağlayıcı anahtarı yokken örnek skor gösterilmez.

Demo, `APP_ENV=dev` ve `ALLOW_SYNTHETIC=true` ister. Üretimde sentetik yayın kapalıdır. Yönetim jetonlarını `.env` içinde değiştirin. Editör ekranı `http://127.0.0.1:8000/admin` adresindedir; asıl yetki bu ekranda değil, her istekte roldedir.

PostgreSQL için deponun kökündeki `docker-compose.yml` yerel geliştirme içindir. Bu bilgisayarda Docker yok.

## Android

Projeyi Android Studio ile `android` klasöründen açın. JDK 17 gerekir. Hata ayıklama adresi emülatör için `http://10.0.2.2:8000/v1/` olur. Sürüm derlemesi `https://api.haberver.example/v1/` kullanır; bu alan adı yer tutucudur.

Android cihaz yenilemesi WorkManager ile yaklaşık 30 dakikada bir çalışır; takip edilen konu veya takımla eşleşen yeni haber varsa izin ve sessiz saat tercihine uyan cihaz içi bildirim üretebilir. Arka plan zamanlaması Android tarafından ertelenebilir. FCM sunucu push'u, son dakika sınıflandırması ve günlük özet gönderimi ayrıca yapılandırılmalıdır.

## Bilinçli sınırlar

Tam metin alanı yok. HTML tarama yok. Fotoğraf önbelleği yok. Reklam yok. Hesap yok; temel okuma misafirdir. Bildirim izni ilk açılışta sorulmaz. FCM projesi yok; gelişme bildirimi yerelde ve ayardan sonra düşünülür.

NewsAPI geliştirici planı yalnızca geliştirme ve test içindir; uygulama üretim ortamına geçtiğinde bu kaynaktan gelen kayıtlar akış, arama ve ayrıntı uç noktalarında ayrıca gizlenir. Üretim kullanımı için ticari planın ve yayıncı içerik haklarının doğrulanması gerekir. Kaynak göstermek tek başına yeniden yayınlama izni vermez.
