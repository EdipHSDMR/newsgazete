package dev.haberver.kesif.ui.sports

import java.time.Clock
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

internal val SportsZone: ZoneId = ZoneId.of("Europe/Istanbul")
private val Turkish = Locale.forLanguageTag("tr-TR")

internal data class SportsMeta(
    val provider: String = "",
    val attribution: String? = null,
    val timezone: String = "Europe/Istanbul",
    val refreshedAt: String? = null,
    val fromCache: Boolean = false,
    val stale: Boolean = false,
    val limited: Boolean = false,
    val limitation: String? = null,
)

internal data class Competition(
    val id: String,
    val name: String,
    val area: String?,
    val emblem: String?,
)

internal data class Side(val id: String?, val name: String, val crest: String?)

internal data class MatchScore(val home: Int?, val away: Int?)

internal data class MatchItem(
    val id: String,
    val competitionName: String,
    val home: Side,
    val away: Side,
    val score: MatchScore?,
    val localTime: String,
    val status: String,
    val minute: String?,
)

internal data class StandingRow(
    val rank: Int?,
    val team: Side,
    val played: Int?,
    val won: Int?,
    val drawn: Int?,
    val lost: Int?,
    val goalsDiff: Int?,
    val points: Int?,
)

internal data class TeamItem(
    val id: String?,
    val name: String,
    val shortName: String?,
    val crest: String?,
    val venue: String?,
)

internal data class SportsPage(
    val meta: SportsMeta = SportsMeta(),
    val competitions: List<Competition> = emptyList(),
    val matches: List<MatchItem> = emptyList(),
    val standings: List<StandingRow> = emptyList(),
    val teams: List<TeamItem> = emptyList(),
)

internal data class StatusPresentation(val label: String, val live: Boolean)

internal enum class SportsTab(val title: String, val bucket: String?) {
    Live("Canlı", "live"),
    Today("Bugün", "today"),
    Scheduled("Fikstür", "scheduled"),
    Finished("Sonuçlar", "finished"),
    Standings("Puan Durumu", null),
    Teams("Takımlar", null),
    ;

    val usesDate: Boolean
        get() = this == Today || this == Scheduled || this == Finished
}

class SportsCallException(
    val status: Int,
    val code: String?,
    val serverMessage: String?,
    val retryAfterSeconds: Int? = null,
) : Exception("sports_$status")

internal fun istanbulToday(clock: Clock = Clock.system(SportsZone)): String = LocalDate.now(clock).toString()

internal fun shiftIsoDate(iso: String, days: Long): String {
    val parsed = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return istanbulToday()
    return parsed.plusDays(days).toString()
}

internal fun formatIsoDateLabel(iso: String): String {
    val date = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return ""
    return titleTr(date.format(DateTimeFormatter.ofPattern("d MMMM EEEE", Turkish)))
}

internal fun formatClock(raw: String?): String {
    val text = raw?.trim().orEmpty()
    if (text.isEmpty()) return ""
    val match = Regex("""^(\d{1,2}):(\d{2})$""").matchEntire(text)
    if (match != null) {
        val hour = match.groupValues[1].toIntOrNull() ?: return ""
        val minute = match.groupValues[2].toIntOrNull() ?: return ""
        if (hour !in 0..23 || minute !in 0..59) return ""
        return "%02d:%02d".format(hour, minute)
    }
    val instant = parseInstant(text) ?: return ""
    return DateTimeFormatter.ofPattern("HH:mm").withZone(SportsZone).format(instant)
}

internal fun formatRefreshed(raw: String?): String {
    val instant = raw?.let(::parseInstant) ?: return "bilinmiyor"
    return titleTr(DateTimeFormatter.ofPattern("d MMM HH:mm", Turkish).withZone(SportsZone).format(instant))
}

internal fun sourceLine(meta: SportsMeta?, refreshing: Boolean = false): String {
    if (meta == null) return "Kaynak: football-data.org"
    val attribution = meta.attribution?.trim()?.takeUnless { it.isEmpty() || sportsMessageLooksSensitive(it) }
    val credit = when {
        attribution.isNullOrBlank() -> "Kaynak: football-data.org"
        attribution.contains("football-data.org", ignoreCase = true) -> attribution
        else -> "$attribution · football-data.org"
    }
    val line = "$credit · Son yenilenme: ${formatRefreshed(meta.refreshedAt)} · ${freshnessLabel(meta)}"
    return if (refreshing) "$line · yenileniyor" else line
}

internal fun freshnessLabel(meta: SportsMeta): String = when {
    meta.stale && meta.fromCache -> "Önbellek · son başarılı veri"
    meta.stale -> "Son başarılı veri"
    meta.fromCache -> "Önbellekten"
    else -> "Güncel"
}

internal fun limitationText(meta: SportsMeta): String? {
    val text = meta.limitation?.trim().orEmpty()
    if (text.isNotEmpty() && !sportsMessageLooksSensitive(text)) return text
    if (meta.limited) return "Sağlayıcı bu yanıtı sınırladı. Eksik skor tamamlanmaz."
    return null
}

internal fun humanSportsError(status: Int, code: String?, serverMessage: String?, retryAfterSeconds: Int? = null): String {
    val normalized = code?.trim()?.lowercase(Locale.US).orEmpty()
    if (status == 429 || normalized == "rate_limited") {
        if (retryAfterSeconds != null && retryAfterSeconds in 1..900) {
            val minutes = ((retryAfterSeconds + 59) / 60).coerceAtLeast(1)
            return "Çok fazla istek atıldı. Yaklaşık $minutes dakika sonra Yenile ile tekrar dene."
        }
        return "Çok fazla istek atıldı. Birkaç dakika sonra Yenile ile tekrar dene."
    }
    if (status == 401 || status == 403 || normalized == "forbidden" || normalized == "provider_forbidden") {
        return "Skor verisine erişim kapalı. Bu ekran anahtar tutmaz; erişim sunucuda açıldığında veriler gelir."
    }
    if (status == 404 || normalized == "not_found") {
        return "Spor servisi henüz hazır değil. Biraz sonra Yenile ile tekrar dene."
    }
    if (status == 502 || status == 503 || status == 504 || normalized == "source_unavailable" || normalized == "service_unavailable") {
        return "Skor servisi şu an yanıt vermiyor. Kısa süre sonra yeniden dene."
    }
    if (normalized == "timeout") return "Skor servisi zamanında yanıt vermedi. Yenile ile tekrar dene."
    if (status == 0 || normalized == "offline" || normalized == "bad_base") {
        return "Bağlantı kurulamadı. Ağını kontrol edip Yenile."
    }
    if (status == 500 || normalized == "server_error") return "Spor servisinde bir hata oluştu. Biraz sonra Yenile."
    val safe = serverMessage?.trim()?.takeUnless {
        it.isEmpty() || it.length > 280 || sportsMessageLooksSensitive(it) || it.equals("Not Found", true)
    }
    return safe ?: "Skorlar şu an alınamadı. Yenile ile tekrar dene."
}

internal fun humanFrom(error: Throwable): String = when (error) {
    is SportsCallException -> humanSportsError(error.status, error.code, error.serverMessage, error.retryAfterSeconds)
    else -> humanSportsError(0, "offline", null, null)
}

internal fun statusPresentation(status: String, minute: String?): StatusPresentation {
    val labels = mapOf(
        "IN_PLAY" to "Canlı",
        "LIVE" to "Canlı",
        "PAUSED" to "Devre arası",
        "HALFTIME" to "Devre arası",
        "HT" to "Devre arası",
        "EXTRA_TIME" to "Uzatma",
        "ET" to "Uzatma",
        "PENALTY_SHOOTOUT" to "Penaltılar",
        "PENALTIES" to "Penaltılar",
        "SCHEDULED" to "Başlamadı",
        "TIMED" to "Başlamadı",
        "NS" to "Başlamadı",
        "FINISHED" to "Bitti",
        "FT" to "Bitti",
        "AWARDED" to "Hükmen",
        "POSTPONED" to "Ertelendi",
        "SUSPENDED" to "Durduruldu",
        "INTERRUPTED" to "Durduruldu",
        "CANCELLED" to "İptal",
        "CANCELED" to "İptal",
    )
    val known = labels[status]
    val base = known ?: if (status.matches(Regex("^[A-Z0-9_]{1,24}$"))) status else "Durum bilinmiyor"
    val minuteLabel = minute?.takeIf { it.isNotBlank() }?.let { "$it′" }
    val gold = status in setOf("IN_PLAY", "LIVE", "EXTRA_TIME", "ET", "PENALTY_SHOOTOUT", "PENALTIES")
    return StatusPresentation(if (minuteLabel != null) "$base · $minuteLabel" else base, gold)
}

internal fun scoreCell(score: MatchScore?, home: Boolean): String {
    if (score == null) return "–"
    val value = if (home) score.home else score.away
    return value?.toString() ?: "–"
}

internal fun statCell(value: Int?): String = value?.toString() ?: "–"

internal fun diffCell(value: Int?): String = when {
    value == null -> "–"
    value > 0 -> "+$value"
    else -> value.toString()
}

internal fun httpsCrest(raw: String?): String? {
    val text = raw?.trim().orEmpty()
    if (!text.startsWith("https://")) return null
    val uri = runCatching { java.net.URI(text) }.getOrNull() ?: return null
    if (!uri.scheme.equals("https", true)) return null
    if (!uri.userInfo.isNullOrEmpty() || uri.host.isNullOrBlank()) return null
    return uri.toString()
}

internal fun sportsMessageLooksSensitive(value: String): Boolean {
    return Regex("""api[_-]?key|token|secret|bearer|authorization|x-auth""", RegexOption.IGNORE_CASE).containsMatchIn(value)
}

internal fun String.trContains(query: String): Boolean {
    return lowercase(Turkish).contains(query.trim().lowercase(Turkish))
}

private fun titleTr(value: String): String = value.split(" ").joinToString(" ") { word ->
    word.replaceFirstChar { char -> if (char.isLowerCase()) char.titlecase(Turkish) else char.toString() }
}

private fun parseInstant(raw: String): Instant? {
    if (raw.isBlank()) return null
    runCatching { return Instant.parse(raw) }
    runCatching { return OffsetDateTime.parse(raw).toInstant() }
    runCatching { return ZonedDateTime.parse(raw).toInstant() }
    return null
}
