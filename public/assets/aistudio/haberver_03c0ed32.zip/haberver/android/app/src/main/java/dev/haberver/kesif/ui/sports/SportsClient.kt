package dev.haberver.kesif.ui.sports

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Skor uçları. Api.kt içindeki Retrofit arayüzüne yeni metot eklenmez.
 * İstekte Accept ve X-Request-ID vardır; anahtar veya Authorization yoktur.
 */
internal class SportsClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .build(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    suspend fun competitions(apiBase: String): SportsPage = get(apiBase, "sports/competitions", emptyMap())

    suspend fun matches(apiBase: String, competitionId: String?, bucket: String, date: String?): SportsPage {
        return get(apiBase, "sports/matches", query(competitionId, "bucket" to bucket, "date" to date))
    }

    suspend fun standings(apiBase: String, competitionId: String?): SportsPage {
        return get(apiBase, "sports/standings", query(competitionId))
    }

    suspend fun teams(apiBase: String, competitionId: String?): SportsPage {
        return get(apiBase, "sports/teams", query(competitionId))
    }

    fun close() {
        http.dispatcher.executorService.shutdown()
        http.connectionPool.evictAll()
    }

    private fun query(competitionId: String?, vararg extra: Pair<String, String?>): Map<String, String> {
        val map = linkedMapOf<String, String>()
        if (!competitionId.isNullOrBlank()) map["competition"] = competitionId
        extra.forEach { (key, value) -> if (!value.isNullOrBlank()) map[key] = value }
        return map
    }

    private suspend fun get(apiBase: String, path: String, query: Map<String, String>): SportsPage {
        val url = endpoint(apiBase, path, query)
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("X-Request-ID", UUID.randomUUID().toString().replace("-", ""))
            .get()
            .build()
        val text = execute(request)
        return withContext(Dispatchers.IO) { parsePage(json, text) }
    }

    private suspend fun execute(request: Request): String = suspendCancellableCoroutine { continuation ->
        val call = http.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!continuation.isActive) return
                val code = if (e is SocketTimeoutException) "timeout" else "offline"
                continuation.resumeWithException(SportsCallException(0, code, null))
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    if (!continuation.isActive) return
                    try {
                        val body = it.body?.string().orEmpty()
                        if (!it.isSuccessful) {
                            continuation.resumeWithException(parseFailure(json, it.code, it.header("Retry-After"), body))
                        } else {
                            continuation.resume(body)
                        }
                    } catch (error: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(SportsCallException(it.code, "offline", null))
                    }
                }
            }
        })
    }
}

internal fun endpoint(apiBase: String, path: String, query: Map<String, String>): String {
    val parsed = apiBase.trim().toHttpUrlOrNull() ?: throw SportsCallException(0, "bad_base", null)
    if (parsed.username.isNotEmpty() || parsed.password.isNotEmpty()) {
        throw SportsCallException(0, "bad_base", null)
    }
    val base = parsed.newBuilder().query(null).fragment(null).build()
    val root = base.newBuilder()
    val segments = base.encodedPath.trim('/').split('/').filter { it.isNotEmpty() }.toMutableList()
    if (segments.lastOrNull() != "v1") segments += "v1"
    root.encodedPath("/")
    segments.forEach { root.addPathSegment(it) }
    path.trim('/').split('/').filter { it.isNotEmpty() }.forEach { root.addPathSegment(it) }
    query.forEach { (key, value) -> if (value.isNotBlank()) root.addQueryParameter(key, value) }
    return root.build().toString()
}

internal fun parsePage(json: Json, text: String): SportsPage {
    val root = runCatching { json.parseToJsonElement(text) }.getOrNull() as? JsonObject ?: return SportsPage()
    if (root["error"] != null && root["data"] == null) {
        val error = root["error"] as? JsonObject
        throw SportsCallException(200, error.plain("code"), error.plain("message")?.takeUnless { sportsMessageLooksSensitive(it) })
    }
    val data = (root["data"] as? JsonObject) ?: root
    return SportsPage(
        meta = parseMeta(data),
        competitions = data.rows("competitions").mapNotNull(::parseCompetition),
        matches = data.rows("matches").mapNotNull(::parseMatch),
        standings = data.rows("standings").mapNotNull(::parseStanding),
        teams = data.rows("teams").mapNotNull(::parseTeam),
    )
}

private fun parseFailure(json: Json, status: Int, retryAfter: String?, text: String): SportsCallException {
    val root = runCatching { json.parseToJsonElement(text) }.getOrNull() as? JsonObject
    val error = root?.get("error") as? JsonObject
    val detail = (root?.get("detail") as? JsonPrimitive)?.contentOrNull
    val message = error.plain("message") ?: detail
    return SportsCallException(
        status = status,
        code = error.plain("code"),
        serverMessage = message?.takeUnless { sportsMessageLooksSensitive(it) },
        retryAfterSeconds = retryAfter?.toIntOrNull(),
    )
}

private fun parseMeta(data: JsonObject): SportsMeta {
    val limitation = data.plain("limitation")?.takeUnless { sportsMessageLooksSensitive(it) }
    return SportsMeta(
        provider = data.plain("provider").orEmpty(),
        attribution = data.plain("attribution")?.takeUnless { sportsMessageLooksSensitive(it) },
        timezone = data.plain("timezone") ?: "Europe/Istanbul",
        refreshedAt = data.plain("refreshed_at", "refreshedAt"),
        fromCache = data.flag("from_cache", "fromCache"),
        stale = data.flag("stale"),
        limited = data.flag("limited"),
        limitation = limitation,
    )
}

private fun parseCompetition(row: JsonObject): Competition? {
    val id = row.plain("id") ?: row.plain("code") ?: return null
    val area = when (val value = row["area"]) {
        is JsonObject -> value.plain("name")
        else -> value.plainPrimitive()
    }
    return Competition(
        id = id,
        name = row.plain("name") ?: id,
        area = area,
        emblem = httpsCrest(row.plain("emblem", "crest")),
    )
}

private fun parseMatch(row: JsonObject): MatchItem? {
    val home = parseSide(row["home"] ?: row["home_team"] ?: row["homeTeam"], row.plain("home_name"), row.plain("home_crest"))
    val away = parseSide(row["away"] ?: row["away_team"] ?: row["awayTeam"], row.plain("away_name"), row.plain("away_crest"))
    if (home.name == "—" && away.name == "—") return null
    val competition = row["competition"] as? JsonObject
    val score = if (row.containsKey("score")) parseScore(row["score"]) else parseScore(
        JsonObject(mapOf("home" to (row["home_score"] ?: JsonNull), "away" to (row["away_score"] ?: JsonNull))),
    )
    return MatchItem(
        id = row.plain("id").orEmpty(),
        competitionName = row.plain("competition_name", "competitionName") ?: competition.plain("name").orEmpty(),
        home = home,
        away = away,
        score = score,
        localTime = formatClock(row.plain("local_time", "localTime", "kickoff", "utc_date", "utcDate")),
        status = normalizeStatus(row["status"]),
        minute = normalizeMinute(row["minute"]),
    )
}

private fun parseStanding(row: JsonObject): StandingRow? {
    val team = when (val value = row["team"]) {
        null, is JsonNull -> Side(row.plain("team_id"), row.plain("team_name") ?: "—", httpsCrest(row.plain("crest")))
        else -> parseSide(value, row.plain("team_name"), row.plain("crest"))
    }
    if (team.name == "—") return null
    return StandingRow(
        rank = row.whole("rank", 1, 200),
        team = team,
        played = row.whole("played", 0, 200),
        won = row.whole("won", 0, 200),
        drawn = row.whole("drawn", 0, 200),
        lost = row.whole("lost", 0, 200),
        goalsDiff = row.whole("goals_diff", -500, 500) ?: row.whole("goalsDiff", -500, 500) ?: row.whole("goal_difference", -500, 500),
        points = row.whole("points", 0, 400),
    )
}

private fun parseTeam(row: JsonObject): TeamItem? {
    val name = row.plain("name", "short_name", "shortName") ?: return null
    val venue = when (val value = row["venue"]) {
        is JsonObject -> value.plain("name")
        else -> value.plainPrimitive()
    }
    return TeamItem(
        id = row.plain("id")?.takeIf { it.length <= 80 },
        name = name,
        shortName = row.plain("short_name", "shortName", "tla"),
        crest = httpsCrest(row.plain("crest", "emblem")),
        venue = venue,
    )
}

private fun parseSide(element: JsonElement?, alternateName: String?, alternateCrest: String? = null): Side {
    return when (element) {
        is JsonObject -> Side(
            id = element.plain("id")?.takeIf { it.length <= 80 },
            name = element.plain("name", "short_name", "shortName", "tla") ?: alternateName ?: "—",
            crest = httpsCrest(element.plain("crest", "emblem", "logo") ?: alternateCrest),
        )
        is JsonPrimitive -> Side(null, element.plainPrimitive() ?: alternateName ?: "—", httpsCrest(alternateCrest))
        else -> Side(null, alternateName ?: "—", httpsCrest(alternateCrest))
    }
}

private fun parseScore(element: JsonElement?): MatchScore? {
    val obj = element as? JsonObject ?: return null
    val source = (obj["fullTime"] as? JsonObject) ?: (obj["full_time"] as? JsonObject) ?: obj
    val home = source.whole("home", 0, 99)
    val away = source.whole("away", 0, 99)
    if (home == null && away == null) return null
    return MatchScore(home, away)
}

private fun normalizeStatus(element: JsonElement?): String {
    val raw = when (element) {
        is JsonObject -> element.plain("short", "code")
        else -> element.plainPrimitive()
    }.orEmpty()
    return raw.trim().uppercase().replace(Regex("\\s+"), "_")
}

private fun normalizeMinute(element: JsonElement?): String? {
    val raw = element.plainPrimitive() ?: return null
    return if (raw.matches(Regex("""^\d{1,3}(\+\d{1,2})?$"""))) raw else null
}

private fun JsonObject.rows(key: String): List<JsonObject> {
    val value = this[key] as? JsonArray ?: return emptyList()
    return value.mapNotNull { it as? JsonObject }
}

private fun JsonObject?.plain(vararg keys: String): String? {
    if (this == null) return null
    for (key in keys) {
        val value = this[key].plainPrimitive()
        if (!value.isNullOrBlank()) return value
    }
    return null
}

private fun JsonElement?.plainPrimitive(): String? {
    val primitive = this as? JsonPrimitive ?: return null
    if (this is JsonNull || primitive.booleanOrNull != null) return null
    val text = primitive.contentOrNull?.trim().orEmpty()
    if (text.isEmpty() || text.equals("null", true)) return null
    return text
}

private fun JsonObject.whole(key: String, min: Int, max: Int): Int? {
    val primitive = this[key] as? JsonPrimitive ?: return null
    if (primitive is JsonNull || primitive.booleanOrNull != null) return null
    val direct = primitive.intOrNull ?: primitive.contentOrNull?.trim()?.toIntOrNull()
    if (direct != null) return direct.takeIf { it in min..max }
    val fractional = primitive.contentOrNull?.trim()?.toDoubleOrNull() ?: return null
    if (fractional % 1.0 != 0.0) return null
    return fractional.toInt().takeIf { it in min..max }
}

private fun JsonObject.flag(vararg keys: String): Boolean {
    for (key in keys) {
        val primitive = this[key] as? JsonPrimitive ?: continue
        if (primitive is JsonNull) continue
        primitive.booleanOrNull?.let { return it }
        when (primitive.contentOrNull) {
            "true" -> return true
            "false" -> return false
        }
    }
    return false
}
