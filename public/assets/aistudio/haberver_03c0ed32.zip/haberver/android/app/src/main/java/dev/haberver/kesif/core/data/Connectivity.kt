package dev.haberver.kesif.core.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Cihazın çevrimiçi/çevrimdışı durumu. Web'deki CizgiBoot.isOffline /
 * onConnectivityChange karşılığıdır.
 *
 * Yalnızca ağ kapasitesi okunur; konum, kimlik veya kullanım verisi toplanmaz.
 * ACCESS_NETWORK_STATE izni normal düzeydedir ve manifestte tanımlıdır.
 */
object Connectivity {

    /** Şu an doğrulanmış bir internet bağlantısı var mı? */
    fun isOnline(context: Context): Boolean {
        val manager = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val network = manager.activeNetwork ?: return false
        val caps = manager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * Çevrimiçi durumu akış olarak yayar. İlk değer anlık durumdur;
     * sonra sistem geri çağırması ile güncellenir.
     */
    fun observeOnline(context: Context): Flow<Boolean> = callbackFlow {
        val manager = context.getSystemService(ConnectivityManager::class.java)
        if (manager == null) {
            trySend(true)
            close()
            return@callbackFlow
        }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(true)
            }

            override fun onLost(network: Network) {
                trySend(isOnline(context))
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val online = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                trySend(online)
            }
        }
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { manager.registerNetworkCallback(request, callback) }
        trySend(isOnline(context))
        awaitClose {
            runCatching { manager.unregisterNetworkCallback(callback) }
        }
    }
}