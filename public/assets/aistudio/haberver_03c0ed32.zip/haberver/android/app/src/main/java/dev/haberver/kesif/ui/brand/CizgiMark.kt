package dev.haberver.kesif.ui.brand

import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

private fun markNodes(data: String) =
    PathParser().parsePathString(data).toNodes().toList()

fun cizgiMarkVector(lineColor: Color, directionColor: Color): ImageVector {
    val line = markNodes(CizgiMarkGeometry.LINE)
    val direction = markNodes(CizgiMarkGeometry.DIRECTION)
    return ImageVector.Builder(
        name = "CizgiMark",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = CizgiMarkGeometry.VIEWPORT,
        viewportHeight = CizgiMarkGeometry.VIEWPORT,
        autoMirror = false,
    ).apply {
        addPath(
            pathData = line,
            stroke = SolidColor(lineColor),
            strokeLineWidth = CizgiMarkGeometry.STROKE,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
        addPath(
            pathData = direction,
            stroke = SolidColor(directionColor),
            strokeLineWidth = CizgiMarkGeometry.STROKE,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
    }.build()
}

/**
 * İnce çizgi ve yön oku. Varsayılan boya koyu zemin içindir.
 * Açık zeminde cizgiLineColor(false) ve cizgiDirectionColor(false) geçilir.
 * Sözcük ÇİZGİ yanındaysa contentDescription null verilir.
 * Dokunma alanı bu composable'da değildir; ebeveyn en az CizgiSpace.touch kullanır.
 */
@Composable
fun CizgiMark(
    modifier: Modifier = Modifier,
    lineColor: Color = CizgiColor.Ink,
    directionColor: Color = CizgiColor.Gold,
    contentDescription: String? = "Çizgi",
) {
    val vector = remember(lineColor, directionColor) {
        cizgiMarkVector(lineColor, directionColor)
    }
    Icon(
        imageVector = vector,
        contentDescription = contentDescription,
        modifier = modifier,
        tint = Color.Unspecified,
    )
}
