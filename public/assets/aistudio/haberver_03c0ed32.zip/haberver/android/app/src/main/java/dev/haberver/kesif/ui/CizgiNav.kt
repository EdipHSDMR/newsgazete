package dev.haberver.kesif.ui

import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

internal object CizgiRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val SPORTS = "sports"
    const val WEATHER = "hava"
    const val SEARCH = "search"
    const val SAVED = "saved"
    const val PROFILE = "profile"
    const val TOPICS = "topics"
    const val STORY = "story/{id}"
    const val COMPARE = "compare/{id}"
    const val SOURCE = "source/{id}"
    const val ABOUT = "about"
    const val REPORT = "report/{id}"

    fun story(id: String) = "story/$id"
    fun compare(id: String) = "compare/$id"
    fun source(id: String) = "source/$id"
    fun report(id: String) = "report/$id"
}

internal data class CizgiTab(
    val route: String,
    val label: String,
    val contentDescription: String,
    val icon: ImageVector,
)

internal val CizgiTabs: List<CizgiTab> = listOf(
    CizgiTab(CizgiRoutes.HOME, "Akış", "Akış sekmesi", AkisIcon),
    CizgiTab(CizgiRoutes.SEARCH, "Keşfet", "Keşfet sekmesi", AraIcon),
    CizgiTab(CizgiRoutes.SPORTS, "Spor", "Spor sekmesi", SporIcon),
    CizgiTab(CizgiRoutes.SAVED, "Kaydedilen", "Kaydedilen sekmesi", KaydedilenIcon),
    CizgiTab(CizgiRoutes.PROFILE, "Profil", "Profil sekmesi", ProfilIcon),
)

internal fun NavHostController.switchCizgiTab(route: String) {
    navigate(route) {
        popUpTo(CizgiRoutes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
internal fun CizgiBottomBar(
    currentRoute: String?,
    onSelect: (String) -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    NavigationBar(
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 0.dp,
        windowInsets = NavigationBarDefaults.windowInsets,
    ) {
        CizgiTabs.forEach { tab ->
            val selected = currentRoute == tab.route
            NavigationBarItem(
                selected = selected,
                onClick = { onSelect(tab.route) },
                modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp),
                alwaysShowLabel = true,
                icon = {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.contentDescription,
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        modifier = Modifier.clearAndSetSemantics { },
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = accent,
                    selectedTextColor = accent,
                    indicatorColor = accent.copy(alpha = 0.22f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}

private fun tabIcon(name: String, path: String, filled: Boolean = false): ImageVector {
    val nodes = PathParser().parsePathString(path).toNodes().toList()
    return ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).apply {
        if (filled) {
            addPath(pathData = nodes, fill = SolidColor(Color.Black))
        } else {
            addPath(
                pathData = nodes,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.7f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            )
        }
    }.build()
}

private val AkisIcon = tabIcon("Akis", "M4,4H20V20H4Z M7,8H17 M7,12H17 M7,16H13")
private val SporIcon = tabIcon("Spor", "M8,4H16V9.2C16,12.4 8,12.4 8,9.2Z M8,6.2H5.2C5.2,9.4 8,10.2 8,8.2 M16,6.2H18.8C18.8,9.4 16,10.2 16,8.2 M12,12.2V16.4 M8.5,19H15.5")
private val AraIcon = tabIcon("Ara", "M16,11A5,5 0 1 1 6,11A5,5 0 1 1 16,11 M14.6,14.6L19,19")
private val KaydedilenIcon = tabIcon("Kaydedilen", "M6,3H18V21L12,16.5L6,21Z", filled = true)
private val ProfilIcon = tabIcon("Profil", "M15.6,8.6A3.6,3.6 0 1 1 8.4,8.6A3.6,3.6 0 1 1 15.6,8.6 M5.5,19.5C6.4,16.2 8.8,14.6 12,14.6C15.2,14.6 17.6,16.2 18.5,19.5")
