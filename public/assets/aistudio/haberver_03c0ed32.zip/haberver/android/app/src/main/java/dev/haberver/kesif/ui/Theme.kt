package dev.haberver.kesif.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import dev.haberver.kesif.ui.brand.cizgiDarkColorScheme
import dev.haberver.kesif.ui.brand.cizgiLightColorScheme
import dev.haberver.kesif.ui.brand.cizgiTypography

/**
 * `light` ve `system` açık şema (sistem seçilince açık tercih).
 * Yalnızca `dark` koyu şemadır. Primary = lacivert; turkuaz yok.
 */
@Composable
fun HaberTheme(mode: String, content: @Composable () -> Unit) {
    val dark = mode == "dark"
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val lightScheme = remember { cizgiLightColorScheme() }
    val darkScheme = remember { cizgiDarkColorScheme() }
    val type = remember { cizgiTypography() }
    MaterialTheme(
        colorScheme = if (dark) darkScheme else lightScheme,
        typography = type,
        content = content,
    )
}

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}
