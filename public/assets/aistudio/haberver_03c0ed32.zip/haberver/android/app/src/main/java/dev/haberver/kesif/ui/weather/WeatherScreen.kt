package dev.haberver.kesif.ui.weather

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val PlacePrefs = "cizgi.weather.place.v1"
private val WeatherJson = Json { ignoreUnknownKeys = true }

/**
 * Hava merkezi. GPS varsayılan kapalı; şehir elle seçilir.
 * İstemci anahtar göndermez; yalnızca /v1/weather uçlarını çağırır.
 */
@Composable
fun WeatherScreen(apiBase: String, onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val client = remember { WeatherClient() }
    DisposableEffect(client) { onDispose { client.close() } }
    val scope = rememberCoroutineScope()

    var place by remember { mutableStateOf(loadPlace(context)) }
    var query by remember { mutableStateOf(place?.label.orEmpty()) }
    var suggestions by remember { mutableStateOf<List<WeatherPlace>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var panel by remember { mutableStateOf<WeatherPanel>(if (place == null) WeatherPanel.Empty else WeatherPanel.Loading) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    fun select(picked: WeatherPlace) {
        place = picked
        savePlace(context, picked)
        query = picked.label
        suggestions = emptyList()
        searchError = null
    }

    fun clearPlace() {
        place = null
        savePlace(context, null)
        panel = WeatherPanel.Empty
        suggestions = emptyList()
    }

    fun loadForecast(selected: WeatherPlace, refresh: Boolean) {
        scope.launch {
            if (!refresh || panel !is WeatherPanel.Content) panel = WeatherPanel.Loading
            panel = try {
                val page = client.forecast(apiBase, selected.latitude, selected.longitude, selected.label)
                WeatherPanel.Content(page)
            } catch (error: WeatherCallException) {
                val existing = panel as? WeatherPanel.Content
                if (existing != null) {
                    existing.copy(banner = error.userMessage())
                } else {
                    WeatherPanel.Problem(error.userMessage(), offline = error.code == "offline")
                }
            } catch (_: Exception) {
                WeatherPanel.Problem("Tahmin alınamadı.", offline = false)
            }
        }
    }

    LaunchedEffect(place?.latitude, place?.longitude) {
        val selected = place ?: return@LaunchedEffect
        loadForecast(selected, refresh = false)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Meteoroloji", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text("Hava", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
            }
            if (onBack != null) {
                TextButton(onClick = onBack, modifier = Modifier.heightIn(min = 48.dp)) { Text("Geri") }
            }
        }
        Text(
            "Şehir elle seçilir. Konum izni istenmez; GPS kapalıdır.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                searchJob?.cancel()
                searchJob = scope.launch {
                    delay(320)
                    val q = it.trim()
                    if (q.length < 2) {
                        suggestions = emptyList()
                        searchError = null
                        searching = false
                        return@launch
                    }
                    searching = true
                    searchError = null
                    try {
                        suggestions = client.search(apiBase, q).places
                        searching = false
                    } catch (error: WeatherCallException) {
                        searching = false
                        suggestions = emptyList()
                        searchError = error.userMessage()
                    } catch (_: Exception) {
                        searching = false
                        suggestions = emptyList()
                        searchError = "Arama yapılamadı."
                    }
                }
            },
            label = { Text("Şehir ara") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    searchJob?.cancel()
                    scope.launch {
                        val q = query.trim()
                        if (q.length < 2) {
                            searchError = "En az 2 karakter girin."
                            return@launch
                        }
                        searching = true
                        try {
                            suggestions = client.search(apiBase, q).places
                            searching = false
                        } catch (error: WeatherCallException) {
                            searching = false
                            searchError = error.userMessage()
                        }
                    }
                },
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("Ara") }
            if (place != null) {
                OutlinedButton(onClick = { clearPlace() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Temizle") }
                OutlinedButton(
                    onClick = { place?.let { loadForecast(it, refresh = true) } },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("Yenile") }
            }
        }
        if (searching) Text("Aranıyor…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        searchError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        suggestions.forEach { item ->
            TextButton(
                onClick = { select(item) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) { Text(item.label, modifier = Modifier.fillMaxWidth()) }
        }
        when (val view = panel) {
            WeatherPanel.Empty -> Text("Hava durumunu görmek için bir şehir seç.")
            WeatherPanel.Loading -> {
                CircularProgressIndicator()
                Text("Tahmin getiriliyor")
            }
            is WeatherPanel.Problem -> Text(view.text, color = MaterialTheme.colorScheme.error)
            is WeatherPanel.Content -> WeatherBody(view)
        }
        Text(
            "Veri: Open-Meteo (CC BY 4.0). Resmi uyarı API’si yok; uyarı üretilmez. Europe/Istanbul · metrik.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun WeatherBody(view: WeatherPanel.Content) {
    val page = view.page
    val current = page.current
    view.banner?.let { Text(it, color = MaterialTheme.colorScheme.tertiary) }
    if (page.stale) Text("Sağlayıcıya ulaşılamadı; son başarılı tahmin gösteriliyor.", color = MaterialTheme.colorScheme.tertiary)
    Text(page.placeLabel.ifBlank { "Seçili yer" }, style = MaterialTheme.typography.titleMedium)
    Text("${fmtTemp(current?.temperatureC)} · ${current?.condition ?: "—"}", style = MaterialTheme.typography.headlineSmall)
    Text(
        "Nem ${fmtPct(current?.humidityPct)} · Yağış ${fmtOne(current?.precipitationMm, " mm")} · " +
            "Rüzgâr ${fmtOne(current?.windSpeedKmh, " km/s")} · UV ${fmtOne(current?.uvIndex, "")}",
        style = MaterialTheme.typography.bodyMedium,
    )
    Text("Doğuş ${clock(page.sunrise)} · Batış ${clock(page.sunset)}", style = MaterialTheme.typography.bodyMedium)
    Text("Saatlik", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        page.hourly.take(24).forEach { row ->
            Column(
                Modifier
                    .width(108.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.medium)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(clock(row.time), style = MaterialTheme.typography.labelMedium)
                Text(fmtTemp(row.temperatureC), style = MaterialTheme.typography.titleMedium)
                Text(row.condition ?: "—", style = MaterialTheme.typography.bodySmall, maxLines = 2)
                Text("yağış ${fmtPct(row.precipProbability)}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Text("7 gün", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
    page.daily.take(7).forEach { day ->
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.medium)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text("${day.date} · ${day.condition ?: "—"}", style = MaterialTheme.typography.titleSmall)
            Text("${fmtTemp(day.tempMaxC)} / ${fmtTemp(day.tempMinC)} · yağış ${fmtOne(day.precipSumMm, " mm")} · UV ${fmtOne(day.uvMax, "")}")
        }
    }
    Text(
        listOfNotNull(page.provider.ifBlank { null }, page.attribution, if (page.fromCache) "önbellek" else null)
            .joinToString(" · "),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

private sealed interface WeatherPanel {
    data object Empty : WeatherPanel
    data object Loading : WeatherPanel
    data class Problem(val text: String, val offline: Boolean) : WeatherPanel
    data class Content(val page: WeatherPage, val banner: String? = null) : WeatherPanel
}

private data class WeatherPlace(
    val id: Int?,
    val name: String,
    val label: String,
    val latitude: Double,
    val longitude: Double,
)

private data class WeatherCurrent(
    val temperatureC: Double?,
    val condition: String?,
    val humidityPct: Int?,
    val precipitationMm: Double?,
    val windSpeedKmh: Double?,
    val uvIndex: Double?,
)

private data class WeatherHour(
    val time: String?,
    val temperatureC: Double?,
    val condition: String?,
    val precipProbability: Int?,
)

private data class WeatherDay(
    val date: String?,
    val condition: String?,
    val tempMaxC: Double?,
    val tempMinC: Double?,
    val precipSumMm: Double?,
    val uvMax: Double?,
)

private data class WeatherPage(
    val placeLabel: String,
    val provider: String,
    val attribution: String?,
    val fromCache: Boolean,
    val stale: Boolean,
    val sunrise: String?,
    val sunset: String?,
    val current: WeatherCurrent?,
    val hourly: List<WeatherHour>,
    val daily: List<WeatherDay>,
)

private data class SearchPage(val places: List<WeatherPlace>)

private class WeatherCallException(val status: Int, val code: String, message: String?) : Exception(message) {
    fun userMessage(): String = message?.takeIf { it.isNotBlank() } ?: when (code) {
        "offline" -> "Bağlantı kurulamadı."
        "timeout" -> "İstek zaman aşımına uğradı."
        else -> "Hava servisi yanıt vermedi."
    }
}

private class WeatherClient(
    private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build(),
) {
    suspend fun search(apiBase: String, q: String): SearchPage {
        val root = get(apiBase, "weather/search", mapOf("q" to q))
        val places = root.arr("places").mapNotNull { el ->
            val obj = el.asObject() ?: return@mapNotNull null
            val lat = obj.double("latitude") ?: return@mapNotNull null
            val lon = obj.double("longitude") ?: return@mapNotNull null
            val name = obj.str("name") ?: return@mapNotNull null
            WeatherPlace(obj.int("id"), name, obj.str("label") ?: name, lat, lon)
        }
        return SearchPage(places)
    }

    suspend fun forecast(apiBase: String, lat: Double, lon: Double, name: String): WeatherPage {
        val root = get(
            apiBase,
            "weather/forecast",
            mapOf("latitude" to lat.toString(), "longitude" to lon.toString(), "name" to name),
        )
        val forecast = root.obj("forecast") ?: JsonObject(emptyMap())
        val currentObj = forecast.obj("current")
        val placeObj = root.obj("place")
        return WeatherPage(
            placeLabel = placeObj?.str("label") ?: placeObj?.str("name") ?: name,
            provider = root.str("provider").orEmpty(),
            attribution = root.str("attribution"),
            fromCache = root.bool("from_cache") == true,
            stale = root.bool("stale") == true,
            sunrise = forecast.str("sunrise"),
            sunset = forecast.str("sunset"),
            current = currentObj?.let {
                WeatherCurrent(
                    temperatureC = it.double("temperature_c"),
                    condition = it.str("condition"),
                    humidityPct = it.int("humidity_pct"),
                    precipitationMm = it.double("precipitation_mm"),
                    windSpeedKmh = it.double("wind_speed_kmh"),
                    uvIndex = it.double("uv_index"),
                )
            },
            hourly = forecast.arr("hourly").mapNotNull { el ->
                val row = el.asObject() ?: return@mapNotNull null
                WeatherHour(
                    time = row.str("time"),
                    temperatureC = row.double("temperature_c"),
                    condition = row.str("condition"),
                    precipProbability = row.int("precipitation_probability_pct"),
                )
            },
            daily = forecast.arr("daily").mapNotNull { el ->
                val row = el.asObject() ?: return@mapNotNull null
                WeatherDay(
                    date = row.str("date"),
                    condition = row.str("condition"),
                    tempMaxC = row.double("temperature_max_c"),
                    tempMinC = row.double("temperature_min_c"),
                    precipSumMm = row.double("precipitation_sum_mm"),
                    uvMax = row.double("uv_index_max"),
                )
            },
        )
    }

    fun close() {
        http.dispatcher.executorService.shutdown()
        http.connectionPool.evictAll()
    }

    private suspend fun get(apiBase: String, path: String, query: Map<String, String>): JsonObject {
        val base = normalizeBase(apiBase)
        val urlBuilder = "$base$path".toHttpUrlOrNull()?.newBuilder()
            ?: throw WeatherCallException(0, "offline", "Geçersiz adres.")
        query.forEach { (k, v) -> if (v.isNotBlank()) urlBuilder.addQueryParameter(k, v) }
        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("Accept", "application/json")
            .header("X-Request-ID", UUID.randomUUID().toString().replace("-", ""))
            .get()
            .build()
        val text = execute(request)
        return withContext(Dispatchers.IO) {
            val root = WeatherJson.parseToJsonElement(text).asObject() ?: JsonObject(emptyMap())
            root.obj("data") ?: root
        }
    }

    private suspend fun execute(request: Request): String = suspendCancellableCoroutine { continuation ->
        val call = http.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!continuation.isActive) return
                val code = if (e is SocketTimeoutException) "timeout" else "offline"
                continuation.resumeWithException(WeatherCallException(0, code, null))
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    if (!continuation.isActive) return
                    val body = it.body?.string().orEmpty()
                    if (!it.isSuccessful) {
                        val message = runCatching {
                            WeatherJson.parseToJsonElement(body).asObject()?.obj("error")?.str("message")
                        }.getOrNull()
                        continuation.resumeWithException(WeatherCallException(it.code, "error", message))
                    } else {
                        continuation.resume(body)
                    }
                }
            }
        })
    }
}

private fun normalizeBase(apiBase: String): String {
    val trimmed = apiBase.trim().trimEnd('/')
    return when {
        trimmed.endsWith("/v1") -> "$trimmed/"
        else -> "$trimmed/v1/"
    }
}

private fun loadPlace(context: Context): WeatherPlace? {
    val prefs = context.getSharedPreferences(PlacePrefs, Context.MODE_PRIVATE)
    val lat = prefs.getString("latitude", null)?.toDoubleOrNull() ?: return null
    val lon = prefs.getString("longitude", null)?.toDoubleOrNull() ?: return null
    val name = prefs.getString("name", null)?.takeIf { it.isNotBlank() } ?: return null
    val label = prefs.getString("label", null)?.takeIf { it.isNotBlank() } ?: name
    val id = prefs.getInt("id", Int.MIN_VALUE).takeIf { it != Int.MIN_VALUE }
    return WeatherPlace(id, name, label, lat, lon)
}

private fun savePlace(context: Context, place: WeatherPlace?) {
    val editor = context.getSharedPreferences(PlacePrefs, Context.MODE_PRIVATE).edit().clear()
    if (place != null) {
        editor
            .putString("name", place.name)
            .putString("label", place.label)
            .putString("latitude", place.latitude.toString())
            .putString("longitude", place.longitude.toString())
        if (place.id != null) editor.putInt("id", place.id)
    }
    editor.apply()
}

private fun fmtTemp(value: Double?): String = value?.let { "${kotlin.math.round(it).toInt()}°" } ?: "—"
private fun fmtOne(value: Double?, suffix: String): String =
    value?.let {
        val rounded = if (kotlin.math.abs(it) >= 10) kotlin.math.round(it) else kotlin.math.round(it * 10) / 10.0
        "$rounded$suffix"
    } ?: "—"
private fun fmtPct(value: Int?): String = value?.let { "$it%" } ?: "—"
private fun clock(iso: String?): String {
    if (iso.isNullOrBlank()) return "—"
    val t = iso.substringAfter('T', "").take(5)
    return t.ifBlank { iso }
}

private fun JsonElement.asObject(): JsonObject? = this as? JsonObject
private fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
private fun JsonObject.arr(key: String): List<JsonElement> = (this[key] as? JsonArray)?.toList().orEmpty()
private fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
private fun JsonObject.int(key: String): Int? = (this[key] as? JsonPrimitive)?.intOrNull
private fun JsonObject.double(key: String): Double? = (this[key] as? JsonPrimitive)?.doubleOrNull
private fun JsonObject.bool(key: String): Boolean? = (this[key] as? JsonPrimitive)?.booleanOrNull
