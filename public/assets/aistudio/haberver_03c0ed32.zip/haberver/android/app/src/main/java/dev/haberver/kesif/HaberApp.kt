package dev.haberver.kesif

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import dev.haberver.kesif.core.data.AppDatabase
import dev.haberver.kesif.core.data.Preferences
import dev.haberver.kesif.core.data.StoryRepository
import dev.haberver.kesif.core.network.NewsApi
import dev.haberver.kesif.worker.RefreshWorker
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.UUID
import java.util.concurrent.TimeUnit

class HaberApp : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        createChannel()
        val request = PeriodicWorkRequestBuilder<RefreshWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "feed-refresh",
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel("stories", "Haber gelişmeleri", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "Takip edilen konulardaki editoryal özetler"
        manager.createNotificationChannel(channel)
    }
}

class AppContainer(context: Application) {
    val json = Json { ignoreUnknownKeys = true }
    val preferences = Preferences(context)
    val database = AppDatabase.create(context)
    val api: NewsApi
    val repository: StoryRepository

    init {
        val client = OkHttpClient.Builder()
            .callTimeout(15, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("X-Request-ID", UUID.randomUUID().toString().replace("-", ""))
                    .header("Accept", "application/json")
                    .build()
                chain.proceed(request)
            }
            .build()
        val base = if (BuildConfig.API_BASE_URL.endsWith("/")) BuildConfig.API_BASE_URL else BuildConfig.API_BASE_URL + "/"
        api = Retrofit.Builder()
            .baseUrl(base)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(NewsApi::class.java)
        repository = StoryRepository(api, database.stories(), json)
    }
}
