package dev.haberver.kesif.ui.profile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import dev.haberver.kesif.BuildConfig
import dev.haberver.kesif.core.data.Preferences
import dev.haberver.kesif.core.data.UserPrefs
import dev.haberver.kesif.ui.HaberTheme
import dev.haberver.kesif.worker.LocalAlerts
import dev.haberver.kesif.worker.NotificationAccess
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

data class CizgiNotice(
    val id: String,
    val title: String,
    val body: String = "",
    val read: Boolean = false,
)

private const val KEY_FONT = "font"
private const val KEY_MATCH_START = "match_start_alerts"
private const val KEY_SCORE = "score_change_alerts"
private const val KEY_FREQUENCY = "alert_frequency"
private const val KEY_SOURCE = "followed_source_alerts"
private const val FREQUENCY_OFF = "off"
private const val FREQUENCY_REFRESH = "device_refresh"

private object AlertStringState {
    var font by mutableStateOf("md")
    var matchStart by mutableStateOf(false)
    var scoreChange by mutableStateOf(false)
    var frequency by mutableStateOf(FREQUENCY_OFF)
    var generation: Int = 0
}

private val topicNames = mapOf(
    "ulusal" to "Türkiye",
    "dunya" to "Dünya",
    "ekonomi" to "Ekonomi",
    "bilim-teknoloji" to "Bilim ve teknoloji",
    "iklim-cevre" to "İklim ve çevre",
    "kultur" to "Kültür ve yaşam",
    "spor" to "Spor",
    "yerel" to "Yerel",
)

private fun topicLabel(slug: String): String = topicNames[slug] ?: slug

private suspend fun readAlertStrings(preferences: Preferences) {
    val seen = AlertStringState.generation
    var font = "md"
    var matchStart = false
    var scoreChange = false
    var frequency = FREQUENCY_OFF
    preferences.update { store ->
        font = when (readString(store, KEY_FONT)) {
            "lg" -> "lg"
            "xl" -> "xl"
            else -> "md"
        }
        matchStart = readString(store, KEY_MATCH_START) == "true"
        scoreChange = readString(store, KEY_SCORE) == "true"
        frequency = if (readString(store, KEY_FREQUENCY) == FREQUENCY_REFRESH) FREQUENCY_REFRESH else FREQUENCY_OFF
    }
    if (seen != AlertStringState.generation) return
    AlertStringState.font = font
    AlertStringState.matchStart = matchStart
    AlertStringState.scoreChange = scoreChange
    AlertStringState.frequency = frequency
}

private fun readString(store: MutablePreferences, name: String): String? {
    return runCatching { store[stringPreferencesKey(name)] }.getOrNull()
}

private fun selectFont(preferences: Preferences, scope: CoroutineScope, value: String) {
    val safe = if (value == "lg" || value == "xl") value else "md"
    AlertStringState.generation += 1
    AlertStringState.font = safe
    scope.launch {
        preferences.update { it[stringPreferencesKey(KEY_FONT)] = safe }
    }
}

private fun selectFrequency(preferences: Preferences, scope: CoroutineScope, value: String) {
    val safe = if (value == FREQUENCY_REFRESH) FREQUENCY_REFRESH else FREQUENCY_OFF
    AlertStringState.generation += 1
    AlertStringState.frequency = safe
    scope.launch {
        preferences.update { it[stringPreferencesKey(KEY_FREQUENCY)] = safe }
    }
}

private fun selectMatch(preferences: Preferences, scope: CoroutineScope, enabled: Boolean) {
    AlertStringState.generation += 1
    AlertStringState.matchStart = enabled
    scope.launch {
        preferences.update { it[stringPreferencesKey(KEY_MATCH_START)] = if (enabled) "true" else "false" }
    }
}

private fun selectScore(preferences: Preferences, scope: CoroutineScope, enabled: Boolean) {
    AlertStringState.generation += 1
    AlertStringState.scoreChange = enabled
    scope.launch {
        preferences.update { it[stringPreferencesKey(KEY_SCORE)] = if (enabled) "true" else "false" }
    }
}

private fun TextStyle.scaled(scale: Float): TextStyle {
    if (fontSize == TextUnit.Unspecified) return this
    val nextLine = if (lineHeight == TextUnit.Unspecified) lineHeight else lineHeight * scale
    return copy(fontSize = fontSize * scale, lineHeight = nextLine)
}

@Composable
private fun CizgiChrome(prefs: UserPrefs, modifier: Modifier, content: @Composable () -> Unit) {
    val scale = when (AlertStringState.font) {
        "lg" -> 1.15f
        "xl" -> 1.3f
        else -> 1f
    }
    HaberTheme(mode = prefs.theme) {
        val base = MaterialTheme.typography
        MaterialTheme(
            colorScheme = MaterialTheme.colorScheme,
            typography = base.copy(
                bodyLarge = base.bodyLarge.scaled(scale),
                bodyMedium = base.bodyMedium.scaled(scale),
                titleLarge = base.titleLarge.scaled(scale),
                titleMedium = base.titleMedium.scaled(scale),
                headlineSmall = base.headlineSmall.scaled(scale),
            ),
        ) {
            Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                content()
            }
        }
    }
}

@Composable
fun CizgiProfileScreen(
    preferences: Preferences,
    prefs: UserPrefs,
    onOpenNotifications: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    var showCenter by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(preferences) {
        runCatching { readAlertStrings(preferences) }
    }
    if (onOpenNotifications == null && showCenter) {
        CizgiNotificationCenterScreen(
            preferences = preferences,
            prefs = prefs,
            onBack = { showCenter = false },
            modifier = modifier,
        )
        return
    }
    CizgiChrome(prefs, modifier) {
        ProfileBody(
            preferences = preferences,
            prefs = prefs,
            onOpenNotifications = { onOpenNotifications?.invoke() ?: run { showCenter = true } },
        )
    }
}

@Composable
fun CizgiNotificationCenterScreen(
    preferences: Preferences,
    prefs: UserPrefs,
    notices: List<CizgiNotice> = emptyList(),
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    LaunchedEffect(preferences) {
        runCatching { readAlertStrings(preferences) }
    }
    CizgiChrome(prefs, modifier) {
        NotificationBody(
            preferences = preferences,
            prefs = prefs,
            notices = notices,
            onBack = onBack,
        )
    }
}

@Composable
private fun ProfileBody(
    preferences: Preferences,
    prefs: UserPrefs,
    onOpenNotifications: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var flash by rememberSaveable { mutableStateOf("") }
    val topics = prefs.followedTopics.filter { it.isNotBlank() }.sorted()
    val teams = prefs.followedTeams.filter { it.isNotBlank() }.sorted()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Misafir", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleMedium)
        Text("Profil", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.semantics { heading() })
        SectionTitle("Takip özeti")
        if (topics.isEmpty() && teams.isEmpty()) {
            Body("Takip edilen konu veya takım yok.")
        } else {
            topics.forEach { slug ->
                FollowRow(topicLabel(slug)) {
                    scope.launch {
                        preferences.update { store ->
                            val key = stringSetPreferencesKey("followed_topics")
                            store[key] = (store[key] ?: prefs.followedTopics) - slug
                        }
                    }
                }
            }
            teams.forEach { team ->
                FollowRow(team) {
                    scope.launch {
                        preferences.update { store ->
                            val key = stringSetPreferencesKey("followed_teams")
                            store[key] = (store[key] ?: prefs.followedTeams) - team
                        }
                    }
                }
            }
        }
        Body("Kaynak listesi bu ekrana bağlı değil.")
        SectionTitle("Bildirim tercihleri")
        Body(LocalAlerts.DEVICE_ONLY_COPY)
        Body("Son dakika: ${onOff(prefs.breakingAlerts)}")
        Body("Takip konu ve kaynak: ${onOff(prefs.followedTopicAlerts)}")
        Body("Maç başlangıcı: ${onOff(AlertStringState.matchStart)}")
        Body("Skor değişimi: ${onOff(AlertStringState.scoreChange)}")
        QuietStatus(prefs.quietStart, prefs.quietEnd)
        ChoiceButton("Bildirim merkezinde düzenle", false, onOpenNotifications)
        SectionTitle("Görünüm")
        Body("Açık tema varsayılandır. Seçim bu cihazda kalıcıdır.")
        val themeMode = when (prefs.theme) {
            "dark", "system" -> prefs.theme
            else -> "light"
        }
        ChoiceButton("Açık", themeMode == "light") {
            scope.launch {
                preferences.update { it[stringPreferencesKey("theme")] = "light" }
            }
        }
        ChoiceButton("Koyu lacivert", themeMode == "dark") {
            scope.launch {
                preferences.update { it[stringPreferencesKey("theme")] = "dark" }
            }
        }
        ChoiceButton("Sistem (açık tercih)", themeMode == "system") {
            scope.launch {
                preferences.update { it[stringPreferencesKey("theme")] = "system" }
            }
        }
        SectionTitle("Yazı boyutu")
        ChoiceButton("Standart", AlertStringState.font == "md") { selectFont(preferences, scope, "md") }
        ChoiceButton("Büyük", AlertStringState.font == "lg") { selectFont(preferences, scope, "lg") }
        ChoiceButton("Daha büyük", AlertStringState.font == "xl") { selectFont(preferences, scope, "xl") }
        Text("Önizleme", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleMedium)
        Text(
            "Gündemi bul, bağlamı gör.",
            fontSize = previewSize(AlertStringState.font),
            lineHeight = previewLine(AlertStringState.font),
        )
        SectionTitle("Gizlilik")
        Body("Hesap yok. Takip, bildirim tercihleri ve arama geçmişi bu cihazda durur.")
        Body("Konum izni istenmez.")
        PrefSwitch("İsteğe bağlı kullanım ölçümü", prefs.analyticsOptIn) { enabled ->
            scope.launch {
                preferences.update { it[booleanPreferencesKey("analytics_opt_in")] = enabled }
            }
        }
        Body("Ölçüm kapalı başlar. Açıkken de bu ekran ölçüm göndermez; seçim yalnızca bu cihaza yazılır.")
        SectionTitle("Arama geçmişi")
        if (prefs.recentSearches.isEmpty()) {
            Body("Kayıtlı arama yok.")
        } else {
            prefs.recentSearches.forEach { query -> Body(query) }
        }
        ChoiceButton("Arama geçmişini temizle", false) {
            scope.launch {
                preferences.update { it[stringPreferencesKey("recent_searches")] = "" }
                flash = if (prefs.recentSearches.isEmpty()) "Arama geçmişi zaten boş." else "Arama geçmişi temizlendi."
            }
        }
        SectionTitle("Uygulama")
        Text("Çizgi", style = MaterialTheme.typography.headlineSmall)
        Body("Gündemi bul, bağlamı gör.")
        Body("Marka: TBD")
        Body("Ticari marka ve alan adı uygunluğu yayın öncesinde doğrulanmalıdır.")
        Body("Sürüm ${BuildConfig.VERSION_NAME}")
        if (flash.isNotEmpty()) Body(flash)
    }
}

@Composable
private fun NotificationBody(
    preferences: Preferences,
    prefs: UserPrefs,
    notices: List<CizgiNotice>,
    onBack: (() -> Unit)?,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var flash by rememberSaveable { mutableStateOf("") }
    var asked by rememberSaveable { mutableStateOf(false) }
    val access = LocalAlerts.notificationAccess(context)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        asked = true
        scope.launch {
            preferences.update { it[booleanPreferencesKey("notifications")] = granted }
            flash = if (granted) {
                "Tercih bu cihazda açıldı. Anlık sunucu push gönderilmez."
            } else {
                "İzin verilmedi. Uygulama tercihi kapalı kaldı."
            }
        }
    }
    var localNotices by remember { mutableStateOf(notices) }
    var inboxFilter by rememberSaveable { mutableStateOf("all") }
    LaunchedEffect(notices) { localNotices = notices }
    val visible = localNotices.filter { it.id.isNotBlank() && it.title.isNotBlank() }
    val unread = visible.count { !it.read }
    val filtered = when (inboxFilter) {
        "unread" -> visible.filter { !it.read }
        "read" -> visible.filter { it.read }
        else -> visible
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        onBack?.let { back ->
            ChoiceButton("Profile dön", false, back)
        }
        Text("Cihaz", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleMedium)
        Text("Bildirim merkezi", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.semantics { heading() })
        Text("Okunmamış: $unread", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            ChoiceButton("Tümü", inboxFilter == "all") { inboxFilter = "all" }
            ChoiceButton("Okunmadı", inboxFilter == "unread") { inboxFilter = "unread" }
            ChoiceButton("Okundu", inboxFilter == "read") { inboxFilter = "read" }
        }
        if (visible.isEmpty()) {
            Body("Liste boş. ${LocalAlerts.DEVICE_ONLY_COPY} Teslim edilmiş bildirim olmadığı için gösterilecek kayıt yok.")
        } else if (filtered.isEmpty()) {
            Body("Bu süzgeçte bildirim yok.")
        } else {
            filtered.forEach { notice ->
                ChoiceButton(notice.title, notice.read) {
                    localNotices = localNotices.map { if (it.id == notice.id) it.copy(read = true) else it }
                }
                if (notice.body.isNotBlank()) Body(notice.body)
                Body(if (notice.read) "Okundu" else "Okunmadı · dokununca okundu")
            }
            if (unread > 0) {
                ChoiceButton("Tümünü okundu say", false) {
                    localNotices = localNotices.map { it.copy(read = true) }
                }
            }
        }
        Body(LocalAlerts.DEVICE_ONLY_COPY)
        SectionTitle("Kategoriler")
        Body("Son dakika anahtarı cihazda durur. Yenileme işçisi bu anahtarla bildirim basmaz.")
        PrefSwitch("Son dakika", prefs.breakingAlerts) { enabled ->
            scope.launch {
                preferences.update { it[booleanPreferencesKey("breaking_alerts")] = enabled }
            }
        }
        Body("Takip ettiğin konudaki yeni özet, tercih ve sistem izni açıkken, sessiz saat dışında, yaklaşık 30 dakikalık cihaz yenilemesinde yerel bildirim olabilir. Kaynak anahtarı aynı seçimle yazılır; yenileme işçisi kaynak kimliği eşlemez.")
        PrefSwitch("Takip konu ve kaynak", prefs.followedTopicAlerts) { enabled ->
            scope.launch {
                preferences.update { store ->
                    store[booleanPreferencesKey("followed_topic_alerts")] = enabled
                    store[stringPreferencesKey(KEY_SOURCE)] = if (enabled) "true" else "false"
                }
            }
        }
        Body("Maç başlangıcı ve skor değişimi bu sürümde gönderilmez. Seçim cihaz anahtarına yazılır.")
        PrefSwitch("Maç başlangıcı", AlertStringState.matchStart) { selectMatch(preferences, scope, it) }
        PrefSwitch("Skor değişimi", AlertStringState.scoreChange) { selectScore(preferences, scope, it) }
        SectionTitle("Sıklık")
        ChoiceButton("Gönderim yok", AlertStringState.frequency == FREQUENCY_OFF) {
            selectFrequency(preferences, scope, FREQUENCY_OFF)
        }
        ChoiceButton("Cihaz yenilemesi", AlertStringState.frequency == FREQUENCY_REFRESH) {
            selectFrequency(preferences, scope, FREQUENCY_REFRESH)
        }
        Body("Sıklık anahtarı yenileme işçisinin 30 dakikalık kurulumunu değiştirmez. Anlık sunucu push gönderilmez.")
        SectionTitle("Sessiz saat")
        HourStepper("Başlangıç", prefs.quietStart) { hour ->
            scope.launch {
                preferences.update { it[intPreferencesKey("quiet_start")] = hour }
            }
        }
        HourStepper("Bitiş", prefs.quietEnd) { hour ->
            scope.launch {
                preferences.update { it[intPreferencesKey("quiet_end")] = hour }
            }
        }
        QuietStatus(prefs.quietStart, prefs.quietEnd)
        Body("Sessiz saatte cihaz yenilemesi yerel bildirim basmaz.")
        SectionTitle("İzin")
        Body(permissionStatus(access))
        Body(if (prefs.notificationsEnabled) "Uygulama tercihi açık." else "Uygulama tercihi kapalı.")
        Body(LocalAlerts.DEVICE_ONLY_COPY)
        if (!prefs.notificationsEnabled) {
            ChoiceButton("Bildirimleri aç", false) {
                flash = ""
                enableNotifications(
                    context = context,
                    access = access,
                    asked = asked,
                    launch = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    markEnabled = {
                        scope.launch {
                            preferences.update { it[booleanPreferencesKey("notifications")] = true }
                            flash = "Tercih bu cihazda açıldı. Anlık sunucu push gönderilmez."
                        }
                    },
                    onFlash = { flash = it },
                )
            }
            ChoiceButton("Şimdi değil", false) {
                flash = "İzin şimdi istenmedi."
            }
        } else {
            ChoiceButton("Bildirim tercihini kapat", false) {
                scope.launch {
                    preferences.update { it[booleanPreferencesKey("notifications")] = false }
                    flash = "Uygulama tercihi kapatıldı. Sistem izni ayrıca durur."
                }
            }
        }
        if (flash.isNotEmpty()) Body(flash)
    }
}

private fun enableNotifications(
    context: android.content.Context,
    access: NotificationAccess,
    asked: Boolean,
    launch: () -> Unit,
    markEnabled: () -> Unit,
    onFlash: (String) -> Unit,
) {
    val activity = context as? Activity
    if (Build.VERSION.SDK_INT >= 33 && !access.runtimeGranted) {
        val permanentlyDenied = asked && activity?.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) == false
        if (permanentlyDenied) {
            openNotificationSettings(context)
            onFlash("Sistem ayarları açıldı. İzin bu ekrandan zorlanmaz.")
            return
        }
        launch()
        return
    }
    if (!access.systemEnabled) {
        openNotificationSettings(context)
        onFlash("Sistem bildirimleri kapalı. Ayarlar açıldı. Anlık sunucu push gönderilmez.")
        return
    }
    markEnabled()
}

private fun openNotificationSettings(context: android.content.Context) {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}

private fun permissionStatus(access: NotificationAccess): String {
    val runtime = if (Build.VERSION.SDK_INT < 33) {
        "Bu Android sürümü bildirim iznini ilk açılışta sormaz."
    } else if (access.runtimeGranted) {
        "Sistem izni açık."
    } else {
        "Sistem izni kapalı."
    }
    val system = if (access.systemEnabled) "Sistem bildirimleri açık." else "Sistem bildirimleri kapalı."
    return "$runtime $system"
}

@Composable
private fun QuietStatus(start: Int, end: Int) {
    val startHour = start.coerceIn(0, 23)
    val endHour = end.coerceIn(0, 23)
    val quiet = LocalAlerts.inQuietHoursNow(startHour, endHour)
    Body("Sessiz saat ${startHour.clock()}–${endHour.clock()}. ${if (quiet) "Şu an sessiz saat içindesin." else "Şu an sessiz saat dışındasın."} Başlangıç ve bitiş aynıysa sessiz saat yok sayılır.")
}

private fun Int.clock(): String = toString().padStart(2, '0') + ":00"

private fun onOff(enabled: Boolean): String = if (enabled) "açık" else "kapalı"

private fun previewSize(font: String) = when (font) {
    "lg" -> 21.sp
    "xl" -> 26.sp
    else -> 17.sp
}

private fun previewLine(font: String) = when (font) {
    "lg" -> 30.sp
    "xl" -> 36.sp
    else -> 26.sp
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }.padding(top = 8.dp))
}

@Composable
private fun Body(text: String) {
    Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
}

@Composable
private fun PrefSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val text = if (selected) "$label, seçili" else label
    val modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
    if (selected) {
        Button(onClick = onClick, modifier = modifier) { Text(text) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) { Text(text) }
    }
}

@Composable
private fun HourStepper(label: String, hour: Int, onChange: (Int) -> Unit) {
    val shown = hour.coerceIn(0, 23)
    Text(label, style = MaterialTheme.typography.titleMedium)
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedButton(
            onClick = { onChange((shown - 1).mod(24)) },
            modifier = Modifier.weight(1f).heightIn(min = 44.dp),
        ) { Text("Azalt") }
        Text(
            shown.clock(),
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleLarge,
        )
        OutlinedButton(
            onClick = { onChange((shown + 1).mod(24)) },
            modifier = Modifier.weight(1f).heightIn(min = 44.dp),
        ) { Text("Artır") }
    }
}

@Composable
private fun FollowRow(label: String, onUnfollow: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        OutlinedButton(onClick = onUnfollow, modifier = Modifier.heightIn(min = 44.dp)) {
            Text("Takibi bırak")
        }
    }
}
