package dev.haberver.kesif.ui.brand

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import android.provider.Settings

/**
 * Blueprint §64-67 durum rozetleri: çevrimdışı çipi ve stale-cache bandı.
 * Web'deki `cizgi-offline-chip` / `cizgi-state-banner` karşılığıdır.
 */

/** Azaltılmış hareket tercihi (web `CizgiBoot.prefersReducedMotion`). */
@Composable
fun cizgiReducedMotion(): Boolean {
    val context = LocalContext.current
    val scale = Settings.Global.getFloat(
        context.contentResolver,
        Settings.Global.ANIMATOR_DURATION_SCALE,
        1f,
    )
    return scale == 0f
}

/** Hareket kısıtlıysa anlık, değilse kısa ve sakin geçiş. */
@Composable
fun cizgiMotionSpec(): AnimationSpec<Float> =
    if (cizgiReducedMotion()) snap() else tween(durationMillis = 220)

/**
 * "Çevrimdışı" rozeti. Yalnızca `offline` true iken görünür.
 * Erişilebilirlik: canlı bölge olarak işaretli; ekran okuyucu durumu duyurur.
 */
@Composable
fun CizgiOfflineChip(offline: Boolean, modifier: Modifier = Modifier) {
    if (!offline) return
    Surface(
        modifier = modifier.semantics { liveRegion = LiveRegionMode.Polite },
        shape = RoundedCornerShape(999.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .background(MaterialTheme.colorScheme.onErrorContainer, CircleShape),
            )
            Text("Çevrimdışı", style = MaterialTheme.typography.labelMedium)
        }
    }
}

/**
 * Stale-cache / durum bandı. `text` boşsa hiçbir şey çizilmez.
 * Web `cizgi-home-banner` / `cizgi-state-banner[data-kind="stale"]` karşılığı.
 */
@Composable
fun CizgiStateBanner(text: String, modifier: Modifier = Modifier) {
    if (text.isBlank()) return
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .semantics { liveRegion = LiveRegionMode.Polite },
        shape = RoundedCornerShape(CizgiSpace.radiusControl),
        color = MaterialTheme.colorScheme.tertiaryContainer,
        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(CizgiColor.Gold, CircleShape),
            )
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}