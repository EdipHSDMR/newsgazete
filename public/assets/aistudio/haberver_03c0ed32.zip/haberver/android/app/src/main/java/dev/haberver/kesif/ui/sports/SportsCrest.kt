package dev.haberver.kesif.ui.sports

import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/** https arma. Yönlendirme yok, 400 KB üstü yok, başarısızda null. */
internal object CrestImages {
    private val http = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()
    private val cache = object : LinkedHashMap<String, ImageBitmap>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ImageBitmap>?) = size > 48
    }

    fun peek(url: String): ImageBitmap? = synchronized(cache) { cache[url] }

    fun load(url: String): ImageBitmap? {
        val safe = httpsCrest(url) ?: return null
        synchronized(cache) { cache[safe]?.let { return it } }
        val request = Request.Builder().url(safe).header("Accept", "image/*").get().build()
        return try {
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body ?: return null
                val bytes = readLimited(body) ?: return null
                val image = decode(bytes) ?: return null
                synchronized(cache) { cache[safe] = image }
                image
            }
        } catch (_: IOException) {
            null
        }
    }

    fun close() {
        http.dispatcher.executorService.shutdown()
        http.connectionPool.evictAll()
    }

    private fun readLimited(body: okhttp3.ResponseBody): ByteArray? {
        if (body.contentLength() > LIMIT) return null
        val buffer = ByteArrayOutputStream()
        body.byteStream().use { stream ->
            val chunk = ByteArray(8192)
            var total = 0
            while (true) {
                val count = stream.read(chunk)
                if (count < 0) break
                total += count
                if (total > LIMIT) return null
                buffer.write(chunk, 0, count)
            }
        }
        return buffer.toByteArray()
    }

    private fun decode(bytes: ByteArray): ImageBitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 128 || bounds.outHeight / sample > 128) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return null
        return bitmap.asImageBitmap()
    }

    private const val LIMIT = 400_000
}
