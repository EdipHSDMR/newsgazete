package dev.haberver.kesif.worker

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuietHoursTest {
    @Test
    fun overnightWindowIncludesLateAndEarlyHours() {
        assertTrue(inQuietHours(23, 22, 7))
        assertTrue(inQuietHours(6, 22, 7))
        assertFalse(inQuietHours(12, 22, 7))
    }
}
