package dev.haberver.kesif.ui.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.haberver.kesif.HaberApp
import dev.haberver.kesif.core.data.Refresh
import dev.haberver.kesif.core.data.UserPrefs
import dev.haberver.kesif.core.model.StoryCard
import dev.haberver.kesif.core.model.Topic
import dev.haberver.kesif.core.model.classify
import dev.haberver.kesif.ui.brand.CizgiColor
import dev.haberver.kesif.ui.brand.CizgiType
import dev.haberver.kesif.ui.brand.cizgiDarkColorScheme
import dev.haberver.kesif.ui.brand.cizgiTypography
import java.io.IOException
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import retrofit2.HttpException

private val Tr = Locale.forLanguageTag("tr-TR")
private val RecentKey = stringPreferencesKey("recent_searches")
private val Navy = CizgiColor.Ground
private val CardNavy = CizgiColor.Navy
private val Raised = Color(0xFF17324C)
private val Ink = CizgiColor.Ink
private val Muted = CizgiColor.Mist
private val Line = CizgiColor.Rule
private val Gold = CizgiColor.Gold

private enum class ResultTab { NEWS, TOPICS, SOURCES }

private enum class DateWindow { ALL, TODAY, WEEK, MONTH }

private data class SearchFailure(val kind: String, val message: String)

@Composable
fun DiscoverSearchScreen(onOpenStory: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as? HaberApp
    DiscoverSearchTheme {
        if (app == null) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Arama şu an açılamıyor. Yeniden deneyin.")
            }
        } else {
            DiscoverSearchContent(app, onOpenStory)
        }
    }
}

@Composable
private fun DiscoverSearchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = cizgiDarkColorScheme().copy(
            secondaryContainer = CizgiColor.Teal,
            onSecondaryContainer = CizgiColor.Navy,
        ),
        typography = cizgiTypography(),
        content = content,
    )
}

@Composable
private fun DiscoverSearchContent(app: HaberApp, onOpenStory: (String) -> Unit) {
    val prefs by app.container.preferences.flow.collectAsStateWithLifecycle(UserPrefs())
    val feed by app.container.repository.observeFeed().collectAsStateWithLifecycle(emptyList())
    val savedStories by app.container.repository.observeSaved().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(ResultTab.NEWS) }
    var dateWindow by remember { mutableStateOf(DateWindow.ALL) }
    var category by remember { mutableStateOf("") }
    var publisher by remember { mutableStateOf("") }
    var selectedTopic by remember { mutableStateOf("") }
    var topics by remember { mutableStateOf(emptyList<Topic>()) }
    var topicsError by remember { mutableStateOf<String?>(null) }
    var hits by remember { mutableStateOf(emptyList<StoryCard>()) }
    var searchError by remember { mutableStateOf<SearchFailure?>(null) }
    var feedError by remember { mutableStateOf<String?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }
    var loadingSearch by remember { mutableStateOf(false) }
    var loadingFeed by remember { mutableStateOf(false) }
    var slow by remember { mutableStateOf(false) }
    var searchNonce by remember { mutableStateOf(0) }
    var feedNonce by remember { mutableStateOf(0) }
    var topicNonce by remember { mutableStateOf(0) }
    var pinnedSaved by remember { mutableStateOf(setOf<String>()) }
    var pinnedUnsaved by remember { mutableStateOf(setOf<String>()) }
    var saveNote by remember { mutableStateOf<String?>(null) }
    val loading = loadingSearch || loadingFeed
    val persistedIds = savedStories.map { it.id }.toSet()

    LaunchedEffect(loading) {
        if (!loading) {
            slow = false
            return@LaunchedEffect
        }
        delay(2500)
        slow = true
    }
    LaunchedEffect(topicNonce) {
        app.container.repository.topics()
            .onSuccess {
                topics = it
                topicsError = if (it.isEmpty()) "Yayında konu listesi yok." else null
            }
            .onFailure { topicsError = describeFailure(it, app.container.json).message }
    }
    LaunchedEffect(selectedTopic, feedNonce) {
        loadingFeed = true
        feedError = null
        val result = app.container.repository.refresh(selectedTopic.ifBlank { null })
        loadingFeed = false
        if (result is Refresh.Failed) feedError = result.message
    }
    LaunchedEffect(submitted, selectedTopic, searchNonce) {
        val term = submitted.trim()
        if (term.isEmpty()) {
            hits = emptyList()
            searchError = null
            hint = null
            loadingSearch = false
            return@LaunchedEffect
        }
        if (term.length == 1 || term.length > 80) {
            hits = emptyList()
            searchError = null
            hint = if (term.length > 80) {
                "Arama 2 ile 80 karakter arasında olmalıdır."
            } else {
                "Aramak için en az 2 karakter yaz."
            }
            loadingSearch = false
            return@LaunchedEffect
        }
        loadingSearch = true
        searchError = null
        hint = null
        hits = emptyList()
        app.container.repository.search(term, selectedTopic.ifBlank { null })
            .onSuccess { hits = it }
            .onFailure { searchError = describeFailure(it, app.container.json) }
        loadingSearch = false
    }

    val base = mergeStories(hits, feed, submitted, selectedTopic.ifBlank { null })
    val dated = base.filter { it.inWindow(dateWindow) }
    val categories = dated
        .map { it.topicSlug to it.topicName.ifBlank { it.topicSlug } }
        .distinctBy { it.first }
        .filter { it.first.isNotBlank() }
        .sortedBy { it.second.lowercase(Tr) }
    val publishers = dated
        .map { it.sourceLabel() }
        .distinct()
        .sortedBy { it.lowercase(Tr) }
    val categoryActive = if (categories.any { it.first == category }) category else ""
    val publisherActive = if (publishers.any { it == publisher }) publisher else ""
    val shown = dated
        .filter { categoryActive.isBlank() || it.topicSlug == categoryActive }
        .filter { publisherActive.isBlank() || it.sourceLabel() == publisherActive }
    val topicMatches = topics.filter { topic ->
        val needle = query.trim().lowercase(Tr)
        needle.isEmpty() || topic.name.lowercase(Tr).contains(needle) || topic.slug.lowercase(Tr).contains(needle)
    }
    val sourceGroups = shown
        .groupBy { it.sourceLabel() }
        .entries
        .sortedWith(compareByDescending<Map.Entry<String, List<StoryCard>>> { group ->
            val needle = submitted.trim().lowercase(Tr)
            if (needle.length >= 2 && group.key.lowercase(Tr).contains(needle)) 1 else 0
        }.thenByDescending { it.value.size })

    fun savedNow(id: String): Boolean {
        if (id in pinnedUnsaved) return false
        if (id in pinnedSaved) return true
        return id in persistedIds || feed.any { it.id == id && it.saved } || savedStories.any { it.id == id }
    }

    fun selectTopic(slug: String) {
        selectedTopic = if (selectedTopic == slug) "" else slug
        category = ""
        publisher = ""
    }

    fun runSearch(raw: String, store: Boolean) {
        val term = raw.trim()
        query = term
        submitted = term
        searchNonce += 1
        if (store && term.length in 2..80) {
            scope.launch { app.container.preferences.rememberSearch(term) }
        }
    }

    fun retry() {
        if (searchError != null || submitted.trim().length in 2..80) searchNonce += 1
        feedNonce += 1
        if (topicsError != null) topicNonce += 1
    }

    fun toggleSave(card: StoryCard) {
        val want = !savedNow(card.id)
        if (want) {
            pinnedSaved = pinnedSaved + card.id
            pinnedUnsaved = pinnedUnsaved - card.id
        } else {
            pinnedUnsaved = pinnedUnsaved + card.id
            pinnedSaved = pinnedSaved - card.id
        }
        scope.launch {
            val known = feed.any { it.id == card.id } || savedStories.any { it.id == card.id }
            if (!known) {
                val refreshed = app.container.repository.refreshDetail(card.id)
                if (refreshed is Refresh.Failed) {
                    if (want) pinnedSaved = pinnedSaved - card.id else pinnedUnsaved = pinnedUnsaved - card.id
                    saveNote = refreshed.message
                    return@launch
                }
            }
            app.container.repository.setSaved(card.id, want)
            saveNote = null
        }
    }

    val showSearchBanner = searchError != null
    val showFeedBanner = feedError != null && submitted.trim().length < 2
    val emptyCopy = when {
        shown.isEmpty() && base.isNotEmpty() -> "Bu süzgeçte haber yok."
        submitted.trim().length >= 2 -> "Bu aramada haber yok."
        selectedTopic.isNotBlank() -> "Bu konuda şu an haber yok."
        else -> "Şu anda listelenecek haber yok."
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 960.dp).fillMaxWidth().fillMaxHeight(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("ARA VE KEŞFET", color = Gold, style = MaterialTheme.typography.labelLarge)
                Text(
                    "Aradığın gündemi bul.",
                    modifier = Modifier.semantics { heading() },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text("Başlık, yayıncı, konu veya özette ara.", color = Muted)
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Sorgu") },
                    placeholder = { Text("Örn. ekonomi, İstanbul, yayıncı") },
                    textStyle = MaterialTheme.typography.bodyLarge,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                        onSearch = { runSearch(query, store = true) },
                    ),
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { runSearch(query, store = true) },
                        modifier = Modifier.heightIn(min = 44.dp),
                    ) { Text(if (loadingSearch) "Aranıyor" else "Ara") }
                    if (query.isNotBlank()) {
                        OutlinedButton(
                            onClick = { runSearch("", store = false) },
                            modifier = Modifier.heightIn(min = 44.dp),
                        ) { Text("Sorguyu temizle") }
                    }
                }
            }
            hint?.let { message -> item { Text(message, color = Muted) } }
            item {
                Text("Popüler konular", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                when {
                    topicsError != null && topics.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(topicsError ?: "", color = MaterialTheme.colorScheme.error)
                        OutlinedButton(onClick = { topicNonce += 1 }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Yeniden dene") }
                    }
                    topics.isEmpty() -> Text(if (loading) "Konular yükleniyor." else "Yayında konu listesi yok.", color = Muted)
                    else -> ChipRow {
                        topics.forEach { topic ->
                            FilterChip(
                                selected = topic.slug == selectedTopic,
                                onClick = { selectTopic(topic.slug) },
                                label = { Text(topic.name) },
                                modifier = Modifier.heightIn(min = 44.dp),
                            )
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Son aramalar", style = MaterialTheme.typography.titleMedium)
                    if (prefs.recentSearches.isNotEmpty()) {
                        TextButton(
                            onClick = { scope.launch { app.container.preferences.update { it[RecentKey] = "" } } },
                            modifier = Modifier.heightIn(min = 44.dp),
                        ) { Text("Temizle") }
                    }
                }
                if (prefs.recentSearches.isEmpty()) {
                    Text("Henüz arama yok. Bir sorgu yazınca burada durur.", color = Muted)
                } else {
                    ChipRow {
                        prefs.recentSearches.forEach { term ->
                            FilterChip(
                                selected = term == submitted,
                                onClick = { runSearch(term, store = true) },
                                label = { Text(term) },
                                modifier = Modifier.heightIn(min = 44.dp),
                            )
                        }
                    }
                }
            }
            if (selectedTopic.isNotBlank()) {
                item {
                    val name = topics.find { it.slug == selectedTopic }?.name ?: selectedTopic
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Konu: $name", fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { selectTopic(selectedTopic) }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Kaldır") }
                    }
                }
            }
            item {
                ChipRow {
                    ResultTab.entries.forEach { entry ->
                        FilterChip(
                            selected = tab == entry,
                            onClick = { tab = entry },
                            label = { Text(entry.label()) },
                            modifier = Modifier.heightIn(min = 44.dp),
                        )
                    }
                }
            }
            item {
                Text("Tarih", color = Muted, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                ChipRow {
                    DateWindow.entries.forEach { entry ->
                        FilterChip(
                            selected = dateWindow == entry,
                            onClick = { dateWindow = entry },
                            label = { Text(entry.label()) },
                            modifier = Modifier.heightIn(min = 44.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Sıra: en yeni", color = Muted, fontWeight = FontWeight.SemiBold)
            }
            if (categories.isNotEmpty()) {
                item {
                    Text("Kategori", color = Muted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    ChipRow {
                        FilterChip(selected = categoryActive.isBlank(), onClick = { category = "" }, label = { Text("Tümü") }, modifier = Modifier.heightIn(min = 44.dp))
                        categories.forEach { (slug, name) ->
                            FilterChip(
                                selected = categoryActive == slug,
                                onClick = { category = slug },
                                label = { Text(name) },
                                modifier = Modifier.heightIn(min = 44.dp),
                            )
                        }
                    }
                }
            }
            if (publishers.isNotEmpty()) {
                item {
                    Text("Yayıncı", color = Muted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    ChipRow {
                        FilterChip(selected = publisherActive.isBlank(), onClick = { publisher = "" }, label = { Text("Tümü") }, modifier = Modifier.heightIn(min = 44.dp))
                        publishers.forEach { label ->
                            FilterChip(
                                selected = publisherActive == label,
                                onClick = { publisher = label },
                                label = { Text(label) },
                                modifier = Modifier.heightIn(min = 44.dp),
                            )
                        }
                    }
                }
            }
            item {
                val count = when (tab) {
                    ResultTab.NEWS -> shown.size
                    ResultTab.TOPICS -> topicMatches.size
                    ResultTab.SOURCES -> sourceGroups.size
                }
                val unit = when (tab) {
                    ResultTab.NEWS -> "sonuç"
                    ResultTab.TOPICS -> "konu"
                    ResultTab.SOURCES -> "kaynak"
                }
                Text("$count $unit", fontWeight = FontWeight.Bold)
                if (loading) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Text(if (slow) "Arama uzun sürüyor." else "Yükleniyor.", color = Muted)
                    }
                }
                if (slow) {
                    OutlinedButton(onClick = { retry() }, modifier = Modifier.padding(top = 8.dp).heightIn(min = 44.dp)) { Text("Yeniden dene") }
                }
            }
            saveNote?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error) } }
            if (showSearchBanner || showFeedBanner) {
                item {
                    val failure = searchError
                    val title = when (failure?.kind) {
                        "quota" -> "Arama sınırı"
                        "offline" -> "Bağlantı yok"
                        null -> "Akış yenilenemedi"
                        else -> "Arama tamamlanamadı"
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, color = if (failure?.kind == "quota") Gold else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        Text(failure?.message ?: feedError.orEmpty(), color = Ink)
                        OutlinedButton(onClick = { retry() }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Yeniden dene") }
                    }
                }
            }
            when (tab) {
                ResultTab.NEWS -> {
                    if (!loading && shown.isEmpty() && searchError == null && feedError == null) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Sonuç yok", style = MaterialTheme.typography.titleMedium)
                                Text(emptyCopy, color = Muted)
                                OutlinedButton(onClick = { retry() }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Yeniden dene") }
                            }
                        }
                    }
                    items(shown, key = { "news-${it.id}" }) { card ->
                        StoryResultCard(card, savedNow(card.id), { onOpenStory(card.id) }, { toggleSave(card) })
                    }
                }
                ResultTab.TOPICS -> {
                    if (topicMatches.isEmpty()) {
                        item {
                            Text(
                                when {
                                    topicsError != null -> topicsError.orEmpty()
                                    loading && topics.isEmpty() -> "Konular yükleniyor."
                                    else -> "Eşleşen konu yok."
                                },
                                color = Muted,
                            )
                        }
                    } else {
                        item {
                            ChipRow {
                                topicMatches.forEach { topic ->
                                    FilterChip(
                                        selected = topic.slug == selectedTopic,
                                        onClick = { selectTopic(topic.slug) },
                                        label = { Text(topic.name) },
                                        modifier = Modifier.heightIn(min = 44.dp),
                                    )
                                }
                            }
                        }
                    }
                    if (selectedTopic.isBlank()) {
                        item { Text("Konuya dokununca o konunun haberleri listelenir.", color = Muted) }
                    } else {
                        val topicStories = shown.filter { it.topicSlug == selectedTopic }
                        if (!loading && topicStories.isEmpty()) {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Bu konuda şu an haber yok.", color = Muted)
                                    OutlinedButton(onClick = { retry() }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Yeniden dene") }
                                }
                            }
                        }
                        items(topicStories, key = { "topic-${it.id}" }) { card ->
                            StoryResultCard(card, savedNow(card.id), { onOpenStory(card.id) }, { toggleSave(card) })
                        }
                    }
                }
                ResultTab.SOURCES -> {
                    if (!loading && sourceGroups.isEmpty() && searchError == null && feedError == null) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Eşleşen kaynak yok", style = MaterialTheme.typography.titleMedium)
                                Text("Kaynaklar, dönen haberlerdeki yayıncı adından çıkar.", color = Muted)
                                OutlinedButton(onClick = { retry() }, modifier = Modifier.heightIn(min = 44.dp)) { Text("Yeniden dene") }
                            }
                        }
                    }
                    items(sourceGroups, key = { "source-${it.key}" }) { group ->
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                            Text(group.key, style = MaterialTheme.typography.titleMedium)
                            Text("${group.value.size} haber", color = Muted)
                            group.value.forEach { card ->
                                StoryResultCard(card, savedNow(card.id), { onOpenStory(card.id) }, { toggleSave(card) })
                            }
                        }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

@Composable
private fun StoryResultCard(
    card: StoryCard,
    saved: Boolean,
    onOpen: () -> Unit,
    onSave: () -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardNavy)
            .border(1.dp, Line, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp).clickable(role = Role.Button, onClick = onOpen),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier.size(88.dp).clip(RoundedCornerShape(12.dp)).background(Raised),
                contentAlignment = Alignment.Center,
            ) {
                Text(card.initial(), color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(card.editorialTitle.orEmpty(), style = MaterialTheme.typography.titleMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                val lead = spot(card.editorialSummary)
                if (lead.isNotBlank()) {
                    Text(lead, color = Muted, style = CizgiType.Spot, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    "${card.sourceLabel()} · ${timeLabel(card.publishedMillis())}",
                    color = Muted,
                    style = CizgiType.Meta,
                )
            }
        }
        if (saved) {
            Button(onClick = onSave, modifier = Modifier.heightIn(min = 44.dp)) { Text("Kayıtlı") }
        } else {
            OutlinedButton(onClick = onSave, modifier = Modifier.heightIn(min = 44.dp)) { Text("Kaydet") }
        }
    }
}

private fun ResultTab.label() = when (this) {
    ResultTab.NEWS -> "Haberler"
    ResultTab.TOPICS -> "Konular"
    ResultTab.SOURCES -> "Kaynaklar"
}

private fun DateWindow.label() = when (this) {
    DateWindow.ALL -> "Tümü"
    DateWindow.TODAY -> "Bugün"
    DateWindow.WEEK -> "7 gün"
    DateWindow.MONTH -> "30 gün"
}

private fun StoryCard.visibleStory(): Boolean {
    val title = editorialTitle?.trim().orEmpty()
    if (title.isEmpty()) return false
    if (synthetic) return false
    val label = displayLabel.orEmpty().lowercase(Tr)
    if (label.contains("sentetik") || label.contains("kurmaca")) return false
    if (title.lowercase(Tr).startsWith("sentetik")) return false
    if (editorialSummary.orEmpty().lowercase(Tr).contains("gerçek bir haber değildir")) return false
    return true
}

private fun StoryCard.matchesQuery(query: String): Boolean {
    val needle = query.trim().lowercase(Tr)
    if (needle.isEmpty()) return true
    return listOf(editorialTitle, authorshipLabel, topicName, topicSlug, editorialSummary)
        .any { it?.lowercase(Tr)?.contains(needle) == true }
}

private fun StoryCard.publishedMillis(): Long {
    val raw = publishedAt.trim()
    if (raw.isEmpty()) return 0L
    runCatching { Instant.parse(raw).toEpochMilli() }.getOrNull()?.let { return it }
    runCatching { OffsetDateTime.parse(raw).toInstant().toEpochMilli() }.getOrNull()?.let { return it }
    runCatching { LocalDateTime.parse(raw).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }.getOrNull()?.let { return it }
    return 0L
}

private fun StoryCard.inWindow(window: DateWindow, now: Long = System.currentTimeMillis()): Boolean {
    if (window == DateWindow.ALL) return true
    val published = publishedMillis()
    if (published <= 0L) return false
    val zone = ZoneId.systemDefault()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate().atStartOfDay(zone)
    val start = when (window) {
        DateWindow.TODAY -> today
        DateWindow.WEEK -> today.minusDays(6)
        DateWindow.MONTH -> today.minusDays(29)
        DateWindow.ALL -> today
    }
    return published >= start.toInstant().toEpochMilli()
}

private fun StoryCard.sourceLabel(): String {
    val label = authorshipLabel.trim()
    if (label.isEmpty() || label.lowercase(Tr) == "editoryal özet") return "Kaynak"
    return label
}

private fun StoryCard.initial(): String {
    val source = topicName.ifBlank { editorialTitle.orEmpty() }.trim()
    return source.firstOrNull()?.uppercase(Tr) ?: "Ç"
}

private fun spot(summary: String?): String {
    val text = summary?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
    if (text.isEmpty()) return ""
    val parts = text.split(Regex("(?<=[.!?…])\\s+")).filter { it.isNotBlank() }
    val taken = if (parts.isEmpty()) text else parts.take(2).joinToString(" ")
    if (taken.length <= 240) return taken
    val cut = taken.take(240)
    val space = cut.lastIndexOf(' ')
    return (if (space > 160) cut.take(space) else cut).trimEnd() + "…"
}

private fun timeLabel(millis: Long, now: Long = System.currentTimeMillis()): String {
    if (millis <= 0L) return ""
    val delta = now - millis
    val minute = 60_000L
    val hour = 60 * minute
    val day = 24 * hour
    if (delta < 0 || delta >= 7 * day) {
        return DateTimeFormatter.ofPattern("d MMM", Tr).format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()))
    }
    return when {
        delta < minute -> "az önce"
        delta < hour -> "${delta / minute} dk"
        delta < day -> "${delta / hour} sa"
        else -> "${delta / day} gün"
    }
}

private fun mergeStories(hits: List<StoryCard>, feed: List<StoryCard>, query: String, topic: String?): List<StoryCard> {
    val map = linkedMapOf<String, StoryCard>()
    fun add(card: StoryCard) {
        if (!card.visibleStory()) return
        if (topic != null && card.topicSlug != topic) return
        val previous = map[card.id]
        if (previous == null) map[card.id] = card
        else if (card.saved && !previous.saved) map[card.id] = previous.copy(saved = true)
    }
    val term = query.trim()
    val scopedFeed = feed.filter { topic == null || it.topicSlug == topic }
    if (term.length !in 2..80) scopedFeed.forEach(::add)
    else {
        hits.forEach(::add)
        scopedFeed.filter { it.matchesQuery(term) }.forEach(::add)
    }
    return map.values.sortedByDescending { it.publishedMillis() }
}

private fun describeFailure(error: Throwable, json: Json): SearchFailure {
    if (error is IOException) return SearchFailure("offline", "Bağlantı kurulamadı. Yeniden deneyin.")
    if (error is HttpException) {
        val raw = runCatching { error.response()?.errorBody()?.string() }.getOrNull()
        var code: String? = null
        var message: String? = null
        if (!raw.isNullOrBlank()) {
            runCatching {
                val obj = json.parseToJsonElement(raw).jsonObject["error"]?.jsonObject
                code = obj?.get("code")?.jsonPrimitive?.contentOrNull
                message = obj?.get("message")?.jsonPrimitive?.contentOrNull
            }
        }
        if (error.code() == 429 || code == "rate_limited") {
            return SearchFailure("quota", message ?: "Arama sınırı doldu. Bir süre sonra yeniden deneyin.")
        }
        return SearchFailure("error", message ?: classify(code, error.code(), offline = false).message)
    }
    return SearchFailure("error", "Arama tamamlanamadı. Yeniden deneyin.")
}
