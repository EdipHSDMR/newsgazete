package dev.haberver.kesif.core.model

data class Topic(val slug: String, val name: String)

data class SourceLink(
    val id: String,
    val publisherName: String?,
    val domain: String?,
    val sourceTitle: String?,
    val publishedAt: String,
    val canonicalUrl: String?,
    val partnershipLabel: String?,
    val partnershipNote: String?,
)

data class CorrectionNote(
    val id: String,
    val reason: String,
    val editor: String,
    val createdAt: String,
)

data class StoryCard(
    val id: String,
    val editorialTitle: String?,
    val editorialSummary: String?,
    val authorshipLabel: String,
    val publishedAt: String,
    val updatedAt: String,
    val sourceCount: Int,
    val topicSlug: String,
    val topicName: String,
    val synthetic: Boolean,
    val displayLabel: String?,
    val updatedBadge: Boolean,
    val rankingReason: String,
    val editorPriority: Int,
    val sourceIds: List<String>,
    val rightsExpiresAt: String?,
    val unavailableReason: String?,
    val saved: Boolean,
    val cacheTimeEpoch: Long,
    val contextNote: String = "",
    val developing: Boolean = false,
    val uncertaintyNote: String? = null,
    val singleSourceNote: String? = null,
    val contentWarning: String? = null,
    val sources: List<SourceLink> = emptyList(),
    val corrections: List<CorrectionNote> = emptyList(),
)

enum class Phase { Loading, Content, Empty, Error, Offline, LicenseRemoved }

data class FeedUi(
    val phase: Phase,
    val items: List<StoryCard>,
    val message: String?,
    val cacheLabel: String?,
)

class ClassifiedError(
    val phase: Phase,
    val message: String,
    val retryable: Boolean,
)
