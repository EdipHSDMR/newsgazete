package dev.haberver.kesif.ui.story

import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.haberver.kesif.BuildConfig
import dev.haberver.kesif.HaberApp
import dev.haberver.kesif.core.data.Refresh
import dev.haberver.kesif.core.data.StoryRepository
import dev.haberver.kesif.core.model.StoryCard
import dev.haberver.kesif.core.model.hideExpired
import dev.haberver.kesif.openExternal
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal object ReaderPalette {
    val Navy = Color(0xFF07111C)
    val Navy2 = Color(0xFF10243A)
    val Navy3 = Color(0xFF17324C)
    val Ink = Color(0xFFF7F9FC)
    val Muted = Color(0xFFC5D4E4)
    val Line = Color(0x66C5D4E4)
    val Gold = Color(0xFFF1B548)
    val Teal = Color(0xFF10243A)
    val TealInk = Color(0xFFFFFFFF)
    val Blue = Color(0xFF9FD0F5)
}

internal object ReaderLines {
    const val SINGLE = "Tek yayın. Başka kaynakla karşılaştırılmadı."
    const val NO_UNCERTAINTY = "Kayıtlı bir belirsizlik notu yok."
    const val NO_CORRECTION = "Kayıtlı düzeltme yok."
    const val CHECKING = "Kayıt kontrol ediliyor."
    const val NO_SUMMARY = "Bu kayıtta kısa özet yok."
    const val SAME = "Kısa özetle aynı metin."
    const val FIRST = "Kısa özetteki ilk cümle."
    const val NO_IMAGE = "Görsel yok"
    const val NO_SOURCE_TITLE = "Kaynak başlığı bu kayıtta yok."
    const val NO_HTTPS = "Kaynak bağlantısı bu kayıtta güvenli açılmıyor."
    const val NO_PUBLISHER = "Yayıncı adı yok"
    const val NO_PUBLISHER_LINE = "Yayıncı adı bu kayıtta yok."
    const val SIDE = "Ortak metin ve belirsiz not yan yana. Yalnızca kayıtlı alanlar gösterilir."
    const val NOT_INTERSECTION = "Kayıtlı kısa özettir. Kaynak metinlerinin kesişimi hesaplanmaz."
    const val EACH = "Her satır kendi kaynağına aittir. Tam makale burada yok."
    const val RIGHTS = "Kaynağı göstermek yeniden kullanım izni değildir."
    const val NO_SOURCE_ROW = "Bu kayıtta kaynak satırı yok."
    const val REMOVED = "Bu içerik izin süresi veya kaldırma kararı nedeniyle gizlendi."
    const val INVALID = "Geçersiz bağlantı."
    const val NO_REASON = "Gerekçe metni yok."
    const val COUNT_NOT_SCORE = "Kaynak sayısı doğruluk puanı değildir."
    const val REPORT_NO_REWRITE = "Okur bildirimi yayındaki metni otomatik değiştirmez."
    const val NO_CONTEXT = "Kayıtlı bir kapsam notu yok. Tam makale burada yoktur."
}

internal data class KnownLine(val text: String, val same: Boolean)

internal data class ReaderSourceRow(
    val index: Int,
    val publisher: String,
    val domain: String?,
    val title: String?,
    val published: String,
    val httpsUrl: String?,
    val sourceId: String?,
)

internal data class ReaderCorrectionRow(
    val time: String,
    val rawTime: String,
    val reason: String,
    val editor: String,
)

internal data class ReaderCopy(
    val id: String,
    val title: String,
    val summary: String,
    val spotLabel: String,
    val publisherLine: String,
    val publishedLabel: String,
    val updatedLabel: String?,
    val minutes: Int?,
    val synthetic: Boolean,
    val displayLabel: String?,
    val warning: String?,
    val context: String,
    val known: String,
    val knownSame: Boolean,
    val uncertainty: List<String>,
    val multi: Boolean,
    val countLine: String,
    val sources: List<ReaderSourceRow>,
    val corrections: List<ReaderCorrectionRow>,
    val correctionsNote: String?,
    val sourcesNote: String?,
    val saved: Boolean,
    val primaryHttps: String?,
)

internal class ReaderLoad(
    val story: StoryCard?,
    val message: String?,
    val retryable: Boolean,
    val settled: Boolean,
    val refresh: () -> Unit,
)

private val sentenceBreak = Regex("""^([\s\S]+?[.!?…])\s+\S""")

internal fun readerScale(font: String): Float = when (font) {
    "lg" -> 1.22f
    "xl" -> 1.42f
    else -> 1f
}

internal fun readerLeading(font: String, simple: Boolean): Float {
    val base = when (font) {
        "lg" -> 1.7f
        "xl" -> 1.8f
        else -> 1.6f
    }
    return if (simple) max(base, 1.85f) else base
}

internal fun foldTr(value: String): String =
    value.trim().lowercase(Locale.forLanguageTag("tr-TR")).replace('ı', 'i')

internal fun spotLabel(authorship: String): String {
    val label = authorship.trim()
    if (label.isEmpty()) return "Kayıtlı imza yok"
    val folded = foldTr(label)
    if (folded == "editoryal özet" || folded.startsWith("editoryal")) return label
    if (folded.contains("otomatik") || folded.contains("yapay zeka")) return label
    return "Kaynak spotu"
}

internal fun readingMinutes(text: String): Int? {
    val words = text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    if (words == 0) return null
    return max(1, (words / 35.0).roundToInt())
}

internal fun knownText(summary: String): KnownLine {
    val text = summary.trim()
    if (text.isEmpty()) return KnownLine("", true)
    val sentence = sentenceBreak.find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    if (sentence.length < 40 || sentence.length >= text.length - 1) return KnownLine(text, true)
    return KnownLine(sentence, false)
}

internal fun formatTime(iso: String?): String {
    val raw = iso?.trim().orEmpty()
    if (raw.isEmpty()) return ""
    return runCatching {
        val instant = Instant.parse(raw)
        DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
            .withLocale(Locale.forLanguageTag("tr-TR"))
            .format(instant.atZone(ZoneId.systemDefault()))
    }.getOrDefault("")
}

internal fun httpsCanonical(raw: String?): String? {
    val value = raw?.trim().orEmpty()
    if (value.isEmpty()) return null
    val uri = Uri.parse(value)
    if (!uri.scheme.equals("https", ignoreCase = true)) return null
    if (uri.host.isNullOrBlank()) return null
    if (!uri.userInfo.isNullOrBlank()) return null
    return value
}

internal fun pairedSourceId(index: Int, total: Int, sourceIds: List<String>): String? {
    if (total != sourceIds.size || index !in sourceIds.indices) return null
    return sourceIds[index].takeIf { it.isNotBlank() }
}

internal fun uncertaintyLines(note: String?, singleNote: String?, sourceCount: Int, settled: Boolean): List<String> {
    val lines = mutableListOf<String>()
    val uncertainty = note?.trim().orEmpty()
    val single = singleNote?.trim().orEmpty()
    if (uncertainty.isNotEmpty()) lines += uncertainty
    if (single.isNotEmpty() && single !in lines) lines += single
    if (uncertainty.isEmpty() && sourceCount < 2) {
        if (!settled && single.isEmpty()) return listOf(ReaderLines.CHECKING)
        if (ReaderLines.SINGLE !in lines) lines += ReaderLines.SINGLE
    }
    if (lines.isEmpty()) {
        if (!settled) return listOf(ReaderLines.CHECKING)
        lines += ReaderLines.NO_UNCERTAINTY
    }
    return lines
}

internal fun countLine(sourceCount: Int, visible: Int, settled: Boolean): String {
    if (sourceCount < 2) return ReaderLines.SINGLE
    if (settled && visible != sourceCount) return "$sourceCount yayın. Bu ekranda $visible kaynak bağlantısı var."
    return "$sourceCount yayın."
}

internal fun scopeLead(sourceCount: Int, visible: Int, settled: Boolean): String =
    ReaderLines.COUNT_NOT_SCORE + " " + countLine(sourceCount, visible, settled)

internal fun isReadable(story: StoryCard): Boolean =
    story.unavailableReason == null && !story.editorialTitle.isNullOrBlank()

internal fun readerOrigin(apiBase: String): String {
    val trimmed = apiBase.trim().trimEnd('/')
    return if (trimmed.endsWith("/v1")) trimmed.dropLast(3) else trimmed
}

internal fun shareText(title: String, id: String, apiBase: String): String =
    title + "\n" + readerOrigin(apiBase) + "/#/haber/" + id

internal fun toReader(story: StoryCard, settled: Boolean): ReaderCopy {
    val summary = story.editorialSummary?.trim().orEmpty()
    val known = knownText(summary)
    val spot = spotLabel(story.authorshipLabel)
    val names = story.sources.mapNotNull { source ->
        source.publisherName?.trim()?.takeIf { it.isNotEmpty() }
            ?: source.domain?.trim()?.takeIf { it.isNotEmpty() }
    }.distinct()
    val publisherLine = when {
        names.isNotEmpty() -> names.joinToString(" · ")
        spot == "Kaynak spotu" && story.authorshipLabel.isNotBlank() -> story.authorshipLabel.trim()
        else -> ReaderLines.NO_PUBLISHER_LINE
    }
    val updated = story.updatedAt.takeIf { it.isNotBlank() && it != story.publishedAt }?.let(::formatTime)?.ifBlank { null }
    val rows = story.sources.mapIndexed { index, source ->
        val publisher = source.publisherName?.trim().orEmpty().ifBlank { ReaderLines.NO_PUBLISHER }
        val domain = source.domain?.trim()?.takeIf { it.isNotEmpty() && !it.equals(publisher, ignoreCase = true) }
        ReaderSourceRow(
            index = index + 1,
            publisher = publisher,
            domain = domain,
            title = source.sourceTitle?.trim()?.takeIf { it.isNotEmpty() },
            published = formatTime(source.publishedAt),
            httpsUrl = httpsCanonical(source.canonicalUrl),
            sourceId = pairedSourceId(index, story.sources.size, story.sourceIds),
        )
    }
    val urls = rows.mapNotNull { it.httpsUrl }.distinct()
    val corrections = story.corrections.sortedWith(compareBy { row ->
        runCatching { Instant.parse(row.createdAt) }.getOrNull() ?: Instant.EPOCH
    }).map { row ->
        ReaderCorrectionRow(
            time = formatTime(row.createdAt),
            rawTime = row.createdAt,
            reason = row.reason.trim().ifBlank { ReaderLines.NO_REASON },
            editor = row.editor.trim(),
        )
    }
    return ReaderCopy(
        id = story.id,
        title = story.editorialTitle?.trim().orEmpty(),
        summary = summary,
        spotLabel = spot,
        publisherLine = publisherLine,
        publishedLabel = formatTime(story.publishedAt),
        updatedLabel = updated,
        minutes = readingMinutes(summary),
        synthetic = story.synthetic,
        displayLabel = story.displayLabel?.trim()?.ifBlank { null },
        warning = story.contentWarning?.trim()?.ifBlank { null },
        context = story.contextNote.trim(),
        known = known.text,
        knownSame = known.same,
        uncertainty = uncertaintyLines(story.uncertaintyNote, story.singleSourceNote, story.sourceCount, settled),
        multi = story.sourceCount >= 2,
        countLine = countLine(story.sourceCount, story.sources.size, settled),
        sources = rows,
        corrections = corrections,
        correctionsNote = when {
            corrections.isNotEmpty() -> null
            settled -> ReaderLines.NO_CORRECTION
            else -> ReaderLines.CHECKING
        },
        sourcesNote = when {
            rows.isNotEmpty() -> null
            settled -> ReaderLines.NO_SOURCE_ROW
            else -> ReaderLines.CHECKING
        },
        saved = story.saved,
        primaryHttps = if (urls.size == 1) urls[0] else null,
    )
}

internal fun metaLine(copy: ReaderCopy): String = listOfNotNull(
    copy.publisherLine,
    copy.publishedLabel.takeIf { it.isNotBlank() },
    copy.updatedLabel?.let { "Güncellendi $it" },
    copy.minutes?.let { "$it dk okuma" },
).joinToString(" · ")

internal fun openReaderLink(activity: ComponentActivity?, url: String): String? {
    val safe = httpsCanonical(url) ?: return ReaderLines.NO_HTTPS
    if (activity == null || !openExternal(activity, safe)) return "Bağlantı açılamadı. Yeniden deneyin."
    return null
}

internal fun shareReader(activity: ComponentActivity?, title: String, id: String): String? {
    if (activity == null) return "Paylaşım bu ekranda açılamadı."
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText(title, id, BuildConfig.API_BASE_URL))
    }
    return try {
        activity.startActivity(Intent.createChooser(send, "Paylaş"))
        null
    } catch (_: Exception) {
        "Paylaşım açılamadı."
    }
}

@Composable
internal fun rememberReader(storyId: String): ReaderLoad {
    val repository = (LocalContext.current.applicationContext as HaberApp).container.repository
    val card by repository.observe(storyId).collectAsStateWithLifecycle(null)
    var generation by remember(storyId) { mutableStateOf(0) }
    var message by remember(storyId) { mutableStateOf<String?>(null) }
    var retryable by remember(storyId) { mutableStateOf(false) }
    var settled by remember(storyId) { mutableStateOf(false) }
    LaunchedEffect(storyId, generation) {
        val mine = generation
        if (!storyId.matches(StoryRepository.UUID)) {
            message = ReaderLines.INVALID
            retryable = false
            settled = true
            return@LaunchedEffect
        }
        val result = repository.refreshDetail(storyId)
        if (!isActive || mine != generation) return@LaunchedEffect
        when (result) {
            Refresh.Fresh -> {
                message = null
                retryable = false
            }
            is Refresh.Failed -> {
                message = result.message
                retryable = result.retryable
            }
        }
        settled = true
    }
    val story = card?.let { hideExpired(it, System.currentTimeMillis()) }
    return ReaderLoad(story, message, retryable, settled) { generation += 1 }
}

@Composable
fun StoryDetailScreen(
    storyId: String,
    onOpenSource: (String) -> Unit,
    onReport: (String) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    val repository = (context.applicationContext as HaberApp).container.repository
    val scope = rememberCoroutineScope()
    var font by rememberSaveable { mutableStateOf("md") }
    var simple by rememberSaveable { mutableStateOf(false) }
    var notice by remember(storyId) { mutableStateOf<String?>(null) }
    ReaderShell(
        storyId = storyId,
        font = font,
        onBack = onBack,
        notice = notice,
        onDismissNotice = { notice = null },
        onOpenHttps = { notice = openReaderLink(activity, it) },
    ) { copy ->
        ReaderArticle(
            copy = copy,
            font = font,
            onFont = { font = it },
            simple = simple,
            onSimple = { simple = !simple },
            detail = true,
            onOpenHttps = { notice = openReaderLink(activity, it) },
            onSave = { scope.launch { repository.setSaved(copy.id, !copy.saved) } },
            onShare = {
                val error = shareReader(activity, copy.title, copy.id)
                if (error != null) notice = error
            },
            onReport = { onReport(copy.id) },
            onOpenSource = onOpenSource,
        )
    }
}

@Composable
internal fun ReaderShell(
    storyId: String,
    font: String,
    onBack: () -> Unit,
    notice: String?,
    onDismissNotice: () -> Unit,
    onOpenHttps: (String) -> Unit,
    content: @Composable (ReaderCopy) -> Unit,
) {
    val load = rememberReader(storyId)
    val scale = readerScale(font)
    val story = load.story
    val scroll = rememberSaveable(storyId, saver = androidx.compose.foundation.ScrollState.Saver) {
        androidx.compose.foundation.ScrollState(0)
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(ReaderPalette.Navy)
            .verticalScroll(scroll)
            .padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ReaderButton("Geri", onBack, Modifier.fillMaxWidth(), filled = false, scale = scale)
        if (!load.message.isNullOrBlank() && story != null && isReadable(story)) {
            ReaderParagraph(load.message, scale, color = ReaderPalette.Gold)
            if (load.retryable) ReaderButton("Yeniden dene", load.refresh, Modifier.fillMaxWidth(), scale = scale)
        }
        if (!notice.isNullOrBlank()) {
            ReaderParagraph(notice, scale, color = ReaderPalette.Gold)
            ReaderButton("Kapat", onDismissNotice, Modifier.fillMaxWidth(), filled = false, scale = scale)
        }
        when {
            story != null && isReadable(story) -> content(toReader(story, load.settled))
            story != null -> RemovedStory(story, scale, onOpenHttps)
            !load.settled -> {
                CircularProgressIndicator(color = ReaderPalette.Teal)
                ReaderParagraph("Haber yükleniyor", scale, color = ReaderPalette.Blue)
            }
            else -> {
                ReaderParagraph(load.message ?: "Haber alınamadı.", scale)
                if (load.retryable) ReaderButton("Yeniden dene", load.refresh, Modifier.fillMaxWidth(), scale = scale)
                else if (load.message.isNullOrBlank()) ReaderParagraph("Yükleme tamamlanamadı. Yeniden deneyebilirsin.", scale)
            }
        }
    }
}

@Composable
private fun RemovedStory(story: StoryCard, scale: Float, onOpenHttps: (String) -> Unit) {
    if (story.synthetic) ReaderFiction(story.displayLabel, scale)
    ReaderParagraph(ReaderLines.REMOVED, scale)
    val links = story.sources.mapNotNull { source ->
        val href = httpsCanonical(source.canonicalUrl) ?: return@mapNotNull null
        val name = source.publisherName?.trim()?.takeIf { it.isNotEmpty() }
            ?: source.domain?.trim()?.takeIf { it.isNotEmpty() }
        name to href
    }
    links.forEach { (name, href) ->
        if (name != null) ReaderParagraph(name, scale, muted = true)
        ReaderButton("Kaynağında oku", { onOpenHttps(href) }, Modifier.fillMaxWidth(), scale = scale)
    }
}

@Composable
internal fun ReaderArticle(
    copy: ReaderCopy,
    font: String,
    onFont: (String) -> Unit,
    detail: Boolean,
    onOpenHttps: (String) -> Unit,
    onSave: (() -> Unit)?,
    onShare: (() -> Unit)?,
    onReport: (() -> Unit)?,
    onOpenSource: ((String) -> Unit)?,
    simple: Boolean = false,
    onSimple: (() -> Unit)? = null,
) {
    val scale = readerScale(font)
    val leading = readerLeading(font, simple && detail)
    if (copy.synthetic) ReaderFiction(copy.displayLabel, scale)
    if (!copy.warning.isNullOrBlank()) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Color(0x33FFB4AB), RoundedCornerShape(12.dp))
                .padding(12.dp),
        ) {
            ReaderParagraph("Uyarı: ${copy.warning}", scale, leading = leading)
        }
    }
    if (!copy.multi) ReaderParagraph(ReaderLines.SINGLE, scale, color = ReaderPalette.Blue, leading = leading)
    if (!detail) ReaderKicker("Kaynak karşılaştırması", scale)
    ReaderTitle(copy.title, scale)
    ReaderKicker(copy.spotLabel, scale)
    if (detail) ReaderParagraph(copy.summary.ifBlank { ReaderLines.NO_SUMMARY }, scale, leading = leading)
    ReaderParagraph(metaLine(copy), scale, muted = true, leading = leading)
    if (detail && !simple) ReaderImage(scale)
    ReaderFonts(font, onFont, scale)
    if (detail && onSimple != null) {
        ReaderButton(
            if (simple) "Sade okuma açık" else "Sade okuma",
            onSimple,
            Modifier.fillMaxWidth().semantics { this.selected = simple },
            filled = simple,
            scale = scale,
        )
    }
    if (detail && onSave != null && onShare != null && onReport != null) {
        ReaderButton(if (copy.saved) "Kaydedildi" else "Kaydet", onSave, Modifier.fillMaxWidth(), scale = scale)
        ReaderButton("Paylaş", onShare, Modifier.fillMaxWidth(), filled = false, scale = scale)
        copy.primaryHttps?.let { href ->
            ReaderButton("Kaynağında oku", { onOpenHttps(href) }, Modifier.fillMaxWidth(), scale = scale)
        }
        ReaderButton("Sorun bildir", onReport, Modifier.fillMaxWidth(), filled = false, scale = scale)
    }
    if (detail && simple) {
        ReaderCard {
            ReaderHeading("Kısa özet", scale)
            ReaderParagraph(copy.summary.ifBlank { ReaderLines.NO_SUMMARY }, scale, leading = leading)
            ReaderParagraph("Sade okuma: görsel ve kaynak listesi gizli. Tam makale yok.", scale, muted = true, leading = leading)
        }
        ReaderCard {
            ReaderHeading("Belirsiz", scale)
            copy.uncertainty.forEach { line -> ReaderParagraph(line, scale, leading = leading) }
        }
        ReaderParagraph(ReaderLines.RIGHTS, scale, muted = true, leading = leading)
        return
    }
    ReaderCard {
        ReaderHeading("Neler biliniyor / belirsiz", scale)
        if (copy.multi) {
            ReaderSideBySide(
                scale = scale,
                left = { CommonColumn(copy, scale) },
                right = { UncertaintyColumn(copy, scale) },
            )
        } else {
            ReaderHeading("Kısa özet", scale, level = 3)
            ReaderParagraph(copy.summary.ifBlank { ReaderLines.NO_SUMMARY }, scale)
            ReaderHeading("Bilinenler", scale, level = 3)
            ReaderParagraph(copy.known.ifBlank { ReaderLines.NO_SUMMARY }, scale)
            if (copy.summary.isNotBlank()) {
                ReaderParagraph(if (copy.knownSame) ReaderLines.SAME else ReaderLines.FIRST, scale, muted = true)
            }
            ReaderHeading("Belirsiz", scale, level = 3)
            copy.uncertainty.forEach { line -> ReaderParagraph(line, scale) }
        }
    }
    ReaderCard {
        ReaderHeading("Kaynaklar ve kapsam", scale)
        ReaderParagraph(ReaderLines.COUNT_NOT_SCORE + " " + copy.countLine, scale, color = ReaderPalette.Blue)
        ReaderParagraph(ReaderLines.EACH, scale, muted = true)
        if (copy.context.isNotBlank()) {
            ReaderHeading("Kapsam", scale, level = 3)
            ReaderParagraph(copy.context, scale)
        } else {
            ReaderParagraph(ReaderLines.NO_CONTEXT, scale, muted = true)
        }
        if (copy.sources.isEmpty()) {
            ReaderParagraph(copy.sourcesNote ?: ReaderLines.NO_SOURCE_ROW, scale)
        } else {
            copy.sources.forEach { row ->
                SourceRow(row, scale, onOpenHttps, onOpenSource)
            }
        }
    }
    ReaderCard {
        ReaderHeading("Güncellemeler ve düzeltmeler", scale)
        if (copy.corrections.isEmpty()) {
            ReaderParagraph(copy.correctionsNote ?: ReaderLines.NO_CORRECTION, scale)
        } else {
            copy.corrections.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier
                            .padding(top = 4.dp)
                            .width(3.dp)
                            .defaultMinSize(minHeight = 44.dp)
                            .background(ReaderPalette.Gold),
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ReaderParagraph(row.time.ifBlank { "Zaman yok" }, scale, muted = true)
                        ReaderParagraph(row.reason, scale)
                        if (row.editor.isNotBlank()) ReaderParagraph(row.editor, scale, muted = true)
                    }
                }
            }
        }
        ReaderParagraph(ReaderLines.REPORT_NO_REWRITE, scale, muted = true)
    }
    ReaderParagraph(ReaderLines.RIGHTS, scale, muted = true)
}

@Composable
private fun CommonColumn(copy: ReaderCopy, scale: Float) {
    ReaderCard {
        ReaderHeading("Ortak metin", scale)
        ReaderParagraph(ReaderLines.NOT_INTERSECTION, scale, muted = true)
        ReaderHeading("Kısa özet", scale, level = 3)
        ReaderParagraph(copy.summary.ifBlank { ReaderLines.NO_SUMMARY }, scale)
        ReaderHeading("Bilinenler", scale, level = 3)
        ReaderParagraph(copy.known.ifBlank { ReaderLines.NO_SUMMARY }, scale)
        if (copy.summary.isNotBlank()) {
            ReaderParagraph(if (copy.knownSame) ReaderLines.SAME else ReaderLines.FIRST, scale, muted = true)
        }
    }
}

@Composable
private fun UncertaintyColumn(copy: ReaderCopy, scale: Float) {
    ReaderCard {
        ReaderHeading("Belirsiz", scale, level = 3)
        copy.uncertainty.forEach { line -> ReaderParagraph(line, scale) }
    }
}

@Composable
private fun SourceRow(
    row: ReaderSourceRow,
    scale: Float,
    onOpenHttps: (String) -> Unit,
    onOpenSource: ((String) -> Unit)?,
) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ReaderKicker("Kaynak ${row.index}", scale)
        ReaderHeading(row.publisher, scale, level = 3)
        row.domain?.let { ReaderParagraph(it, scale, muted = true) }
        ReaderParagraph(row.title ?: ReaderLines.NO_SOURCE_TITLE, scale)
        if (row.published.isNotBlank()) ReaderParagraph(row.published, scale, muted = true)
        val href = row.httpsUrl
        if (href != null) ReaderButton("Kaynağında oku", { onOpenHttps(href) }, Modifier.fillMaxWidth(), scale = scale)
        else ReaderParagraph(ReaderLines.NO_HTTPS, scale, muted = true)
        val sourceId = row.sourceId
        if (sourceId != null && onOpenSource != null) {
            ReaderButton("Yayıncı sayfası", { onOpenSource(sourceId) }, Modifier.fillMaxWidth(), filled = false, scale = scale)
        }
    }
}

@Composable
internal fun ReaderSideBySide(scale: Float, left: @Composable () -> Unit, right: @Composable () -> Unit) {
    val scroll = rememberScrollState()
    ReaderParagraph(ReaderLines.SIDE, scale, muted = true)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        if (maxWidth >= 760.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) { left() }
                Column(Modifier.weight(1f)) { right() }
            }
        } else {
            Row(
                Modifier.horizontalScroll(scroll),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Column(Modifier.width(maxWidth)) { left() }
                Column(Modifier.width(maxWidth)) { right() }
            }
        }
    }
}

@Composable
internal fun ReaderTitle(text: String, scale: Float) {
    val size = 44.sp * scale
    Text(
        text = text,
        color = ReaderPalette.Ink,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.SemiBold,
        fontSize = size,
        lineHeight = size * 1.25f,
        softWrap = true,
        overflow = TextOverflow.Visible,
        modifier = Modifier.fillMaxWidth().semantics { heading() },
    )
}

@Composable
internal fun ReaderHeading(text: String, scale: Float, level: Int = 2) {
    val size = (if (level == 2) 28.sp else 22.sp) * scale
    Text(
        text = text,
        color = ReaderPalette.Ink,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.SemiBold,
        fontSize = size,
        lineHeight = size * 1.25f,
        softWrap = true,
        overflow = TextOverflow.Visible,
        modifier = Modifier.fillMaxWidth().semantics { heading() },
    )
}

@Composable
internal fun ReaderKicker(text: String, scale: Float) {
    val size = 14.sp * scale
    Text(
        text = text,
        color = ReaderPalette.Teal,
        fontWeight = FontWeight.Bold,
        fontSize = size,
        lineHeight = size * 1.35f,
        softWrap = true,
        overflow = TextOverflow.Visible,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun ReaderParagraph(
    text: String,
    scale: Float,
    muted: Boolean = false,
    color: Color? = null,
    leading: Float = 1.5f,
) {
    val size = (if (muted) 16.sp else 18.sp) * scale
    Text(
        text = text,
        color = color ?: if (muted) ReaderPalette.Muted else ReaderPalette.Ink,
        fontFamily = FontFamily.SansSerif,
        fontSize = size,
        lineHeight = size * leading,
        softWrap = true,
        overflow = TextOverflow.Visible,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun ReaderFiction(label: String?, scale: Float) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .border(2.dp, ReaderPalette.Gold, RoundedCornerShape(10.dp))
                .defaultMinSize(minHeight = 44.dp)
                .padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            val size = 16.sp * scale
            Text(
                "KURMACA",
                color = ReaderPalette.Gold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
                fontSize = size,
                lineHeight = size * 1.3f,
            )
        }
        if (!label.isNullOrBlank()) ReaderParagraph(label, scale)
    }
}

@Composable
internal fun ReaderImage(scale: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 240.dp)
            .background(ReaderPalette.Navy3, RoundedCornerShape(18.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        val size = 18.sp * scale
        Text(ReaderLines.NO_IMAGE, color = ReaderPalette.Muted, fontSize = size, lineHeight = size * 1.4f)
    }
}

@Composable
internal fun ReaderFonts(selected: String, onFont: (String) -> Unit, scale: Float) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FontChoice("md", "Orta", selected, onFont, scale)
        FontChoice("lg", "Büyük", selected, onFont, scale)
        FontChoice("xl", "En büyük", selected, onFont, scale)
    }
}

@Composable
private fun RowScope.FontChoice(
    id: String,
    label: String,
    selected: String,
    onFont: (String) -> Unit,
    scale: Float,
) {
    val on = selected == id
    ReaderButton(
        label = label,
        onClick = { onFont(id) },
        modifier = Modifier.weight(1f).semantics { this.selected = on },
        filled = on,
        scale = scale,
    )
}

@Composable
internal fun ReaderCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(ReaderPalette.Navy2, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

@Composable
internal fun ReaderButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    scale: Float = 1f,
) {
    val sized = modifier.defaultMinSize(minWidth = 44.dp, minHeight = 44.dp)
    if (filled) {
        Button(
            onClick = onClick,
            modifier = sized,
            colors = ButtonDefaults.buttonColors(containerColor = ReaderPalette.Teal, contentColor = ReaderPalette.TealInk),
        ) { ReaderButtonLabel(label, scale) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = sized,
            border = BorderStroke(1.dp, ReaderPalette.Line),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = ReaderPalette.Ink),
        ) { ReaderButtonLabel(label, scale) }
    }
}

@Composable
private fun ReaderButtonLabel(label: String, scale: Float) {
    val size = 16.sp * scale
    Text(label, fontSize = size, lineHeight = size * 1.3f, softWrap = true, overflow = TextOverflow.Visible)
}
