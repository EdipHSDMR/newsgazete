package dev.haberver.kesif.core.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey val id: String,
    val editorialTitle: String?,
    val editorialSummary: String?,
    val authorshipLabel: String,
    val publishedAt: String,
    val updatedAt: String,
    val sourceCount: Int,
    val topicSlug: String,
    val topicName: String,
    val synthetic: Boolean,
    val displayLabel: String?,
    val updatedBadge: Boolean,
    val rankingReason: String,
    val editorPriority: Int,
    val sourceIdsCsv: String,
    val rightsExpiresAt: String?,
    val unavailableReason: String?,
    val saved: Boolean,
    val cacheTimeEpoch: Long,
    val detailJson: String,
)

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories ORDER BY editorPriority DESC, publishedAt DESC")
    fun observeAll(): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE saved = 1 ORDER BY publishedAt DESC")
    fun observeSaved(): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE id = :id")
    suspend fun get(id: String): StoryEntity?

    @Query("SELECT * FROM stories WHERE id = :id")
    fun observe(id: String): Flow<StoryEntity?>

    @Upsert
    suspend fun upsert(items: List<StoryEntity>)

    @Query("UPDATE stories SET editorialTitle = NULL, editorialSummary = NULL, unavailableReason = :reason, detailJson = :detail WHERE id = :id")
    suspend fun hide(id: String, reason: String, detail: String)

    @Query("UPDATE stories SET saved = :saved WHERE id = :id")
    suspend fun setSaved(id: String, saved: Boolean)

    @Query("DELETE FROM stories")
    suspend fun clear()
}
