# Çizgi kabuk sözleşmesi

Kabuk bu dosyaları sahiplenir: `HaberRoot.kt`, `Theme.kt`, `CizgiNav.kt`. Ekran dosyası üretmez. API anahtarı yoktur; anahtar APK içine konmaz. Spor verisi sunucu `/v1/sports` uçlarındadır.

## Tema

`HaberTheme(mode)`: yalnızca `mode == "dark"` koyu şema. `light`, `system` ve diğer değerler açık şemadır (`system` açık tercih eder). Varsayılan `UserPrefs.theme` = `"light"`.

Açık palet `Theme.kt`: zemin `#F7F9FC`, yazı `#10243A`, teal `#10A6A0`. Koyu: `cizgiDarkColorScheme()` — zemin `#07111C`, yüzey `#10243A`, teal `#10A6A0`, altın `#F1B548`, metin `#F7F9FC`.

`cizgiLightColorScheme()` kabukta kullanılmaz. Yazı ölçeği `cizgiTypography()`. `Preferences` anahtarları: `theme`, `font` (`md`/`lg`/`xl`, varsayılan `md`).

## Rotalar

Alt çubukta beş sekme: `home`, `sports`, `search`, `saved`, `profile`. Ayrıca: `onboarding`, `topics`, `story/{id}`, `compare/{id}`, `source/{id}`, `report/{id}`, `about`.

Onboarding bildirim izni istemez. Bildirim izni yalnızca profil / bildirim merkezindedir.

## Bağlanan ekranlar

| Rota | Composable |
| --- | --- |
| `search` | `DiscoverSearchScreen(onOpenStory)` |
| `sports` | `SportsCenterScreen(apiBase, followedTeamIds, onFollowTeam)` |
| `saved` | `LibraryScreen(onOpenStory)` |
| `story/{id}` | `StoryDetailScreen(storyId, onOpenSource, onReport, onBack)` |
| `compare/{id}` | `CompareSourcesScreen(storyId, onBack)` |
| `profile` | `CizgiProfileScreen(preferences, prefs)` (+ kabuk Hakkında düğmesi) |

## Yedekler

| Rota | Durum |
| --- | --- |
| `home` | `ShellHomeFallback` — ayrı HomeScreen yok |

## Derleme

Bu makinede JDK 17 ve Android SDK yok (java 1.8). Gradle wrapper yok; derleme çalıştırılmadı.
