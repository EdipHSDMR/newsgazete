package dev.haberver.kesif.ui.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.haberver.kesif.HaberApp
import dev.haberver.kesif.core.data.FollowKind
import dev.haberver.kesif.core.data.LibraryFolder
import dev.haberver.kesif.core.data.LibrarySnapshot
import dev.haberver.kesif.core.data.LibraryStore
import dev.haberver.kesif.core.data.LibraryView
import dev.haberver.kesif.core.data.SavedStory
import dev.haberver.kesif.core.network.NewsApi
import dev.haberver.kesif.core.network.StoryDetailDto
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import retrofit2.HttpException
import java.io.IOException
import java.time.Instant

private val Navy = Color(0xFF07111C)
private val CardNavy = Color(0xFF10243A)
private val Ink = Color(0xFFF7F9FC)
private val Muted = Color(0xFFC5D4E4)
private val Teal = Color(0xFF10243A)
private val TealInk = Color(0xFFFFFFFF)
private val Gold = Color(0xFFF1B548)
private val Line = Color(0x29F7F9FC)

private const val HIDDEN_TEXT = "Kayıt duruyor. Metin yayında değil veya izin bittiği için gizlendi."
private const val UNAVAILABLE_TEXT = "Metin şu an alınamadı. Kayıt duruyor."
private const val CACHE_LABEL = "Çevrimdışı / önbellek"
private const val CACHE_NOTE = "Özet ve bağlantı cihaz önbelleğinden. Tam makale yok."

private val LibraryColors = darkColorScheme(
    primary = Teal,
    onPrimary = TealInk,
    secondary = Color(0xFF9FD0F5),
    onSecondary = Navy,
    background = Navy,
    onBackground = Ink,
    surface = CardNavy,
    onSurface = Ink,
    surfaceVariant = Color(0xFF17324C),
    onSurfaceVariant = Muted,
    outline = Muted,
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
)

private enum class SavedFilter { Open, Unread, Read, Archived, Folder }

private sealed interface StoryText {
    data object Loading : StoryText
    data object Hidden : StoryText
    data object Unavailable : StoryText
    data class Cached(
        val title: String,
        val summary: String,
        val link: String,
    ) : StoryText
    data class Visible(
        val title: String,
        val summary: String,
        val topic: String,
        val authorship: String,
        val sourceCount: Int,
        val synthetic: Boolean,
        val displayLabel: String,
        val link: String = "",
    ) : StoryText
}

@Composable
fun LibraryScreen(onOpenStory: (String) -> Unit) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val store = remember { LibraryStore(appContext) }
    val record by store.state.collectAsStateWithLifecycle(LibraryView())
    val scope = rememberCoroutineScope()
    val api = (appContext as? HaberApp)?.container?.api
    var notice by remember { mutableStateOf<String?>(null) }
    var topics by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var filter by remember { mutableStateOf(SavedFilter.Open) }
    var folderId by remember { mutableStateOf(LibraryStore.LATER_ID) }

    LaunchedEffect(store) {
        runCatching { store.repair() }
        val app = appContext as? HaberApp ?: return@LaunchedEffect
        val prefs = runCatching { app.container.preferences.flow.first() }.getOrNull() ?: return@LaunchedEffect
        val savedIds = runCatching { app.container.repository.observeSaved().first().map { it.id } }.getOrNull()
            ?: return@LaunchedEffect
        val before = store.flow.first()
        if (before.legacyImported) return@LaunchedEffect
        store.importLegacyOnce(prefs.followedTopics, prefs.followedTeams, prefs.mutedSources, savedIds)
        val after = store.flow.first()
        val grew = after.savedStories.size > before.savedStories.size ||
            after.followedTopics.size > before.followedTopics.size ||
            after.followedTeams.size > before.followedTeams.size ||
            after.muted.size > before.muted.size
        if (grew) notice = "Bu cihazdaki eski kayıtlar listeye alındı."
    }
    LaunchedEffect(api) {
        val client = api ?: return@LaunchedEffect
        topics = runCatching { client.topics().data.map { it.slug to it.name } }.getOrDefault(emptyList())
    }

    val type = MaterialTheme.typography.copy(
        bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 17.sp, lineHeight = 26.sp),
        bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 24.sp),
        titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
        headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp),
    )
    MaterialTheme(colorScheme = LibraryColors, typography = type) {
        LibraryBody(
            record = record,
            notice = notice,
            topics = topics,
            filter = filter,
            folderId = folderId,
            api = api,
            store = store,
            onNotice = { notice = null },
            onFilter = { next, id ->
                filter = next
                if (id != null) folderId = id
            },
            onOpenStory = onOpenStory,
            onAddFolder = { scope.launch { store.addFolder(it) } },
            onRenameFolder = { id, name -> scope.launch { store.renameFolder(id, name) } },
            onRemoveFolder = { id ->
                filter = SavedFilter.Open
                scope.launch { store.removeFolder(id) }
            },
            onRead = { id, read -> scope.launch { store.setRead(id, read) } },
            onLater = { scope.launch { store.readLater(it) } },
            onArchive = { id, archived -> scope.launch { store.setArchived(id, archived) } },
            onRemove = { scope.launch { store.removeStory(it) } },
            onMove = { id, target -> scope.launch { store.moveStory(id, target) } },
            onFollow = { kind, value -> scope.launch { store.follow(kind, value) } },
            onUnfollow = { kind, value -> scope.launch { store.unfollow(kind, value) } },
            onUnmute = { scope.launch { store.removeMuted(it) } },
            onUndo = { scope.launch { store.undo() } },
        )
    }
}

@Composable
private fun LibraryBody(
    record: LibraryView,
    notice: String?,
    topics: List<Pair<String, String>>,
    filter: SavedFilter,
    folderId: String,
    api: NewsApi?,
    store: LibraryStore,
    onNotice: () -> Unit,
    onFilter: (SavedFilter, String?) -> Unit,
    onOpenStory: (String) -> Unit,
    onAddFolder: (String) -> Unit,
    onRenameFolder: (String, String) -> Unit,
    onRemoveFolder: (String) -> Unit,
    onRead: (String, Boolean) -> Unit,
    onLater: (String) -> Unit,
    onArchive: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onMove: (String, String) -> Unit,
    onFollow: (FollowKind, String) -> Unit,
    onUnfollow: (FollowKind, String) -> Unit,
    onUnmute: (String) -> Unit,
    onUndo: () -> Unit,
) {
    val snapshot = record.snapshot
    val folderMissing = filter == SavedFilter.Folder && snapshot.folders.none { it.id == folderId }
    val effective = if (folderMissing) SavedFilter.Open else filter
    val stories = visibleStories(snapshot, effective, folderId)
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Navy),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Bu cihaz", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp)
            Text("Kayıtlılar", color = Ink, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.semantics { heading() })
            Text("Kayıtlar ve takipler bu cihazda durur.", color = Muted, style = MaterialTheme.typography.bodyLarge)
        }
        if (record.damaged) {
            item {
                SectionCard {
                    Text("Kayıt dosyası okunamadı. Dosyanın üzerine yazılmadı.", color = Ink, style = MaterialTheme.typography.bodyLarge)
                }
            }
        } else {
        notice?.let { message ->
            item {
                SectionCard {
                    Text(message, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    TapButton("Tamam", onNotice)
                }
            }
        }
        snapshot.undo?.let { undo ->
            item {
                SectionCard {
                    Text(undo.label, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    TapButton("Geri al", onUndo)
                }
            }
        }
        item {
            Text("Kayıtlı haberler", color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
            Text("${snapshot.savedStories.size} kayıt", color = Muted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterButton("Açık kayıtlar", effective == SavedFilter.Open) { onFilter(SavedFilter.Open, null) }
                FilterButton("Okunmadı", effective == SavedFilter.Unread) { onFilter(SavedFilter.Unread, null) }
                FilterButton("Okundu", effective == SavedFilter.Read) { onFilter(SavedFilter.Read, null) }
                FilterButton("Arşiv", effective == SavedFilter.Archived) { onFilter(SavedFilter.Archived, null) }
                snapshot.folders.forEach { folder ->
                    FilterButton(folder.name, effective == SavedFilter.Folder && folder.id == folderId) {
                        onFilter(SavedFilter.Folder, folder.id)
                    }
                }
            }
            AddFolderField(onAddFolder)
            if (effective == SavedFilter.Folder) {
                snapshot.folders.find { it.id == folderId }?.let { folder ->
                    FolderEditor(folder, onRenameFolder, onRemoveFolder)
                }
            }
        }
        if (snapshot.savedStories.isEmpty()) {
            item {
                SectionCard {
                    Text("Henüz kayıtlı haber yok", color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                    Text("Kaydettiğin haber bu cihazda durur.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                }
            }
        } else if (stories.isEmpty()) {
            item { Text("Bu görünümde kayıt yok.", color = Muted, style = MaterialTheme.typography.bodyLarge) }
        }
        items(stories, key = { it.id }) { story ->
            SavedStoryCard(story, snapshot.folders, api, store, onOpenStory, onRead, onLater, onArchive, onRemove, onMove)
        }
        item {
            TopicSection(topics, snapshot.followedTopics, onFollow, onUnfollow)
        }
        item {
            FollowSection("Yayıncı takibi", "Kaynak kimliği veya yayıncı etiketi", "Yayıncı", "Yayıncıyı takip et", snapshot.followedPublishers, FollowKind.Publisher, onFollow, onUnfollow)
        }
        item {
            FollowSection("Takım takibi", "Takım adı", "Takım", "Takımı takip et", snapshot.followedTeams, FollowKind.Team, onFollow, onUnfollow)
        }
        item {
            FollowSection("Lig takibi", "Lig veya turnuva", "Lig", "Ligi takip et", snapshot.followedCompetitions, FollowKind.Competition, onFollow, onUnfollow)
        }
        if (snapshot.muted.isNotEmpty()) {
            item {
                SectionCard {
                    Text("Sessize alınan yayıncılar", color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                    Text("Eski okuyucudan kopyalandı.", color = Muted)
                    snapshot.muted.forEach { label ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = Ink, modifier = Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyLarge)
                            OutlineTap("Listeden çıkar") { onUnmute(label) }
                        }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun SavedStoryCard(
    story: SavedStory,
    folders: List<LibraryFolder>,
    api: NewsApi?,
    store: LibraryStore,
    onOpenStory: (String) -> Unit,
    onRead: (String, Boolean) -> Unit,
    onLater: (String) -> Unit,
    onArchive: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onMove: (String, String) -> Unit,
) {
    var text by remember(story.id) { mutableStateOf<StoryText>(StoryText.Loading) }
    LaunchedEffect(story.id, api) {
        text = when {
            api == null -> cachedOrUnavailable(story)
            else -> {
                val loaded = loadStory(api, story.id)
                when (loaded) {
                    is StoryText.Visible -> {
                        store.cacheSnippet(story.id, loaded.title, loaded.summary, loaded.link)
                        loaded
                    }
                    is StoryText.Unavailable -> cachedOrUnavailable(story)
                    else -> loaded
                }
            }
        }
    }
    val hidden = text is StoryText.Hidden
    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy, contentColor = Ink),
        border = BorderStroke(1.dp, if (hidden) Gold else Line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (val body = text) {
                StoryText.Loading -> {
                    Text("Metin sunucudan yükleniyor.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                    Text("Kayıt kimliği: ${story.id}", color = Muted)
                }
                StoryText.Hidden -> {
                    Text(HIDDEN_TEXT, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    Text("Kayıt kimliği: ${story.id}", color = Muted)
                }
                StoryText.Unavailable -> {
                    Text(UNAVAILABLE_TEXT, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    Text("Kayıt kimliği: ${story.id}", color = Muted)
                }
                is StoryText.Cached -> {
                    Text(CACHE_LABEL, color = Color(0xFF9FD0F5), fontWeight = FontWeight.Bold)
                    Text(body.title, color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                    if (body.summary.isNotBlank()) Text(body.summary, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    Text(CACHE_NOTE, color = Muted, style = MaterialTheme.typography.bodyMedium)
                    if (body.link.isNotBlank()) {
                        TapButton("Kaynağında oku") { /* harici açılış kabukta yok; haber detayı */ onOpenStory(story.id) }
                    }
                }
                is StoryText.Visible -> {
                    if (body.synthetic) Text("KURMACA", color = Gold, fontWeight = FontWeight.Bold)
                    if (body.displayLabel.isNotBlank()) Text(body.displayLabel, color = Gold)
                    Text(body.title, color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                    if (body.summary.isNotBlank()) Text(body.summary, color = Ink, style = MaterialTheme.typography.bodyLarge)
                    val meta = listOf(body.topic, body.authorship, if (body.sourceCount > 0) "${body.sourceCount} kaynak" else "").filter { it.isNotBlank() }
                    if (meta.isNotEmpty()) Text(meta.joinToString(" · "), color = Muted)
                }
            }
            val folderName = folders.find { it.id == story.folderId }?.name ?: LibraryStore.LATER_NAME
            Text(
                listOf(if (story.read) "Okundu" else "Okunmadı", folderName, if (story.archived) "Arşiv" else "").filter { it.isNotBlank() }.joinToString(" · "),
                color = Muted,
            )
            FlowActions {
                OutlineTap(if (story.read) "Okunmadı işaretle" else "Okundu işaretle") { onRead(story.id, !story.read) }
                OutlineTap("Daha sonra oku") { onLater(story.id) }
                OutlineTap(if (story.archived) "Arşivden çıkar" else "Arşivle") { onArchive(story.id, !story.archived) }
                TapButton("Sil") { onRemove(story.id) }
                TapButton("Haberi aç") { onOpenStory(story.id) }
            }
            Text("Klasöre taşı", color = Muted)
            FlowActions {
                folders.forEach { folder ->
                    FilterButton(folder.name, folder.id == story.folderId) { onMove(story.id, folder.id) }
                }
            }
        }
    }
}

@Composable
private fun TopicSection(
    topics: List<Pair<String, String>>,
    followed: List<String>,
    onFollow: (FollowKind, String) -> Unit,
    onUnfollow: (FollowKind, String) -> Unit,
) {
    val known = topics.map { it.first.lowercase() }.toSet()
    val extra = followed.filter { it.lowercase() !in known }
    SectionCard {
        Text("Konu takibi", color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        if (topics.isEmpty()) Text("Konu listesi alınamadı. Slug yazarak takip edebilirsin.", color = Muted)
        if (topics.isNotEmpty()) {
            FlowActions {
                topics.forEach { (slug, name) ->
                    val on = followed.any { it.equals(slug, ignoreCase = true) }
                    FilterButton(name, on) {
                        if (on) onUnfollow(FollowKind.Topic, slug) else onFollow(FollowKind.Topic, slug)
                    }
                }
            }
        }
        extra.forEach { label ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, color = Ink, modifier = Modifier.weight(1f).padding(end = 8.dp))
                OutlineTap("Takibi bırak") { onUnfollow(FollowKind.Topic, label) }
            }
        }
        FollowField("Konu slug", "Konuyu takip et") { onFollow(FollowKind.Topic, it) }
    }
}

@Composable
private fun FollowSection(
    title: String,
    hint: String,
    field: String,
    action: String,
    values: List<String>,
    kind: FollowKind,
    onFollow: (FollowKind, String) -> Unit,
    onUnfollow: (FollowKind, String) -> Unit,
) {
    SectionCard {
        Text(title, color = Ink, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        Text(hint, color = Muted)
        if (values.isEmpty()) Text("Liste boş.", color = Muted)
        values.forEach { label ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, color = Ink, modifier = Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyLarge)
                OutlineTap("Takibi bırak") { onUnfollow(kind, label) }
            }
        }
        FollowField(field, action) { onFollow(kind, it) }
    }
}

@Composable
private fun AddFolderField(onAdd: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    OutlinedTextField(
        value = name,
        onValueChange = { name = it.take(160) },
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        label = { Text("Yeni klasör") },
        singleLine = true,
    )
    TapButton("Klasör ekle") {
        onAdd(name)
        name = ""
    }
}

@Composable
private fun FolderEditor(
    folder: LibraryFolder,
    onRename: (String, String) -> Unit,
    onRemove: (String) -> Unit,
) {
    var name by remember(folder.id, folder.name) { mutableStateOf(folder.name) }
    OutlinedTextField(
        value = name,
        onValueChange = { name = it.take(160) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Klasör adı") },
        singleLine = true,
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TapButton("Klasör adını kaydet") { onRename(folder.id, name) }
        if (folder.id != LibraryStore.LATER_ID) OutlineTap("Klasörü sil") { onRemove(folder.id) }
    }
}

@Composable
private fun FollowField(label: String, action: String, onAdd: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    OutlinedTextField(
        value = value,
        onValueChange = { value = it.take(160) },
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        label = { Text(label) },
        singleLine = true,
    )
    TapButton(action) {
        onAdd(value)
        value = ""
    }
}

@Composable
private fun SectionCard(content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy, contentColor = Ink),
        border = BorderStroke(1.dp, Line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = { content() })
    }
}

@Composable
private fun FlowActions(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = { content() },
    )
}

@Composable
private fun FilterButton(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier.tapTarget(),
    )
}

@Composable
private fun TapButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.tapTarget(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = TealInk),
    ) { Text(label) }
}

@Composable
private fun OutlineTap(label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.tapTarget(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        border = BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
    ) { Text(label) }
}

private fun Modifier.tapTarget(): Modifier = heightIn(min = 44.dp).defaultMinSize(minWidth = 44.dp, minHeight = 44.dp)

private fun visibleStories(snapshot: LibrarySnapshot, filter: SavedFilter, folderId: String): List<SavedStory> {
    return snapshot.savedStories.filter { story ->
        when (filter) {
            SavedFilter.Archived -> story.archived
            SavedFilter.Unread -> !story.archived && !story.read
            SavedFilter.Read -> !story.archived && story.read
            SavedFilter.Folder -> !story.archived && story.folderId == folderId
            SavedFilter.Open -> !story.archived
        }
    }
}

private val errorJson = Json { ignoreUnknownKeys = true }

private suspend fun loadStory(api: NewsApi, id: String): StoryText {
    return try {
        presentStory(api.story(id).data)
    } catch (error: HttpException) {
        if (hidesText(error.code(), errorCode(error))) StoryText.Hidden else StoryText.Unavailable
    } catch (_: IOException) {
        StoryText.Unavailable
    } catch (_: Exception) {
        StoryText.Unavailable
    }
}

private fun presentStory(story: StoryDetailDto): StoryText {
    val expiry = story.rightsExpiresAt?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() }
    if (expiry != null && expiry <= System.currentTimeMillis()) return StoryText.Hidden
    val title = story.editorialTitle?.trim().orEmpty()
    if (title.isEmpty()) return StoryText.Hidden
    val link = story.sources.mapNotNull { source ->
        val raw = source.canonicalUrl?.trim().orEmpty()
        if (raw.startsWith("https://", ignoreCase = true)) raw else null
    }.firstOrNull().orEmpty()
    return StoryText.Visible(
        title = title,
        summary = story.editorialSummary?.trim().orEmpty(),
        topic = story.topicName,
        authorship = story.authorshipLabel,
        sourceCount = story.sourceCount,
        synthetic = story.synthetic,
        displayLabel = story.displayLabel?.trim().orEmpty(),
        link = link,
    )
}

private fun cachedOrUnavailable(story: SavedStory): StoryText {
    val title = story.cacheTitle.trim()
    val summary = story.cacheSummary.trim()
    if (title.isEmpty() && summary.isEmpty()) return StoryText.Unavailable
    return StoryText.Cached(
        title = title.ifEmpty { "Kayıtlı özet" },
        summary = summary,
        link = story.cacheLink.trim(),
    )
}

private fun hidesText(status: Int, code: String?): Boolean {
    if (status == 404 || status == 410) return true
    return code == "content_unavailable" || code == "not_found" || code == "rights_blocked"
}

private fun errorCode(error: HttpException): String? {
    val raw = runCatching { error.response()?.errorBody()?.string() }.getOrNull() ?: return null
    val root = runCatching { errorJson.parseToJsonElement(raw) }.getOrNull() as? JsonObject ?: return null
    val body = root["error"] as? JsonObject ?: return null
    val code = body["code"] as? JsonPrimitive ?: return null
    return code.contentOrNull
}
