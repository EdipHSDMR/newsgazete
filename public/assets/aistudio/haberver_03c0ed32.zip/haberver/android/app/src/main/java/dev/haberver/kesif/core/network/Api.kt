package dev.haberver.kesif.core.network

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

@Serializable
data class Envelope<T>(@SerialName("request_id") val requestId: String = "", val data: T)

@Serializable
data class FeedPageDto(val items: List<StoryCardDto> = emptyList(), @SerialName("next_cursor") val nextCursor: String? = null)

@Serializable
data class SportsOverviewDto(
    val configured: Boolean = false,
    val provider: String = "API-Football",
    val notice: String = "Skor sağlayıcısı henüz yapılandırılmadı.",
    val matches: List<SportsMatchDto> = emptyList(),
    val standings: List<StandingDto> = emptyList(),
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("standings_updated_at") val standingsUpdatedAt: String? = null,
    @SerialName("matches_available") val matchesAvailable: Boolean = false,
    @SerialName("standings_available") val standingsAvailable: Boolean = false,
    val stale: Boolean = false,
    @SerialName("refresh_minutes") val refreshMinutes: Int = 20,
)

@Serializable
data class SportsMatchDto(
    val id: Long? = null,
    val competition: String = "Futbol",
    val round: String? = null,
    val kickoff: String? = null,
    val status: String = "NS",
    @SerialName("status_label") val statusLabel: String = "Başlamadı",
    val minute: Int? = null,
    val home: String = "Ev sahibi",
    val away: String = "Deplasman",
    @SerialName("home_score") val homeScore: Int? = null,
    @SerialName("away_score") val awayScore: Int? = null,
)

@Serializable
data class StandingDto(
    val rank: Int? = null,
    val team: String = "Takım",
    val played: Int? = null,
    val won: Int? = null,
    val drawn: Int? = null,
    val lost: Int? = null,
    @SerialName("goals_diff") val goalsDiff: Int? = null,
    val points: Int? = null,
    val form: String? = null,
)

@Serializable
data class StoryCardDto(
    val id: String,
    @SerialName("editorial_title") val editorialTitle: String? = null,
    @SerialName("editorial_summary") val editorialSummary: String? = null,
    @SerialName("authorship_label") val authorshipLabel: String = "Editoryal özet",
    @SerialName("published_at") val publishedAt: String = "",
    @SerialName("updated_at") val updatedAt: String = "",
    @SerialName("source_count") val sourceCount: Int = 0,
    @SerialName("topic_slug") val topicSlug: String = "",
    @SerialName("topic_name") val topicName: String = "",
    val synthetic: Boolean = false,
    @SerialName("display_label") val displayLabel: String? = null,
    @SerialName("updated_badge") val updatedBadge: Boolean = false,
    val image: String? = null,
    val placeholder: String? = null,
    @SerialName("ranking_reason") val rankingReason: String = "",
    @SerialName("editor_priority") val editorPriority: Int = 0,
    @SerialName("source_ids") val sourceIds: List<String> = emptyList(),
    @SerialName("rights_expires_at") val rightsExpiresAt: String? = null,
)

@Serializable
data class StoryDetailDto(
    val id: String,
    @SerialName("editorial_title") val editorialTitle: String? = null,
    @SerialName("editorial_summary") val editorialSummary: String? = null,
    @SerialName("authorship_label") val authorshipLabel: String = "Editoryal özet",
    @SerialName("published_at") val publishedAt: String = "",
    @SerialName("updated_at") val updatedAt: String = "",
    @SerialName("source_count") val sourceCount: Int = 0,
    @SerialName("topic_slug") val topicSlug: String = "",
    @SerialName("topic_name") val topicName: String = "",
    val synthetic: Boolean = false,
    @SerialName("display_label") val displayLabel: String? = null,
    @SerialName("updated_badge") val updatedBadge: Boolean = false,
    @SerialName("ranking_reason") val rankingReason: String = "",
    @SerialName("editor_priority") val editorPriority: Int = 0,
    @SerialName("source_ids") val sourceIds: List<String> = emptyList(),
    @SerialName("rights_expires_at") val rightsExpiresAt: String? = null,
    @SerialName("context_note") val contextNote: String = "",
    val developing: Boolean = false,
    @SerialName("uncertainty_note") val uncertaintyNote: String? = null,
    @SerialName("single_source_note") val singleSourceNote: String? = null,
    @SerialName("content_warning") val contentWarning: String? = null,
    val sources: List<SourceDto> = emptyList(),
    val corrections: List<CorrectionDto> = emptyList(),
)

@Serializable
data class SourceDto(
    val id: String,
    @SerialName("publisher_name") val publisherName: String? = null,
    val domain: String? = null,
    @SerialName("source_title") val sourceTitle: String? = null,
    @SerialName("published_at") val publishedAt: String = "",
    @SerialName("canonical_url") val canonicalUrl: String? = null,
    @SerialName("partnership_label") val partnershipLabel: String? = null,
    @SerialName("partnership_note") val partnershipNote: String? = null,
)

@Serializable
data class CorrectionDto(
    val id: String,
    val reason: String,
    val editor: String,
    @SerialName("created_at") val createdAt: String,
)

@Serializable
data class TopicDto(val slug: String, val name: String)

@Serializable
data class SourceProfileDto(
    val id: String,
    val name: String,
    val domain: String,
    @SerialName("editorial_description") val editorialDescription: String = "",
    @SerialName("partnership_label") val partnershipLabel: String? = null,
    @SerialName("partnership_note") val partnershipNote: String? = null,
    val stories: List<StoryCardDto> = emptyList(),
)

@Serializable
data class ReportBody(
    @SerialName("story_id") val storyId: String,
    val category: String,
    val description: String? = null,
)

@Serializable
data class ReportResult(val id: String, val status: String)

@Serializable
data class EventBody(
    val name: String,
    @SerialName("app_version") val appVersion: String,
    @SerialName("installation_id") val installationId: String? = null,
    @SerialName("story_id") val storyId: String? = null,
    @SerialName("topic_slug") val topicSlug: String? = null,
)

@Serializable
data class StatusDto(val status: String = "", val deleted: Int = 0)

@Serializable
data class ErrorEnvelope(val error: ErrorBody = ErrorBody())

interface NewsApi {
    @GET("sports/overview")
    suspend fun sportsOverview(): Envelope<SportsOverviewDto>

    @GET("feed")
    suspend fun feed(
        @Query("topic") topic: String?,
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): Envelope<FeedPageDto>

    @GET("stories/{id}")
    suspend fun story(@Path("id") id: String): Envelope<StoryDetailDto>

    @GET("sources/{id}")
    suspend fun source(@Path("id") id: String): Envelope<SourceProfileDto>

    @GET("topics")
    suspend fun topics(): Envelope<List<TopicDto>>

    @GET("search")
    suspend fun search(
        @Query("q") q: String,
        @Query("topic") topic: String?,
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): Envelope<FeedPageDto>

    @POST("reports")
    suspend fun report(@Body body: ReportBody): Envelope<ReportResult>

    @POST("events")
    suspend fun event(@Body body: EventBody): Envelope<StatusDto>

    @DELETE("privacy/installations/{id}")
    suspend fun deleteInstallation(@Path("id") id: String): Envelope<StatusDto>
}
