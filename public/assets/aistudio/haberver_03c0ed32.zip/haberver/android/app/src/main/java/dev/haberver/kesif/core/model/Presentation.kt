package dev.haberver.kesif.core.model

import java.time.Instant

fun hideExpired(card: StoryCard, nowEpochMillis: Long): StoryCard {
    val expiry = card.rightsExpiresAt?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() }
    val expired = card.unavailableReason != null || (expiry != null && expiry <= nowEpochMillis)
    if (!expired) return card
    return card.copy(
        editorialTitle = null,
        editorialSummary = null,
        contextNote = "",
        sources = card.sources.map { it.copy(sourceTitle = null) },
        unavailableReason = card.unavailableReason ?: "license_removed",
    )
}

fun presentFeed(
    items: List<StoryCard>,
    nowEpochMillis: Long,
    loading: Boolean,
    offline: Boolean,
    errorMessage: String?,
    followed: Set<String>,
    mutedSourceIds: Set<String>,
    onlyFollowed: Boolean,
): FeedUi {
    val visible = items.map { hideExpired(it, nowEpochMillis) }
        .filter { it.unavailableReason == null && !it.editorialTitle.isNullOrBlank() }
        .filter { card -> card.sourceIds.isEmpty() || card.sourceIds.any { it !in mutedSourceIds } }
        .filter { card -> !onlyFollowed || followed.isEmpty() || card.topicSlug in followed }
    val newest = items.maxOfOrNull { it.cacheTimeEpoch }
    val cacheLabel = newest?.let { "Son güncelleme: kayıtlı özet" }
    return when {
        visible.isNotEmpty() -> FeedUi(Phase.Content, visible, if (offline) errorMessage else null, cacheLabel)
        loading -> FeedUi(Phase.Loading, emptyList(), null, null)
        offline -> FeedUi(Phase.Offline, emptyList(), errorMessage, null)
        errorMessage != null -> FeedUi(Phase.Error, emptyList(), errorMessage, null)
        else -> FeedUi(Phase.Empty, emptyList(), null, null)
    }
}

fun classify(code: String?, http: Int, offline: Boolean): ClassifiedError {
    if (offline) return ClassifiedError(Phase.Offline, "Bağlantı yok. Kayıtlı özet varsa o gösterilir.", true)
    return when (code) {
        "content_unavailable" -> ClassifiedError(
            Phase.LicenseRemoved,
            "Bu içerik izin süresi veya kaldırma kararı nedeniyle gizlendi.",
            false,
        )
        "rate_limited" -> ClassifiedError(Phase.Error, "Çok fazla istek. Bir süre sonra yeniden deneyin.", true)
        "cursor_invalid", "validation", "query_invalid" -> ClassifiedError(Phase.Error, "İstek doğrulanamadı.", false)
        else -> if (http in 500..599) {
            ClassifiedError(Phase.Error, "Sunucu yanıt vermedi. Yeniden deneyin.", true)
        } else {
            ClassifiedError(Phase.Error, "İçerik alınamadı.", http == 0)
        }
    }
}
