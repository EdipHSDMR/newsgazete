package dev.haberver.kesif.core.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.text.Collator
import java.time.Instant
import java.util.Locale
import java.util.UUID

private val Context.cizgiLibraryStore by preferencesDataStore("cizgi_library")

private val snapshotKey = stringPreferencesKey("snapshot")

private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    explicitNulls = true
}

private const val STORY_LIMIT = 400
private const val FOLDER_LIMIT = 24
private const val FOLLOW_LIMIT = 80
private const val MOVE_LIMIT = 400
private const val ID_LIMIT = 80
private const val LABEL_LIMIT = 160
private const val SUMMARY_LIMIT = 2000
private const val EPOCH = "1970-01-01T00:00:00Z"

private val turkish = Locale.forLanguageTag("tr-TR")

@Serializable
data class SavedStory(
    val id: String,
    val savedAt: String,
    val folderId: String,
    val read: Boolean = false,
    val archived: Boolean = false,
    /** Kısa özet + bağlantı önbelleği. Tam makale yazılmaz. */
    val cacheTitle: String = "",
    val cacheSummary: String = "",
    val cacheLink: String = "",
    val cachedAt: String = "",
)

@Serializable
data class LibraryFolder(
    val id: String,
    val name: String,
)

@Serializable
data class FolderMove(
    val id: String,
    val folderId: String,
)

@Serializable
data class LibraryUndo(
    val label: String,
    val savedStories: List<SavedStory> = emptyList(),
    val folders: List<LibraryFolder> = emptyList(),
    val folderMoves: List<FolderMove> = emptyList(),
    val topics: List<String> = emptyList(),
    val publishers: List<String> = emptyList(),
    val teams: List<String> = emptyList(),
    val competitions: List<String> = emptyList(),
    val muted: List<String> = emptyList(),
)

@Serializable
data class LibrarySnapshot(
    val version: Int = 1,
    val legacyImported: Boolean = false,
    val savedStories: List<SavedStory> = emptyList(),
    val folders: List<LibraryFolder> = listOf(LibraryFolder(LibraryStore.LATER_ID, LibraryStore.LATER_NAME)),
    val followedTopics: List<String> = emptyList(),
    val followedPublishers: List<String> = emptyList(),
    val followedTeams: List<String> = emptyList(),
    val followedCompetitions: List<String> = emptyList(),
    val muted: List<String> = emptyList(),
    val undo: LibraryUndo? = null,
)

data class LibraryView(
    val snapshot: LibrarySnapshot = LibrarySnapshot(),
    val damaged: Boolean = false,
)

enum class FollowKind { Topic, Publisher, Team, Competition }

/** Cihazdaki kayıt ve takip belgesi. Tercih dosyası `cizgi_library`; `haberkesif` dosyasına yazmaz. */
class LibraryStore(private val context: Context) {
    val state: Flow<LibraryView> = context.cizgiLibraryStore.data
        .map { prefs -> parse(prefs[snapshotKey]) }
        .catch { emit(LibraryView(damaged = true)) }

    val flow: Flow<LibrarySnapshot> = state.map { it.snapshot }

    suspend fun repair() {
        context.cizgiLibraryStore.edit { prefs ->
            val raw = prefs[snapshotKey] ?: return@edit
            val view = parse(raw)
            if (view.damaged) return@edit
            val next = encode(view.snapshot)
            if (raw != next) prefs[snapshotKey] = next
        }
    }

    suspend fun saveStory(id: String, folderId: String = LATER_ID) {
        val clean = cleanId(id) ?: return
        update { current ->
            val target = if (current.folders.any { it.id == folderId }) folderId else LATER_ID
            val index = current.savedStories.indexOfFirst { it.id == clean }
            val stories = current.savedStories.toMutableList()
            if (index == -1) {
                stories.add(0, SavedStory(clean, Instant.now().toString(), target, read = false, archived = false))
            } else {
                val story = stories[index]
                stories[index] = story.copy(folderId = target, archived = false)
            }
            current.copy(savedStories = stories)
        }
    }

    /** Özet + https bağlantı önbelleği. Tam makale yazılmaz. */
    suspend fun cacheSnippet(id: String, title: String, summary: String, link: String) {
        val clean = cleanId(id) ?: return
        val cacheTitle = cleanLabel(title).orEmpty()
        val cacheSummary = cleanSummary(summary)
        val cacheLink = cleanHttps(link)
        if (cacheTitle.isEmpty() && cacheSummary.isEmpty() && cacheLink.isEmpty()) return
        update { current ->
            current.mapStory(clean) { story ->
                story.copy(
                    cacheTitle = cacheTitle.ifEmpty { story.cacheTitle },
                    cacheSummary = cacheSummary.ifEmpty { story.cacheSummary },
                    cacheLink = cacheLink.ifEmpty { story.cacheLink },
                    cachedAt = Instant.now().toString(),
                )
            }
        }
    }

    suspend fun setRead(id: String, read: Boolean) {
        update { it.mapStory(id) { story -> story.copy(read = read) } }
    }

    suspend fun setArchived(id: String, archived: Boolean) {
        update { it.mapStory(id) { story -> story.copy(archived = archived) } }
    }

    suspend fun moveStory(id: String, folderId: String) {
        update { current ->
            if (current.folders.none { it.id == folderId }) current
            else current.mapStory(id) { story -> story.copy(folderId = folderId) }
        }
    }

    suspend fun readLater(id: String) {
        update { it.mapStory(id) { story -> story.copy(folderId = LATER_ID, archived = false) } }
    }

    suspend fun removeStory(id: String) {
        val clean = cleanId(id) ?: return
        update { current ->
            val story = current.savedStories.find { it.id == clean } ?: return@update current
            current.copy(
                savedStories = current.savedStories.filterNot { it.id == clean },
                undo = LibraryUndo(label = "Kayıt silindi", savedStories = listOf(story)),
            )
        }
    }

    suspend fun addFolder(name: String) {
        val label = cleanLabel(name) ?: return
        update { current ->
            if (current.folders.any { fold(it.name) == fold(label) }) return@update current
            val used = current.folders.map { it.id }.toMutableSet()
            var id: String
            do {
                id = "fld-" + UUID.randomUUID().toString().replace("-", "").take(8)
            } while (!used.add(id))
            current.copy(folders = current.folders + LibraryFolder(id, label))
        }
    }

    suspend fun renameFolder(id: String, name: String) {
        val clean = cleanId(id) ?: return
        val label = cleanLabel(name) ?: return
        update { current ->
            if (current.folders.none { it.id == clean }) return@update current
            if (current.folders.any { it.id != clean && fold(it.name) == fold(label) }) return@update current
            current.copy(folders = current.folders.map { if (it.id == clean) it.copy(name = label) else it })
        }
    }

    suspend fun removeFolder(id: String) {
        val clean = cleanId(id) ?: return
        if (clean == LATER_ID) return
        update { current ->
            val folder = current.folders.find { it.id == clean } ?: return@update current
            val moves = current.savedStories.filter { it.folderId == clean }.map { FolderMove(it.id, it.folderId) }
            current.copy(
                folders = current.folders.filterNot { it.id == clean },
                savedStories = current.savedStories.map { if (it.folderId == clean) it.copy(folderId = LATER_ID) else it },
                undo = LibraryUndo(label = "Klasör silindi", folders = listOf(folder), folderMoves = moves),
            )
        }
    }

    suspend fun follow(kind: FollowKind, value: String) {
        val label = cleanLabel(value) ?: return
        update { current ->
            val list = current.labels(kind)
            if (list.any { fold(it) == fold(label) }) current
            else current.withLabels(kind, list + label)
        }
    }

    suspend fun unfollow(kind: FollowKind, value: String) {
        val label = cleanLabel(value) ?: return
        update { current ->
            val kept = current.labels(kind).find { fold(it) == fold(label) } ?: return@update current
            current.withLabels(kind, current.labels(kind).filterNot { fold(it) == fold(label) })
                .copy(undo = undoFor(kind, kept))
        }
    }

    suspend fun removeMuted(value: String) {
        val label = cleanLabel(value) ?: return
        update { current ->
            val kept = current.muted.find { fold(it) == fold(label) } ?: return@update current
            current.copy(
                muted = current.muted.filterNot { fold(it) == fold(label) },
                undo = LibraryUndo(label = "Sessiz yayıncı listeden çıkarıldı", muted = listOf(kept)),
            )
        }
    }

    suspend fun undo() {
        update { current ->
            val action = current.undo ?: return@update current
            val stories = current.savedStories.toMutableList()
            val seen = stories.map { it.id }.toMutableSet()
            action.savedStories.forEach { story ->
                if (seen.add(story.id)) stories.add(0, story)
            }
            val folders = current.folders.toMutableList()
            val folderIds = folders.map { it.id }.toMutableSet()
            action.folders.forEach { folder ->
                if (folderIds.add(folder.id)) folders.add(folder)
            }
            val moves = action.folderMoves.associate { it.id to it.folderId }
            val moved = stories.map { story ->
                val folderId = moves[story.id]
                if (folderId == null || story.folderId != LATER_ID) story else story.copy(folderId = folderId)
            }
            current.copy(
                savedStories = moved,
                folders = folders,
                followedTopics = current.followedTopics + action.topics,
                followedPublishers = current.followedPublishers + action.publishers,
                followedTeams = current.followedTeams + action.teams,
                followedCompetitions = current.followedCompetitions + action.competitions,
                muted = current.muted + action.muted,
                undo = null,
            )
        }
    }

    suspend fun importLegacyOnce(
        topics: Set<String>,
        teams: Set<String>,
        mutedSources: Set<String>,
        savedIds: List<String>,
    ): Boolean {
        var wrote = false
        update { current ->
            if (current.legacyImported) return@update current
            wrote = true
            val now = Instant.now().toString()
            val seen = current.savedStories.map { it.id }.toMutableSet()
            val imported = buildList {
                savedIds.forEach { raw ->
                    val id = cleanId(raw) ?: return@forEach
                    if (!seen.add(id)) return@forEach
                    add(SavedStory(id, now, LATER_ID, read = false, archived = false))
                }
            }
            current.copy(
                legacyImported = true,
                savedStories = imported + current.savedStories,
                followedTopics = current.followedTopics + sortedLabels(topics),
                followedTeams = current.followedTeams + sortedLabels(teams),
                muted = current.muted + sortedLabels(mutedSources),
            )
        }
        return wrote
    }

    private suspend fun update(block: (LibrarySnapshot) -> LibrarySnapshot) {
        context.cizgiLibraryStore.edit { prefs ->
            val view = parse(prefs[snapshotKey])
            if (view.damaged) return@edit
            prefs[snapshotKey] = encode(normalize(block(view.snapshot)))
        }
    }

    companion object {
        const val LATER_ID = "later"
        const val LATER_NAME = "Daha sonra oku"
    }
}

private fun parse(raw: String?): LibraryView {
    if (raw.isNullOrBlank()) return LibraryView(normalize(LibrarySnapshot()))
    val decoded = runCatching { json.decodeFromString(LibrarySnapshot.serializer(), raw) }.getOrNull()
        ?: return LibraryView(damaged = true)
    return LibraryView(normalize(decoded))
}

private fun encode(snapshot: LibrarySnapshot): String = json.encodeToString(LibrarySnapshot.serializer(), snapshot)

private fun normalize(input: LibrarySnapshot): LibrarySnapshot {
    val folders = cleanFolders(input.folders)
    val folderIds = folders.map { it.id }.toSet()
    return LibrarySnapshot(
        version = 1,
        legacyImported = input.legacyImported,
        savedStories = cleanStories(input.savedStories, folderIds),
        folders = folders,
        followedTopics = cleanLabels(input.followedTopics),
        followedPublishers = cleanLabels(input.followedPublishers),
        followedTeams = cleanLabels(input.followedTeams),
        followedCompetitions = cleanLabels(input.followedCompetitions),
        muted = cleanLabels(input.muted),
        undo = cleanUndo(input.undo, folderIds),
    )
}

private fun LibrarySnapshot.mapStory(id: String, block: (SavedStory) -> SavedStory): LibrarySnapshot {
    val clean = cleanId(id) ?: return this
    if (savedStories.none { it.id == clean }) return this
    return copy(savedStories = savedStories.map { if (it.id == clean) block(it) else it })
}

private fun LibrarySnapshot.labels(kind: FollowKind): List<String> = when (kind) {
    FollowKind.Topic -> followedTopics
    FollowKind.Publisher -> followedPublishers
    FollowKind.Team -> followedTeams
    FollowKind.Competition -> followedCompetitions
}

private fun LibrarySnapshot.withLabels(kind: FollowKind, labels: List<String>): LibrarySnapshot = when (kind) {
    FollowKind.Topic -> copy(followedTopics = labels)
    FollowKind.Publisher -> copy(followedPublishers = labels)
    FollowKind.Team -> copy(followedTeams = labels)
    FollowKind.Competition -> copy(followedCompetitions = labels)
}

private fun undoFor(kind: FollowKind, label: String): LibraryUndo {
    val base = LibraryUndo(label = "Takip kaldırıldı")
    return when (kind) {
        FollowKind.Topic -> base.copy(topics = listOf(label))
        FollowKind.Publisher -> base.copy(publishers = listOf(label))
        FollowKind.Team -> base.copy(teams = listOf(label))
        FollowKind.Competition -> base.copy(competitions = listOf(label))
    }
}

private fun cleanFolders(list: List<LibraryFolder>): List<LibraryFolder> {
    val out = ArrayList<LibraryFolder>()
    val seen = HashSet<String>()
    for (folder in list) {
        val id = cleanId(folder.id) ?: continue
        val name = cleanLabel(folder.name) ?: continue
        if (!seen.add(id)) continue
        out.add(LibraryFolder(id, name))
        if (out.size == FOLDER_LIMIT) break
    }
    val later = out.find { it.id == LibraryStore.LATER_ID } ?: LibraryFolder(LibraryStore.LATER_ID, LibraryStore.LATER_NAME)
    val rest = out.filter { it.id != LibraryStore.LATER_ID }
    return listOf(later) + rest.take(FOLDER_LIMIT - 1)
}

private fun cleanStories(list: List<SavedStory>, folderIds: Set<String>): List<SavedStory> {
    val out = ArrayList<SavedStory>()
    val seen = HashSet<String>()
    for (story in list) {
        val clean = cleanStory(story, folderIds) ?: continue
        if (!seen.add(clean.id)) continue
        out.add(clean)
        if (out.size == STORY_LIMIT) break
    }
    return out
}

private fun cleanStory(story: SavedStory, folderIds: Set<String>): SavedStory? {
    val id = cleanId(story.id) ?: return null
    val requested = cleanId(story.folderId)
    val folderId = if (requested != null && requested in folderIds) requested else LibraryStore.LATER_ID
    return SavedStory(
        id = id,
        savedAt = cleanSavedAt(story.savedAt),
        folderId = folderId,
        read = story.read,
        archived = story.archived,
        cacheTitle = cleanLabel(story.cacheTitle).orEmpty(),
        cacheSummary = cleanSummary(story.cacheSummary),
        cacheLink = cleanHttps(story.cacheLink),
        cachedAt = if (story.cachedAt.isNotBlank() && runCatching { Instant.parse(story.cachedAt) }.isSuccess) story.cachedAt else "",
    )
}

private fun cleanSummary(value: String): String {
    val text = value.replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001f]"), " ").trim()
    if (text.isEmpty()) return ""
    return if (text.length > SUMMARY_LIMIT) text.take(SUMMARY_LIMIT).trim() else text
}

private fun cleanHttps(raw: String): String {
    val value = raw.trim()
    if (value.isEmpty()) return ""
    val uri = android.net.Uri.parse(value)
    if (!uri.scheme.equals("https", ignoreCase = true)) return ""
    if (uri.host.isNullOrBlank()) return ""
    if (!uri.userInfo.isNullOrBlank()) return ""
    return value
}

private fun cleanUndo(raw: LibraryUndo?, folderIds: Set<String>): LibraryUndo? {
    if (raw == null) return null
    val undoFolders = ArrayList<LibraryFolder>()
    val seenFolders = HashSet<String>()
    for (folder in raw.folders) {
        val id = cleanId(folder.id) ?: continue
        val name = cleanLabel(folder.name) ?: continue
        if (id == LibraryStore.LATER_ID || !seenFolders.add(id)) continue
        undoFolders.add(LibraryFolder(id, name))
    }
    val allowed = folderIds + undoFolders.map { it.id } + LibraryStore.LATER_ID
    val stories = cleanStories(raw.savedStories, allowed)
    val moves = ArrayList<FolderMove>()
    val seenMoves = HashSet<String>()
    for (move in raw.folderMoves) {
        val id = cleanId(move.id) ?: continue
        val folderId = cleanId(move.folderId) ?: continue
        if (folderId !in allowed || !seenMoves.add(id)) continue
        moves.add(FolderMove(id, folderId))
        if (moves.size == MOVE_LIMIT) break
    }
    val topics = cleanLabels(raw.topics)
    val publishers = cleanLabels(raw.publishers)
    val teams = cleanLabels(raw.teams)
    val competitions = cleanLabels(raw.competitions)
    val muted = cleanLabels(raw.muted)
    if (stories.isEmpty() && undoFolders.isEmpty() && moves.isEmpty() && topics.isEmpty() && publishers.isEmpty() && teams.isEmpty() && competitions.isEmpty() && muted.isEmpty()) {
        return null
    }
    return LibraryUndo(
        label = cleanLabel(raw.label) ?: "Son silme geri alınabilir",
        savedStories = stories,
        folders = undoFolders,
        folderMoves = moves,
        topics = topics,
        publishers = publishers,
        teams = teams,
        competitions = competitions,
        muted = muted,
    )
}

private fun cleanLabels(list: List<String>): List<String> {
    val out = ArrayList<String>()
    val seen = HashSet<String>()
    for (item in list) {
        val label = cleanLabel(item) ?: continue
        if (!seen.add(fold(label))) continue
        out.add(label)
        if (out.size == FOLLOW_LIMIT) break
    }
    return out
}

private fun sortedLabels(values: Iterable<String>): List<String> {
    val collator = Collator.getInstance(turkish)
    return values.toList().sortedWith { left, right -> collator.compare(left, right) }
}

private fun cleanSavedAt(value: String): String {
    if (value.isBlank()) return EPOCH
    return if (runCatching { Instant.parse(value) }.isSuccess) value else EPOCH
}

private fun cleanId(value: String?): String? {
    val id = value?.trim().orEmpty()
    if (id.isEmpty() || id.length > ID_LIMIT) return null
    if (id.any { it <= '\u001f' || it.isWhitespace() }) return null
    return id
}

private fun cleanLabel(value: String?): String? {
    if (value == null) return null
    val label = value.map { ch -> if (ch <= '\u001f') ' ' else ch }.joinToString("").replace(WHITESPACE, " ").trim()
    if (label.isEmpty() || label.length > LABEL_LIMIT) return null
    return label
}

private fun fold(value: String): String = value.lowercase(turkish)

private val WHITESPACE = Regex("\\s+")
