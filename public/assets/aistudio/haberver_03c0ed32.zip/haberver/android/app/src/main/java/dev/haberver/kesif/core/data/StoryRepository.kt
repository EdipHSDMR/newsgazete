package dev.haberver.kesif.core.data

import dev.haberver.kesif.core.model.CorrectionNote
import dev.haberver.kesif.core.model.SourceLink
import dev.haberver.kesif.core.model.StoryCard
import dev.haberver.kesif.core.model.Topic
import dev.haberver.kesif.core.model.classify
import dev.haberver.kesif.core.network.ErrorEnvelope
import dev.haberver.kesif.core.network.NewsApi
import dev.haberver.kesif.core.network.StoryCardDto
import dev.haberver.kesif.core.network.StoryDetailDto
import dev.haberver.kesif.core.network.SportsOverviewDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.io.IOException

class StoryRepository(
    private val api: NewsApi,
    private val dao: StoryDao,
    private val json: Json,
    private val now: () -> Long = System::currentTimeMillis,
) {
    fun observeFeed(): Flow<List<StoryCard>> = dao.observeAll().map { rows -> rows.map { it.toCard() } }

    fun observeSaved(): Flow<List<StoryCard>> = dao.observeSaved().map { rows -> rows.map { it.toCard() } }

    fun observe(id: String): Flow<StoryCard?> = dao.observe(id).map { it?.toCard() }

    suspend fun refresh(topic: String?): Refresh {
        return try {
            val page = api.feed(topic = topic, cursor = null, limit = 30)
            val existing = page.data.items.associate { dto ->
                dto.id to (dao.get(dto.id)?.saved ?: false)
            }
            val epoch = now()
            dao.upsert(page.data.items.map { it.toEntity(epoch, existing[it.id] ?: false, json) })
            Refresh.Fresh
        } catch (error: Exception) {
            val classified = classifyFailure(error, json)
            Refresh.Failed(classified.message, classified.phase.name, classified.retryable)
        }
    }

    suspend fun refreshDetail(id: String): Refresh {
        if (!id.matches(UUID)) return Refresh.Failed("Hikaye bulunamadı.", "Error", false)
        return try {
            val detail = api.story(id).data
            val saved = dao.get(id)?.saved ?: false
            dao.upsert(listOf(detail.toEntity(now(), saved, json)))
            Refresh.Fresh
        } catch (error: Exception) {
            val classified = classifyFailure(error, json)
            if (classified.phase.name == "LicenseRemoved") {
                val current = dao.get(id)
                if (current != null) {
                    val detail = runCatching { json.decodeFromString(StoryDetailDto.serializer(), current.detailJson) }.getOrNull()
                    val cleared = detail?.copy(editorialTitle = null, editorialSummary = null, contextNote = "")
                    val encoded = if (cleared != null) json.encodeToString(StoryDetailDto.serializer(), cleared) else current.detailJson
                    dao.hide(id, "license_removed", encoded)
                }
            }
            Refresh.Failed(classified.message, classified.phase.name, classified.retryable)
        }
    }

    suspend fun search(query: String, topic: String?): Result<List<StoryCard>> = runCatching {
        api.search(q = query, topic = topic, cursor = null, limit = 30).data.items.map { it.toCard(now()) }
    }

    suspend fun topics(): Result<List<Topic>> = runCatching {
        api.topics().data.map { Topic(it.slug, it.name) }
    }

    suspend fun sourceProfile(id: String) = runCatching { api.source(id).data }

    suspend fun sportsOverview(): Result<SportsOverviewDto> = runCatching { api.sportsOverview().data }

    suspend fun report(storyId: String, category: String, description: String?) = runCatching {
        api.report(dev.haberver.kesif.core.network.ReportBody(storyId, category, description)).data.id
    }

    suspend fun setSaved(id: String, saved: Boolean) {
        dao.setSaved(id, saved)
    }

    suspend fun clearCache() {
        dao.clear()
    }

    private fun StoryEntity.toCard(): StoryCard {
        val detail = runCatching { json.decodeFromString(StoryDetailDto.serializer(), detailJson) }.getOrNull()
        return StoryCard(
            id = id,
            editorialTitle = editorialTitle,
            editorialSummary = editorialSummary,
            authorshipLabel = authorshipLabel,
            publishedAt = publishedAt,
            updatedAt = updatedAt,
            sourceCount = sourceCount,
            topicSlug = topicSlug,
            topicName = topicName,
            synthetic = synthetic,
            displayLabel = displayLabel,
            updatedBadge = updatedBadge,
            rankingReason = rankingReason,
            editorPriority = editorPriority,
            sourceIds = sourceIdsCsv.split(",").filter { it.isNotBlank() },
            rightsExpiresAt = rightsExpiresAt,
            unavailableReason = unavailableReason,
            saved = saved,
            cacheTimeEpoch = cacheTimeEpoch,
            contextNote = detail?.contextNote.orEmpty(),
            developing = detail?.developing ?: false,
            uncertaintyNote = detail?.uncertaintyNote,
            singleSourceNote = detail?.singleSourceNote,
            contentWarning = detail?.contentWarning,
            sources = detail?.sources?.map {
                SourceLink(it.id, it.publisherName, it.domain, it.sourceTitle, it.publishedAt, it.canonicalUrl, it.partnershipLabel, it.partnershipNote)
            } ?: emptyList(),
            corrections = detail?.corrections?.map { CorrectionNote(it.id, it.reason, it.editor, it.createdAt) } ?: emptyList(),
        )
    }

    companion object {
        val UUID = Regex("^[0-9a-fA-F-]{32,36}$")
    }
}

sealed interface Refresh {
    data object Fresh : Refresh
    data class Failed(val message: String, val phase: String, val retryable: Boolean) : Refresh
}

private fun classifyFailure(error: Exception, json: Json) = when (error) {
    is IOException -> classify(null, 0, offline = true)
    is HttpException -> {
        val body = error.response()?.errorBody()?.string()
        val parsed = body?.let { runCatching { json.decodeFromString(ErrorEnvelope.serializer(), it) }.getOrNull() }
        classify(parsed?.error?.code, error.code(), offline = false)
    }
    else -> classify(null, 0, offline = false)
}

private fun StoryCardDto.toEntity(epoch: Long, saved: Boolean, json: Json): StoryEntity {
    val detail = StoryDetailDto(
        id = id,
        editorialTitle = editorialTitle,
        editorialSummary = editorialSummary,
        authorshipLabel = authorshipLabel,
        publishedAt = publishedAt,
        updatedAt = updatedAt,
        sourceCount = sourceCount,
        topicSlug = topicSlug,
        topicName = topicName,
        synthetic = synthetic,
        displayLabel = displayLabel,
        updatedBadge = updatedBadge,
        rankingReason = rankingReason,
        editorPriority = editorPriority,
        sourceIds = sourceIds,
        rightsExpiresAt = rightsExpiresAt,
    )
    return detail.toEntity(epoch, saved, json)
}

private fun StoryDetailDto.toEntity(epoch: Long, saved: Boolean, json: Json) = StoryEntity(
    id = id,
    editorialTitle = editorialTitle,
    editorialSummary = editorialSummary,
    authorshipLabel = authorshipLabel,
    publishedAt = publishedAt,
    updatedAt = updatedAt,
    sourceCount = sourceCount,
    topicSlug = topicSlug,
    topicName = topicName,
    synthetic = synthetic,
    displayLabel = displayLabel,
    updatedBadge = updatedBadge,
    rankingReason = rankingReason,
    editorPriority = editorPriority,
    sourceIdsCsv = sourceIds.joinToString(","),
    rightsExpiresAt = rightsExpiresAt,
    unavailableReason = null,
    saved = saved,
    cacheTimeEpoch = epoch,
    detailJson = json.encodeToString(StoryDetailDto.serializer(), this),
)

private fun StoryCardDto.toCard(epoch: Long) = StoryCard(
    id = id,
    editorialTitle = editorialTitle,
    editorialSummary = editorialSummary,
    authorshipLabel = authorshipLabel,
    publishedAt = publishedAt,
    updatedAt = updatedAt,
    sourceCount = sourceCount,
    topicSlug = topicSlug,
    topicName = topicName,
    synthetic = synthetic,
    displayLabel = displayLabel,
    updatedBadge = updatedBadge,
    rankingReason = rankingReason,
    editorPriority = editorPriority,
    sourceIds = sourceIds,
    rightsExpiresAt = rightsExpiresAt,
    unavailableReason = null,
    saved = false,
    cacheTimeEpoch = epoch,
)
