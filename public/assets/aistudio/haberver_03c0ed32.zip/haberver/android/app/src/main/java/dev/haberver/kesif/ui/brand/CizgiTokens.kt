package dev.haberver.kesif.ui.brand

import androidx.compose.foundation.layout.sizeIn
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Kapalı palet. Açık (light) varsayılandır. Lacivert + beyaz; turkuaz yok. */
object CizgiColor {
    val Navy = Color(0xFF10243A)
    val Ground = Color(0xFF07111C)
    val Ink = Color(0xFFF7F9FC)
    val White = Color(0xFFFFFFFF)
    val Paper = Color(0xFFF7F9FC)
    val Surface = Color(0xFFEEF1F5)
    val Surface2 = Color(0xFFE5E9EF)
    val Blue = Color(0xFF1769AA)
    val Link = Color(0xFF9FD0F5)
    val Gold = Color(0xFFF1B548)
    val Mist = Color(0xFFEAF2F9)
    val Muted = Color(0xFF3E5670)
    /** Kenar: nötr gri. */
    val Rule = Color(0xFFC5CCD6)
    val RuleDark = Color(0xFF728190)
    val ErrorDark = Color(0xFFFFB4AB)
    val OnErrorDark = Color(0xFF690005)
    val ErrorLight = Color(0xFF8C2F2F)
    val OnErrorLight = Color(0xFFFFFFFF)

    /** Eski ad uyumu — teal artık lacivert. */
    @Deprecated("Use Navy", ReplaceWith("Navy"))
    val Teal = Navy
}

object CizgiSpace {
    val s1 = 4.dp
    val s2 = 8.dp
    val s3 = 12.dp
    val s4 = 16.dp
    val s5 = 24.dp
    val s6 = 32.dp
    val s7 = 48.dp
    val card = 16.dp
    val touch = 44.dp
    val radiusCard = 10.dp
    val radiusControl = 8.dp
}

fun Modifier.cizgiHedef(): Modifier = sizeIn(minWidth = CizgiSpace.touch, minHeight = CizgiSpace.touch)

/**
 * Ölçek sp cinsindendir; sistem yazı büyütünce büyür.
 * Gövde 16/25, meta 13/18. 12sp altı yok.
 */
object CizgiType {
    private val sans = FontFamily.SansSerif

    val Manset = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = 0.sp,
    )
    val Ekran = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp,
    )
    val Kart = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 21.sp,
        letterSpacing = 0.sp,
    )
    val Govde = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 25.sp,
        letterSpacing = 0.sp,
    )
    val Spot = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.sp,
    )
    val Meta = TextStyle(
        fontFamily = sans,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.sp,
    )
    val Ikincil = Meta
}

/** İşaret geometrisi. logo.svg ve ic_cizgi_mark.xml ile aynı path. */
object CizgiMarkGeometry {
    const val VIEWPORT = 24f
    const val STROKE = 2.5f
    const val LINE = "M2.5,12H10.5"
    const val DIRECTION = "M16,7.75L21.5,12L16,16.25"
}

fun cizgiLinkColor(dark: Boolean): Color = if (dark) CizgiColor.Link else CizgiColor.Blue

fun cizgiLineColor(dark: Boolean): Color = if (dark) CizgiColor.Ink else CizgiColor.Navy

/** Açıkta lacivert, koyuda altın (son dakika aksanı). */
fun cizgiDirectionColor(dark: Boolean): Color = if (dark) CizgiColor.Gold else CizgiColor.Navy

fun cizgiDarkColorScheme(): ColorScheme = darkColorScheme(
    primary = CizgiColor.White,
    onPrimary = CizgiColor.Navy,
    primaryContainer = CizgiColor.Navy,
    onPrimaryContainer = CizgiColor.Ink,
    secondary = CizgiColor.Link,
    onSecondary = CizgiColor.Navy,
    secondaryContainer = CizgiColor.Ground,
    onSecondaryContainer = CizgiColor.Link,
    tertiary = CizgiColor.Gold,
    onTertiary = CizgiColor.Navy,
    tertiaryContainer = CizgiColor.Navy,
    onTertiaryContainer = CizgiColor.Gold,
    error = CizgiColor.ErrorDark,
    onError = CizgiColor.OnErrorDark,
    errorContainer = CizgiColor.OnErrorDark,
    onErrorContainer = CizgiColor.ErrorDark,
    background = CizgiColor.Ground,
    onBackground = CizgiColor.Ink,
    surface = CizgiColor.Navy,
    onSurface = CizgiColor.Ink,
    surfaceVariant = CizgiColor.Ground,
    onSurfaceVariant = CizgiColor.Mist,
    surfaceTint = CizgiColor.White,
    inverseSurface = CizgiColor.Mist,
    inverseOnSurface = CizgiColor.Navy,
    inversePrimary = CizgiColor.Navy,
    outline = CizgiColor.RuleDark,
    outlineVariant = CizgiColor.RuleDark,
    scrim = CizgiColor.Ground,
    surfaceBright = CizgiColor.Navy,
    surfaceDim = CizgiColor.Ground,
    surfaceContainerLowest = CizgiColor.Ground,
    surfaceContainerLow = CizgiColor.Ground,
    surfaceContainer = CizgiColor.Navy,
    surfaceContainerHigh = CizgiColor.Navy,
    surfaceContainerHighest = CizgiColor.Navy,
)

fun cizgiLightColorScheme(): ColorScheme = lightColorScheme(
    primary = CizgiColor.Navy,
    onPrimary = CizgiColor.White,
    primaryContainer = CizgiColor.Surface,
    onPrimaryContainer = CizgiColor.Navy,
    secondary = CizgiColor.Blue,
    onSecondary = CizgiColor.White,
    secondaryContainer = CizgiColor.Surface,
    onSecondaryContainer = CizgiColor.Navy,
    tertiary = CizgiColor.Gold,
    onTertiary = CizgiColor.Navy,
    tertiaryContainer = CizgiColor.Surface,
    onTertiaryContainer = CizgiColor.Navy,
    error = CizgiColor.ErrorLight,
    onError = CizgiColor.OnErrorLight,
    errorContainer = CizgiColor.Surface,
    onErrorContainer = CizgiColor.ErrorLight,
    background = CizgiColor.Paper,
    onBackground = CizgiColor.Navy,
    surface = CizgiColor.White,
    onSurface = CizgiColor.Navy,
    surfaceVariant = CizgiColor.Surface,
    onSurfaceVariant = CizgiColor.Muted,
    surfaceTint = CizgiColor.Navy,
    inverseSurface = CizgiColor.Navy,
    inverseOnSurface = CizgiColor.Ink,
    inversePrimary = CizgiColor.White,
    outline = CizgiColor.Rule,
    outlineVariant = CizgiColor.Rule,
    scrim = CizgiColor.Navy,
    surfaceBright = CizgiColor.White,
    surfaceDim = CizgiColor.Surface,
    surfaceContainerLowest = CizgiColor.White,
    surfaceContainerLow = CizgiColor.Paper,
    surfaceContainer = CizgiColor.White,
    surfaceContainerHigh = CizgiColor.Surface,
    surfaceContainerHighest = CizgiColor.Surface2,
)

fun cizgiTypography(): Typography = Typography(
    displayLarge = CizgiType.Manset,
    displayMedium = CizgiType.Manset,
    displaySmall = CizgiType.Manset,
    headlineLarge = CizgiType.Manset,
    headlineMedium = CizgiType.Manset,
    headlineSmall = CizgiType.Ekran,
    titleLarge = CizgiType.Ekran,
    titleMedium = CizgiType.Kart,
    titleSmall = CizgiType.Kart,
    bodyLarge = CizgiType.Govde,
    bodyMedium = CizgiType.Govde,
    bodySmall = CizgiType.Meta,
    labelLarge = CizgiType.Govde,
    labelMedium = CizgiType.Meta,
    labelSmall = CizgiType.Meta,
)
