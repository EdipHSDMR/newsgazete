package dev.haberver.kesif.worker

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import dev.haberver.kesif.HaberApp
import kotlinx.coroutines.flow.first
import java.util.Calendar

/**
 * Anlık sunucu push'u bu sınıftan çıkmaz.
 *
 * Gradle'da firebase-messaging yoktur. Sunucu push kuyruğu sağlayıcısız
 * kaldığı için cihaz bu kuyruğu da çekmez. WorkManager bağımlılığı
 * (androidx.work:work-runtime-ktx) projede vardır; bu worker o API ile derlenir.
 * Kuyruğa alınmaz. [RefreshWorker] yaklaşık 30 dakikalık yenilemede, izin ve
 * sessiz saat uygunsa takip konusu veya takım adı eşleşmesi için yerel bildirim
 * üretebilir. Bu dosya onu ikinci kez basmaz ve son dakika, maç başlangıcı,
 * skor değişimi için metin uydurmaz.
 */
class LocalAlertsWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (applicationContext !is HaberApp) {
            return Result.success(workDataOf("delivered" to 0, "reason" to "no_app"))
        }
        return runCatching {
            val app = applicationContext as HaberApp
            val prefs = app.container.preferences.flow.first()
            val reason = localDeliveryReason(
                preferenceOn = prefs.notificationsEnabled,
                permissionGranted = LocalAlerts.notificationAccess(applicationContext).allowsLocal,
                quiet = inQuietHours(
                    Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                    prefs.quietStart,
                    prefs.quietEnd,
                ),
            )
            Result.success(workDataOf("delivered" to 0, "reason" to reason))
        }.getOrElse {
            Result.success(workDataOf("delivered" to 0, "reason" to "unavailable"))
        }
    }
}

data class NotificationAccess(
    val runtimeGranted: Boolean,
    val systemEnabled: Boolean,
) {
    val allowsLocal: Boolean get() = runtimeGranted && systemEnabled
}

fun localDeliveryReason(preferenceOn: Boolean, permissionGranted: Boolean, quiet: Boolean): String {
    if (!preferenceOn) return "preference_off"
    if (!permissionGranted) return "permission_missing"
    if (quiet) return "quiet_hours"
    return "no_server_push"
}

object LocalAlerts {
    const val DEVICE_ONLY_COPY =
        "Bu sürümde bildirimler cihazdaki tercihlerdir, anlık sunucu push gönderilmez."

    fun notificationAccess(context: Context): NotificationAccess {
        val runtimeGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
        val manager = context.getSystemService(NotificationManager::class.java)
        return NotificationAccess(
            runtimeGranted = runtimeGranted,
            systemEnabled = manager?.areNotificationsEnabled() == true,
        )
    }

    fun inQuietHoursNow(start: Int, end: Int): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return inQuietHours(hour, start, end)
    }
}
