package dev.haberver.kesif.worker

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dev.haberver.kesif.HaberApp
import dev.haberver.kesif.MainActivity
import dev.haberver.kesif.core.data.Refresh
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.time.OffsetDateTime

class RefreshWorker(context: android.content.Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as HaberApp
        val previousSuccess = app.container.preferences.flow.first().lastSuccessEpoch
        val refresh = app.container.repository.refresh(null)
        if (refresh is Refresh.Fresh) {
            app.container.preferences.markSuccess(System.currentTimeMillis())
            notifyIfAllowed(app, previousSuccess)
        }
        return if (refresh is Refresh.Failed && refresh.retryable) Result.retry() else Result.success()
    }

    private suspend fun notifyIfAllowed(app: HaberApp, previousSuccess: Long) {
        val prefs = app.container.preferences.flow.first()
        if (!prefs.notificationsEnabled) return
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (inQuietHours(hour, prefs.quietStart, prefs.quietEnd)) return
        val cards = app.container.repository.observeFeed().first()
        val fresh = cards.filter { story ->
            val title = story.editorialTitle ?: return@filter false
            if (story.id in prefs.seenNotifications || previousSuccess == 0L) return@filter false
            val publishedEpoch = runCatching { OffsetDateTime.parse(story.publishedAt).toInstant().toEpochMilli() }.getOrDefault(0L)
            if (publishedEpoch <= previousSuccess) return@filter false
            val text = "$title ${story.editorialSummary.orEmpty()}"
            val followedTopic = prefs.followedTopicAlerts && story.topicSlug in prefs.followedTopics
            val followedTeam = prefs.sportsAlerts && story.topicSlug == "spor" &&
                prefs.followedTeams.any { team -> text.contains(team, ignoreCase = true) }
            followedTopic || followedTeam
        }.take(1)
        if (fresh.isEmpty()) return
        val story = fresh.first()
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            data = android.net.Uri.parse("haberver://story/${story.id}")
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext,
            story.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(applicationContext, "stories")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(story.editorialTitle)
            .setContentText("Editoryal özet")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(story.id.hashCode(), notification)
        app.container.preferences.markNotified(setOf(story.id))
    }
}

fun inQuietHours(hour: Int, start: Int, end: Int): Boolean {
    return if (start == end) false
    else if (start < end) hour in start until end
    else hour >= start || hour < end
}
