package dev.haberver.kesif.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import androidx.datastore.preferences.core.stringSetPreferencesKey
import dev.haberver.kesif.BuildConfig
import dev.haberver.kesif.HaberApp
import dev.haberver.kesif.ui.brand.CizgiMark
import dev.haberver.kesif.ui.brand.CizgiType
import dev.haberver.kesif.ui.brand.cizgiDirectionColor
import dev.haberver.kesif.ui.brand.cizgiLineColor
import dev.haberver.kesif.ui.discover.DiscoverSearchScreen
import dev.haberver.kesif.ui.library.LibraryScreen
import dev.haberver.kesif.ui.profile.CizgiProfileScreen
import dev.haberver.kesif.ui.sports.SportsCenterScreen
import dev.haberver.kesif.ui.story.CompareSourcesScreen
import dev.haberver.kesif.ui.story.StoryDetailScreen
import dev.haberver.kesif.ui.weather.WeatherScreen
import dev.haberver.kesif.core.data.Preferences
import dev.haberver.kesif.core.data.Refresh
import dev.haberver.kesif.core.data.StoryRepository
import dev.haberver.kesif.core.data.UserPrefs
import dev.haberver.kesif.core.data.Connectivity
import dev.haberver.kesif.core.model.FeedUi
import dev.haberver.kesif.core.model.Phase
import dev.haberver.kesif.core.model.StoryCard
import dev.haberver.kesif.core.model.hideExpired
import dev.haberver.kesif.core.model.presentFeed
import dev.haberver.kesif.ui.brand.CizgiOfflineChip
import dev.haberver.kesif.ui.brand.CizgiStateBanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val fallbackTopics = listOf(
    "ulusal" to "Türkiye",
    "dunya" to "Dünya",
    "ekonomi" to "Ekonomi",
    "bilim-teknoloji" to "Bilim ve teknoloji",
    "iklim-cevre" to "İklim ve çevre",
    "kultur" to "Kültür ve yaşam",
    "spor" to "Spor",
    "yerel" to "Yerel",
)
class FeedViewModel(private val repository: StoryRepository, private val preferences: Preferences) : ViewModel() {
    private val loading = MutableStateFlow(true)
    private val offline = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val ui = combine(repository.observeFeed(), preferences.flow, loading, offline, message) { items, prefs, isLoading, isOffline, note ->
        presentFeed(items, System.currentTimeMillis(), isLoading, isOffline, note, prefs.followedTopics, prefs.mutedSources, prefs.onlyFollowed)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FeedUi(Phase.Loading, emptyList(), null, null))

    fun refresh(topic: String?) {
        viewModelScope.launch {
            loading.value = true
            when (val result = repository.refresh(topic)) {
                Refresh.Fresh -> {
                    offline.value = false
                    message.value = null
                    preferences.markSuccess(System.currentTimeMillis())
                }
                is Refresh.Failed -> {
                    offline.value = result.phase == "Offline"
                    message.value = result.message
                }
            }
            loading.value = false
        }
    }
}

class AppFactory(private val app: HaberApp) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return FeedViewModel(app.container.repository, app.container.preferences) as T
    }
}

@Composable
fun HaberRoot(app: HaberApp, prefs: UserPrefs, startStoryId: String?) {
    HaberTheme(prefs.theme) {
        val nav = rememberNavController()
        val currentEntry by nav.currentBackStackEntryAsState()
        val currentRoute = currentEntry?.destination?.route
        val start = if (prefs.onboardingDone) CizgiRoutes.HOME else CizgiRoutes.ONBOARDING
        // Dosyası olan ekranlar import edilir. Gerçek adlar burada tanımlanmaz.
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.onBackground,
            contentWindowInsets = WindowInsets.systemBars,
            bottomBar = {
                if (currentRoute != CizgiRoutes.ONBOARDING) {
                    CizgiBottomBar(currentRoute = currentRoute, onSelect = nav::switchCizgiTab)
                }
            },
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = start,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding).fillMaxSize(),
            ) {
                composable(CizgiRoutes.ONBOARDING) {
                    Onboarding(app) {
                        nav.navigate(CizgiRoutes.HOME) { popUpTo(CizgiRoutes.ONBOARDING) { inclusive = true } }
                    }
                }
                composable(CizgiRoutes.HOME) {
                    ShellHomeFallback(
                        app,
                        prefs,
                        { nav.navigate(CizgiRoutes.story(it)) },
                        { nav.switchCizgiTab(CizgiRoutes.PROFILE) },
                        { nav.navigate(CizgiRoutes.TOPICS) },
                        { nav.navigate(CizgiRoutes.WEATHER) },
                    )
                }
                composable(CizgiRoutes.WEATHER) {
                    WeatherScreen(
                        apiBase = BuildConfig.API_BASE_URL,
                        onBack = { if (!nav.popBackStack()) nav.switchCizgiTab(CizgiRoutes.HOME) },
                    )
                }
                composable(CizgiRoutes.SPORTS) {
                    val scope = rememberCoroutineScope()
                    SportsCenterScreen(
                        apiBase = BuildConfig.API_BASE_URL,
                        followedTeamIds = prefs.followedTeams,
                        onFollowTeam = { teamId, follow ->
                            scope.launch {
                                app.container.preferences.update { store ->
                                    val key = stringSetPreferencesKey("followed_teams")
                                    val current = store[key] ?: emptySet()
                                    store[key] = if (follow) current + teamId else current - teamId
                                }
                            }
                        },
                    )
                }
                composable(CizgiRoutes.TOPICS) { TopicsScreen(app, prefs) }
                composable(CizgiRoutes.SEARCH) {
                    DiscoverSearchScreen { nav.navigate(CizgiRoutes.story(it)) }
                }
                composable(CizgiRoutes.SAVED) {
                    LibraryScreen { nav.navigate(CizgiRoutes.story(it)) }
                }
                composable(
                    CizgiRoutes.STORY,
                    arguments = listOf(navArgument("id") { type = NavType.StringType }),
                    deepLinks = listOf(
                        navDeepLink { uriPattern = "https://haberver.example/story/{id}" },
                        navDeepLink { uriPattern = "haberver://story/{id}" },
                    ),
                ) { entry ->
                    StoryDetailScreen(
                        storyId = entry.arguments?.getString("id").orEmpty(),
                        onOpenSource = { nav.navigate(CizgiRoutes.source(it)) },
                        onReport = { nav.navigate(CizgiRoutes.report(it)) },
                        onBack = { if (!nav.popBackStack()) nav.switchCizgiTab(CizgiRoutes.HOME) },
                    )
                }
                composable(
                    CizgiRoutes.COMPARE,
                    arguments = listOf(navArgument("id") { type = NavType.StringType }),
                ) { entry ->
                    CompareSourcesScreen(
                        storyId = entry.arguments?.getString("id").orEmpty(),
                        onBack = { nav.popBackStack() },
                    )
                }
                composable(
                    CizgiRoutes.SOURCE,
                    arguments = listOf(navArgument("id") { type = NavType.StringType }),
                ) { entry ->
                    SourceScreen(app, entry.arguments?.getString("id").orEmpty()) { nav.navigate(CizgiRoutes.story(it)) }
                }
                composable(CizgiRoutes.PROFILE) {
                    Column(Modifier.fillMaxSize()) {
                        CizgiProfileScreen(
                            preferences = app.container.preferences,
                            prefs = prefs,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(
                            onClick = { nav.navigate(CizgiRoutes.ABOUT) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) { Text("Hakkında, standartlar, gizlilik") }
                    }
                }
                composable(CizgiRoutes.ABOUT) { AboutScreen { nav.popBackStack() } }
                composable(
                    CizgiRoutes.REPORT,
                    arguments = listOf(navArgument("id") { type = NavType.StringType }),
                ) { entry ->
                    ReportScreen(app, entry.arguments?.getString("id").orEmpty()) { nav.popBackStack() }
                }
            }
        }
        val activity = LocalContext.current as? ComponentActivity
        LaunchedEffect(Unit) {
            activity?.intent?.let { nav.handleDeepLink(it) }
        }
        LaunchedEffect(startStoryId) {
            if (!startStoryId.isNullOrBlank()) nav.navigate(CizgiRoutes.story(startStoryId))
        }
    }
}

@Composable
private fun Onboarding(app: HaberApp, onDone: () -> Unit) {
    var selected by remember { mutableStateOf(setOf<String>()) }
    var city by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ÇİZGİ", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
        Text("Gündemi bul, bağlamı gör.")
        Text("İlgi alanlarını seç; akışını dilediğin zaman değiştirebilirsin. Konu seçmek zorunlu değil. Konum izni istenmez. Bildirim izni ilk açılışta sorulmaz; daha sonra profilden açarsın.")
        fallbackTopics.forEach { (slug, name) ->
            FilterChip(selected = slug in selected, onClick = { selected = if (slug in selected) selected - slug else selected + slug }, label = { Text(name) })
        }
        OutlinedTextField(city, { city = it }, label = { Text("Şehir (elle, isteğe bağlı)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { app.container.preferences.completeOnboarding(selected, city.trim()); onDone() } }, modifier = Modifier.fillMaxWidth()) {
            Text("Şimdi başla")
        }
        OutlinedButton(
            onClick = { scope.launch { app.container.preferences.completeOnboarding(emptySet(), city.trim()); onDone() } },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Konu seçmeden devam et")
        }
    }
}

@Composable
private fun ShellHomeFallback(
    app: HaberApp,
    prefs: UserPrefs,
    openStory: (String) -> Unit,
    openProfile: () -> Unit,
    openTopics: () -> Unit,
    openWeather: () -> Unit,
) {
    val model: FeedViewModel = viewModel(factory = AppFactory(app))
    val state by model.ui.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var selectedTopic by remember { mutableStateOf<String?>(null) }
    val editionDate = remember { editionDateLabel() }
    LaunchedEffect(Unit) { model.refresh(null) }
    val context = LocalContext.current
    val online by Connectivity.observeOnline(context).collectAsStateWithLifecycle(initialValue = Connectivity.isOnline(context))
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            val darkMasthead = prefs.theme == "dark"
            Row(
                modifier = Modifier.padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                CizgiMark(
                    modifier = Modifier.size(28.dp),
                    lineColor = cizgiLineColor(darkMasthead),
                    directionColor = cizgiDirectionColor(darkMasthead),
                    contentDescription = null,
                )
                Text(
                    "Çizgi",
                    modifier = Modifier.semantics { heading() },
                    style = CizgiType.Manset,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.weight(1f))
                CizgiOfflineChip(offline = !online)
            }
            Text(editionDate, style = CizgiType.Meta, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { selectedTopic = null; model.refresh(null) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Yenile") }
                TextButton(onClick = openTopics, modifier = Modifier.heightIn(min = 48.dp)) { Text("Konular") }
                TextButton(onClick = openProfile, modifier = Modifier.heightIn(min = 48.dp)) { Text("Ayarlar") }
            }
            HorizontalDivider(thickness = 2.dp, color = MaterialTheme.colorScheme.tertiary)
            state.cacheLabel?.let { CizgiStateBanner(text = it, modifier = Modifier.padding(top = 8.dp)) }
            if (prefs.city.isNotBlank()) {
                Text("Seçili şehir: ${prefs.city}", modifier = Modifier.padding(top = 2.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterChip(selected = selectedTopic == null, onClick = { selectedTopic = null; model.refresh(null) }, label = { Text("Gündem") })
                fallbackTopics.forEach { (slug, name) ->
                    FilterChip(selected = selectedTopic == slug, onClick = { selectedTopic = slug; model.refresh(slug) }, label = { Text(name) })
                }
                FilterChip(selected = false, onClick = openWeather, label = { Text("Hava") })
            }
        }
        PhaseBody(state, openStory, { id, saved ->
            scope.launch { app.container.repository.setSaved(id, saved) }
        }, Modifier.weight(1f).padding(horizontal = 16.dp))
    }
}

private fun editionDateLabel(): String = runCatching {
    LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale.forLanguageTag("tr-TR")))
}.getOrElse { LocalDate.now().toString() }

@Composable
private fun PhaseBody(state: FeedUi, openStory: (String) -> Unit, onSave: (String, Boolean) -> Unit, modifier: Modifier = Modifier) {
    when (state.phase) {
        Phase.Loading -> Column(modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CircularProgressIndicator()
            Text("Yükleniyor")
        }
        Phase.Empty -> Message("Gösterilecek haber yok. Konu filtresini sıfırlayabilir veya yenileyebilirsiniz.", modifier)
        Phase.Offline -> Message(state.message ?: "Bağlantı yok.", modifier)
        Phase.Error -> Message(state.message ?: "Bir sorun oluştu.", modifier)
        Phase.LicenseRemoved -> Message("İçerik izin nedeniyle kaldırıldı.", modifier)
        Phase.Content -> LazyColumn(modifier = modifier, contentPadding = PaddingValues(bottom = 16.dp)) {
            state.message?.let { item { Text(it, modifier = Modifier.padding(bottom = 8.dp)) } }
            state.items.firstOrNull()?.let { lead ->
                item(key = "lead-${lead.id}") { StoryCardView(lead, openStory, onSave, featured = true) }
            }
            items(state.items.drop(1), key = { it.id }) { card ->
                FeedListRow(card, openStory, onSave)
            }
        }
    }
}


@Composable
private fun Message(text: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(vertical = 16.dp)) { Text(text) }
}

@Composable
private fun StoryCardView(card: StoryCard, openStory: (String) -> Unit, onSave: (String, Boolean) -> Unit, featured: Boolean = false) {
    val shown = hideExpired(card, System.currentTimeMillis())
    Card(onClick = { openStory(shown.id) }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (featured) Text("MANŞET", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            Text("${shown.topicName.uppercase()}  ·  ${shown.sourceCount} kaynak", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            if (shown.synthetic) Text("KURMACA", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelMedium)
            publicLabel(shown.displayLabel)?.let { Text(it) }
            Text(shown.editorialTitle ?: "Başlık gizlendi", modifier = Modifier.semantics { heading() }, style = if (featured) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleLarge)
            Text(shown.editorialSummary ?: "Özet, izin durumu nedeniyle gizlendi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(storyMeta(shown), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openStory(shown.id) }) { Text("Ayrıntı") }
                TextButton(onClick = { onSave(shown.id, !shown.saved) }) {
                    Text(if (shown.saved) "Kaydedildi" else "Kaydet")
                }
            }
        }
    }
}

@Composable
private fun FeedListRow(card: StoryCard, openStory: (String) -> Unit, onSave: (String, Boolean) -> Unit) {
    val shown = hideExpired(card, System.currentTimeMillis())
    Column(Modifier.fillMaxWidth()) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier.weight(1f).clickable { openStory(shown.id) }.padding(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                if (shown.synthetic) Text("KURMACA", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelMedium)
                Text(shown.topicName.uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                Text(shown.editorialTitle ?: "Başlık gizlendi", modifier = Modifier.semantics { heading() }, style = MaterialTheme.typography.titleMedium)
                Text(storyMeta(shown), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { onSave(shown.id, !shown.saved) }, modifier = Modifier.heightIn(min = 48.dp)) {
                Text(if (shown.saved) "Kaydedildi" else "Kaydet")
            }
        }
    }
}

private fun publicLabel(raw: String?): String? {
    val text = raw?.trim().orEmpty()
    if (text.isEmpty() || text.equals("Editoryal özet", ignoreCase = true)) return null
    return text
}

private fun storyMeta(card: StoryCard): String {
    val credit = publicLabel(card.authorshipLabel)
    return buildString {
        if (!credit.isNullOrBlank()) append(credit).append(" · ")
        append(card.publishedAt)
        if (card.updatedBadge) append(" · Güncellendi")
    }
}

@Composable
private fun TopicsScreen(app: HaberApp, prefs: UserPrefs) {
    var topics by remember { mutableStateOf(fallbackTopics.map { it.first to it.second }) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        app.container.repository.topics().onSuccess { remote -> if (remote.isNotEmpty()) topics = remote.map { it.slug to it.name } }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Konular", modifier = Modifier.semantics { heading() }, style = MaterialTheme.typography.headlineSmall)
        Text("Takip cihazda durur. Hassas profil veya reklam segmenti üretilmez.")
        topics.forEach { (slug, name) ->
            val on = slug in prefs.followedTopics
            FilterChip(selected = on, onClick = {
                scope.launch {
                    app.container.preferences.update {
                        val key = androidx.datastore.preferences.core.stringSetPreferencesKey("followed_topics")
                        val current = it[key] ?: emptySet()
                        it[key] = if (slug in current) current - slug else current + slug
                    }
                }
            }, label = { Text(if (on) "$name, takipte" else name) })
        }
    }
}

@Composable
private fun SourceScreen(app: HaberApp, sourceId: String, openStory: (String) -> Unit) {
    var title by remember { mutableStateOf("Kaynak") }
    var body by remember { mutableStateOf("Yükleniyor") }
    var links by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    LaunchedEffect(sourceId) {
        app.container.repository.sourceProfile(sourceId).onSuccess {
            title = it.name
            body = "${it.domain}\n${it.editorialDescription}\n${it.partnershipNote.orEmpty()}"
            links = it.stories.map { story -> story.id to (story.editorialTitle ?: "Hikaye") }
        }.onFailure { body = "Kaynak profili alınamadı." }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, modifier = Modifier.semantics { heading() })
        Text("Güven puanı yok. Bu ekran yayıncı ilişkisini anlatır.")
        Text(body)
        links.forEach { (storyId, storyTitle) -> TextButton(onClick = { openStory(storyId) }) { Text(storyTitle) } }
    }
}

@Composable
private fun AboutScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Hakkında", modifier = Modifier.semantics { heading() })
        Text("Çizgi, farklı yayınlardaki gelişmeleri kaynaklarıyla birlikte keşfetmen için tasarlanmıştır.")
        Text("Özetler editoryaldir. Tam metin ve fotoğraf yayıncıda kalır. Kaynak göstermek yeniden kullanım izni değildir.")
        Text("Aydınlatma: hesap yokken konu, şehir ve kayıtlar cihazda durur. Arama sorgusu sunucuya analitik olarak yazılmaz. Bu metin hukuk incelemesi bekler.")
        Text("Düzeltme: hikaye ekranından bildirim gönderin. Kayıt kamuya açılmaz.")
        TextButton(onClick = back) { Text("Geri") }
    }
}

@Composable
private fun ReportScreen(app: HaberApp, storyId: String, done: () -> Unit) {
    var category by remember { mutableStateOf("wrong_summary") }
    var description by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Düzeltme bildir", modifier = Modifier.semantics { heading() })
        Text("Hikaye kimliği otomatik eklenir. İletişim bilgisi zorunlu değil.")
        listOf("wrong_summary" to "Yanlış özet", "wrong_date" to "Yanlış tarih", "broken_link" to "Bozuk bağlantı", "other" to "Diğer").forEach { (id, label) ->
            FilterChip(selected = category == id, onClick = { category = id }, label = { Text(label) })
        }
        OutlinedTextField(description, { description = it }, label = { Text("Açıklama (isteğe bağlı)") })
        Button(onClick = {
            scope.launch {
                app.container.repository.report(storyId, category, description.ifBlank { null }).onSuccess {
                    result = "Alındı. Kayıt numarası $it"
                }.onFailure { result = "Gönderilemedi. Yeniden deneyin." }
            }
        }) { Text("Gönder") }
        result?.let { Text(it) }
        TextButton(onClick = done) { Text("Kapat") }
    }
}
