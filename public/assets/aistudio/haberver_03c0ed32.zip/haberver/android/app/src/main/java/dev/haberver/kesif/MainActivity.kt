package dev.haberver.kesif

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.haberver.kesif.core.data.UserPrefs
import dev.haberver.kesif.ui.HaberRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as HaberApp
        val startStory = storyIdFrom(intent?.data)
        setContent {
            val prefs by app.container.preferences.flow.collectAsStateWithLifecycle(initialValue = UserPrefs())
            HaberRoot(app = app, prefs = prefs, startStoryId = startStory)
        }
    }
}

private fun storyIdFrom(data: Uri?): String? {
    if (data == null) return null
    val id = when {
        data.scheme == "https" && data.host == "haberver.example" && data.pathSegments.firstOrNull() == "story" ->
            data.pathSegments.getOrNull(1)
        data.scheme == "haberver" && data.host == "story" -> data.lastPathSegment
        else -> null
    }
    return id?.takeIf { it.isNotBlank() }
}

fun shareStory(activity: ComponentActivity, title: String, id: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "$title\nEditoryal özet. Uygulamada açın: haberver://story/$id")
    }
    activity.startActivity(Intent.createChooser(send, "Paylaş"))
}

fun openExternal(activity: ComponentActivity, url: String): Boolean {
    val view = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    if (view.resolveActivity(activity.packageManager) == null) return false
    activity.startActivity(view)
    return true
}
