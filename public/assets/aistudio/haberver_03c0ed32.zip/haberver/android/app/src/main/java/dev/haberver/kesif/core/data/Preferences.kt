package dev.haberver.kesif.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("haberkesif")

data class UserPrefs(
    val onboardingDone: Boolean = false,
    val followedTopics: Set<String> = emptySet(),
    val followedTeams: Set<String> = emptySet(),
    val onlyFollowed: Boolean = false,
    val mutedSources: Set<String> = emptySet(),
    val city: String = "",
    val theme: String = "light",
    val font: String = "md",
    val notificationsEnabled: Boolean = false,
    val breakingAlerts: Boolean = false,
    val followedTopicAlerts: Boolean = false,
    val sportsAlerts: Boolean = false,
    val dailyDigest: Boolean = false,
    val quietStart: Int = 22,
    val quietEnd: Int = 7,
    val recentSearches: List<String> = emptyList(),
    val seenNotifications: Set<String> = emptySet(),
    val analyticsOptIn: Boolean = false,
    val installationId: String = "",
    val lastSuccessEpoch: Long = 0L,
)

class Preferences(private val context: Context) {
    private object Keys {
        val onboarding = booleanPreferencesKey("onboarding_done")
        val followed = stringSetPreferencesKey("followed_topics")
        val followedTeams = stringSetPreferencesKey("followed_teams")
        val onlyFollowed = booleanPreferencesKey("only_followed")
        val muted = stringSetPreferencesKey("muted_sources")
        val city = stringPreferencesKey("city")
        val theme = stringPreferencesKey("theme")
        val font = stringPreferencesKey("font")
        val notifications = booleanPreferencesKey("notifications")
        val breakingAlerts = booleanPreferencesKey("breaking_alerts")
        val followedTopicAlerts = booleanPreferencesKey("followed_topic_alerts")
        val sportsAlerts = booleanPreferencesKey("sports_alerts")
        val dailyDigest = booleanPreferencesKey("daily_digest")
        val quietStart = intPreferencesKey("quiet_start")
        val quietEnd = intPreferencesKey("quiet_end")
        val recent = stringPreferencesKey("recent_searches")
        val seen = stringSetPreferencesKey("seen_notifications")
        val analytics = booleanPreferencesKey("analytics_opt_in")
        val installation = stringPreferencesKey("installation_id")
        val lastSuccess = longPreferencesKey("last_success")
    }

    val flow: Flow<UserPrefs> = context.store.data.map { prefs ->
        UserPrefs(
            onboardingDone = prefs[Keys.onboarding] ?: false,
            followedTopics = prefs[Keys.followed] ?: emptySet(),
            followedTeams = prefs[Keys.followedTeams] ?: emptySet(),
            onlyFollowed = prefs[Keys.onlyFollowed] ?: false,
            mutedSources = prefs[Keys.muted] ?: emptySet(),
            city = prefs[Keys.city] ?: "",
            theme = prefs[Keys.theme] ?: "light",
            font = when (val stored = prefs[Keys.font]) {
                "lg", "xl" -> stored
                else -> "md"
            },
            notificationsEnabled = prefs[Keys.notifications] ?: false,
            breakingAlerts = prefs[Keys.breakingAlerts] ?: false,
            followedTopicAlerts = prefs[Keys.followedTopicAlerts] ?: false,
            sportsAlerts = prefs[Keys.sportsAlerts] ?: false,
            dailyDigest = prefs[Keys.dailyDigest] ?: false,
            quietStart = prefs[Keys.quietStart] ?: 22,
            quietEnd = prefs[Keys.quietEnd] ?: 7,
            recentSearches = prefs[Keys.recent]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList(),
            seenNotifications = prefs[Keys.seen] ?: emptySet(),
            analyticsOptIn = prefs[Keys.analytics] ?: false,
            installationId = prefs[Keys.installation] ?: "",
            lastSuccessEpoch = prefs[Keys.lastSuccess] ?: 0L,
        )
    }

    suspend fun update(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.store.edit(block)
    }

    suspend fun completeOnboarding(topics: Set<String>, city: String) {
        context.store.edit {
            it[Keys.onboarding] = true
            it[Keys.followed] = topics
            it[Keys.city] = city
        }
    }

    suspend fun reset() {
        context.store.edit { it.clear() }
    }

    suspend fun rememberSearch(query: String) {
        context.store.edit {
            val current = it[Keys.recent]?.split("\n")?.filter { row -> row.isNotBlank() }?.toMutableList() ?: mutableListOf()
            current.remove(query)
            current.add(0, query)
            it[Keys.recent] = current.take(8).joinToString("\n")
        }
    }

    suspend fun markNotified(ids: Set<String>) {
        context.store.edit { it[Keys.seen] = ((it[Keys.seen] ?: emptySet()) + ids).take(200).toSet() }
    }

    suspend fun markSuccess(epoch: Long) {
        context.store.edit { it[Keys.lastSuccess] = epoch }
    }
}
