package dev.haberver.kesif.ui.story

import androidx.activity.ComponentActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

@Composable
fun CompareSourcesScreen(storyId: String, onBack: () -> Unit) {
    val activity = LocalContext.current as? ComponentActivity
    var font by rememberSaveable { mutableStateOf("md") }
    var notice by remember(storyId) { mutableStateOf<String?>(null) }
    ReaderShell(
        storyId = storyId,
        font = font,
        onBack = onBack,
        notice = notice,
        onDismissNotice = { notice = null },
        onOpenHttps = { notice = openReaderLink(activity, it) },
    ) { copy ->
        ReaderArticle(
            copy = copy,
            font = font,
            onFont = { font = it },
            detail = false,
            onOpenHttps = { notice = openReaderLink(activity, it) },
            onSave = null,
            onShare = null,
            onReport = null,
            onOpenSource = null,
        )
    }
}
