package dev.haberver.kesif.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PresentationTest {
    private fun card(expires: String? = null) = StoryCard(
        id = "11111111-1111-1111-1111-111111111111",
        editorialTitle = "Sentetik demo başlığı",
        editorialSummary = "Sentetik özet metni burada.",
        authorshipLabel = "Editoryal özet",
        publishedAt = "2026-10-22T09:00:00Z",
        updatedAt = "2026-10-22T09:00:00Z",
        sourceCount = 1,
        topicSlug = "ulusal",
        topicName = "Ulusal",
        synthetic = true,
        displayLabel = "Sentetik demo — gerçek haber değildir",
        updatedBadge = false,
        rankingReason = "yayın zamanı",
        editorPriority = 0,
        sourceIds = listOf("source-1"),
        rightsExpiresAt = expires,
        unavailableReason = null,
        saved = false,
        cacheTimeEpoch = 1L,
    )

    @Test
    fun expiredRightsHideText() {
        val hidden = hideExpired(card("2026-10-22T10:00:00Z"), nowEpochMillis = java.time.Instant.parse("2026-10-22T12:00:00Z").toEpochMilli())
        assertNull(hidden.editorialTitle)
        assertNull(hidden.editorialSummary)
        assertEquals("license_removed", hidden.unavailableReason)
    }

    @Test
    fun offlineWithCacheStaysContent() {
        val ui = presentFeed(
            items = listOf(card()),
            nowEpochMillis = 0L,
            loading = false,
            offline = true,
            errorMessage = "Bağlantı yok",
            followed = emptySet(),
            mutedSourceIds = emptySet(),
            onlyFollowed = false,
        )
        assertEquals(Phase.Content, ui.phase)
        assertEquals(1, ui.items.size)
    }

    @Test
    fun emptyFeedWithoutCacheIsOfflineWhenDisconnected() {
        val ui = presentFeed(emptyList(), 0L, loading = false, offline = true, errorMessage = "Bağlantı yok", emptySet(), emptySet(), false)
        assertEquals(Phase.Offline, ui.phase)
    }

    @Test
    fun unknownErrorIsGeneric() {
        val error = classify("no_such_code", 500, offline = false)
        assertEquals(Phase.Error, error.phase)
        assertEquals(true, error.retryable)
    }

    @Test
    fun contentUnavailableIsNotRetried() {
        val error = classify("content_unavailable", 404, offline = false)
        assertEquals(Phase.LicenseRemoved, error.phase)
        assertEquals(false, error.retryable)
    }
}
