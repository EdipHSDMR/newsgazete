package dev.haberver.kesif.ui.sports

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.haberver.kesif.ui.brand.CizgiColor
import dev.haberver.kesif.ui.brand.CizgiSpace
import dev.haberver.kesif.ui.brand.CizgiType
import dev.haberver.kesif.ui.brand.cizgiHedef
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDate

private const val MatchCap = 80

/** Spor merkezi light lacivert-beyaz. Teal yok. */
private object SportsLight {
    val Bg = CizgiColor.Paper
    val Card = CizgiColor.White
    val Ink = CizgiColor.Navy
    val Muted = CizgiColor.Muted
    val Accent = CizgiColor.Navy
    val OnAccent = CizgiColor.White
    val Rule = CizgiColor.Rule
    val Gold = CizgiColor.Gold
    val Crest = CizgiColor.Surface
}


private sealed interface SportsPanel {
    data object Loading : SportsPanel

    data class Content(
        val matches: List<MatchItem> = emptyList(),
        val standings: List<StandingRow> = emptyList(),
        val teams: List<TeamItem> = emptyList(),
        val meta: SportsMeta,
        val banner: String? = null,
        val notice: String? = null,
        val limited: Boolean = false,
    ) : SportsPanel

    data class Problem(
        val text: String,
        val meta: SportsMeta? = null,
        val failure: Boolean = false,
    ) : SportsPanel
}

private sealed interface Attempt {
    data class Page(val page: SportsPage) : Attempt
    data class Fail(val error: Exception) : Attempt
}

@Composable
fun SportsCenterScreen(
    apiBase: String,
    followedTeamIds: Set<String>,
    onFollowTeam: (String, Boolean) -> Unit,
) {
    val client = remember { SportsClient() }
    DisposableEffect(client) {
        onDispose {
            client.close()
            CrestImages.close()
        }
    }
    var tab by remember { mutableStateOf(SportsTab.Live) }
    var competitions by remember { mutableStateOf<List<Competition>>(emptyList()) }
    var competitionId by remember { mutableStateOf<String?>(null) }
    var compMessage by remember { mutableStateOf<String?>(null) }
    var compsReady by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(istanbulToday()) }
    var liveCount by remember { mutableStateOf<Int?>(null) }
    var panel by remember { mutableStateOf<SportsPanel>(SportsPanel.Loading) }
    var refreshing by remember { mutableStateOf(false) }
    var pollNotice by remember { mutableStateOf<String?>(null) }
    var shownKey by remember { mutableStateOf("") }
    var refreshToken by remember { mutableIntStateOf(0) }
    var viewToken by remember { mutableIntStateOf(0) }
    var teamQuery by remember { mutableStateOf("") }
    var pendingFollow by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    val limited = (panel as? SportsPanel.Content)?.limited == true

    LaunchedEffect(followedTeamIds) {
        pendingFollow = pendingFollow.filter { (id, value) -> (id in followedTeamIds) != value }
    }
    LaunchedEffect(apiBase, refreshToken) {
        compsReady = false
        when (val result = attempt { client.competitions(apiBase) }) {
            is Attempt.Page -> {
                competitions = result.page.competitions
                compMessage = null
                if (competitions.none { it.id == competitionId }) competitionId = competitions.firstOrNull()?.id
            }
            is Attempt.Fail -> {
                competitions = emptyList()
                competitionId = null
                compMessage = humanFrom(result.error)
            }
        }
        compsReady = true
    }
    LaunchedEffect(apiBase, refreshToken, viewToken, tab, competitionId, date, compsReady) {
        if (!compsReady) return@LaunchedEffect
        val key = "$tab|$competitionId|$date"
        val keep = panel is SportsPanel.Content && shownKey == key
        refreshing = keep
        if (!keep) panel = SportsPanel.Loading
        val next = try {
            when (tab) {
                SportsTab.Live -> loadLive(client, apiBase, competitionId).also { liveCount = it.count }.panel
                SportsTab.Standings -> pagePanel(attempt { client.standings(apiBase, competitionId) }, SportsTab.Standings)
                SportsTab.Teams -> pagePanel(attempt { client.teams(apiBase, competitionId) }, SportsTab.Teams)
                else -> pagePanel(
                    attempt { client.matches(apiBase, competitionId, tab.bucket.orEmpty(), date) },
                    tab,
                )
            }
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (error: Exception) {
            SportsPanel.Problem(humanFrom(error), failure = true)
        }
        if (!isActive) return@LaunchedEffect
        if (keep && next is SportsPanel.Problem && next.failure && panel is SportsPanel.Content) {
            pollNotice = next.text
        } else {
            pollNotice = null
            panel = next
            shownKey = key
        }
        refreshing = false
    }
    LaunchedEffect(apiBase, refreshToken, viewToken, competitionId, compsReady, tab) {
        if (!compsReady || tab == SportsTab.Live) return@LaunchedEffect
        liveCount = when (val result = attempt { client.matches(apiBase, competitionId, "live", null) }) {
            is Attempt.Page -> result.page.matches.size
            is Attempt.Fail -> null
        }
    }
    LaunchedEffect(tab, limited, compsReady) {
        if (tab != SportsTab.Live || limited || !compsReady) return@LaunchedEffect
        while (true) {
            delay(60_000)
            viewToken += 1
        }
    }

    val meta = when (val current = panel) {
        is SportsPanel.Content -> current.meta
        is SportsPanel.Problem -> current.meta
        SportsPanel.Loading -> null
    }
    val reload = {
        pollNotice = null
        compsReady = false
        refreshToken += 1
    }
    fun followed(id: String): Boolean = pendingFollow[id] ?: (id in followedTeamIds)
    fun toggle(id: String) {
        val next = !followed(id)
        pendingFollow = pendingFollow + (id to next)
        onFollowTeam(id, next)
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(SportsLight.Bg)) {
        val wide = maxWidth >= 700.dp
        val pad = if (maxWidth <= 430.dp) 12.dp else CizgiSpace.s4
        Column(Modifier.fillMaxSize().padding(horizontal = pad, vertical = 12.dp)) {
            Header(sourceLine(meta, refreshing), reload)
            LeagueBar(competitions, competitionId, compMessage, compsReady) { competitionId = it }
            if (tab.usesDate) DayBar(date) { date = it }
            TabBar(tab, liveCount) { tab = it }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (val current = panel) {
                    SportsPanel.Loading -> LoadingBlock()
                    is SportsPanel.Problem -> ProblemBlock(current, reload)
                    is SportsPanel.Content -> ContentBlock(
                        panel = current,
                        tab = tab,
                        wide = wide,
                        teamQuery = teamQuery,
                        onQuery = { teamQuery = it.take(40) },
                        pollNotice = pollNotice,
                        followed = ::followed,
                        onToggle = ::toggle,
                        onReload = reload,
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(source: String, onReload: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "SPOR MERKEZİ",
                color = SportsLight.Accent,
                style = CizgiType.Meta.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp),
            )
            Text("Skorlar", color = SportsLight.Ink, style = CizgiType.Ekran, modifier = Modifier.semantics { heading() })
            Text(source, color = SportsLight.Muted, style = CizgiType.Meta, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
        }
        TealButton("Yenile", onReload)
    }
}

@Composable
private fun LeagueBar(
    competitions: List<Competition>,
    selected: String?,
    message: String?,
    ready: Boolean,
    onSelect: (String) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Lig", color = SportsLight.Muted, style = CizgiType.Meta.copy(fontWeight = FontWeight.SemiBold))
        when {
            message != null -> Note(message, failure = true)
            ready && competitions.isEmpty() -> Note("Lig listesi boş. Sağlayıcı lig döndürmedi.", failure = false)
            competitions.isNotEmpty() -> {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (competition in competitions) {
                        val label = if (competition.area.isNullOrBlank()) competition.name else "${competition.name} · ${competition.area}"
                        Choice(label, competition.id == selected) { onSelect(competition.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayBar(date: String, onChange: (String) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Choice("Önceki", false, Modifier.weight(1f)) { onChange(shiftIsoDate(date, -1)) }
            Choice("Sonraki", false, Modifier.weight(1f)) { onChange(shiftIsoDate(date, 1)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Choice(formatIsoDateLabel(date).ifBlank { date }, false, Modifier.weight(1f)) {
                val parsed = runCatching { LocalDate.parse(date) }.getOrNull()
                if (parsed != null) {
                    DatePickerDialog(
                        context,
                        { _, year, month, day -> onChange(LocalDate.of(year, month + 1, day).toString()) },
                        parsed.year,
                        parsed.monthValue - 1,
                        parsed.dayOfMonth,
                    ).show()
                }
            }
            Choice("Bugün", false) { onChange(istanbulToday()) }
        }
    }
}

@Composable
private fun TabBar(selected: SportsTab, liveCount: Int?, onSelect: (SportsTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (item in SportsTab.entries) {
            val on = item == selected
            Surface(
                onClick = { onSelect(item) },
                modifier = Modifier.heightIn(min = CizgiSpace.touch).cizgiHedef(),
                shape = RoundedCornerShape(999.dp),
                color = if (on) SportsLight.Accent else SportsLight.Card,
                contentColor = if (on) SportsLight.OnAccent else SportsLight.Ink,
                border = if (on) null else BorderStroke(1.dp, SportsLight.Rule),
            ) {
                Row(
                    Modifier.heightIn(min = CizgiSpace.touch).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(item.title, style = CizgiType.Govde, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    if (item == SportsTab.Live && liveCount != null) CountPill(liveCount)
                }
            }
        }
    }
}

@Composable
private fun ContentBlock(
    panel: SportsPanel.Content,
    tab: SportsTab,
    wide: Boolean,
    teamQuery: String,
    onQuery: (String) -> Unit,
    pollNotice: String?,
    followed: (String) -> Boolean,
    onToggle: (String) -> Unit,
    onReload: () -> Unit,
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        panel.banner?.let { Note(it, failure = false) }
        panel.notice?.let { Note(it, failure = false) }
        pollNotice?.let { Note(it, failure = true) }
        when (tab) {
            SportsTab.Standings -> {
                if (panel.standings.isEmpty()) {
                    ProblemBlock(SportsPanel.Problem(emptyCopy(tab), panel.meta), onReload)
                } else if (wide) {
                    StandingTable(panel.standings, followed, onToggle, Modifier.weight(1f))
                } else {
                    StandingCards(panel.standings, followed, onToggle, Modifier.weight(1f))
                }
            }
            SportsTab.Teams -> TeamList(panel.teams, teamQuery, onQuery, followed, onToggle, onReload, Modifier.weight(1f))
            else -> {
                if (panel.matches.isEmpty()) {
                    ProblemBlock(SportsPanel.Problem(emptyCopy(tab), panel.meta), onReload)
                } else {
                    MatchGrid(panel.matches, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MatchGrid(matches: List<MatchItem>, modifier: Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(320.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        gridItemsIndexed(matches, key = { index, match -> "${match.id}-$index" }) { _, match ->
            MatchCard(match)
        }
    }
}

@Composable
private fun MatchCard(match: MatchItem) {
    val status = statusPresentation(match.status, match.minute)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CizgiSpace.radiusCard),
        color = SportsLight.Card,
        contentColor = SportsLight.Ink,
        border = BorderStroke(1.dp, SportsLight.Rule),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                if (status.live) LiveBadge(status.label) else Text(status.label, color = SportsLight.Muted, style = CizgiType.Meta)
                if (match.competitionName.isNotBlank()) {
                    Text(match.competitionName, color = SportsLight.Muted, style = CizgiType.Meta, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp).weight(1f))
                }
            }
            SideRow(match.home, scoreCell(match.score, home = true))
            SideRow(match.away, scoreCell(match.score, home = false))
            Text(
                if (match.localTime.isBlank()) "Saat yok · Europe/Istanbul" else "${match.localTime} TSİ · Europe/Istanbul",
                color = SportsLight.Muted,
                style = CizgiType.Meta,
            )
        }
    }
}

@Composable
private fun SideRow(side: Side, score: String) {
    Row(Modifier.fillMaxWidth().heightIn(min = CizgiSpace.touch), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Crest(side.crest, side.name)
        Text(side.name, color = SportsLight.Ink, style = CizgiType.Kart, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(score, color = SportsLight.Ink, style = CizgiType.Ekran)
    }
}

@Composable
private fun StandingTable(rows: List<StandingRow>, followed: (String) -> Boolean, onToggle: (String) -> Unit, modifier: Modifier) {
    LazyColumn(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                HeaderCell("#", Modifier.width(36.dp))
                HeaderCell("Takım", Modifier.weight(1.6f))
                HeaderCell("O", Modifier.weight(0.45f))
                HeaderCell("G", Modifier.weight(0.45f))
                HeaderCell("B", Modifier.weight(0.45f))
                HeaderCell("M", Modifier.weight(0.45f))
                HeaderCell("Av", Modifier.weight(0.45f))
                HeaderCell("P", Modifier.weight(0.45f))
                Box(Modifier.width(112.dp))
            }
        }
        itemsIndexed(rows, key = { index, row -> "${row.team.id}-${row.team.name}-$index" }) { _, row ->
            Surface(shape = RoundedCornerShape(CizgiSpace.radiusCard), color = SportsLight.Card, border = BorderStroke(1.dp, SportsLight.Rule)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(statCell(row.rank), color = SportsLight.Accent, style = CizgiType.Kart, modifier = Modifier.width(36.dp))
                    Row(Modifier.weight(1.6f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Crest(row.team.crest, row.team.name)
                        Text(row.team.name, color = SportsLight.Ink, style = CizgiType.Kart, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    }
                    Text(statCell(row.played), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    Text(statCell(row.won), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    Text(statCell(row.drawn), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    Text(statCell(row.lost), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    Text(diffCell(row.goalsDiff), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    Text(statCell(row.points), color = SportsLight.Ink, style = CizgiType.Meta, modifier = Modifier.weight(0.45f))
                    FollowButton(row.team.id, row.team.name, followed, onToggle)
                }
            }
        }
    }
}

@Composable
private fun StandingCards(rows: List<StandingRow>, followed: (String) -> Boolean, onToggle: (String) -> Unit, modifier: Modifier) {
    LazyColumn(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        itemsIndexed(rows, key = { index, row -> "card-${row.team.id}-${row.team.name}-$index" }) { _, row ->
            Surface(shape = RoundedCornerShape(CizgiSpace.radiusCard), color = SportsLight.Card, border = BorderStroke(1.dp, SportsLight.Rule)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(statCell(row.rank), color = SportsLight.Accent, style = CizgiType.Kart, modifier = Modifier.width(28.dp))
                        Crest(row.team.crest, row.team.name)
                        Text(row.team.name, color = SportsLight.Ink, style = CizgiType.Kart, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("O", statCell(row.played))
                        Stat("G", statCell(row.won))
                        Stat("B", statCell(row.drawn))
                        Stat("M", statCell(row.lost))
                        Stat("Av", diffCell(row.goalsDiff))
                        Stat("P", statCell(row.points))
                    }
                    FollowButton(row.team.id, row.team.name, followed, onToggle, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun TeamList(
    teams: List<TeamItem>,
    query: String,
    onQuery: (String) -> Unit,
    followed: (String) -> Boolean,
    onToggle: (String) -> Unit,
    onReload: () -> Unit,
    modifier: Modifier,
) {
    val shown = teams.filter { query.isBlank() || it.name.trContains(query) || it.shortName.orEmpty().trContains(query) }
        .sortedByDescending { team -> team.id?.let(followed) == true }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = CizgiType.Govde.copy(color = SportsLight.Ink),
            label = { Text("Takım ara") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SportsLight.Ink,
                unfocusedTextColor = SportsLight.Ink,
                focusedContainerColor = SportsLight.Card,
                unfocusedContainerColor = SportsLight.Card,
                cursorColor = SportsLight.Accent,
                focusedBorderColor = SportsLight.Accent,
                unfocusedBorderColor = SportsLight.Rule,
                focusedLabelColor = SportsLight.Muted,
                unfocusedLabelColor = SportsLight.Muted,
            ),
        )
        when {
            teams.isEmpty() -> ProblemBlock(SportsPanel.Problem("Bu lig için takım listesi yok."), onReload)
            shown.isEmpty() -> Note("Bu aramayla eşleşen takım yok.", failure = false)
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp), modifier = Modifier.weight(1f)) {
                itemsIndexed(shown, key = { index, team -> "${team.id}-${team.name}-$index" }) { _, team ->
                    Surface(shape = RoundedCornerShape(CizgiSpace.radiusCard), color = SportsLight.Card, border = BorderStroke(1.dp, SportsLight.Rule)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Crest(team.crest, team.name)
                            Column(Modifier.weight(1f)) {
                                Text(team.name, color = SportsLight.Ink, style = CizgiType.Kart, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (!team.venue.isNullOrBlank()) Text(team.venue, color = SportsLight.Muted, style = CizgiType.Meta)
                            }
                            FollowButton(team.id, team.name, followed, onToggle)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FollowButton(
    id: String?,
    name: String,
    followed: (String) -> Boolean,
    onToggle: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (id.isNullOrBlank()) return
    val on = followed(id)
    val label = if (on) "Takipte" else "Takip et"
    Button(
        onClick = { onToggle(id) },
        modifier = modifier.heightIn(min = CizgiSpace.touch).cizgiHedef(),
        shape = RoundedCornerShape(CizgiSpace.radiusControl),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
        border = if (on) null else BorderStroke(1.dp, SportsLight.Accent),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (on) SportsLight.Accent else SportsLight.Card,
            contentColor = if (on) SportsLight.OnAccent else SportsLight.Ink,
        ),
    ) {
        Text(label, style = CizgiType.Govde, maxLines = 1)
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = CizgiSpace.touch).cizgiHedef(),
        shape = RoundedCornerShape(999.dp),
        color = if (selected) SportsLight.Accent else SportsLight.Card,
        contentColor = if (selected) SportsLight.OnAccent else SportsLight.Ink,
        border = if (selected) null else BorderStroke(1.dp, SportsLight.Rule),
    ) {
        Box(Modifier.heightIn(min = CizgiSpace.touch).padding(horizontal = 14.dp), contentAlignment = Alignment.Center) {
            Text(label, style = CizgiType.Govde, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun TealButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.heightIn(min = CizgiSpace.touch).cizgiHedef(),
        shape = RoundedCornerShape(CizgiSpace.radiusControl),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = SportsLight.Accent, contentColor = SportsLight.OnAccent),
    ) {
        Text(label, style = CizgiType.Govde, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LiveBadge(text: String) {
    Surface(shape = RoundedCornerShape(999.dp), color = SportsLight.Gold, contentColor = SportsLight.OnAccent) {
        Text(text, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = CizgiType.Meta, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CountPill(count: Int) {
    val live = count > 0
    Box(
        Modifier.background(if (live) SportsLight.Gold else SportsLight.Crest, CircleShape).padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            count.toString(),
            color = if (live) CizgiColor.Navy else SportsLight.Ink,
            style = CizgiType.Meta,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun Crest(url: String?, name: String) {
    val safe = remember(url) { httpsCrest(url) }
    var image by remember(safe) { mutableStateOf(safe?.let(CrestImages::peek)) }
    LaunchedEffect(safe) {
        if (safe == null || image != null) return@LaunchedEffect
        val loaded = withContext(Dispatchers.IO) { CrestImages.load(safe) }
        image = loaded
    }
    if (image != null) {
        Image(image as ImageBitmap, contentDescription = null, modifier = Modifier.size(36.dp).clip(CircleShape))
    } else {
        val letter = name.trim().firstOrNull()?.toString()?.uppercase(java.util.Locale.forLanguageTag("tr-TR")) ?: "?"
        Box(Modifier.size(36.dp).clip(CircleShape).background(SportsLight.Crest), contentAlignment = Alignment.Center) {
            Text(letter, color = SportsLight.Ink, style = CizgiType.Kart)
        }
    }
}

@Composable
private fun Note(text: String, failure: Boolean) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CizgiSpace.radiusCard),
        color = if (failure) CizgiColor.OnErrorDark else SportsLight.Card,
        contentColor = if (failure) CizgiColor.ErrorDark else SportsLight.Ink,
        border = BorderStroke(1.dp, if (failure) CizgiColor.ErrorDark else SportsLight.Accent),
    ) {
        Text(text, modifier = Modifier.padding(12.dp).semantics { liveRegion = LiveRegionMode.Polite }, style = CizgiType.Govde)
    }
}

@Composable
private fun ProblemBlock(problem: SportsPanel.Problem, onReload: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Note(problem.text, failure = problem.failure)
        TealButton("Yenile", onReload)
    }
}

@Composable
private fun LoadingBlock() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Yükleniyor", color = SportsLight.Muted, style = CizgiType.Govde)
        CircularProgressIndicator(color = SportsLight.Accent)
    }
}

@Composable
private fun HeaderCell(text: String, modifier: Modifier) {
    Text(text, modifier = modifier, color = SportsLight.Muted, style = CizgiType.Meta, fontWeight = FontWeight.Bold)
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = SportsLight.Muted, style = CizgiType.Meta)
        Text(value, color = SportsLight.Ink, style = CizgiType.Kart)
    }
}

private suspend fun attempt(block: suspend () -> SportsPage): Attempt = try {
    Attempt.Page(block())
} catch (cancel: CancellationException) {
    throw cancel
} catch (error: Exception) {
    Attempt.Fail(error)
}

private data class LiveBoard(val count: Int?, val panel: SportsPanel)

private suspend fun loadLive(client: SportsClient, apiBase: String, competitionId: String?): LiveBoard {
    val live = attempt { client.matches(apiBase, competitionId, "live", null) }
    val liveError = (live as? Attempt.Fail)?.error
    if (liveError != null && liveError.hardStop()) {
        return LiveBoard(null, SportsPanel.Problem(humanFrom(liveError), failure = true))
    }
    val livePage = (live as? Attempt.Page)?.page
    val count = livePage?.matches?.size
    if (livePage != null && livePage.matches.isNotEmpty()) return LiveBoard(count, contentFrom(livePage, null))
    val today = attempt { client.matches(apiBase, competitionId, "today", istanbulToday()) }
    val todayPage = (today as? Attempt.Page)?.page
    if (todayPage != null && todayPage.matches.isNotEmpty()) {
        return LiveBoard(count, contentFrom(todayPage, "Şu an canlı maç yok. Bugünün fikstürü gösteriliyor."))
    }
    val upcoming = attempt { client.matches(apiBase, competitionId, "scheduled", null) }
    val upcomingPage = (upcoming as? Attempt.Page)?.page
    if (upcomingPage != null && upcomingPage.matches.isNotEmpty()) {
        return LiveBoard(count, contentFrom(upcomingPage, "Şu an canlı maç yok. Yaklaşan maçlar gösteriliyor."))
    }
    val finished = attempt { client.matches(apiBase, competitionId, "finished", null) }
    val finishedPage = (finished as? Attempt.Page)?.page
    if (finishedPage != null && finishedPage.matches.isNotEmpty()) {
        return LiveBoard(count, contentFrom(finishedPage, "Şu an canlı maç yok. Son sonuçlar gösteriliyor."))
    }
    val pages = listOfNotNull(livePage, todayPage, upcomingPage, finishedPage)
    val limitation = pages.firstNotNullOfOrNull { limitationText(it.meta) }
    val failure = listOf(live, today, upcoming, finished).firstNotNullOfOrNull { (it as? Attempt.Fail)?.error }
    val text = limitation ?: failure?.let(::humanFrom) ?: emptyCopy(SportsTab.Live)
    return LiveBoard(count, SportsPanel.Problem(text, pages.firstOrNull()?.meta, failure = failure != null && limitation == null))
}

private fun pagePanel(result: Attempt, tab: SportsTab): SportsPanel = when (result) {
    is Attempt.Fail -> SportsPanel.Problem(humanFrom(result.error), failure = true)
    is Attempt.Page -> {
        val page = result.page
        val empty = page.matches.isEmpty() && page.standings.isEmpty() && page.teams.isEmpty()
        if (empty) SportsPanel.Problem(limitationText(page.meta) ?: emptyCopy(tab), page.meta, failure = false)
        else contentFrom(page, null)
    }
}

private fun contentFrom(page: SportsPage, banner: String?): SportsPanel.Content {
    val notice = listOfNotNull(
        limitationText(page.meta),
        if (page.matches.size > MatchCap) "İlk 80 karşılaşma gösteriliyor." else null,
    ).joinToString(" ").ifBlank { null }
    return SportsPanel.Content(
        matches = page.matches.take(MatchCap),
        standings = page.standings,
        teams = page.teams,
        meta = page.meta,
        banner = banner,
        notice = notice,
        limited = page.meta.limited,
    )
}

private fun emptyCopy(tab: SportsTab): String = when (tab) {
    SportsTab.Today -> "Bu günde maç yok."
    SportsTab.Scheduled -> "Bu günde planlanmış maç yok."
    SportsTab.Finished -> "Bu günde sonuç yok."
    SportsTab.Standings -> "Bu lig için puan durumu yok."
    SportsTab.Teams -> "Bu lig için takım listesi yok."
    SportsTab.Live -> "Gösterilecek canlı maç, fikstür veya sonuç yok."
}

private fun Exception.hardStop(): Boolean {
    val status = (this as? SportsCallException)?.status ?: return false
    return status == 401 || status == 403 || status == 404 || status == 429
}
