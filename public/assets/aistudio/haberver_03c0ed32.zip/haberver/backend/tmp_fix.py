﻿from pathlib import Path
p = Path(r"C:\Users\edipbey\Desktop\haberver\backend\app\local\catalog.py")
t = p.read_text(encoding="utf-8")
wrong = '"Rory"'
right = '"Rize"'
# actually Rize:
right = '"Rize"'.replace("Rory", "Rize")
right = '"Rize"'
print(repr(wrong), "->", repr('"Rize"'))
t2 = t.replace('"Rory"', '"Rize"', 1)
t2 = t.replace('"Rory"', '"Rize"', 1)
