from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import NullPool, StaticPool


def make_engine(database_url: str):
    if database_url.startswith("sqlite"):
        # :memory: tek bağlantı; dosya DB'de StaticPool eşzamanlı isteklerde
        # sqlite3.InterfaceError / süreç çökmesine yol açar.
        memory = ":memory:" in database_url or database_url in {"sqlite://", "sqlite:///:memory:"}
        engine = create_engine(
            database_url,
            connect_args={"check_same_thread": False, "timeout": 30},
            poolclass=StaticPool if memory else NullPool,
            future=True,
        )

        @event.listens_for(engine, "connect")
        def _sqlite_pragma(dbapi_connection, _connection_record) -> None:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.close()

        return engine
    return create_engine(database_url, future=True, pool_pre_ping=True)


def make_session_factory(engine):
    return sessionmaker(bind=engine, autoflush=True, expire_on_commit=False, class_=Session)
