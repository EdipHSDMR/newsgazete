"""RSS/Atom ayrıştırıcı. XXE kapalıdır. Açıklama burada yayın kararı vermez."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import defusedxml.ElementTree as ET

from app.errors import FatalFetch


@dataclass
class ParsedItem:
    external_id: str
    link: str
    title: str
    description: str
    published_at: datetime | None
    date_error: str | None


def parse_feed(payload: bytes, *, max_bytes: int) -> list[ParsedItem]:
    if len(payload) > max_bytes:
        raise FatalFetch("Akış boyutu sınırını aştı.", "feed_too_large")
    lowered = payload[:400].lower()
    if b"<!doctype" in lowered or b"<!entity" in lowered:
        raise FatalFetch("XML dış varlık bildirimi reddedildi.", "feed_unsafe_xml")
    if lowered.lstrip().startswith(b"<html") or b"<html" in lowered[:200]:
        raise FatalFetch("HTML belgesi akış olarak kabul edilmez.", "feed_not_xml")
    try:
        root = ET.fromstring(payload)
    except ET.ParseError as exc:
        raise FatalFetch("XML ayrıştırılamadı.", "feed_invalid_xml") from exc
    tag = _local(root.tag)
    if tag == "rss":
        channel = _child(root, "channel")
        nodes = _children(channel, "item") if channel is not None else []
    elif tag == "feed":
        nodes = _children(root, "entry")
    else:
        raise FatalFetch("RSS veya Atom kökü bulunamadı.", "feed_invalid_xml")
    items: list[ParsedItem] = []
    for node in nodes:
        items.append(_item(node, atom=tag == "feed"))
    return items


def _item(node, *, atom: bool) -> ParsedItem:
    title = _text(node, "title")
    description = _text(node, "summary" if atom else "description")
    link = _atom_link(node) if atom else _text(node, "link")
    external = _text(node, "id" if atom else "guid") or link or title
    raw_date = _text(node, "updated" if atom else "pubDate") or _text(node, "published")
    published, date_error = _parse_date(raw_date)
    return ParsedItem(
        external_id=external.strip(),
        link=link.strip(),
        title=title.strip(),
        description=description.strip(),
        published_at=published,
        date_error=date_error,
    )


def _parse_date(raw: str) -> tuple[datetime | None, str | None]:
    if not raw:
        return None, "missing_date"
    try:
        if raw[:1].isdigit() and "T" in raw:
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        else:
            parsed = parsedate_to_datetime(raw)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc), None
    except (TypeError, ValueError, IndexError, OverflowError):
        return None, "malformed_date"


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _children(node, name: str):
    if node is None:
        return []
    wanted = name.lower()
    return [child for child in list(node) if _local(child.tag) == wanted]


def _child(node, name: str):
    found = _children(node, name)
    return found[0] if found else None


def _text(node, name: str) -> str:
    child = _child(node, name)
    if child is None or child.text is None:
        return ""
    return child.text


def _atom_link(node) -> str:
    for child in _children(node, "link"):
        rel = child.attrib.get("rel", "alternate")
        href = child.attrib.get("href", "")
        if rel == "alternate" and href:
            return href
    return ""
