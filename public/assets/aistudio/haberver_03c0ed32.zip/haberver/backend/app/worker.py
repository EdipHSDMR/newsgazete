"""Postgres kuyruğu. Aynı iş ikinci kez tek sonuç üretir."""

from __future__ import annotations

import uuid
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.errors import ApiError, FatalFetch, RetryableFetch
from app.ingest import run_ingest
from app.models import IngestJob, Source


def enqueue_job(session: Session, source_id: str, key: str, now) -> IngestJob:
    existing = session.scalar(select(IngestJob).where(IngestJob.idempotency_key == key))
    if existing:
        return existing
    job = IngestJob(
        id=str(uuid.uuid4()),
        source_id=source_id,
        idempotency_key=key,
        status="queued",
        attempt=0,
        max_attempts=5,
        next_run_at=now,
        created_at=now,
        updated_at=now,
    )
    session.add(job)
    session.commit()
    return job


def lease_next(session: Session, now, worker_id: str) -> IngestJob | None:
    stmt = (
        select(IngestJob)
        .where(IngestJob.status.in_(("queued", "retry")), IngestJob.next_run_at <= now)
        .order_by(IngestJob.next_run_at)
    )
    bind = session.get_bind()
    if bind is not None and bind.dialect.name == "postgresql":
        stmt = stmt.with_for_update(skip_locked=True)
    job = session.scalar(stmt)
    if job is None:
        return None
    job.status = "leased"
    job.leased_by = worker_id
    job.lease_until = now + timedelta(minutes=5)
    job.updated_at = now
    session.commit()
    return job


def execute_job(app, job_id: str, actor: str) -> dict:
    session = app.state.sessions()
    try:
        job = session.get(IngestJob, job_id)
        if job is None:
            raise ApiError(404, "not_found", "İş bulunamadı.", retryable=False)
        if job.status == "succeeded":
            return {"job_id": job.id, "status": job.status, "duplicate": True}
        source = session.get(Source, job.source_id)
        now = app.state.clock.now()
        if job.status in {"queued", "retry"}:
            job.status = "leased"
            job.leased_by = actor
            job.lease_until = now + timedelta(minutes=5)
            job.updated_at = now
            session.commit()
        try:
            result = run_ingest(
                session,
                source,
                app.state.settings,
                app.state.clock,
                app.state.metrics,
                actor=actor,
            )
        except RetryableFetch as exc:
            _retry(app, session, job_id, exc.message)
            raise
        except FatalFetch as exc:
            _dead(session, job_id, exc.code, app.state.clock.now())
            raise
        except ApiError as exc:
            _dead(session, job_id, exc.code, app.state.clock.now())
            raise
        job = session.get(IngestJob, job_id)
        job.status = "succeeded"
        job.last_error = None
        job.updated_at = app.state.clock.now()
        session.commit()
        return {"job_id": job_id, "status": "succeeded", "duplicate": False, **result}
    finally:
        session.close()


def _retry(app, session, job_id: str, message: str) -> None:
    job = session.get(IngestJob, job_id)
    job.attempt += 1
    job.last_error = message[:400]
    now = app.state.clock.now()
    if job.attempt >= job.max_attempts:
        job.status = "dead"
        app.state.metrics.parser_alerts += 1
    else:
        delay = min(3600, 30 * (2 ** (job.attempt - 1)))
        job.status = "retry"
        job.next_run_at = now + timedelta(seconds=delay)
    job.updated_at = now
    session.commit()


def _dead(session, job_id: str, code: str, now) -> None:
    job = session.get(IngestJob, job_id)
    job.status = "dead"
    job.last_error = code[:400]
    job.updated_at = now
    session.commit()


def run_once(app, worker_id: str = "worker") -> dict | None:
    session = app.state.sessions()
    try:
        job = lease_next(session, app.state.clock.now(), worker_id)
    finally:
        session.close()
    if job is None:
        return None
    try:
        return execute_job(app, job.id, worker_id)
    except ApiError as exc:
        return {"job_id": job.id, "status": "error", "code": exc.code}
