"""Poll the licensed PHA news API and publish new bulletins every five minutes."""

from __future__ import annotations

import argparse
import time

from app.clock import Clock
from app.config import Settings
from app.db import make_engine, make_session_factory
from app.demo.pha_sync import sync_bulletins
from app.logutil import safe_log
from app.models import Base
from app.runtime import Metrics

POLL_INTERVAL_SECONDS = 300


def sync_once(session_factory, settings: Settings) -> int:
    session = session_factory()
    try:
        added = sync_bulletins(session, settings, Clock(), Metrics())
        safe_log("pha_sync_complete", status="ok", code=f"added_{added}")
        return added
    except Exception as exc:
        session.rollback()
        safe_log("pha_sync_failed", status="error", code=type(exc).__name__)
        raise
    finally:
        session.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Sync licensed Press Haber Ajansı bulletins.")
    parser.add_argument("--once", action="store_true", help="Sync once, then exit.")
    args = parser.parse_args()

    settings = Settings()
    if not settings.pha_api_key:
        parser.error("PHA_API_KEY backend ortamında tanımlanmalı.")

    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session_factory = make_session_factory(engine)
    while True:
        try:
            sync_once(session_factory, settings)
        except Exception:
            if args.once:
                engine.dispose()
                return 1
        if args.once:
            engine.dispose()
            return 0
        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    raise SystemExit(main())
