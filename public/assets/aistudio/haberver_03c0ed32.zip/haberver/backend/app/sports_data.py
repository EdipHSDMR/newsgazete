"""Server-side, quota-conscious football data integration."""

from __future__ import annotations

import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

from app.config import Settings

BASE_URL = "https://v3.football.api-sports.io"
ISTANBUL = ZoneInfo("Europe/Istanbul")
FIXTURES_TTL = 20 * 60
STANDINGS_TTL = 3 * 60 * 60
SUPER_LIG_ID = 203


def sports_overview(settings: Settings, cache: dict, lock: threading.RLock) -> dict:
    if not settings.api_football_key:
        return {
            "configured": False,
            "provider": "API-Football",
            "provider_url": "https://www.api-football.com/",
            "notice": "Skor ve puan tablosunu açmak için sunucuda API_FOOTBALL_KEY tanımlanmalı. Haber akışı çalışmaya devam ediyor.",
            "matches": [],
            "standings": [],
            "updated_at": None,
            "refresh_minutes": 20,
        }

    now = datetime.now(ISTANBUL)
    season = now.year if now.month >= 7 else now.year - 1
    with lock:
        matches, match_time, match_stale = _cached_request(
            cache, f"matches:{now.date().isoformat()}", FIXTURES_TTL, settings.api_football_key,
            "/fixtures", {"league": SUPER_LIG_ID, "season": season, "date": now.date().isoformat(), "timezone": "Europe/Istanbul"},
        )
        standings, table_time, table_stale = _cached_request(
            cache, f"standings:{season}", STANDINGS_TTL, settings.api_football_key,
            "/standings", {"league": SUPER_LIG_ID, "season": season},
        )

    return {
        "configured": True,
        "provider": "API-Football",
        "provider_url": "https://www.api-football.com/",
        "notice": "Türkiye saatiyle bugünün karşılaşmaları. Ücretsiz API kotasını korumak için skorlar 20, puan tablosu 180 dakikada bir yenilenir.",
        "matches": [_match(row) for row in matches[:30]],
        "standings": _standings(standings),
        "updated_at": match_time,
        "standings_updated_at": table_time,
        "matches_available": match_time is not None,
        "standings_available": table_time is not None,
        "stale": match_stale or table_stale,
        "refresh_minutes": 20,
    }


def _cached_request(cache: dict, key: str, ttl: int, token: str, endpoint: str, params: dict):
    now = time.monotonic()
    entry = cache.get(key)
    if entry and now - entry["fetched"] < ttl:
        return entry["data"], entry["updated_at"], False
    try:
        response = httpx.get(
            f"{BASE_URL}{endpoint}",
            params=params,
            headers={"x-apisports-key": token, "Accept": "application/json"},
            timeout=8.0,
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("errors"):
            raise ValueError("provider_error")
        data = payload.get("response") or []
        fetched_at = datetime.now(ISTANBUL).isoformat(timespec="seconds")
        cache[key] = {"fetched": now, "updated_at": fetched_at, "data": data}
        return data, fetched_at, False
    except (httpx.HTTPError, ValueError, TypeError):
        if entry:
            return entry["data"], entry["updated_at"], True
        return [], None, False


def _match(row: dict) -> dict:
    fixture = row.get("fixture") or {}
    teams = row.get("teams") or {}
    goals = row.get("goals") or {}
    league = row.get("league") or {}
    status = fixture.get("status") or {}
    return {
        "id": fixture.get("id"),
        "competition": league.get("name") or "Futbol",
        "round": league.get("round"),
        "kickoff": fixture.get("date"),
        "status": status.get("short") or "NS",
        "status_label": status.get("long") or "Başlamadı",
        "minute": status.get("elapsed"),
        "home": (teams.get("home") or {}).get("name") or "Ev sahibi",
        "away": (teams.get("away") or {}).get("name") or "Deplasman",
        "home_score": goals.get("home"),
        "away_score": goals.get("away"),
    }


def _standings(payload: list) -> list[dict]:
    if not payload:
        return []
    league = (payload[0] or {}).get("league") or {}
    groups = league.get("standings") or []
    rows = groups[0] if groups else []
    return [{
        "rank": row.get("rank"),
        "team": (row.get("team") or {}).get("name") or "Takım",
        "played": (row.get("all") or {}).get("played"),
        "won": (row.get("all") or {}).get("win"),
        "drawn": (row.get("all") or {}).get("draw"),
        "lost": (row.get("all") or {}).get("lose"),
        "goals_diff": row.get("goalsDiff"),
        "points": row.get("points"),
        "form": row.get("form"),
    } for row in rows]
