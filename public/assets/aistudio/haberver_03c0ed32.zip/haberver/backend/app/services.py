"""Kaynak, izin, özet ve yayın. Otomatik yapay zeka yayını yoktur."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.audit import audit, move_source
from app.clock import Clock, as_utc
from app.config import Settings
from app.errors import ApiError
from app.models import (
    Complaint,
    Correction,
    Entitlement,
    LicenseGrant,
    PushOutbox,
    Source,
    SourceItem,
    Story,
    StorySource,
    SummaryVersion,
    Topic,
)
from app.rights import ENTITLEMENT_KEYS, active_grant, decide, entitlement_allowed
from app.runtime import Metrics
from app.state_machine import STORY_TRANSITIONS, transition
from app.urlsec import canonical_hash, canonicalize, host_allowed

TOPICS = (
    ("ulusal", "Türkiye", 1),
    ("dunya", "Dünya", 2),
    ("ekonomi", "Ekonomi", 3),
    ("bilim-teknoloji", "Bilim ve teknoloji", 4),
    ("iklim-cevre", "İklim ve çevre", 5),
    ("kultur", "Kültür ve yaşam", 6),
    ("spor", "Spor", 7),
    ("yerel", "Yerel", 8),
)


def ensure_topics(session: Session) -> None:
    for slug, name, order in TOPICS:
        row = session.scalar(select(Topic).where(Topic.slug == slug))
        if row is None:
            session.add(Topic(id=str(uuid.uuid4()), slug=slug, name=name, sort_order=order))
        else:
            row.name = name
            row.sort_order = order
    session.commit()


def create_source(session: Session, actor: str, now: datetime, data: dict) -> Source:
    source = Source(
        id=str(uuid.uuid4()),
        name=data["name"],
        domain=data["domain"].lower(),
        allowed_host=data["allowed_host"].lower(),
        feed_url=data["feed_url"],
        source_type=data["source_type"],
        status="candidate",
        editorial_description=data.get("editorial_description") or "",
        partnership_label=data.get("partnership_label"),
        partnership_note=data.get("partnership_note"),
        contact_email=data.get("contact_email"),
        terms_note=data.get("terms_note"),
        user_agent=data["user_agent"],
        rate_limit_per_minute=data.get("rate_limit_per_minute") or 6,
        timeout_seconds=data.get("timeout_seconds") or 10,
        synthetic=bool(data.get("synthetic")),
        created_at=now,
        updated_at=now,
    )
    if source.synthetic and source.source_type != "synthetic_fixture":
        raise ApiError(422, "validation", "Sentetik kayıt kendi türünde olmalıdır.", retryable=False)
    if source.partnership_label and not source.partnership_note:
        raise ApiError(422, "validation", "Ortaklık etiketi açıklama ister.", retryable=False)
    session.add(source)
    audit(session, actor=actor, role="source_admin", action="source_created", entity_type="source", entity_id=source.id, reason="aday kaynak", now=now)
    session.commit()
    return source


def verify_domain(session: Session, source: Source, actor: str, now: datetime) -> Source:
    host_allowed(f"https://{source.allowed_host}/", source.allowed_host)
    if source.domain != source.allowed_host:
        raise ApiError(422, "validation", "Alan adı ile izinli ana makine aynı olmalıdır.", retryable=False)
    move_source(source, "domain_verified")
    source.updated_at = now
    audit(session, actor=actor, role="source_admin", action="domain_verified", entity_type="source", entity_id=source.id, reason="alan adı biçimi doğrulandı; bu hukuki izin değildir", now=now)
    session.commit()
    return source


def add_grant(session: Session, source: Source, actor: str, now: datetime, data: dict, *, synthetic_allowed: bool) -> LicenseGrant:
    if data["kind"] == "synthetic_demo" and not (source.synthetic and synthetic_allowed):
        raise ApiError(403, "synthetic_blocked", "Sentetik demo kaydı bu kaynakta veya ortamda açılamaz.", retryable=False)
    if data["kind"] == "written_license" and source.synthetic:
        raise ApiError(422, "validation", "Sentetik kaynağa gerçek lisans yazılamaz.", retryable=False)
    version = session.scalar(select(func.max(LicenseGrant.version)).where(LicenseGrant.source_id == source.id)) or 0
    grant = LicenseGrant(
        id=str(uuid.uuid4()),
        source_id=source.id,
        version=version + 1,
        kind=data["kind"],
        document_ref=data["document_ref"],
        rights_holder=data["rights_holder"],
        signed_at=data.get("signed_at"),
        starts_at=data["starts_at"],
        expires_at=data["expires_at"],
        platform=data.get("platform") or "android",
        country=data.get("country") or "TR",
        purpose=data.get("purpose") or "editorial_discovery",
        attribution_required=True,
        attribution_text=data.get("attribution_text") or source.name,
        status="draft",
        created_by=actor,
        created_at=now,
    )
    if as_utc(grant.expires_at) <= as_utc(grant.starts_at):
        raise ApiError(422, "validation", "Bitiş, başlangıçtan sonra olmalıdır.", retryable=False)
    session.add(grant)
    if source.status == "domain_verified":
        move_source(source, "rights_review")
    source.updated_at = now
    audit(session, actor=actor, role="legal_reviewer", action="grant_drafted", entity_type="license_grant", entity_id=grant.id, reason="taslak izin; önceki sürüm silinmedi", now=now)
    session.commit()
    return grant


def set_entitlements(session: Session, grant: LicenseGrant, actor: str, now: datetime, rows: list[dict]) -> None:
    if grant.status not in {"draft", "active"}:
        raise ApiError(409, "invalid_transition", "Bu izin sürümü düzenlenemez.", retryable=False)
    seen = {row["key"] for row in rows}
    if set(ENTITLEMENT_KEYS) - seen:
        raise ApiError(422, "validation", "Bütün hak alanları açıkça true veya false yazılmalıdır.", retryable=False)
    for row in rows:
        if row["key"] not in ENTITLEMENT_KEYS:
            raise ApiError(422, "validation", "Bilinmeyen hak alanı.", retryable=False)
        current = session.scalar(
            select(Entitlement).where(
                Entitlement.grant_id == grant.id,
                Entitlement.key == row["key"],
                Entitlement.surface == "android",
            )
        )
        if current is None:
            session.add(
                Entitlement(
                    id=str(uuid.uuid4()),
                    grant_id=grant.id,
                    key=row["key"],
                    allowed=bool(row["allowed"]),
                    region=grant.country,
                    surface="android",
                    purpose=grant.purpose,
                )
            )
        else:
            current.allowed = bool(row["allowed"])
    source = session.get(Source, grant.source_id)
    if source and source.status == "rights_review":
        move_source(source, "scope_defined")
        source.updated_at = now
    audit(session, actor=actor, role="legal_reviewer", action="entitlements_set", entity_type="license_grant", entity_id=grant.id, reason="alan bazlı izin", now=now)
    session.commit()


def activate_grant(session: Session, grant: LicenseGrant, actor: str, now: datetime) -> None:
    rows = session.scalars(select(Entitlement).where(Entitlement.grant_id == grant.id)).all()
    if {row.key for row in rows} != set(ENTITLEMENT_KEYS):
        raise ApiError(422, "validation", "İzin aktive edilmeden kapsam eksik.", retryable=False)
    previous = session.scalars(
        select(LicenseGrant).where(LicenseGrant.source_id == grant.source_id, LicenseGrant.status == "active")
    ).all()
    for old in previous:
        old.status = "superseded"
    grant.status = "active"
    grant.supersedes_id = previous[-1].id if previous else None
    source = session.get(Source, grant.source_id)
    if source:
        source.legal_approved_by = actor
        source.legal_approved_at = now
        source.updated_at = now
        if source.status == "scope_defined":
            move_source(source, "testing")
    audit(session, actor=actor, role="legal_reviewer", action="grant_activated", entity_type="license_grant", entity_id=grant.id, reason="hukuk onayı; eski sürüm saklandı", now=now)
    session.commit()


def mark_source_live(session: Session, source: Source, actor: str, now: datetime, *, mode: str) -> None:
    if source.legal_approved_by is None or source.legal_approved_at is None:
        raise ApiError(409, "approval_required", "Hukuk onayı olmadan kaynak açılamaz.", retryable=False)
    if actor == source.legal_approved_by:
        raise ApiError(409, "approval_required", "Kaynak onayı, hukuk onayını veren kişiden farklı olmalıdır.", retryable=False)
    grant = active_grant(session, source, now)
    if grant is None or not entitlement_allowed(session, grant, "link"):
        raise ApiError(403, "rights_blocked", "Bağlantı izni olmadan kaynak açılamaz.", retryable=False)
    if source.status in {"scope_defined", "testing"}:
        move_source(source, "approved")
    if mode == "canary":
        move_source(source, "canary")
    elif mode == "active":
        if source.status == "approved":
            move_source(source, "canary")
        move_source(source, "active")
    else:
        raise ApiError(422, "validation", "Mod canary veya active olmalıdır.", retryable=False)
    source.source_admin_approved_by = actor
    source.source_admin_approved_at = now
    source.updated_at = now
    audit(session, actor=actor, role="source_admin", action="source_live", entity_type="source", entity_id=source.id, reason=mode, now=now)
    session.commit()


def create_story(session: Session, actor: str, now: datetime, data: dict, *, synthetic_allowed: bool) -> Story:
    item = session.get(SourceItem, data["source_item_id"])
    if item is None or item.status != "editorial_review":
        raise ApiError(409, "invalid_transition", "Özet yalnız incelemedeki kayıt için yazılır.", retryable=False)
    source = session.get(Source, item.source_id)
    if source is None:
        raise ApiError(404, "not_found", "Kaynak bulunamadı.", retryable=False)
    existing_link = session.scalar(
        select(StorySource).where(StorySource.source_item_id == item.id, StorySource.removed_at.is_(None))
    )
    if existing_link:
        raise ApiError(409, "duplicate", "Kayıt zaten bir hikayeye bağlı.", retryable=False)
    if item.synthetic and not synthetic_allowed:
        raise ApiError(403, "synthetic_blocked", "Sentetik kayıt bu ortamda kapalı.", retryable=False)
    _reject_copy(data["editorial_title"], data["editorial_summary"], item)
    if data["ai_assisted"] and not (data.get("ai_role_note") or "").strip():
        raise ApiError(422, "validation", "Yapay zeka kullanıldıysa rolü yazılmalıdır. Otomatik yayın yok.", retryable=False)
    topic = session.scalar(select(Topic).where(Topic.slug == data["topic_slug"]))
    if topic is None:
        raise ApiError(422, "validation", "Konu taksonomide yok.", retryable=False)
    story = Story(
        id=str(uuid.uuid4()),
        editorial_title=data["editorial_title"].strip(),
        editorial_summary=data["editorial_summary"].strip(),
        context_note=(data.get("context_note") or "").strip(),
        topic_id=topic.id,
        authorship_label="Editoryal özet",
        editor_actor=actor,
        verification_note=data["verification_note"].strip(),
        published_at=None,
        updated_at=now,
        status="editorial_review",
        synthetic=item.synthetic,
        single_source_note="Bu özette tek kaynak var.",
        developing=bool(data.get("developing")),
        uncertainty_note=data.get("uncertainty_note"),
        last_verified_at=now,
        risk_level=data.get("risk_level") or "normal",
        content_warning=data.get("content_warning"),
        editor_priority=data.get("editor_priority") or 0,
        ranking_reason="editör önceliği, sonra yayın zamanı" if (data.get("editor_priority") or 0) else "yayın zamanı, sonra kimlik",
        ai_assisted=bool(data.get("ai_assisted")),
        ai_role_note=data.get("ai_role_note"),
        created_at=now,
    )
    session.add(story)
    session.add(
        SummaryVersion(
            id=str(uuid.uuid4()),
            story_id=story.id,
            editorial_title=story.editorial_title,
            editorial_summary=story.editorial_summary,
            context_note=story.context_note,
            author=actor,
            reason="ilk editoryal özet",
            ai_assisted=story.ai_assisted,
            created_at=now,
        )
    )
    session.add(
        StorySource(
            id=str(uuid.uuid4()),
            story_id=story.id,
            source_item_id=item.id,
            added_by=actor,
            added_at=now,
        )
    )
    audit(session, actor=actor, role="editor", action="story_drafted", entity_type="story", entity_id=story.id, reason=story.verification_note, now=now)
    session.commit()
    return story


def second_approve(session: Session, story: Story, actor: str, now: datetime) -> None:
    if story.risk_level != "high":
        raise ApiError(409, "invalid_transition", "İkinci onay yalnız yüksek riskte gerekir.", retryable=False)
    if actor == story.editor_actor:
        raise ApiError(409, "approval_required", "İkinci onay farklı bir editörden gelmelidir.", retryable=False)
    story.second_approver = actor
    story.updated_at = now
    audit(session, actor=actor, role="editor", action="second_approval", entity_type="story", entity_id=story.id, reason="yüksek risk ikinci göz", now=now)
    session.commit()


def publish_story(
    session: Session,
    story: Story,
    actor: str,
    now: datetime,
    settings: Settings,
    metrics: Metrics,
    *,
    send_push: bool,
) -> Story:
    if story.synthetic and not settings.synthetic_allowed:
        raise ApiError(403, "synthetic_blocked", "Sentetik hikaye bu ortamda yayınlanamaz.", retryable=False)
    if not story.editor_actor or not story.verification_note.strip():
        raise ApiError(422, "validation", "Yayın için editör ve doğrulama notu zorunludur.", retryable=False)
    if story.risk_level == "high" and not story.second_approver:
        raise ApiError(409, "approval_required", "Yüksek riskli içerik ikinci onay olmadan yayınlanamaz.", retryable=False)
    members = _active_members(session, story.id)
    if not members:
        raise ApiError(422, "validation", "Yayın için en az bir kaynak gerekir.", retryable=False)
    expiries: list[datetime] = []
    for item, source in members:
        if item.published_at is None or not item.canonical_url:
            raise ApiError(422, "validation", "Tarihi veya bağlantısı olmayan kayıt yayınlanamaz.", retryable=False)
        if source.status not in {"canary", "active"}:
            raise ApiError(403, "source_not_live", "Kaynak yayında değil.", retryable=False)
        grant = active_grant(session, source, now)
        if grant is None or not entitlement_allowed(session, grant, "link"):
            metrics.rights_blocks += 1
            raise ApiError(403, "rights_blocked", "Kaynağın bağlantı izni yok.", retryable=False)
        for key in ("link", "metadata", "source_title", "excerpt", "image", "logo", "push_quote"):
            decide(session, source, key, now, actor, synthetic_allowed=settings.synthetic_allowed, item_id=item.id)
        expiries.append(as_utc(grant.expires_at))
        transition(item.status, "published", {"editorial_review": {"published"}, "published": {"published"}})
        item.status = "published"
        item.updated_at = now
    transition(story.status, "published", STORY_TRANSITIONS)
    story.status = "published"
    story.published_at = story.published_at or now
    story.updated_at = now
    story.last_verified_at = now
    story.rights_expires_at = min(expiries)
    story.single_source_note = "Bu özette tek kaynak var." if len(members) == 1 else None
    if send_push:
        _queue_push(session, story, members, now, metrics)
    audit(session, actor=actor, role="editor", action="story_published", entity_type="story", entity_id=story.id, reason=story.verification_note, now=now)
    session.commit()
    return story


def correct_story(session: Session, story: Story, actor: str, now: datetime, data: dict, *, synthetic_allowed: bool) -> Story:
    if story.status not in {"published", "corrected"}:
        raise ApiError(409, "invalid_transition", "Düzeltme yayınlanmış hikaye için yapılır.", retryable=False)
    item = _active_members(session, story.id)[0][0]
    _reject_copy(data["editorial_title"], data["editorial_summary"], item)
    previous = session.scalar(
        select(SummaryVersion).where(SummaryVersion.story_id == story.id).order_by(SummaryVersion.created_at.desc())
    )
    version = SummaryVersion(
        id=str(uuid.uuid4()),
        story_id=story.id,
        editorial_title=data["editorial_title"].strip(),
        editorial_summary=data["editorial_summary"].strip(),
        context_note=(data.get("context_note") or story.context_note).strip(),
        author=actor,
        reason=data["reason"].strip(),
        ai_assisted=False,
        created_at=now,
    )
    session.add(version)
    session.add(
        Correction(
            id=str(uuid.uuid4()),
            story_id=story.id,
            summary_version_id=version.id,
            previous_summary_version_id=previous.id if previous else None,
            reason=data["reason"].strip(),
            editor=actor,
            public=True,
            created_at=now,
        )
    )
    transition(story.status, "corrected", STORY_TRANSITIONS)
    story.status = "corrected"
    story.editorial_title = version.editorial_title
    story.editorial_summary = version.editorial_summary
    story.context_note = version.context_note
    story.updated_at = now
    if story.synthetic and not synthetic_allowed:
        raise ApiError(403, "synthetic_blocked", "Sentetik kayıt bu ortamda kapalı.", retryable=False)
    audit(session, actor=actor, role="editor", action="story_corrected", entity_type="story", entity_id=story.id, reason=data["reason"], now=now)
    session.commit()
    return story


def withdraw_story(session: Session, story: Story, actor: str, role: str, now: datetime, reason: str) -> None:
    if not reason.strip():
        raise ApiError(422, "validation", "Geri çekme gerekçesi zorunludur.", retryable=False)
    if story.status not in {"withdrawn"}:
        transition(story.status, "withdrawn", STORY_TRANSITIONS)
    story.status = "withdrawn"
    story.updated_at = now
    for item, _source in _active_members(session, story.id):
        if item.status in {"published", "corrected", "editorial_review"}:
            item.status = "withdrawn"
            item.updated_at = now
    _cancel_push(session, story.id, "hikaye geri çekildi")
    audit(session, actor=actor, role=role, action="story_withdrawn", entity_type="story", entity_id=story.id, reason=reason, now=now)
    session.commit()


def add_member(session: Session, story: Story, item_id: str, actor: str, now: datetime, settings: Settings) -> None:
    item = session.get(SourceItem, item_id)
    if item is None:
        raise ApiError(404, "not_found", "Kayıt bulunamadı.", retryable=False)
    source = session.get(Source, item.source_id)
    grant = active_grant(session, source, now) if source else None
    if grant is None or not entitlement_allowed(session, grant, "link"):
        raise ApiError(403, "rights_blocked", "Üyelik, kaydın kendi iznini taşımaz ve bu kayıtta bağlantı izni yok.", retryable=False)
    if item.published_at is None or not item.canonical_url:
        raise ApiError(422, "validation", "Üye kaydın tarihi ve bağlantısı olmalıdır.", retryable=False)
    existing = session.scalar(
        select(StorySource).where(
            StorySource.story_id == story.id,
            StorySource.source_item_id == item.id,
            StorySource.removed_at.is_(None),
        )
    )
    if existing:
        raise ApiError(409, "duplicate", "Kayıt zaten bu hikayede.", retryable=False)
    session.add(
        StorySource(
            id=str(uuid.uuid4()),
            story_id=story.id,
            source_item_id=item.id,
            added_by=actor,
            added_at=now,
        )
    )
    story.single_source_note = None
    story.updated_at = now
    audit(session, actor=actor, role="editor", action="cluster_added", entity_type="story", entity_id=story.id, reason=item.id, now=now, metadata={"source_item_id": item.id})
    session.commit()


def remove_member(session: Session, story: Story, item_id: str, actor: str, now: datetime) -> None:
    link = session.scalar(
        select(StorySource).where(
            StorySource.story_id == story.id,
            StorySource.source_item_id == item_id,
            StorySource.removed_at.is_(None),
        )
    )
    if link is None:
        raise ApiError(404, "not_found", "Üyelik bulunamadı.", retryable=False)
    link.removed_at = now
    link.removed_by = actor
    session.flush()
    remaining = _active_members(session, story.id)
    story.single_source_note = "Bu özette tek kaynak var." if len(remaining) == 1 else None
    story.updated_at = now
    audit(session, actor=actor, role="editor", action="cluster_removed", entity_type="story", entity_id=story.id, reason=item_id, now=now)
    session.commit()


def manual_item(session: Session, actor: str, now: datetime, data: dict, settings: Settings) -> SourceItem:
    note = (data.get("observed_facts") or "").strip()
    if len(note) > 500:
        raise ApiError(422, "validation", "Gözlem notu kısa olmalıdır; makale gövdesi kaydedilmez.", retryable=False)
    source = session.get(Source, data["source_id"])
    if source is None or source.status not in {"canary", "active"}:
        raise ApiError(409, "source_not_live", "Manuel kayıt yalnız açık kaynakta tutulur.", retryable=False)
    try:
        host_allowed(data["url"], source.allowed_host)
        canonical = canonicalize(data["url"])
        digest = canonical_hash(data["url"])
    except ApiError as exc:
        raise ApiError(422, "url_blocked", exc.message, retryable=False) from exc
    grant = active_grant(session, source, now)
    if grant is None or not entitlement_allowed(session, grant, "link"):
        raise ApiError(403, "rights_blocked", "Bağlantı izni yok.", retryable=False)
    item = SourceItem(
        id=str(uuid.uuid4()),
        source_id=source.id,
        external_id=data["external_id"],
        canonical_url=canonical,
        original_url=data["url"],
        canonical_hash=digest,
        source_title="",
        source_description="",
        published_at=data["published_at"],
        fetched_at=now,
        locale=settings.default_locale,
        content_hash=digest,
        status="editorial_review",
        grant_id=grant.id,
        synthetic=source.synthetic,
        created_at=now,
        updated_at=now,
    )
    session.add(item)
    audit(session, actor=actor, role="editor", action="manual_item", entity_type="source_item", entity_id=item.id, reason=note or "manuel kayıt", now=now)
    session.commit()
    return item


def takedown(session: Session, actor: str, role: str, now: datetime, data: dict) -> Complaint:
    complaint = Complaint(
        id=str(uuid.uuid4()),
        story_id=data.get("story_id"),
        source_id=data.get("source_id"),
        url=data.get("url") or "",
        claim=data["claim"],
        received_at=now,
        status="hidden",
        decision="temporarily_hidden",
        decision_reason=data["claim"],
        decided_by=actor,
        decided_at=now,
    )
    session.add(complaint)
    if data.get("story_id"):
        story = session.get(Story, data["story_id"])
        if story and story.status != "withdrawn":
            withdraw_story(session, story, actor, role, now, data["claim"])
    if data.get("source_id"):
        source = session.get(Source, data["source_id"])
        if source and source.status != "suspended":
            if source.status in {"active", "canary"}:
                move_source(source, "suspended")
            source.paused_reason = "itiraz üzerine durduruldu"
            source.updated_at = now
    audit(session, actor=actor, role=role, action="takedown", entity_type="complaint", entity_id=complaint.id, reason=data["claim"], now=now)
    session.commit()
    return complaint


def expire_due(session: Session, now: datetime, metrics: Metrics) -> int:
    changed = 0
    grants = session.scalars(select(LicenseGrant).where(LicenseGrant.status == "active")).all()
    for grant in grants:
        if as_utc(grant.expires_at) <= now:
            grant.status = "expired"
            changed += 1
            audit(session, actor="system", role="system", action="grant_expired", entity_type="license_grant", entity_id=grant.id, reason="süre doldu", now=now)
    stories = session.scalars(select(Story).where(Story.status.in_(("published", "corrected")))).all()
    for story in stories:
        if story.rights_expires_at and as_utc(story.rights_expires_at) <= now:
            story.status = "expired"
            story.updated_at = now
            _cancel_push(session, story.id, "izin süresi doldu")
            changed += 1
            continue
        members = _active_members(session, story.id)
        live = False
        for item, source in members:
            grant = active_grant(session, source, now)
            if grant and entitlement_allowed(session, grant, "link"):
                live = True
                break
        if members and not live:
            story.status = "expired"
            story.updated_at = now
            _cancel_push(session, story.id, "izin kalmadı")
            changed += 1
    if changed:
        metrics.cache_purges += 1
        session.commit()
    return changed


def _active_members(session: Session, story_id: str) -> list[tuple[SourceItem, Source]]:
    links = session.scalars(
        select(StorySource).where(StorySource.story_id == story_id, StorySource.removed_at.is_(None))
    ).all()
    rows = []
    for link in links:
        item = session.get(SourceItem, link.source_item_id)
        source = session.get(Source, item.source_id) if item else None
        if item and source:
            rows.append((item, source))
    return rows


def _cancel_push(session: Session, story_id: str, reason: str) -> None:
    rows = session.scalars(select(PushOutbox).where(PushOutbox.story_id == story_id)).all()
    for row in rows:
        if row.status in {"eligible", "skipped_no_provider"}:
            row.status = "cancelled"
            row.reason = reason


def _queue_push(session, story: Story, members, now: datetime, metrics: Metrics) -> None:
    raw_titles = {item.source_title for item, _source in members}
    if story.editorial_title in raw_titles:
        return
    key = f"story:{story.id}:publish"
    if session.scalar(select(PushOutbox).where(PushOutbox.dedupe_key == key)):
        metrics.push_duplicates += 1
        return
    session.add(
        PushOutbox(
            id=str(uuid.uuid4()),
            story_id=story.id,
            dedupe_key=key,
            title=story.editorial_title[:180],
            body=story.editorial_summary[:220],
            deep_link=f"haberver://story/{story.id}",
            status="skipped_no_provider",
            reason="FCM projesi TBD; gönderim yapılmadı",
            created_at=now,
        )
    )


def _reject_copy(title: str, summary: str, item: SourceItem) -> None:
    def norm(value: str) -> str:
        return " ".join((value or "").casefold().split())

    if norm(title) == norm(item.source_title) and norm(title):
        raise ApiError(422, "not_original", "Başlık, kaynak başlığının kopyası olamaz.", retryable=False)
    blob = norm(summary)
    for raw in (item.source_title, item.source_description):
        text = norm(raw)
        if len(text) >= 40 and text in blob:
            raise ApiError(422, "not_original", "Özet, kaynak metnini olduğu gibi taşımamalıdır.", retryable=False)
        words = text.split()
        if len(words) >= 8 and " ".join(words[:8]) in blob:
            raise ApiError(422, "not_original", "Özet, kaynak cümlesini yakın biçimde tekrar etmemelidir.", retryable=False)


def review_backlog(session: Session) -> int:
    items = session.scalar(select(func.count()).select_from(SourceItem).where(SourceItem.status == "editorial_review")) or 0
    stories = session.scalar(select(func.count()).select_from(Story).where(Story.status == "editorial_review")) or 0
    return int(items + stories)
