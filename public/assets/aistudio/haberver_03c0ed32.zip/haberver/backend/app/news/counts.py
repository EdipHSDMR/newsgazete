"""Canlı akışta sayılabilecek kayıtlar. GET /v1/feed gövdesine yazılmaz."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models import Source, SourceItem, Story, StorySource
from app.news.dedupe import suppressed_duplicate_ids

PUBLIC_STATUSES = ("published", "corrected")

PROVIDER_NOTE = (
    "stored_public: üretim kurallarıyla canlı akışa girebilecek kayıt sayısı "
    "(yayınlanmış veya düzeltilmiş, hak süresi dolmamış, sentetik değil, sentetik kaynağa bağlı değil, "
    "newsapi.org geliştirici kaydı değil; aynı canonical URL veya external id bir kez sayılır). "
    "Geliştirme ortamında sentetik demo tohumu akışta kalabilir; bu sayıya girmez. "
    "NewsAPI /v2/everything geliştirici planında sayfa 2 HTTP 426 döndürür; yalnız sayfa 1 ve en fazla 100 sonuç istenir, sayfa 2 yenilenmez. "
    "Spot yalnızca kaynağın description veya bülten özetidir. Tam makale HTML'i, kazıma, paywall aşma ve AI özeti yoktur. "
    "Bu nesne GET /v1/feed yanıtına zorunlu alan olarak eklenmez."
)


def live_feed_clauses(now: datetime, *, hide_synthetic: bool, hide_newsapi: bool) -> list:
    """Yayınlanmış ve hakkı süren kayıtlar. Sentetik kural yalnız istenirse uygulanır."""
    clauses = [
        Story.status.in_(PUBLIC_STATUSES),
        or_(Story.rights_expires_at.is_(None), Story.rights_expires_at > now),
    ]
    if hide_synthetic:
        clauses.append(Story.synthetic.is_(False))
        clauses.append(~_member_exists(Source.synthetic.is_(True)))
    if hide_newsapi:
        clauses.append(~_member_exists(Source.domain == "newsapi.org"))
    return clauses


def count_stored_public(session: Session, now: datetime | None = None) -> int:
    moment = now or datetime.now(timezone.utc)
    clauses = live_feed_clauses(moment, hide_synthetic=True, hide_newsapi=True)
    hidden = suppressed_duplicate_ids(session, clauses)
    stmt = select(func.count(Story.id)).where(*clauses)
    if hidden:
        stmt = stmt.where(Story.id.notin_(tuple(hidden)))
    return int(session.scalar(stmt) or 0)


def _member_exists(condition):
    return (
        select(StorySource.id)
        .join(SourceItem, StorySource.source_item_id == SourceItem.id)
        .join(Source, SourceItem.source_id == Source.id)
        .where(
            StorySource.story_id == Story.id,
            StorySource.removed_at.is_(None),
            condition,
        )
        .exists()
    )
