"""Akış yardımcıları. GET /v1/feed sözleşmesi CONTRACT.md içindedir."""
