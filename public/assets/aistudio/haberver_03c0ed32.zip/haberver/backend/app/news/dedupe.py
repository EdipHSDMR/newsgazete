"""Aynı canonical URL veya external id tekrarını düşürür.

Okuma sırası akışla aynıdır: editor_priority azalan, published_at azalan, id azalan.
İlk kayıt kalır. Bir hikaye kendi üyeleri yüzünden tekrar sayılmaz.
Bu süzgeç imleçten önce uygulanır; imleç biçimi değişmez.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.errors import ApiError
from app.models import SourceItem, Story, StorySource
from app.urlsec import canonicalize


class HeadlineIndex:
    """Ingest sırasında canonical URL, hash ve external id kimliği."""

    def __init__(self) -> None:
        self.external_ids: set[str] = set()
        self.urls: set[str] = set()
        self.hashes: set[str] = set()

    def absorb(self, *, external_id: str, canonical_url: str, canonical_hash: str) -> None:
        if external_id:
            self.external_ids.add(external_id)
        if canonical_hash:
            self.hashes.add(canonical_hash)
        self.urls.update(_url_forms(canonical_url))

    def contains(
        self,
        *,
        external_id: str = "",
        canonical_url: str = "",
        canonical_hash: str = "",
        aliases: tuple[str, ...] = (),
    ) -> bool:
        if canonical_hash and canonical_hash in self.hashes:
            return True
        for key in (external_id, *aliases):
            if key and (key in self.external_ids or key in self.hashes):
                return True
        return any(form in self.urls for form in _url_forms(canonical_url))

    @classmethod
    def from_session(cls, session: Session) -> HeadlineIndex:
        index = cls()
        rows = session.execute(
            select(SourceItem.external_id, SourceItem.canonical_url, SourceItem.canonical_hash)
        ).all()
        for external_id, canonical_url, canonical_hash in rows:
            index.absorb(
                external_id=external_id or "",
                canonical_url=canonical_url or "",
                canonical_hash=canonical_hash or "",
            )
        return index


def suppressed_duplicate_ids(session: Session, visibility: Sequence[object]) -> set[str]:
    """Görünür akışta daha öndeki bir hikayeyle aynı kimliği taşıyan id'ler."""
    rows = session.execute(
        select(
            Story.id,
            SourceItem.canonical_url,
            SourceItem.canonical_hash,
            SourceItem.external_id,
        )
        .join(StorySource, StorySource.story_id == Story.id)
        .join(SourceItem, SourceItem.id == StorySource.source_item_id)
        .where(*visibility, StorySource.removed_at.is_(None))
        .order_by(Story.editor_priority.desc(), Story.published_at.desc(), Story.id.desc())
    ).all()
    grouped: dict[str, list[tuple[str, str, str]]] = {}
    order: list[str] = []
    for story_id, canonical_url, canonical_hash, external_id in rows:
        if story_id not in grouped:
            order.append(story_id)
            grouped[story_id] = []
        grouped[story_id].append((canonical_url or "", canonical_hash or "", external_id or ""))
    seen_urls: dict[str, str] = {}
    seen_external: dict[str, str] = {}
    suppressed: set[str] = set()
    for story_id in order:
        urls: set[str] = set()
        externals: set[str] = set()
        for canonical_url, canonical_hash, external_id in grouped[story_id]:
            urls.update(_url_keys(canonical_url, canonical_hash))
            if external_id.strip():
                externals.add(external_id.strip())
        repeated = any(seen_urls.get(key, story_id) != story_id for key in urls) or any(
            seen_external.get(key, story_id) != story_id for key in externals
        )
        if repeated:
            suppressed.add(story_id)
            continue
        for key in urls:
            seen_urls.setdefault(key, story_id)
        for key in externals:
            seen_external.setdefault(key, story_id)
    return suppressed


def _canonical_form(url: str) -> str | None:
    try:
        return canonicalize(url)
    except ApiError:
        return None


def _url_forms(url: str) -> set[str]:
    raw = (url or "").strip()
    if not raw:
        return set()
    forms = {raw}
    folded = _canonical_form(raw)
    if folded:
        forms.add(folded)
    return forms


def _url_keys(canonical_url: str, canonical_hash: str) -> set[str]:
    keys: set[str] = set()
    if canonical_hash.strip():
        keys.add("h:" + canonical_hash.strip())
    for form in _url_forms(canonical_url):
        keys.add("u:" + form)
    return keys
