# Akış envanteri sözleşmesi

`GET /v1/feed` gövdesi değişmez. `data.items` mevcut `StoryCard` alanlarıdır; `data.next_cursor` aynı imleçtir. `stored_public` ve `provider_note` bu yanıta zorunlu alan olarak eklenmez.

Entegrasyon route'u şu fonksiyonu kullanır:

```python
from app.reading import feed_inventory

feed_inventory(session) -> {"stored_public": int, "provider_note": str}
```

- `stored_public`: üretim kurallarıyla canlı akışa girebilecek tekil hikaye sayısı. Durum `published` veya `corrected`, `rights_expires_at` boş ya da gelecekte, `synthetic` değil, aktif üyesi sentetik kaynak değil, aktif üyesi `newsapi.org` değil. Aynı canonical URL veya external id bir kez sayılır.
- `provider_note`: sabit açıklama (`app.news.counts.PROVIDER_NOTE`). Anahtar, kota değeri veya makale gövdesi içermez.
- Geliştirme ortamında sentetik demo tohumu, `synthetic_allowed` açıksa akışta kalır ve `stored_public` içine girmez. Bu kural gevşetilmez.
- Sayfalama imleci `base64(editor_priority|published_at|id)` olarak kalır. Tekrar düşürme imleçten önce uygulanır.

Yardımcılar:

- `app.news.dedupe.suppressed_duplicate_ids`
- `app.news.dedupe.HeadlineIndex`
- `app.news.counts.count_stored_public`
- `app.news.counts.live_feed_clauses`

NewsAPI geliştirici planı: `GET /v2/everything` sayfa 2 HTTP 426 döndürür. İstemci yalnız sayfa 1 ve en fazla 100 sonuç ister; 426 sonrası sayfa artırılmaz ve aynı sayfa yenilenmez. Spot yalnızca kaynak `description` veya bülten özetidir. Tam makale HTML'i, kazıma, paywall aşma ve AI özeti yoktur. Görsel yalnız `https` adresiyse saklanır ve okumada image izni varsa döner.
