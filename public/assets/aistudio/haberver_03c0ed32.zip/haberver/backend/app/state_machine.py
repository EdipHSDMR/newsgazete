from app.errors import ApiError

ITEM_TRANSITIONS: dict[str, set[str]] = {
    "candidate": {"quarantined", "needs_rights", "editorial_review"},
    "quarantined": {"needs_rights", "editorial_review", "candidate"},
    "needs_rights": {"editorial_review", "quarantined", "expired"},
    "editorial_review": {"published", "quarantined", "needs_rights", "withdrawn"},
    "published": {"corrected", "withdrawn", "expired", "editorial_review"},
    "corrected": {"published", "withdrawn", "expired"},
    "withdrawn": {"editorial_review"},
    "expired": {"needs_rights", "editorial_review"},
    "scheduled": {"published", "editorial_review", "withdrawn"},
}

STORY_TRANSITIONS: dict[str, set[str]] = {
    "editorial_review": {"scheduled", "published", "quarantined", "needs_rights", "withdrawn"},
    "scheduled": {"published", "editorial_review", "withdrawn"},
    "published": {"corrected", "withdrawn", "expired"},
    "corrected": {"published", "corrected", "withdrawn", "expired"},
    "withdrawn": {"editorial_review"},
    "expired": {"needs_rights", "editorial_review"},
    "quarantined": {"editorial_review"},
    "needs_rights": {"editorial_review", "expired"},
}


def transition(current: str, target: str, table: dict[str, set[str]]) -> None:
    allowed = table.get(current, set())
    if target not in allowed:
        raise ApiError(
            409,
            "invalid_transition",
            f"Durum geçişi kabul edilmedi: {current} -> {target}.",
            retryable=False,
        )
