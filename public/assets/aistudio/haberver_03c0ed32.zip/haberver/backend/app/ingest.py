"""Onaylı kaynağın akışını normalize eder. HTML sayfası çekilmez."""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urljoin, urlparse

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import Clock, as_utc
from app.config import Settings
from app.errors import ApiError, FatalFetch, RetryableFetch
from app.logutil import safe_log
from app.models import Source, SourceItem
from app.rights import active_grant, entitlement_allowed
from app.rss import parse_feed
from app.runtime import Metrics
from app.urlsec import HTML_CRAWLER_ENABLED, canonicalize, canonical_hash, host_allowed, resolve_public

FIXTURE_DIR = Path(__file__).resolve().parent / "demo"


@dataclass
class FetchResult:
    body: bytes
    status_code: int
    etag: str | None = None
    last_modified: str | None = None
    not_modified: bool = False


class HttpFetcher:
    def __init__(self, resolver=None, transport=None) -> None:
        self.resolver = resolver
        self.transport = transport

    def fetch(self, source: Source, settings: Settings) -> FetchResult:
        if not source.user_agent.strip():
            raise FatalFetch("User-Agent zorunludur.")
        current = source.feed_url
        hops = 0
        while True:
            host_allowed(current, source.allowed_host)
            resolve_public(urlparse(current).hostname or "", self.resolver)
            headers = {
                "User-Agent": source.user_agent,
                "Accept": "application/rss+xml, application/atom+xml, application/xml",
            }
            if source.etag:
                headers["If-None-Match"] = source.etag
            if source.last_modified_header:
                headers["If-Modified-Since"] = source.last_modified_header
            with httpx.Client(
                timeout=source.timeout_seconds,
                follow_redirects=False,
                transport=self.transport,
            ) as client:
                response = client.get(current, headers=headers)
            if response.status_code in {301, 302, 303, 307, 308}:
                hops += 1
                if hops > settings.rss_max_redirects:
                    raise FatalFetch("Yönlendirme sınırı aşıldı.")
                location = response.headers.get("location")
                if not location:
                    raise FatalFetch("Yönlendirmede adres yok.")
                current = urljoin(current, location)
                continue
            if response.status_code == 304:
                return FetchResult(body=b"", status_code=304, not_modified=True)
            if response.status_code == 429 or response.status_code >= 500:
                raise RetryableFetch(f"Kaynak {response.status_code} döndü.")
            if response.status_code in {401, 403}:
                raise FatalFetch("Kaynak erişimi reddetti.", "source_rejected")
            if response.status_code >= 400:
                raise FatalFetch("Kaynak hata döndü.", "source_rejected")
            if len(response.content) > settings.rss_max_bytes:
                raise FatalFetch("Akış boyutu sınırını aştı.", "feed_too_large")
            return FetchResult(
                body=response.content,
                status_code=response.status_code,
                etag=response.headers.get("etag"),
                last_modified=response.headers.get("last-modified"),
            )


def run_ingest(
    session: Session,
    source: Source,
    settings: Settings,
    clock: Clock,
    metrics: Metrics,
    *,
    actor: str,
    fetcher: HttpFetcher | None = None,
    payload: bytes | None = None,
) -> dict:
    from app.audit import pause_source

    try:
        return ingest_source(
            session,
            source,
            settings,
            clock,
            metrics,
            actor=actor,
            fetcher=fetcher,
            payload=payload,
        )
    except FatalFetch as exc:
        metrics.parser_errors += 1
        metrics.parser_alerts += 1
        now = clock.now()
        source.last_error = exc.message[:400]
        if source.status in {"canary", "active"}:
            pause_source(session, source, actor="system", reason=exc.message, now=now)
        session.commit()
        raise


def load_fixture(source: Source, settings: Settings) -> bytes:
    if HTML_CRAWLER_ENABLED:
        raise FatalFetch("HTML tarayıcı kapalı olmalıdır.")
    if not (source.synthetic and settings.synthetic_allowed):
        raise FatalFetch("Fixture yalnız işaretli sentetik kaynakta açılır.")
    if not source.feed_url.startswith("fixture://"):
        raise FatalFetch("Fixture adresi geçersiz.")
    name = source.feed_url.removeprefix("fixture://")
    if "/" in name or "\\" in name or ".." in name or not name.endswith(".xml"):
        raise FatalFetch("Fixture adı geçersiz.")
    path = FIXTURE_DIR / name
    if not path.is_file():
        raise FatalFetch("Fixture bulunamadı.")
    data = path.read_bytes()
    if len(data) > settings.rss_max_bytes:
        raise FatalFetch("Akış boyutu sınırını aştı.", "feed_too_large")
    return data


def ingest_source(
    session: Session,
    source: Source,
    settings: Settings,
    clock: Clock,
    metrics: Metrics,
    *,
    actor: str,
    fetcher: HttpFetcher | None = None,
    payload: bytes | None = None,
) -> dict:
    from app.audit import audit, pause_source

    now = clock.now()
    if source.status not in {"canary", "active"}:
        metrics.rights_blocks += 1
        raise ApiError(409, "source_not_live", "Yalnız canary veya aktif kaynak taranır.", retryable=False)
    if not source.user_agent.strip():
        raise FatalFetch("User-Agent zorunludur.")
    if source.synthetic and not settings.synthetic_allowed:
        metrics.rights_blocks += 1
        pause_source(session, source, actor="system", reason="sentetik veri bu ortamda kapalı", now=now)
        session.commit()
        raise ApiError(403, "synthetic_blocked", "Sentetik kaynak bu ortamda kapalı.", retryable=False)
    grant = active_grant(session, source, now)
    if grant is None or not entitlement_allowed(session, grant, "link"):
        metrics.rights_blocks += 1
        pause_source(session, source, actor="system", reason="yürürlükte bağlantı izni yok", now=now)
        session.commit()
        raise ApiError(403, "rights_blocked", "İzin yok; kaynak durduruldu ve yayın yapılmadı.", retryable=False)
    minimum_gap = 60 / max(source.rate_limit_per_minute, 1)
    if source.last_fetch_at is not None:
        elapsed = (now - as_utc(source.last_fetch_at)).total_seconds()
        if elapsed < minimum_gap:
            raise RetryableFetch("Kaynak hız sınırı nedeniyle bekletildi.")
    if payload is None:
        if source.feed_url.startswith("fixture://"):
            payload = load_fixture(source, settings)
        else:
            if source.source_type == "licensed_api":
                raise FatalFetch("API anahtarı sunucu sırrıdır ve bu ortamda tanımlı değildir.")
            fetched = (fetcher or HttpFetcher()).fetch(source, settings)
            source.last_fetch_at = now
            if fetched.not_modified:
                source.last_success_at = now
                source.last_error = None
                session.commit()
                return {"created": 0, "updated": 0, "quarantined": 0, "not_modified": True}
            if fetched.etag:
                source.etag = fetched.etag[:240]
            if fetched.last_modified:
                source.last_modified_header = fetched.last_modified[:240]
            payload = fetched.body
    source.last_fetch_at = now
    try:
        parsed = parse_feed(payload, max_bytes=settings.rss_max_bytes)
    except FatalFetch:
        raise
    if not parsed:
        metrics.empty_feeds += 1
        safe_log("empty_feed", source_id=source.id, status=source.status)
    created = updated = quarantined = 0
    for entry in parsed:
        outcome = _upsert_item(session, source, entry, grant.id, now, settings)
        if outcome == "created":
            created += 1
        elif outcome == "updated":
            updated += 1
        else:
            quarantined += 1
    source.last_success_at = now
    source.last_error = None
    metrics.ingest_success += 1
    audit(
        session,
        actor=actor,
        role="source_admin",
        action="ingest",
        entity_type="source",
        entity_id=source.id,
        reason="akış işlendi",
        now=now,
        metadata={"created": created, "updated": updated, "quarantined": quarantined},
    )
    session.commit()
    safe_log("ingest_ok", source_id=source.id, status="ok")
    return {"created": created, "updated": updated, "quarantined": quarantined, "not_modified": False}


def _upsert_item(session, source, entry, grant_id: str, now, settings: Settings) -> str:
    reason = None
    canonical = ""
    digest = ""
    if not entry.external_id:
        reason = "missing_id"
    elif not entry.link:
        reason = "missing_link"
    else:
        try:
            host_allowed(entry.link, source.allowed_host)
            canonical = canonicalize(entry.link)
            digest = canonical_hash(entry.link)
        except ApiError:
            reason = "url_blocked"
    if entry.date_error and reason is None:
        reason = entry.date_error
    if reason and not digest:
        digest = hashlib.sha256(f"{source.id}:{entry.external_id}:{entry.link}".encode()).hexdigest()
        canonical = ""
    existing = session.scalar(
        select(SourceItem).where(
            SourceItem.source_id == source.id,
            SourceItem.external_id == (entry.external_id or digest),
        )
    )
    if existing is None and digest:
        existing = session.scalar(
            select(SourceItem).where(SourceItem.source_id == source.id, SourceItem.canonical_hash == digest)
        )
    content = hashlib.sha256(f"{entry.title}|{entry.description}|{entry.link}".encode()).hexdigest()
    if existing:
        existing.fetched_at = now
        existing.updated_at = now
        existing.source_title = entry.title
        existing.source_description = entry.description
        existing.content_hash = content
        if entry.published_at and existing.published_at is None and reason is None:
            existing.published_at = entry.published_at
        return "updated"
    status = "quarantined" if reason else "editorial_review"
    item = SourceItem(
        id=str(uuid.uuid4()),
        source_id=source.id,
        external_id=entry.external_id or digest,
        canonical_url=canonical,
        original_url=entry.link,
        canonical_hash=digest,
        source_title=entry.title,
        source_description=entry.description,
        published_at=entry.published_at if reason is None else None,
        fetched_at=now,
        locale=settings.default_locale,
        content_hash=content,
        status=status,
        quarantine_reason=reason,
        grant_id=grant_id if reason is None else None,
        synthetic=source.synthetic,
        created_at=now,
        updated_at=now,
    )
    if reason is None:
        item.possible_duplicate_of = _title_candidate(session, source.id, entry)
    session.add(item)
    return "quarantined" if reason else "created"


def _title_candidate(session, source_id: str, entry) -> str | None:
    if not entry.title or not entry.published_at:
        return None
    normalized = " ".join(entry.title.casefold().split())
    rows = session.scalars(select(SourceItem).where(SourceItem.source_id == source_id)).all()
    for row in rows:
        if " ".join(row.source_title.casefold().split()) != normalized:
            continue
        if row.published_at is None:
            continue
        delta = abs((as_utc(row.published_at) - as_utc(entry.published_at)).total_seconds())
        if delta <= 3600:
            return row.id
    return None
