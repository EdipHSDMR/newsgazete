"""Server-side Open-Meteo client. No API key required for non-commercial use."""
