"""Open-Meteo Forecast + Geocoding. No API key; never invent official warnings."""

from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
PROVIDER = "Open-Meteo"
ATTRIBUTION = (
    "Hava verisi Open-Meteo tarafından sağlanır (CC BY 4.0). "
    "https://open-meteo.com/"
)
DOCS_URL = "https://open-meteo.com/en/docs"
GEOCODE_DOCS_URL = "https://open-meteo.com/en/docs/geocoding-api"
TIMEZONE = "Europe/Istanbul"
ISTANBUL = ZoneInfo(TIMEZONE)
TIMEOUT = 8.0

# WMO Weather interpretation codes (Open-Meteo docs).
WMO_TR = {
    0: "Açık",
    1: "Çoğunlukla açık",
    2: "Parçalı bulutlu",
    3: "Kapalı",
    45: "Sis",
    48: "Kırağılı sis",
    51: "Hafif çisenti",
    53: "Çisenti",
    55: "Yoğun çisenti",
    56: "Hafif dondurucu çisenti",
    57: "Yoğun dondurucu çisenti",
    61: "Hafif yağmur",
    63: "Yağmur",
    65: "Şiddetli yağmur",
    66: "Hafif dondurucu yağmur",
    67: "Şiddetli dondurucu yağmur",
    71: "Hafif kar",
    73: "Kar",
    75: "Yoğun kar",
    77: "Kar taneleri",
    80: "Hafif sağanak",
    81: "Sağanak",
    82: "Şiddetli sağanak",
    85: "Hafif kar sağanağı",
    86: "Yoğun kar sağanağı",
    95: "Gök gürültülü fırtına",
    96: "Dolu ile fırtına",
    99: "Şiddetli dolu ile fırtına",
}


class ProviderUnavailable(Exception):
    def __init__(self) -> None:
        super().__init__("provider unavailable")


class ProviderBadRequest(Exception):
    def __init__(self, message: str = "bad request") -> None:
        super().__init__(message)
        self.message = message


def now_iso() -> str:
    return datetime.now(ISTANBUL).isoformat(timespec="seconds")


def get_json(url: str, params: dict) -> dict:
    try:
        response = httpx.get(
            url,
            params=params,
            headers={"Accept": "application/json"},
            timeout=TIMEOUT,
            follow_redirects=False,
        )
    except httpx.HTTPError:
        raise ProviderUnavailable() from None
    if response.status_code in {301, 302, 303, 307, 308}:
        raise ProviderUnavailable()
    if response.status_code == 400:
        reason = _error_reason(response) or "İstek geçersiz."
        raise ProviderBadRequest(reason)
    if response.status_code >= 400:
        raise ProviderUnavailable()
    try:
        body = response.json()
    except ValueError:
        raise ProviderUnavailable() from None
    if not isinstance(body, dict):
        raise ProviderUnavailable()
    if body.get("error") is True:
        raise ProviderBadRequest(str(body.get("reason") or "İstek geçersiz."))
    return body


def search_places(query: str, *, count: int = 8) -> list[dict]:
    payload = get_json(
        GEOCODE_URL,
        {
            "name": query,
            "count": count,
            "language": "tr",
            "format": "json",
        },
    )
    rows = payload.get("results")
    if not isinstance(rows, list):
        return []
    places = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        place = normalize_place(row)
        if place is not None:
            places.append(place)
    return places


def fetch_forecast(latitude: float, longitude: float) -> dict:
    payload = get_json(
        FORECAST_URL,
        {
            "latitude": latitude,
            "longitude": longitude,
            "timezone": TIMEZONE,
            "temperature_unit": "celsius",
            "wind_speed_unit": "kmh",
            "precipitation_unit": "mm",
            "forecast_days": 7,
            "current": ",".join(
                [
                    "temperature_2m",
                    "relative_humidity_2m",
                    "apparent_temperature",
                    "is_day",
                    "precipitation",
                    "rain",
                    "weather_code",
                    "cloud_cover",
                    "pressure_msl",
                    "wind_speed_10m",
                    "wind_direction_10m",
                    "wind_gusts_10m",
                ]
            ),
            "hourly": ",".join(
                [
                    "temperature_2m",
                    "precipitation_probability",
                    "precipitation",
                    "weather_code",
                    "wind_speed_10m",
                    "wind_direction_10m",
                    "uv_index",
                    "is_day",
                ]
            ),
            "daily": ",".join(
                [
                    "weather_code",
                    "temperature_2m_max",
                    "temperature_2m_min",
                    "sunrise",
                    "sunset",
                    "precipitation_sum",
                    "precipitation_probability_max",
                    "wind_speed_10m_max",
                    "wind_gusts_10m_max",
                    "uv_index_max",
                ]
            ),
        },
    )
    return normalize_forecast(payload, latitude, longitude)


def normalize_place(row: dict) -> dict | None:
    name = row.get("name")
    lat = _float(row.get("latitude"))
    lon = _float(row.get("longitude"))
    if not isinstance(name, str) or not name.strip() or lat is None or lon is None:
        return None
    admin1 = row.get("admin1") if isinstance(row.get("admin1"), str) else None
    country = row.get("country") if isinstance(row.get("country"), str) else None
    country_code = row.get("country_code") if isinstance(row.get("country_code"), str) else None
    parts = [name.strip()]
    if admin1 and admin1.strip() and admin1.strip().casefold() != name.strip().casefold():
        parts.append(admin1.strip())
    if country and country.strip():
        parts.append(country.strip())
    return {
        "id": row.get("id") if isinstance(row.get("id"), int) else None,
        "name": name.strip(),
        "admin1": admin1.strip() if admin1 else None,
        "country": country.strip() if country else None,
        "country_code": country_code.upper() if country_code else None,
        "latitude": lat,
        "longitude": lon,
        "timezone": row.get("timezone") if isinstance(row.get("timezone"), str) else None,
        "label": ", ".join(parts),
        "population": row.get("population") if isinstance(row.get("population"), int) else None,
    }


def normalize_forecast(payload: dict, latitude: float, longitude: float) -> dict:
    current_raw = payload.get("current") if isinstance(payload.get("current"), dict) else {}
    hourly_raw = payload.get("hourly") if isinstance(payload.get("hourly"), dict) else {}
    daily_raw = payload.get("daily") if isinstance(payload.get("daily"), dict) else {}
    units = payload.get("current_units") if isinstance(payload.get("current_units"), dict) else {}

    hourly = _hourly_rows(hourly_raw)
    daily = _daily_rows(daily_raw)
    uv_now = _uv_at(hourly, current_raw.get("time") if isinstance(current_raw.get("time"), str) else None)

    current = {
        "time": current_raw.get("time") if isinstance(current_raw.get("time"), str) else None,
        "temperature_c": _float(current_raw.get("temperature_2m")),
        "feels_like_c": _float(current_raw.get("apparent_temperature")),
        "humidity_pct": _int(current_raw.get("relative_humidity_2m")),
        "precipitation_mm": _float(current_raw.get("precipitation")),
        "weather_code": _int(current_raw.get("weather_code")),
        "condition": condition_label(_int(current_raw.get("weather_code"))),
        "is_day": bool(current_raw.get("is_day")) if current_raw.get("is_day") is not None else None,
        "cloud_cover_pct": _int(current_raw.get("cloud_cover")),
        "pressure_hpa": _float(current_raw.get("pressure_msl")),
        "wind_speed_kmh": _float(current_raw.get("wind_speed_10m")),
        "wind_direction_deg": _int(current_raw.get("wind_direction_10m")),
        "wind_gusts_kmh": _float(current_raw.get("wind_gusts_10m")),
        "uv_index": uv_now,
    }

    sunrise = daily[0].get("sunrise") if daily else None
    sunset = daily[0].get("sunset") if daily else None

    return {
        "latitude": _float(payload.get("latitude")) if _float(payload.get("latitude")) is not None else latitude,
        "longitude": _float(payload.get("longitude")) if _float(payload.get("longitude")) is not None else longitude,
        "elevation_m": _float(payload.get("elevation")),
        "timezone": TIMEZONE,
        "units": {
            "temperature": units.get("temperature_2m") or "°C",
            "wind_speed": units.get("wind_speed_10m") or "km/h",
            "precipitation": units.get("precipitation") or "mm",
        },
        "current": current,
        "hourly": hourly[:48],
        "daily": daily[:7],
        "sunrise": sunrise,
        "sunset": sunset,
        # Open-Meteo Forecast API does not expose official meteorological warnings.
        "warnings": [],
        "warnings_available": False,
    }


def condition_label(code: int | None) -> str | None:
    if code is None:
        return None
    return WMO_TR.get(code, f"Kod {code}")


def _hourly_rows(block: dict) -> list[dict]:
    times = block.get("time") if isinstance(block.get("time"), list) else []
    rows = []
    for index, time_value in enumerate(times):
        if not isinstance(time_value, str):
            continue
        code = _at(block.get("weather_code"), index)
        rows.append(
            {
                "time": time_value,
                "temperature_c": _float(_at(block.get("temperature_2m"), index)),
                "precipitation_probability_pct": _int(_at(block.get("precipitation_probability"), index)),
                "precipitation_mm": _float(_at(block.get("precipitation"), index)),
                "weather_code": _int(code),
                "condition": condition_label(_int(code)),
                "wind_speed_kmh": _float(_at(block.get("wind_speed_10m"), index)),
                "wind_direction_deg": _int(_at(block.get("wind_direction_10m"), index)),
                "uv_index": _float(_at(block.get("uv_index"), index)),
                "is_day": bool(_at(block.get("is_day"), index)) if _at(block.get("is_day"), index) is not None else None,
            }
        )
    return rows


def _daily_rows(block: dict) -> list[dict]:
    times = block.get("time") if isinstance(block.get("time"), list) else []
    rows = []
    for index, time_value in enumerate(times):
        if not isinstance(time_value, str):
            continue
        code = _at(block.get("weather_code"), index)
        rows.append(
            {
                "date": time_value,
                "weather_code": _int(code),
                "condition": condition_label(_int(code)),
                "temperature_max_c": _float(_at(block.get("temperature_2m_max"), index)),
                "temperature_min_c": _float(_at(block.get("temperature_2m_min"), index)),
                "sunrise": _at(block.get("sunrise"), index) if isinstance(_at(block.get("sunrise"), index), str) else None,
                "sunset": _at(block.get("sunset"), index) if isinstance(_at(block.get("sunset"), index), str) else None,
                "precipitation_sum_mm": _float(_at(block.get("precipitation_sum"), index)),
                "precipitation_probability_max_pct": _int(_at(block.get("precipitation_probability_max"), index)),
                "wind_speed_max_kmh": _float(_at(block.get("wind_speed_10m_max"), index)),
                "wind_gusts_max_kmh": _float(_at(block.get("wind_gusts_10m_max"), index)),
                "uv_index_max": _float(_at(block.get("uv_index_max"), index)),
            }
        )
    return rows


def _uv_at(hourly: list[dict], current_time: str | None) -> float | None:
    if not hourly:
        return None
    if current_time:
        for row in hourly:
            if row.get("time") == current_time:
                return _float(row.get("uv_index"))
        prefix = current_time[:13]
        for row in hourly:
            time_value = row.get("time")
            if isinstance(time_value, str) and time_value.startswith(prefix):
                return _float(row.get("uv_index"))
    return _float(hourly[0].get("uv_index"))


def _at(values, index: int):
    if not isinstance(values, list) or index < 0 or index >= len(values):
        return None
    return values[index]


def _float(value) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _int(value) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return None


def _error_reason(response: httpx.Response) -> str | None:
    try:
        body = response.json()
    except ValueError:
        return None
    if isinstance(body, dict):
        reason = body.get("reason")
        if isinstance(reason, str) and reason.strip():
            return reason.strip()
    return None
