"""Public weather routes. Open-Meteo Forecast + Geocoding; no invented warnings."""

from __future__ import annotations

from fastapi import APIRouter, Request

from app.errors import ApiError
from app.weather.cache import FORECAST_TTL, GEOCODE_TTL, WeatherCache
from app.weather.client import (
    ATTRIBUTION,
    DOCS_URL,
    GEOCODE_DOCS_URL,
    PROVIDER,
    TIMEZONE,
    ProviderBadRequest,
    ProviderUnavailable,
    fetch_forecast,
    now_iso,
    search_places,
)

router = APIRouter(prefix="/v1/weather")
UNAVAILABLE_MESSAGE = "Hava veri sağlayıcısına şu an ulaşılamıyor."
EMPTY_SEARCH = "Arama için en az 2 karakter girin."
BAD_COORDS = "Enlem ve boylam geçerli sayılar olmalıdır."


def _data(payload: dict) -> dict:
    from app.api import request_id_var

    return {"request_id": request_id_var.get(), "data": payload}


def _cache(request: Request) -> WeatherCache:
    return WeatherCache(request.app.state.weather_cache, request.app.state.weather_cache_lock)


def _meta(refreshed_at, from_cache: bool, stale: bool) -> dict:
    return {
        "provider": PROVIDER,
        "attribution": ATTRIBUTION,
        "docs": DOCS_URL,
        "geocode_docs": GEOCODE_DOCS_URL,
        "timezone": TIMEZONE,
        "refreshed_at": refreshed_at,
        "from_cache": from_cache,
        "stale": stale,
        "warnings_available": False,
    }


def _load(cache: WeatherCache, key: str, ttl: float, fetch):
    hit = cache.get_fresh(key, ttl)
    if hit is not None:
        return hit, True
    data = fetch()
    refreshed = now_iso()
    cache.put(key, data, refreshed)
    return {"data": data, "updated_at": refreshed}, False


def _parse_query(value: str | None) -> str:
    text = (value or "").strip()
    if len(text) < 2:
        raise ApiError(422, "validation", EMPTY_SEARCH, retryable=False)
    if len(text) > 80:
        raise ApiError(422, "validation", "Arama metni çok uzun.", retryable=False)
    return text


def _parse_coord(value: float | None, *, name: str, lo: float, hi: float) -> float:
    if value is None:
        raise ApiError(422, "validation", BAD_COORDS, retryable=False)
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ApiError(422, "validation", BAD_COORDS, retryable=False) from None
    if number < lo or number > hi:
        raise ApiError(422, "validation", f"{name} aralık dışında.", retryable=False)
    return number


@router.get("/search")
def get_search(request: Request, q: str | None = None):
    query = _parse_query(q)
    cache = _cache(request)
    key = f"om:geo:{query.casefold()}"

    def fetch():
        return search_places(query)

    def build(places, refreshed_at, from_cache: bool, stale: bool):
        body = _meta(refreshed_at, from_cache, stale)
        body["query"] = query
        body["places"] = places
        return body

    try:
        entry, from_cache = _load(cache, key, GEOCODE_TTL, fetch)
    except ProviderBadRequest as exc:
        raise ApiError(422, "validation", exc.message, retryable=False) from None
    except ProviderUnavailable:
        stale = cache.get_stale(key)
        if stale is not None:
            return _data(build(stale["data"], stale.get("updated_at"), True, True))
        raise ApiError(503, "source_unavailable", UNAVAILABLE_MESSAGE, retryable=True, retry_after=60) from None
    return _data(build(entry["data"], entry.get("updated_at"), from_cache, False))


@router.get("/forecast")
def get_forecast(
    request: Request,
    latitude: float | None = None,
    longitude: float | None = None,
    name: str | None = None,
):
    lat = _parse_coord(latitude, name="Enlem", lo=-90.0, hi=90.0)
    lon = _parse_coord(longitude, name="Boylam", lo=-180.0, hi=180.0)
    label = (name or "").strip()[:120] or None
    cache = _cache(request)
    key = f"om:fc:{round(lat, 3)}:{round(lon, 3)}"

    def fetch():
        return fetch_forecast(lat, lon)

    def build(forecast, refreshed_at, from_cache: bool, stale: bool):
        body = _meta(refreshed_at, from_cache, stale)
        body["place"] = {
            "name": label,
            "latitude": forecast.get("latitude"),
            "longitude": forecast.get("longitude"),
            "label": label,
        }
        body["forecast"] = forecast
        return body

    try:
        entry, from_cache = _load(cache, key, FORECAST_TTL, fetch)
    except ProviderBadRequest as exc:
        raise ApiError(422, "validation", exc.message, retryable=False) from None
    except ProviderUnavailable:
        stale = cache.get_stale(key)
        if stale is not None:
            return _data(build(stale["data"], stale.get("updated_at"), True, True))
        raise ApiError(503, "source_unavailable", UNAVAILABLE_MESSAGE, retryable=True, retry_after=60) from None
    return _data(build(entry["data"], entry.get("updated_at"), from_cache, False))
