"""In-process TTL cache for Open-Meteo responses. No credential storage."""

from __future__ import annotations

import threading
import time

FORECAST_TTL = 10 * 60
GEOCODE_TTL = 60 * 60


class WeatherCache:
    def __init__(self, store: dict, lock: threading.RLock) -> None:
        self._store = store
        self._lock = lock

    def get_fresh(self, key: str, ttl: float) -> dict | None:
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(key)
            if not _has_payload(entry):
                return None
            if now - entry["fetched"] >= ttl:
                return None
            return entry

    def get_stale(self, key: str) -> dict | None:
        with self._lock:
            entry = self._store.get(key)
            if _has_payload(entry):
                return entry
            return None

    def put(self, key: str, data, refreshed_at: str) -> None:
        with self._lock:
            self._store[key] = {"fetched": time.monotonic(), "updated_at": refreshed_at, "data": data}


def _has_payload(entry) -> bool:
    return isinstance(entry, dict) and "data" in entry and isinstance(entry.get("fetched"), (int, float))
