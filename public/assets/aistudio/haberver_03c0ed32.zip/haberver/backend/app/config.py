from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "dev"
    database_url: str = "sqlite:///./haberver.db"
    allow_synthetic: bool = False
    admin_tokens: str = ""
    feed_cache_ttl_seconds: int = 30
    rss_max_bytes: int = 1_000_000
    rss_timeout_seconds: float = 10.0
    rss_max_redirects: int = 3
    search_rate_per_minute: int = 30
    admin_rate_per_minute: int = 30
    privacy_rate_per_minute: int = 10
    analytics_retention_days: int = 90
    pha_api_key: str = ""
    newsapi_key: str = ""
    api_football_key: str = ""
    football_data_token: str = ""
    default_locale: str = "tr"
    api_version: str = "v1"

    @model_validator(mode="after")
    def lock_production(self) -> "Settings":
        if self.app_env == "production":
            self.allow_synthetic = False
        if self.app_env not in {"dev", "staging", "production"}:
            raise ValueError("app_env dev, staging veya production olmalıdır")
        return self

    @property
    def synthetic_allowed(self) -> bool:
        return self.allow_synthetic and self.app_env != "production"
