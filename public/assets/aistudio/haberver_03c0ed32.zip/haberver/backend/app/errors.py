class ApiError(Exception):
    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        *,
        retryable: bool = False,
        field_errors: dict | None = None,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.retryable = retryable
        self.field_errors = field_errors or {}
        self.retry_after = retry_after


class RetryableFetch(ApiError):
    def __init__(self, message: str) -> None:
        super().__init__(503, "source_unavailable", message, retryable=True, retry_after=60)


class FatalFetch(ApiError):
    def __init__(self, message: str, code: str = "source_rejected") -> None:
        super().__init__(422, code, message, retryable=False)
