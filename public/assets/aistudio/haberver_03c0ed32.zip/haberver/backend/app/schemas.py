from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ApiModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class StoryCard(ApiModel):
    id: str
    editorial_title: str
    editorial_summary: str
    authorship_label: str
    published_at: datetime
    updated_at: datetime
    source_count: int
    topic_slug: str
    topic_name: str
    synthetic: bool
    display_label: str | None
    updated_badge: bool
    image: str | None = None
    placeholder: str
    ranking_reason: str
    editor_priority: int
    source_ids: list[str]
    rights_expires_at: datetime | None


class SourceLink(ApiModel):
    id: str
    source_id: str
    publisher_name: str | None
    domain: str | None
    source_title: str | None = None
    published_at: datetime
    canonical_url: str | None
    partnership_label: str | None = None
    partnership_note: str | None = None


class CorrectionOut(ApiModel):
    id: str
    reason: str
    editor: str
    created_at: datetime
    previous_summary_version_id: str | None


class StoryDetail(StoryCard):
    context_note: str
    developing: bool
    uncertainty_note: str | None
    single_source_note: str | None
    content_warning: str | None
    risk_level: str
    ai_assisted: bool
    ai_role_note: str | None
    corrections: list[CorrectionOut]
    sources: list[SourceLink]


class FeedPage(ApiModel):
    items: list[StoryCard]
    next_cursor: str | None


class TopicOut(ApiModel):
    slug: str
    name: str


class SourceProfile(ApiModel):
    id: str
    name: str
    domain: str
    editorial_description: str
    partnership_label: str | None
    partnership_note: str | None
    stories: list[StoryCard]


class ReportIn(ApiModel):
    story_id: str
    category: str
    description: str | None = Field(default=None, max_length=500)


class ReportOut(ApiModel):
    id: str
    status: str


class EventIn(ApiModel):
    name: str
    app_version: str = Field(min_length=1, max_length=40)
    installation_id: str | None = Field(default=None, max_length=64)
    story_id: str | None = None
    topic_slug: str | None = None


class MetaOut(ApiModel):
    name: str
    brand_status: str
    promise: str
    standards: str
    corrections: str
    privacy: str
    revenue: str
    legal_notice: str


class HealthOut(ApiModel):
    status: str
    api: str
    environment: str
    html_crawler: bool


class SourceIn(ApiModel):
    name: str = Field(min_length=2, max_length=200)
    domain: str
    allowed_host: str
    feed_url: str
    source_type: str
    editorial_description: str = ""
    partnership_label: str | None = None
    partnership_note: str | None = None
    contact_email: str | None = None
    terms_note: str | None = None
    user_agent: str = Field(min_length=8, max_length=240)
    rate_limit_per_minute: int = Field(default=6, ge=1, le=60)
    timeout_seconds: int = Field(default=10, ge=2, le=30)
    synthetic: bool = False


class GrantIn(ApiModel):
    source_id: str
    kind: str
    document_ref: str
    rights_holder: str
    starts_at: datetime
    expires_at: datetime
    signed_at: datetime | None = None
    platform: str = "android"
    country: str = "TR"
    purpose: str = "editorial_discovery"
    attribution_text: str = ""


class EntitlementIn(ApiModel):
    key: str
    allowed: bool


class EntitlementBatch(ApiModel):
    items: list[EntitlementIn]


class LiveIn(ApiModel):
    mode: str


class StoryIn(ApiModel):
    source_item_id: str
    editorial_title: str = Field(min_length=12, max_length=180)
    editorial_summary: str = Field(min_length=40, max_length=1200)
    context_note: str = ""
    topic_slug: str
    verification_note: str = Field(min_length=8, max_length=800)
    risk_level: str = "normal"
    content_warning: str | None = None
    developing: bool = False
    uncertainty_note: str | None = None
    editor_priority: int = Field(default=0, ge=0, le=3)
    ai_assisted: bool = False
    ai_role_note: str | None = None


class PublishIn(ApiModel):
    send_push: bool = False


class CorrectIn(ApiModel):
    editorial_title: str = Field(min_length=12, max_length=180)
    editorial_summary: str = Field(min_length=40, max_length=1200)
    context_note: str = ""
    reason: str = Field(min_length=8, max_length=500)
    send_push: bool = False


class ReasonIn(ApiModel):
    reason: str = Field(min_length=3, max_length=500)


class MemberIn(ApiModel):
    source_item_id: str


class ManualIn(ApiModel):
    source_id: str
    url: str
    external_id: str = Field(min_length=3, max_length=200)
    published_at: datetime
    observed_facts: str = Field(default="", max_length=500)


class TakedownIn(ApiModel):
    claim: str = Field(min_length=8, max_length=1000)
    story_id: str | None = None
    source_id: str | None = None
    url: str = ""


class IngestIn(ApiModel):
    idempotency_key: str | None = None
