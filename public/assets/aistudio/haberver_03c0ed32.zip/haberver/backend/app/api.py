"""HTTP sınırı. Android ham hak tablosunu tahmin etmez."""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from contextvars import ContextVar
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app import content
from app.clock import Clock
from app.config import Settings
from app.db import make_engine, make_session_factory
from app.errors import ApiError
from app.ingest import run_ingest
from app.models import (
    AnalyticsEvent,
    AuditEvent,
    Base,
    IdempotencyRecord,
    IngestJob,
    LicenseGrant,
    ReaderReport,
    Source,
    SourceItem,
    Story,
)
from app.reading import feed, feed_bootstrap, feed_inventory, search, source_profile, story_detail
from app.runtime import Metrics, RateLimiter, ResponseCache
from app.sports_data import sports_overview
from app.schemas import (
    CorrectIn,
    EntitlementBatch,
    EventIn,
    GrantIn,
    HealthOut,
    IngestIn,
    LiveIn,
    ManualIn,
    MemberIn,
    MetaOut,
    PublishIn,
    ReasonIn,
    ReportIn,
    SourceIn,
    StoryIn,
    TakedownIn,
)
from app.security import Actor, authenticate, authorize
from app.services import (
    activate_grant,
    add_grant,
    add_member,
    correct_story,
    create_source,
    create_story,
    ensure_topics,
    expire_due,
    manual_item,
    mark_source_live,
    publish_story,
    remove_member,
    review_backlog,
    second_approve,
    set_entitlements,
    takedown,
    verify_domain,
    withdraw_story,
)
from app.worker import enqueue_job, execute_job

request_id_var: ContextVar[str] = ContextVar("request_id", default="")
bearer_scheme = HTTPBearer(auto_error=False)
EVENT_NAMES = {"feed_view", "story_open", "source_click", "save", "preference_change", "report"}
router = APIRouter(prefix="/v1")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    app = FastAPI(
        title="Haber Keşif API",
        version="0.1.0",
        docs_url="/docs",
        openapi_url="/v1/openapi.json",
    )
    engine = make_engine(settings.database_url)
    if settings.database_url.startswith("sqlite") or settings.app_env == "dev":
        Base.metadata.create_all(engine)
    app.state.settings = settings
    app.state.engine = engine
    app.state.sessions = make_session_factory(engine)
    app.state.cache = ResponseCache()
    app.state.limiter = RateLimiter()
    app.state.metrics = Metrics()
    app.state.sports_cache = {}
    app.state.sports_cache_lock = threading.RLock()
    app.state.weather_cache = {}
    app.state.weather_cache_lock = threading.RLock()
    app.state.clock = Clock()
    app.include_router(router)
    from app.sports.router import router as sports_router
    from app.weather.router import router as weather_router
    from app.local.router import router as local_router

    app.include_router(sports_router)
    app.include_router(weather_router)
    app.include_router(local_router)
    app.add_exception_handler(ApiError, _api_error)
    app.add_exception_handler(RequestValidationError, _validation_error)
    app.add_exception_handler(Exception, _unexpected)

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        incoming = request.headers.get("x-request-id", "")
        request_id = incoming if incoming.isalnum() and len(incoming) <= 64 else uuid.uuid4().hex
        token = request_id_var.set(request_id)
        try:
            response = await call_next(request)
        finally:
            request_id_var.reset(token)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Frame-Options"] = "DENY"
        return response

    web_dir = Path(__file__).with_name("web")
    app.mount("/static", StaticFiles(directory=web_dir), name="reader-static")

    @app.get("/")
    def reader_home():
        return FileResponse(web_dir / "index.html")

    @app.get("/admin")
    def admin_page():
        page = Path(__file__).with_name("admin_ui.html")
        return FileResponse(page)

    with app.state.sessions() as session:
        ensure_topics(session)
    return app


def _session(request: Request):
    db: Session = request.app.state.sessions()
    try:
        yield db
    finally:
        db.close()


def _actor(request: Request, credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)) -> Actor:
    retry = request.app.state.limiter.hit(
        f"admin:{request.client.host if request.client else 'local'}",
        request.app.state.settings.admin_rate_per_minute,
        time.monotonic(),
    )
    if retry is not None:
        raise ApiError(429, "rate_limited", "Çok fazla yönetim isteği.", retryable=True, retry_after=retry)
    return authenticate(credentials, request.app.state.settings)


def _roles(*roles: str):
    def dependency(actor: Actor = Depends(_actor)) -> Actor:
        authorize(actor, set(roles))
        return actor

    return dependency


def _data(payload):
    if hasattr(payload, "model_dump"):
        payload = payload.model_dump(mode="json")
    return {"request_id": request_id_var.get(), "data": payload}


def _api_error(_request: Request, exc: ApiError):
    headers = {"X-Request-ID": request_id_var.get()}
    if exc.retry_after:
        headers["Retry-After"] = str(exc.retry_after)
    return JSONResponse(
        status_code=exc.status_code,
        headers=headers,
        content={
            "error": {
                "code": exc.code,
                "message": exc.message,
                "request_id": request_id_var.get(),
                "field_errors": exc.field_errors,
                "retryable": exc.retryable,
            }
        },
    )


def _validation_error(_request: Request, _exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "validation",
                "message": "İstek alanları doğrulanamadı.",
                "request_id": request_id_var.get(),
                "field_errors": {},
                "retryable": False,
            }
        },
    )


def _unexpected(_request: Request, _exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "server_error",
                "message": "İşlem tamamlanamadı. Yeniden deneyin.",
                "request_id": request_id_var.get(),
                "field_errors": {},
                "retryable": True,
            }
        },
    )


@router.get("/health")
def health(request: Request, db: Session = Depends(_session)):
    db.execute(select(1))
    body = HealthOut(status="ok", api="v1", environment=request.app.state.settings.app_env, html_crawler=False)
    return _data(body)


@router.get("/meta")
def meta():
    body = MetaOut(
        name=content.NAME,
        brand_status=content.BRAND,
        promise=content.PROMISE,
        standards=content.STANDARDS,
        corrections=content.CORRECTIONS,
        privacy=content.PRIVACY,
        revenue=content.REVENUE,
        legal_notice=content.LEGAL,
    )
    return _data(body)


@router.get("/topics")
def topics(db: Session = Depends(_session)):
    from app.models import Topic

    rows = db.scalars(select(Topic).order_by(Topic.sort_order)).all()
    return _data([{"slug": row.slug, "name": row.name} for row in rows])


@router.get("/meta/inventory")
def meta_inventory(db: Session = Depends(_session)):
    """stored_public + provider_note. GET /v1/feed gövdesine eklenmez."""
    return _data(feed_inventory(db))


@router.get("/sports/overview")
def get_sports_overview(request: Request):
    """Cached Turkish Super Lig scores and table; provider credentials stay server-side."""
    return _data(sports_overview(
        request.app.state.settings,
        request.app.state.sports_cache,
        request.app.state.sports_cache_lock,
    ))


@router.get("/feed/bootstrap")
def get_feed_bootstrap(
    request: Request,
    limit: int = 12,
    db: Session = Depends(_session),
):
    """Hızlı ilk ekran: cache önce, miss'te feed + inventory. İmleç /v1/feed ile uyumlu."""
    settings: Settings = request.app.state.settings
    clock: Clock = request.app.state.clock
    now = clock.now()
    cache: ResponseCache = request.app.state.cache
    key = f"bootstrap:{settings.api_version}:{settings.default_locale}:{limit}"
    cached = cache.get(key, now)
    if cached is None:
        expire_due(db, now, request.app.state.metrics)
        cards, next_cursor, ttl, inventory = feed_bootstrap(db, settings, now, limit=limit)
        cached = {
            "items": [card.model_dump(mode="json") for card in cards],
            "next_cursor": next_cursor,
            "inventory": inventory,
            "cache_ttl_seconds": ttl,
            "_ttl": ttl,
        }
        cache.set(key, cached, now, ttl)
        # İlk sayfa feed anahtarıyla paylaş: sonraki /v1/feed?limit=N isabeti hızlanır.
        feed_key = f"feed:{settings.api_version}:{settings.default_locale}:*:*:{limit}"
        cache.set(
            feed_key,
            {"items": cached["items"], "next_cursor": next_cursor, "_ttl": ttl},
            now,
            ttl,
        )
    payload = {
        "items": cached["items"],
        "next_cursor": cached["next_cursor"],
        "inventory": cached["inventory"],
        "cache_ttl_seconds": cached["cache_ttl_seconds"],
    }
    body = {"request_id": request_id_var.get(), "data": payload}
    encoded = json.dumps(body, ensure_ascii=False, sort_keys=True)
    etag = hashlib.sha256(encoded.encode()).hexdigest()
    headers = {"ETag": etag, "Cache-Control": f"public, max-age={cached['_ttl']}"}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return JSONResponse(body, headers=headers)


@router.get("/feed")
def get_feed(
    request: Request,
    topic: str | None = None,
    cursor: str | None = None,
    limit: int = 20,
    include_inventory: bool = False,
    db: Session = Depends(_session),
):
    settings: Settings = request.app.state.settings
    clock: Clock = request.app.state.clock
    now = clock.now()
    cache: ResponseCache = request.app.state.cache
    key = f"feed:{settings.api_version}:{settings.default_locale}:{topic or '*'}:{cursor or '*'}:{limit}"
    # expire_due önbellek isabetinde çalışmaz; ilk ekran sıcak yolu ~ms düzeyinde kalır.
    cached = cache.get(key, now)
    if cached is None:
        expire_due(db, now, request.app.state.metrics)
        cards, next_cursor, ttl = feed(db, settings, now, topic=topic, cursor=cursor, limit=limit)
        cached = {
            "items": [card.model_dump(mode="json") for card in cards],
            "next_cursor": next_cursor,
            "_ttl": ttl,
        }
        cache.set(key, cached, now, ttl)
    data = {"items": cached["items"], "next_cursor": cached["next_cursor"]}
    if include_inventory:
        inv_key = f"inventory:{settings.api_version}"
        inventory = cache.get(inv_key, now)
        if inventory is None:
            inventory = feed_inventory(db)
            cache.set(inv_key, inventory, now, max(int(cached["_ttl"]), 15))
        data["inventory"] = inventory
    body = {"request_id": request_id_var.get(), "data": data}
    encoded = json.dumps(body, ensure_ascii=False, sort_keys=True)
    etag = hashlib.sha256(encoded.encode()).hexdigest()
    headers = {"ETag": etag, "Cache-Control": f"public, max-age={cached['_ttl']}"}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return JSONResponse(body, headers=headers)


@router.get("/stories/{story_id}")
def get_story(story_id: str, request: Request, db: Session = Depends(_session)):
    now = request.app.state.clock.now()
    expire_due(db, now, request.app.state.metrics)
    detail = story_detail(db, request.app.state.settings, now, story_id)
    return _data(detail)


@router.get("/sources/{source_id}")
def get_source(source_id: str, request: Request, db: Session = Depends(_session)):
    now = request.app.state.clock.now()
    profile = source_profile(db, request.app.state.settings, now, source_id)
    return _data(profile)


@router.get("/search")
def get_search(
    request: Request,
    q: str = "",
    topic: str | None = None,
    source_id: str | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    cursor: str | None = None,
    limit: int = 20,
    db: Session = Depends(_session),
):
    retry = request.app.state.limiter.hit(
        f"search:{request.client.host if request.client else 'local'}",
        request.app.state.settings.search_rate_per_minute,
        time.monotonic(),
    )
    if retry is not None:
        raise ApiError(429, "rate_limited", "Arama sınırı doldu. Bir süre sonra yeniden deneyin.", retryable=True, retry_after=retry)
    now = request.app.state.clock.now()
    expire_due(db, now, request.app.state.metrics)
    cards, next_cursor = search(
        db,
        request.app.state.settings,
        now,
        q=q,
        topic=topic,
        source_id=source_id,
        date_from=date_from,
        date_to=date_to,
        cursor=cursor,
        limit=limit,
    )
    return _data({"items": [card.model_dump(mode="json") for card in cards], "next_cursor": next_cursor})


@router.post("/reports", status_code=201)
def post_report(body: ReportIn, request: Request, db: Session = Depends(_session)):
    if body.category not in {"wrong_summary", "wrong_date", "broken_link", "other"}:
        raise ApiError(422, "validation", "Bildirim kategorisi geçersiz.", retryable=False)
    story = db.get(Story, body.story_id)
    if story is None:
        raise ApiError(404, "not_found", "Hikaye bulunamadı.", retryable=False)
    report = ReaderReport(
        id=str(uuid.uuid4()),
        story_id=story.id,
        category=body.category,
        description=body.description,
        status="received",
        created_at=request.app.state.clock.now(),
    )
    db.add(report)
    db.commit()
    return _data({"id": report.id, "status": "received"})


@router.post("/events", status_code=202)
def post_event(body: EventIn, request: Request, db: Session = Depends(_session)):
    if body.name not in EVENT_NAMES:
        raise ApiError(422, "validation", "Olay adı listede yok.", retryable=False)
    now = request.app.state.clock.now()
    cutoff = now - timedelta(days=request.app.state.settings.analytics_retention_days)
    db.execute(delete(AnalyticsEvent).where(AnalyticsEvent.occurred_at < cutoff))
    db.add(
        AnalyticsEvent(
            id=str(uuid.uuid4()),
            name=body.name,
            occurred_at=now,
            app_version=body.app_version,
            installation_id=body.installation_id,
            story_id=body.story_id,
            topic_slug=body.topic_slug,
        )
    )
    db.commit()
    return _data({"status": "accepted"})


@router.delete("/privacy/installations/{installation_id}")
def delete_installation(installation_id: str, request: Request, db: Session = Depends(_session)):
    retry = request.app.state.limiter.hit(
        f"privacy:{request.client.host if request.client else 'local'}",
        request.app.state.settings.privacy_rate_per_minute,
        time.monotonic(),
    )
    if retry is not None:
        raise ApiError(429, "rate_limited", "Silme isteği sınırı doldu.", retryable=True, retry_after=retry)
    if len(installation_id) < 8 or len(installation_id) > 64:
        raise ApiError(422, "validation", "Kurulum kimliği geçersiz.", retryable=False)
    result = db.execute(delete(AnalyticsEvent).where(AnalyticsEvent.installation_id == installation_id))
    db.commit()
    return _data({"deleted": result.rowcount or 0})


@router.post("/admin/sources", status_code=201)
def admin_create_source(body: SourceIn, request: Request, actor: Actor = Depends(_roles("source_admin")), db: Session = Depends(_session)):
    source = create_source(db, actor.name, request.app.state.clock.now(), body.model_dump())
    return _data({"id": source.id, "status": source.status})


@router.post("/admin/sources/{source_id}/domain-check")
def admin_domain(source_id: str, request: Request, actor: Actor = Depends(_roles("source_admin")), db: Session = Depends(_session)):
    source = _source_or_404(db, source_id)
    verify_domain(db, source, actor.name, request.app.state.clock.now())
    return _data({"id": source.id, "status": source.status})


@router.post("/admin/grants", status_code=201)
def admin_grant(body: GrantIn, request: Request, actor: Actor = Depends(_roles("legal_reviewer")), db: Session = Depends(_session)):
    source = _source_or_404(db, body.source_id)
    grant = add_grant(
        db,
        source,
        actor.name,
        request.app.state.clock.now(),
        body.model_dump(),
        synthetic_allowed=request.app.state.settings.synthetic_allowed,
    )
    return _data({"id": grant.id, "version": grant.version, "status": grant.status})


@router.post("/admin/grants/{grant_id}/entitlements")
def admin_entitlements(
    grant_id: str,
    body: EntitlementBatch,
    request: Request,
    actor: Actor = Depends(_roles("legal_reviewer")),
    db: Session = Depends(_session),
):
    grant = db.get(LicenseGrant, grant_id)
    if grant is None:
        raise ApiError(404, "not_found", "İzin kaydı bulunamadı.", retryable=False)
    set_entitlements(db, grant, actor.name, request.app.state.clock.now(), [row.model_dump() for row in body.items])
    return _data({"id": grant.id, "status": grant.status})


@router.post("/admin/grants/{grant_id}/activate")
def admin_activate_grant(
    grant_id: str,
    request: Request,
    actor: Actor = Depends(_roles("legal_reviewer")),
    db: Session = Depends(_session),
):
    grant = db.get(LicenseGrant, grant_id)
    if grant is None:
        raise ApiError(404, "not_found", "İzin kaydı bulunamadı.", retryable=False)
    activate_grant(db, grant, actor.name, request.app.state.clock.now())
    return _data({"id": grant.id, "status": grant.status})


@router.post("/admin/sources/{source_id}/live")
def admin_live(
    source_id: str,
    body: LiveIn,
    request: Request,
    actor: Actor = Depends(_roles("source_admin")),
    db: Session = Depends(_session),
):
    source = _source_or_404(db, source_id)
    mark_source_live(db, source, actor.name, request.app.state.clock.now(), mode=body.mode)
    return _data({"id": source.id, "status": source.status})


@router.post("/admin/sources/{source_id}/ingest")
def admin_ingest(
    source_id: str,
    body: IngestIn,
    request: Request,
    actor: Actor = Depends(_roles("source_admin")),
    db: Session = Depends(_session),
):
    source = _source_or_404(db, source_id)
    now = request.app.state.clock.now()
    key = body.idempotency_key or f"manual:{source.id}:{now.strftime('%Y%m%d%H%M')}"
    job = enqueue_job(db, source.id, key, now)
    if job.status == "succeeded":
        return _data({"job_id": job.id, "status": job.status, "duplicate": True})
    result = execute_job(request.app, job.id, actor.name)
    request.app.state.cache.purge()
    request.app.state.metrics.cache_purges += 1
    return _data(result)


@router.get("/admin/review")
def admin_review(actor: Actor = Depends(_roles("editor")), db: Session = Depends(_session)):
    items = db.scalars(select(SourceItem).where(SourceItem.status.in_(("editorial_review", "quarantined", "needs_rights")))).all()
    stories = db.scalars(select(Story).where(Story.status == "editorial_review")).all()
    return _data(
        {
            "items": [
                {
                    "id": item.id,
                    "status": item.status,
                    "quarantine_reason": item.quarantine_reason,
                    "source_id": item.source_id,
                    "canonical_url": item.canonical_url,
                    "published_at": item.published_at.isoformat() if item.published_at else None,
                    "source_title": item.source_title,
                    "has_raw_description": bool(item.source_description),
                }
                for item in items
            ],
            "stories": [{"id": story.id, "title": story.editorial_title, "status": story.status, "risk_level": story.risk_level} for story in stories],
        }
    )


@router.post("/admin/stories", status_code=201)
def admin_story(body: StoryIn, request: Request, actor: Actor = Depends(_roles("editor")), db: Session = Depends(_session)):
    if body.risk_level not in {"normal", "high"}:
        raise ApiError(422, "validation", "Risk düzeyi geçersiz.", retryable=False)
    story = create_story(
        db,
        actor.name,
        request.app.state.clock.now(),
        body.model_dump(),
        synthetic_allowed=request.app.state.settings.synthetic_allowed,
    )
    request.app.state.metrics.review_backlog = review_backlog(db)
    return _data({"id": story.id, "status": story.status})


@router.post("/admin/stories/{story_id}/second-approval")
def admin_second(story_id: str, request: Request, actor: Actor = Depends(_roles("editor")), db: Session = Depends(_session)):
    story = _story_or_404(db, story_id)
    second_approve(db, story, actor.name, request.app.state.clock.now())
    return _data({"id": story.id, "second_approver": story.second_approver})


@router.post("/admin/stories/{story_id}/publish")
def admin_publish(
    story_id: str,
    body: PublishIn,
    request: Request,
    actor: Actor = Depends(_roles("editor")),
    db: Session = Depends(_session),
):
    key = request.headers.get("idempotency-key")
    digest = hashlib.sha256(f"{story_id}:{body.send_push}".encode()).hexdigest()
    if key:
        prior = db.get(IdempotencyRecord, key)
        if prior:
            if prior.request_hash != digest or prior.actor_name != actor.name:
                raise ApiError(409, "idempotency_conflict", "Aynı anahtar farklı istekle kullanıldı.", retryable=False)
            return JSONResponse(json.loads(prior.response_json), status_code=prior.status_code)
    story = _story_or_404(db, story_id)
    publish_story(
        db,
        story,
        actor.name,
        request.app.state.clock.now(),
        request.app.state.settings,
        request.app.state.metrics,
        send_push=body.send_push,
    )
    request.app.state.cache.purge()
    request.app.state.metrics.cache_purges += 1
    payload = _data({"id": story.id, "status": story.status})
    if key:
        db.add(
            IdempotencyRecord(
                key=key,
                actor_name=actor.name,
                request_hash=digest,
                status_code=200,
                response_json=json.dumps(payload),
                created_at=request.app.state.clock.now(),
            )
        )
        db.commit()
    return payload


@router.post("/admin/stories/{story_id}/correct")
def admin_correct(
    story_id: str,
    body: CorrectIn,
    request: Request,
    actor: Actor = Depends(_roles("editor")),
    db: Session = Depends(_session),
):
    story = _story_or_404(db, story_id)
    correct_story(
        db,
        story,
        actor.name,
        request.app.state.clock.now(),
        body.model_dump(),
        synthetic_allowed=request.app.state.settings.synthetic_allowed,
    )
    request.app.state.cache.purge()
    return _data({"id": story.id, "status": story.status})


@router.post("/admin/stories/{story_id}/withdraw")
def admin_withdraw(
    story_id: str,
    body: ReasonIn,
    request: Request,
    actor: Actor = Depends(_roles("editor", "legal_reviewer")),
    db: Session = Depends(_session),
):
    story = _story_or_404(db, story_id)
    withdraw_story(db, story, actor.name, actor.role, request.app.state.clock.now(), body.reason)
    request.app.state.cache.purge()
    return _data({"id": story.id, "status": story.status})


@router.post("/admin/stories/{story_id}/members")
def admin_add_member(
    story_id: str,
    body: MemberIn,
    request: Request,
    actor: Actor = Depends(_roles("editor")),
    db: Session = Depends(_session),
):
    story = _story_or_404(db, story_id)
    add_member(db, story, body.source_item_id, actor.name, request.app.state.clock.now(), request.app.state.settings)
    request.app.state.cache.purge()
    return _data({"id": story.id})


@router.delete("/admin/stories/{story_id}/members/{item_id}")
def admin_remove_member(
    story_id: str,
    item_id: str,
    request: Request,
    actor: Actor = Depends(_roles("editor")),
    db: Session = Depends(_session),
):
    story = _story_or_404(db, story_id)
    remove_member(db, story, item_id, actor.name, request.app.state.clock.now())
    request.app.state.cache.purge()
    return _data({"id": story.id})


@router.post("/admin/manual-items", status_code=201)
def admin_manual(body: ManualIn, request: Request, actor: Actor = Depends(_roles("editor")), db: Session = Depends(_session)):
    item = manual_item(db, actor.name, request.app.state.clock.now(), body.model_dump(), request.app.state.settings)
    return _data({"id": item.id, "status": item.status})


@router.post("/admin/takedowns", status_code=201)
def admin_takedown(
    body: TakedownIn,
    request: Request,
    actor: Actor = Depends(_roles("legal_reviewer")),
    db: Session = Depends(_session),
):
    complaint = takedown(db, actor.name, actor.role, request.app.state.clock.now(), body.model_dump())
    request.app.state.cache.purge()
    request.app.state.metrics.cache_purges += 1
    return _data({"id": complaint.id, "status": complaint.status})


@router.get("/admin/reports")
def admin_reports(actor: Actor = Depends(_roles("editor", "support")), db: Session = Depends(_session)):
    rows = db.scalars(select(ReaderReport).order_by(ReaderReport.created_at.desc())).all()
    return _data(
        [{"id": row.id, "story_id": row.story_id, "category": row.category, "status": row.status} for row in rows]
    )


@router.get("/admin/audit")
def admin_audit(actor: Actor = Depends(_roles("legal_reviewer", "source_admin")), db: Session = Depends(_session)):
    rows = db.scalars(select(AuditEvent).order_by(AuditEvent.at.desc()).limit(100)).all()
    return _data(
        [
            {"id": row.id, "actor": row.actor, "action": row.action, "entity_id": row.entity_id, "reason": row.reason}
            for row in rows
        ]
    )


@router.get("/admin/metrics")
def admin_metrics(request: Request, actor: Actor = Depends(_roles("source_admin"))):
    request.app.state.metrics.review_backlog = 0
    session = request.app.state.sessions()
    try:
        request.app.state.metrics.review_backlog = review_backlog(session)
    finally:
        session.close()
    return _data(request.app.state.metrics.snapshot())


def _source_or_404(db: Session, source_id: str) -> Source:
    source = db.get(Source, source_id)
    if source is None:
        raise ApiError(404, "not_found", "Kaynak bulunamadı.", retryable=False)
    return source


def _story_or_404(db: Session, story_id: str) -> Story:
    story = db.get(Story, story_id)
    if story is None:
        raise ApiError(404, "not_found", "Hikaye bulunamadı.", retryable=False)
    return story
