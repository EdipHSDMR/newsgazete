# Çizgi hava merkezi sözleşmesi

İstemci Open-Meteo’ya doğrudan gitmez. Yalnızca bu uygulamanın `/v1/weather` uçlarını çağırır. API anahtarı istemcide yoktur; Open-Meteo’nun ücretsiz Forecast ve Geocoding uçları sunucu tarafında, anahtarsız kullanılır ([Forecast docs](https://open-meteo.com/en/docs), [Geocoding docs](https://open-meteo.com/en/docs/geocoding-api)).

Web dosyaları:

- `/static/weather/weather.js`
- `/static/weather/weather.css`

## Mount API

```js
const handle = window.CizgiWeather.mount(container, {
  api,                 // (path, { signal }) => Promise<data>  — isteğe bağlı; yoksa createApi()
});
handle.destroy();
```

`CizgiWeather.createApi()` `fetch` ile kurar; yalnızca `Accept: application/json` ve `X-Request-ID` gönderir.

## Davranış

- Şehir **elle** aranır ve seçilir. GPS varsayılan **kapalı**; konum izni istenmez.
- Seçilen yer `localStorage` anahtarı `cizgi.weather.place.v1` altında tutulur.
- Gösterilenler: mevcut koşul, saatlik (48 saate kadar), 7 günlük özet, yağış / rüzgâr / UV, gün doğumu–batımı, yenile, sağlayıcı atıfı.
- Open-Meteo Forecast API resmi meteoroloji uyarısı sunmaz. `warnings_available: false` ve `warnings: []` gelir; istemci uyarı **uydurmaz**.
- Boş / hata / offline durumları ve `stale: true` önbellek açıkça gösterilir.

## Uçlar

Başarılı gövde: `{ "request_id", "data": { … } }`

Ortak meta: `provider`, `attribution`, `docs`, `geocode_docs`, `timezone` (`Europe/Istanbul`), `refreshed_at`, `from_cache`, `stale`, `warnings_available`.

### `GET /v1/weather/search?q=`

En az 2 karakter. `data.places[]`: `id`, `name`, `admin1`, `country`, `country_code`, `latitude`, `longitude`, `label`, …

### `GET /v1/weather/forecast?latitude=&longitude=&name=`

Metrik birimler (°C, km/h, mm). `data.forecast`: `current`, `hourly`, `daily`, `sunrise`, `sunset`, `warnings` (her zaman boş dizi), `warnings_available: false`.

## Hatalar

| HTTP | Kod | Anlam |
| --- | --- | --- |
| 422 | `validation` | Arama / koordinat geçersiz |
| 503 | `source_unavailable` | Sağlayıcı yok; taze önbellek yoksa |
| 0 | `offline` | Ağ yok |

503’te sunucu stale önbellek varsa 200 + `stale: true` döner.

## Android

```kotlin
@Composable
fun WeatherScreen(apiBase: String)
```

`apiBase` örneği `http://10.0.2.2:8000/v1/`. Anahtar eklenmez. GPS varsayılan kapalı.
