/* Çizgi hava merkezi. window.CizgiWeather.mount — ayrıntı CONTRACT.md */
(function (factory) {
  const api = factory();
  const pub = { mount: api.mount, createApi: api.createApi };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window !== "undefined") {
    window.CizgiWeather = pub;
  }
})(function () {
  "use strict";

  const TZ = "Europe/Istanbul";
  const CSS_HREF = "/static/weather/weather.css?v=cizgi17";
  const PLACE_KEY = "cizgi.weather.place.v1";
  const OM_HOME = "https://open-meteo.com/";

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[ch]));
  }
  function text(value) {
    if (value === null || value === undefined) return "";
    if (typeof value === "number" && Number.isFinite(value)) return String(value);
    if (typeof value === "string") return value.trim();
    return "";
  }
  function asArray(value) {
    return Array.isArray(value) ? value : [];
  }
  function num(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    return null;
  }
  function fmtTemp(value) {
    const n = num(value);
    if (n === null) return "—";
    return `${Math.round(n)}°`;
  }
  function fmtOne(value, suffix) {
    const n = num(value);
    if (n === null) return "—";
    const rounded = Math.abs(n) >= 10 ? Math.round(n) : Math.round(n * 10) / 10;
    return `${rounded}${suffix || ""}`;
  }
  function fmtPct(value) {
    const n = num(value);
    if (n === null) return "—";
    return `${Math.round(n)}%`;
  }
  function windDir(deg) {
    const n = num(deg);
    if (n === null) return "";
    const dirs = ["K", "KD", "D", "GD", "G", "GB", "B", "KB"];
    return dirs[Math.round(((n % 360) / 45)) % 8];
  }
  function clockPart(iso) {
    if (!iso) return "—";
    const date = new Date(String(iso).includes("T") ? iso : `${iso}T12:00:00`);
    if (Number.isNaN(date.getTime())) return "—";
    return new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ, hour: "2-digit", minute: "2-digit", hourCycle: "h23",
    }).format(date);
  }
  function weekdayLabel(iso) {
    if (!iso) return "";
    const date = new Date(`${String(iso).slice(0, 10)}T12:00:00`);
    if (Number.isNaN(date.getTime())) return String(iso).slice(0, 10);
    const label = new Intl.DateTimeFormat("tr-TR", { timeZone: TZ, weekday: "short" }).format(date);
    return label.charAt(0).toLocaleUpperCase("tr-TR") + label.slice(1);
  }
  function dayMonth(iso) {
    if (!iso) return "";
    const date = new Date(`${String(iso).slice(0, 10)}T12:00:00`);
    if (Number.isNaN(date.getTime())) return String(iso).slice(0, 10);
    return new Intl.DateTimeFormat("tr-TR", { timeZone: TZ, day: "numeric", month: "short" }).format(date);
  }
  function whenLabel(iso) {
    if (!iso) return "";
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ, dateStyle: "medium", timeStyle: "short",
    }).format(date);
  }
  function requestId() {
    const cryptoObj = globalThis.crypto;
    if (cryptoObj && typeof cryptoObj.randomUUID === "function") {
      return cryptoObj.randomUUID().replace(/-/g, "");
    }
    return `r${Date.now().toString(16)}${Math.floor(Math.random() * 1e8).toString(16)}`;
  }
  function unwrap(body) {
    if (!body || typeof body !== "object") return {};
    if (body.data && typeof body.data === "object" && !Array.isArray(body.data)) return body.data;
    return body;
  }
  function createApi(fetchImpl) {
    const doFetch = fetchImpl || globalThis.fetch;
    return async function api(path, options) {
      const opts = options || {};
      if (typeof doFetch !== "function") {
        const error = new Error("Bağlantı kurulamadı.");
        error.status = 0;
        error.code = "offline";
        throw error;
      }
      let response;
      try {
        response = await doFetch(path, {
          method: "GET",
          signal: opts.signal,
          headers: { Accept: "application/json", "X-Request-ID": requestId() },
        });
      } catch (cause) {
        if (cause && cause.name === "AbortError") throw cause;
        const error = new Error("Bağlantı kurulamadı.");
        error.status = 0;
        error.code = "offline";
        throw error;
      }
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = new Error(text(body && body.error && body.error.message) || "Hava servisi yanıt vermedi.");
        error.status = response.status;
        error.code = text(body && body.error && body.error.code) || "error";
        throw error;
      }
      return unwrap(body);
    };
  }
  function ensureCss() {
    if (typeof document === "undefined") return;
    if (document.querySelector("link[data-cizgi-weather-css]")) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = CSS_HREF;
    link.dataset.cizgiWeatherCss = "1";
    (document.head || document.documentElement).appendChild(link);
  }
  function readPlace() {
    try {
      const raw = JSON.parse(localStorage.getItem(PLACE_KEY) || "null");
      if (!raw || typeof raw !== "object") return null;
      const lat = num(raw.latitude);
      const lon = num(raw.longitude);
      if (lat === null || lon === null) return null;
      return {
        name: text(raw.name) || text(raw.label) || "Seçili yer",
        label: text(raw.label) || text(raw.name) || "Seçili yer",
        latitude: lat,
        longitude: lon,
        id: raw.id ?? null,
      };
    } catch {
      return null;
    }
  }
  function writePlace(place) {
    if (!place) {
      localStorage.removeItem(PLACE_KEY);
      return;
    }
    localStorage.setItem(PLACE_KEY, JSON.stringify({
      id: place.id ?? null,
      name: place.name,
      label: place.label || place.name,
      latitude: place.latitude,
      longitude: place.longitude,
    }));
  }
  function weatherPath(kind, params) {
    const search = new URLSearchParams();
    Object.entries(params || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") search.set(key, String(value));
    });
    const query = search.toString();
    return `/v1/weather/${kind}${query ? `?${query}` : ""}`;
  }

  function mount(container, options) {
    const settings = options || {};
    const api = typeof settings.api === "function" ? settings.api : createApi();
    ensureCss();

    if (!container) return { destroy() {} };

    const state = {
      place: readPlace(),
      query: "",
      suggestions: [],
      searching: false,
      searchError: "",
      loading: false,
      refreshing: false,
      error: "",
      offline: false,
      page: null,
      destroyed: false,
    };
    let searchAbort = null;
    let forecastAbort = null;
    let searchTimer = 0;

    function sourceLine(meta) {
      if (!meta) return "";
      const bits = [text(meta.provider) || "Open-Meteo"];
      if (meta.refreshed_at) bits.push(`yenilendi ${whenLabel(meta.refreshed_at)}`);
      if (meta.from_cache) bits.push("önbellek");
      if (meta.stale) bits.push("eski veri");
      return bits.join(" · ");
    }

    function render() {
      if (state.destroyed) return;
      const place = state.place;
      const page = state.page;
      const forecast = page && page.forecast ? page.forecast : null;
      const current = forecast && forecast.current ? forecast.current : null;
      const meta = page || null;

      let body = "";
      if (!place) {
        body = `<div class="cw-state"><p class="cw-kicker">Şehir</p><h3>Şehir seç</h3><p>Hava durumunu görmek için yukarıdan bir yer ara. Konum izni istenmez; GPS kapalıdır.</p></div>`;
      } else if (state.loading && !forecast) {
        body = `<div class="cw-state" role="status"><p class="cw-kicker">Yükleniyor</p><h3>Tahmin getiriliyor</h3><p>${esc(place.label)}</p></div>`;
      } else if (state.error && !forecast) {
        body = `<div class="cw-state cw-state-error" role="alert"><p class="cw-kicker">${state.offline ? "Bağlantı" : "Hata"}</p><h3>${state.offline ? "Çevrimdışı" : "Tahmin alınamadı"}</h3><p>${esc(state.error)}</p><button type="button" class="cw-btn" data-cw-refresh>Yeniden dene</button></div>`;
      } else if (forecast && current) {
        const hourly = asArray(forecast.hourly).slice(0, 24);
        const daily = asArray(forecast.daily).slice(0, 7);
        const staleNote = meta && meta.stale
          ? `<p class="cw-banner" role="status">Sağlayıcıya ulaşılamadı; son başarılı tahmin gösteriliyor.</p>`
          : "";
        const errNote = state.error
          ? `<p class="cw-banner cw-banner-warn" role="status">${esc(state.error)}</p>`
          : "";
        body = `${staleNote}${errNote}
          <section class="cw-now" aria-label="Mevcut koşul">
            <div class="cw-now-main">
              <p class="cw-place">${esc(place.label)}</p>
              <p class="cw-temp">${esc(fmtTemp(current.temperature_c))}</p>
              <p class="cw-cond">${esc(text(current.condition) || "—")}</p>
              <p class="cw-feels">Hissedilen ${esc(fmtTemp(current.feels_like_c))}</p>
            </div>
            <dl class="cw-facts">
              <div><dt>Nem</dt><dd>${esc(fmtPct(current.humidity_pct))}</dd></div>
              <div><dt>Yağış</dt><dd>${esc(fmtOne(current.precipitation_mm, " mm"))}</dd></div>
              <div><dt>Rüzgâr</dt><dd>${esc(fmtOne(current.wind_speed_kmh, " km/s"))}${windDir(current.wind_direction_deg) ? ` ${esc(windDir(current.wind_direction_deg))}` : ""}</dd></div>
              <div><dt>Gust</dt><dd>${esc(fmtOne(current.wind_gusts_kmh, " km/s"))}</dd></div>
              <div><dt>UV</dt><dd>${esc(fmtOne(current.uv_index, ""))}</dd></div>
              <div><dt>Basınç</dt><dd>${esc(fmtOne(current.pressure_hpa, " hPa"))}</dd></div>
            </dl>
          </section>
          <section class="cw-sun" aria-label="Gün doğumu ve batımı">
            <div><span class="cw-label">Doğuş</span><strong>${esc(clockPart(forecast.sunrise || (daily[0] && daily[0].sunrise)))}</strong></div>
            <div><span class="cw-label">Batış</span><strong>${esc(clockPart(forecast.sunset || (daily[0] && daily[0].sunset)))}</strong></div>
          </section>
          <section class="cw-block" aria-label="Saatlik tahmin">
            <h3>Saatlik</h3>
            <div class="cw-scroll" role="list">${hourly.length ? hourly.map((row) => `
              <article class="cw-hour" role="listitem">
                <span>${esc(clockPart(row.time))}</span>
                <strong>${esc(fmtTemp(row.temperature_c))}</strong>
                <span class="cw-muted">${esc(text(row.condition) || "—")}</span>
                <span class="cw-muted">yağış ${esc(fmtPct(row.precipitation_probability_pct))}</span>
                <span class="cw-muted">rüzgâr ${esc(fmtOne(row.wind_speed_kmh, " km/s"))}</span>
                <span class="cw-muted">UV ${esc(fmtOne(row.uv_index, ""))}</span>
              </article>`).join("") : "<p class='cw-muted'>Saatlik veri yok.</p>"}</div>
          </section>
          <section class="cw-block" aria-label="Yedi günlük tahmin">
            <h3>7 gün</h3>
            <div class="cw-days" role="list">${daily.length ? daily.map((row) => `
              <article class="cw-day" role="listitem">
                <div class="cw-day-head"><strong>${esc(weekdayLabel(row.date))}</strong><span>${esc(dayMonth(row.date))}</span></div>
                <p class="cw-day-cond">${esc(text(row.condition) || "—")}</p>
                <p class="cw-day-temps"><span>${esc(fmtTemp(row.temperature_max_c))}</span><span class="cw-muted">${esc(fmtTemp(row.temperature_min_c))}</span></p>
                <p class="cw-muted">yağış ${esc(fmtOne(row.precipitation_sum_mm, " mm"))} · ${esc(fmtPct(row.precipitation_probability_max_pct))}</p>
                <p class="cw-muted">rüzgâr ${esc(fmtOne(row.wind_speed_max_kmh, " km/s"))} · UV ${esc(fmtOne(row.uv_index_max, ""))}</p>
              </article>`).join("") : "<p class='cw-muted'>Günlük veri yok.</p>"}</div>
          </section>
          <p class="cw-note">Resmi meteoroloji uyarısı bu sağlayıcıda yok; uyarı üretilmez.</p>`;
      } else {
        body = `<div class="cw-state"><h3>Veri yok</h3><p>Bu yer için gösterilecek tahmin bulunamadı.</p><button type="button" class="cw-btn" data-cw-refresh>Yenile</button></div>`;
      }

      const suggestions = state.suggestions.length
        ? `<ul class="cw-suggest" role="listbox">${state.suggestions.map((item, index) => `
            <li><button type="button" role="option" data-cw-pick="${index}">${esc(item.label || item.name)}</button></li>`).join("")}</ul>`
        : (state.searching
          ? `<p class="cw-muted cw-search-status" role="status">Aranıyor…</p>`
          : (state.searchError
            ? `<p class="cw-search-error" role="status">${esc(state.searchError)}</p>`
            : (state.query.trim().length >= 2 && !state.searching
              ? `<p class="cw-muted cw-search-status">Sonuç yok.</p>`
              : "")));

      container.innerHTML = `<section class="cizgi-weather" aria-label="Hava durumu">
        <header class="cw-head">
          <div>
            <p class="cw-kicker">Meteoroloji</p>
            <h2>Hava</h2>
            <p class="cw-source">${esc(sourceLine(meta)) || "Şehir seçerek başla"}</p>
          </div>
          <button type="button" class="cw-btn cw-refresh" data-cw-refresh ${!place || state.loading || state.refreshing ? "disabled" : ""}>${state.refreshing ? "Yenileniyor…" : "Yenile"}</button>
        </header>
        <form class="cw-search" id="cw-search-form" autocomplete="off">
          <label class="cw-field">
            <span>Şehir ara</span>
            <input type="search" name="q" value="${esc(state.query)}" placeholder="Örn. İstanbul, Ankara, İzmir" maxlength="80" enterkeyhint="search">
          </label>
          <button type="submit" class="cw-btn">Ara</button>
          ${place ? `<button type="button" class="cw-btn cw-ghost" data-cw-clear>Temizle</button>` : ""}
        </form>
        ${suggestions}
        <div class="cw-body">${body}</div>
        <footer class="cw-attr">
          <p>Veri: <a href="${OM_HOME}" target="_blank" rel="noopener noreferrer">Open-Meteo</a> (CC BY 4.0). Saat dilimi ${esc(TZ)}. Metrik birimler.</p>
          <p class="cw-muted">${esc((meta && meta.attribution) || "Hava verisi Open-Meteo tarafından sağlanır.")}</p>
        </footer>
      </section>`;

      const form = container.querySelector("#cw-search-form");
      const input = container.querySelector('input[name="q"]');
      if (form) {
        form.onsubmit = (event) => {
          event.preventDefault();
          const q = (new FormData(form).get("q") || "").toString().trim();
          state.query = q;
          runSearch(q, true);
        };
      }
      if (input) {
        input.oninput = () => {
          state.query = input.value;
          window.clearTimeout(searchTimer);
          searchTimer = window.setTimeout(() => runSearch(state.query, false), 320);
        };
      }
      container.querySelectorAll("[data-cw-pick]").forEach((button) => {
        button.onclick = () => {
          const index = Number(button.getAttribute("data-cw-pick"));
          const picked = state.suggestions[index];
          if (!picked) return;
          selectPlace(picked);
        };
      });
      const refresh = container.querySelector("[data-cw-refresh]");
      if (refresh) refresh.onclick = () => loadForecast(true);
      const clear = container.querySelector("[data-cw-clear]");
      if (clear) {
        clear.onclick = () => {
          state.place = null;
          state.page = null;
          state.error = "";
          writePlace(null);
          render();
        };
      }
    }

    async function runSearch(query, force) {
      const q = text(query);
      state.query = q;
      if (q.length < 2) {
        state.suggestions = [];
        state.searchError = "";
        state.searching = false;
        render();
        return;
      }
      if (searchAbort) searchAbort.abort();
      searchAbort = typeof AbortController !== "undefined" ? new AbortController() : null;
      state.searching = true;
      state.searchError = "";
      if (force) render();
      try {
        const data = await api(weatherPath("search", { q }), { signal: searchAbort && searchAbort.signal });
        if (state.destroyed) return;
        state.suggestions = asArray(data.places);
        state.searching = false;
        state.searchError = "";
        render();
      } catch (error) {
        if (error && error.name === "AbortError") return;
        if (state.destroyed) return;
        state.searching = false;
        state.suggestions = [];
        state.searchError = text(error && error.message) || "Arama yapılamadı.";
        render();
      }
    }

    function selectPlace(place) {
      state.place = {
        id: place.id ?? null,
        name: text(place.name) || text(place.label),
        label: text(place.label) || text(place.name),
        latitude: num(place.latitude),
        longitude: num(place.longitude),
      };
      if (state.place.latitude === null || state.place.longitude === null) return;
      writePlace(state.place);
      state.query = state.place.label;
      state.suggestions = [];
      state.searchError = "";
      loadForecast(false);
    }

    async function loadForecast(isRefresh) {
      const place = state.place;
      if (!place) {
        render();
        return;
      }
      if (forecastAbort) forecastAbort.abort();
      forecastAbort = typeof AbortController !== "undefined" ? new AbortController() : null;
      state.loading = !isRefresh || !state.page;
      state.refreshing = !!isRefresh;
      state.error = "";
      state.offline = false;
      render();
      try {
        const data = await api(weatherPath("forecast", {
          latitude: place.latitude,
          longitude: place.longitude,
          name: place.label || place.name,
        }), { signal: forecastAbort && forecastAbort.signal });
        if (state.destroyed) return;
        state.page = data;
        state.loading = false;
        state.refreshing = false;
        state.error = "";
        state.offline = false;
        render();
      } catch (error) {
        if (error && error.name === "AbortError") return;
        if (state.destroyed) return;
        state.loading = false;
        state.refreshing = false;
        state.offline = !!(error && (error.code === "offline" || error.status === 0));
        state.error = text(error && error.message) || "Tahmin alınamadı.";
        render();
      }
    }

    render();
    if (state.place) loadForecast(false);

    return {
      destroy() {
        state.destroyed = true;
        window.clearTimeout(searchTimer);
        if (searchAbort) searchAbort.abort();
        if (forecastAbort) forecastAbort.abort();
        if (container) container.innerHTML = "";
      },
    };
  }

  return { mount, createApi };
});
