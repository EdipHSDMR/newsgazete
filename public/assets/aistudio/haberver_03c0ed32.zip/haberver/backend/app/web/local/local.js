/* Çizgi yerel gündem. window.CizgiLocal.mount — CONTRACT.md */
(function (factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.CizgiLocal = { mount: api.mount };
})(function () {
  "use strict";

  const KEY = "cizgi.local.v1";
  const TZ = "Europe/Istanbul";
  const KIND_LABEL = { haber: "Haber", duyuru: "Duyuru", servis: "Servis" };

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch])
    );
  }

  function readPref() {
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || "{}");
      const city = String(raw.city_slug || "").trim();
      const district = String(raw.district_slug || "").trim();
      return {
        city_slug: city || "",
        district_slug: district || "",
      };
    } catch {
      return { city_slug: "", district_slug: "" };
    }
  }

  function writePref(pref) {
    try {
      localStorage.setItem(
        KEY,
        JSON.stringify({
          city_slug: pref.city_slug || "",
          district_slug: pref.district_slug || "",
        })
      );
    } catch {
      /* cihaz depolaması kapalı olabilir */
    }
  }

  function parsePublished(iso) {
    if (!iso) return null;
    let raw = String(iso).trim();
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(raw)) raw += "Z";
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function when(iso) {
    const date = parsePublished(iso);
    return date
      ? new Intl.DateTimeFormat("tr-TR", {
          timeZone: TZ,
          dateStyle: "medium",
          timeStyle: "short",
        }).format(date)
      : "";
  }

  function httpsUrl(value) {
    const raw = String(value || "").trim();
    if (!raw.startsWith("https://")) return "";
    try {
      const url = new URL(raw);
      if (url.protocol !== "https:" || url.username || url.password) return "";
      return url.href;
    } catch {
      return "";
    }
  }

  function unwrap(body) {
    if (body && typeof body === "object" && "data" in body) return body.data;
    return body;
  }

  function fiction(item) {
    return (
      item.synthetic ||
      String(item.display_label || "").includes("Sentetik") ||
      String(item.editorial_title || "").startsWith("Örnek ") ||
      String(item.editorial_title || "").startsWith("Sentetik")
    );
  }

  function mount(container, options) {
    if (!container || !(container instanceof HTMLElement)) {
      throw new Error("CizgiLocal.mount: container gerekli");
    }
    const opts = options || {};
    const api = typeof opts.api === "function" ? opts.api : null;
    let destroyed = false;
    let pref = readPref();
    let cities = [];
    let cityQuery = "";
    let feed = null;
    let phase = "idle";
    let errorMessage = "";
    let searchTimer = null;
    const saved = new Set(
      Array.isArray(opts.savedIds) ? opts.savedIds.map(String) : []
    );

    container.classList.add("cizgi-local");
    if (!container.getAttribute("lang")) container.setAttribute("lang", "tr");
    container.setAttribute("aria-label", "Yerel gündem");

    async function call(path) {
      if (!api) {
        const res = await fetch(path, { headers: { Accept: "application/json" } });
        const body = await res.json().catch(() => ({}));
        if (!res.ok) {
          const err = new Error(body.error?.message || "İstek başarısız");
          err.phase = "error";
          throw err;
        }
        return unwrap(body);
      }
      return unwrap(await api(path));
    }

    function placeLabel() {
      if (!pref.city_slug) return "";
      const city = cities.find((c) => c.slug === pref.city_slug);
      const name = city ? city.name : pref.city_slug;
      if (!pref.district_slug || !city) return name;
      const dist = (city.districts || []).find((d) => d.slug === pref.district_slug);
      return dist ? `${name} · ${dist.name}` : name;
    }

    function cardHtml(item) {
      if (fiction(item)) return "";
      const kind = KIND_LABEL[item.local_kind] ? item.local_kind : "haber";
      const canon = httpsUrl(item.canonical_url);
      const rawPub = item.publisher_name || "";
      const publisher =
        rawPub && rawPub.toLocaleLowerCase("tr") !== "newsapi"
          ? rawPub
          : item.authorship_label || rawPub || "Kaynak";
      const title = item.editorial_title || "";
      const summary = item.editorial_summary || "";
      const id = item.id || "";
      const on = saved.has(String(id));
      return `<article class="cizgi-local-card">
        <div class="cizgi-local-card-top">
          <span class="cizgi-local-kind" data-kind="${esc(kind)}">${esc(KIND_LABEL[kind])}</span>
          <span>${esc(publisher)}</span>
          <time datetime="${esc(item.published_at || "")}">${esc(when(item.published_at))}</time>
        </div>
        <h2><a href="#/haber/${esc(id)}" data-open="${esc(id)}">${esc(title)}</a></h2>
        ${summary ? `<p class="dek">${esc(summary)}</p>` : ""}
        <div class="cizgi-local-actions">
          ${canon ? `<a class="btn" href="${esc(canon)}" target="_blank" rel="noopener noreferrer" data-original="${esc(canon)}">Kaynağında oku</a>` : ""}
          <a class="ghost" href="#/haber/${esc(id)}" data-open="${esc(id)}">Özeti aç</a>
          <button type="button" class="save" data-save="${esc(id)}" aria-pressed="${on}">${on ? "Kaydedildi" : "Kaydet"}</button>
        </div>
      </article>`;
    }

    function render() {
      if (destroyed) return;
      const label = placeLabel();
      const city = cities.find((c) => c.slug === pref.city_slug);
      const districts = city && Array.isArray(city.districts) ? city.districts : [];
      const cityChips = cities
        .slice(0, 24)
        .map(
          (c) =>
            `<li><button type="button" data-city="${esc(c.slug)}" aria-pressed="${c.slug === pref.city_slug}">${esc(c.name)}</button></li>`
        )
        .join("");
      const districtChips = districts.length
        ? `<div class="cizgi-local-districts" role="toolbar" aria-label="İlçe">${[
            `<button type="button" data-district="" aria-pressed="${!pref.district_slug}">Tüm il</button>`,
            ...districts.map(
              (d) =>
                `<button type="button" data-district="${esc(d.slug)}" aria-pressed="${d.slug === pref.district_slug}">${esc(d.name)}</button>`
            ),
          ].join("")}</div>`
        : "";

      let body = "";
      if (!pref.city_slug) {
        body = `<div class="cizgi-local-empty"><h2>Şehir seç</h2><p>Yerel gündem GPS kullanmaz. İlini elle seç; tercih bu tarayıcıda kalır.</p></div>`;
      } else if (phase === "loading") {
        body = `<p class="cizgi-local-note" role="status">Yerel başlıklar yükleniyor…</p>`;
      } else if (phase === "error") {
        body = `<div class="cizgi-local-error"><h2>Akış alınamadı</h2><p>${esc(errorMessage)}</p><button type="button" class="ghost" data-retry>Yeniden dene</button></div>`;
      } else if (feed && feed.empty) {
        body = `<div class="cizgi-local-empty"><h2>${esc(label)} için başlık yok</h2><p>${esc(feed.config_note || "Eşleşen yerel özet yok.")}</p><p class="cizgi-local-license">${esc(feed.license_note || "")}</p></div>`;
      } else if (feed && (feed.items || []).length) {
        const cards = (feed.items || []).map(cardHtml).filter(Boolean).join("");
        body = `${cards ? `<div class="cizgi-local-list">${cards}</div>` : `<div class="cizgi-local-empty"><h2>Gösterilecek başlık yok</h2></div>`}
          <p class="cizgi-local-license">${esc(feed.license_note || "")}</p>`;
      } else {
        body = `<p class="cizgi-local-note">Şehir seçildiğinde mevcut izinli özetler süzülür.</p>`;
      }

      container.innerHTML = `
        <header class="cizgi-local-head">
          <p class="kicker">Yerel gündem</p>
          <h1>${label ? esc(label) : "İl ve ilçe"}</h1>
          <p class="deck">Konum izni istenmez. Yalnızca yayındaki özetler şehir adına göre süzülür; tam metin yayıncıda kalır.</p>
        </header>
        <section class="cizgi-local-picker" aria-label="Şehir seçimi">
          <div class="cizgi-local-search-wrap">
            <label>Şehir ara<input type="search" name="q" value="${esc(cityQuery)}" placeholder="Örn. İstanbul, 34, İzmir" autocomplete="off"></label>
          </div>
          <ul class="cizgi-local-cities">${cityChips || "<li><span class=\"cizgi-local-note\">Katalog yükleniyor…</span></li>"}</ul>
          ${districtChips}
        </section>
        ${body}
      `;
    }

    async function loadCities(q) {
      cityQuery = q || "";
      try {
        const path = `/v1/local/cities?limit=40${cityQuery ? `&q=${encodeURIComponent(cityQuery)}` : ""}`;
        const data = await call(path);
        cities = Array.isArray(data.items) ? data.items : [];
        // Seçili şehir listede yoksa tek satır olarak ekle (tercih bozulmasın).
        if (pref.city_slug && !cities.some((c) => c.slug === pref.city_slug)) {
          try {
            const one = await call(`/v1/local/cities?limit=5&q=${encodeURIComponent(pref.city_slug)}`);
            const hit = (one.items || []).find((c) => c.slug === pref.city_slug);
            if (hit) cities = [hit, ...cities];
          } catch {
            /* tercih yine de gösterilir */
          }
        }
      } catch (err) {
        cities = [];
        errorMessage = err.message || "Şehir listesi alınamadı.";
        phase = "error";
      }
      render();
    }

    async function loadFeed() {
      if (!pref.city_slug) {
        feed = null;
        phase = "idle";
        render();
        return;
      }
      phase = "loading";
      errorMessage = "";
      render();
      try {
        const params = new URLSearchParams({ city: pref.city_slug, limit: "24" });
        if (pref.district_slug) params.set("district", pref.district_slug);
        feed = await call(`/v1/local/feed?${params}`);
        phase = "idle";
      } catch (err) {
        feed = null;
        phase = "error";
        errorMessage = err.message || "Yerel akış alınamadı.";
      }
      render();
    }

    function onClick(event) {
      const cityBtn = event.target.closest("[data-city]");
      if (cityBtn) {
        pref = { city_slug: cityBtn.getAttribute("data-city") || "", district_slug: "" };
        writePref(pref);
        loadFeed();
        return;
      }
      const distBtn = event.target.closest("[data-district]");
      if (distBtn) {
        pref = {
          city_slug: pref.city_slug,
          district_slug: distBtn.getAttribute("data-district") || "",
        };
        writePref(pref);
        loadFeed();
        return;
      }
      const open = event.target.closest("[data-open]");
      if (open) {
        event.preventDefault();
        const id = open.getAttribute("data-open");
        if (id && typeof opts.onOpenStory === "function") opts.onOpenStory(id);
        else if (id) location.hash = `#/haber/${id}`;
        return;
      }
      const original = event.target.closest("[data-original]");
      if (original) {
        const url = original.getAttribute("data-original");
        if (url && typeof opts.onOpenOriginal === "function") {
          event.preventDefault();
          opts.onOpenOriginal(url);
        }
        return;
      }
      const saveBtn = event.target.closest("[data-save]");
      if (saveBtn) {
        const id = saveBtn.getAttribute("data-save");
        if (!id) return;
        if (saved.has(id)) saved.delete(id);
        else saved.add(id);
        if (typeof opts.onSave === "function") opts.onSave(id);
        saveBtn.setAttribute("aria-pressed", String(saved.has(id)));
        saveBtn.textContent = saved.has(id) ? "Kaydedildi" : "Kaydet";
        return;
      }
      if (event.target.closest("[data-retry]")) loadFeed();
    }

    function onInput(event) {
      const input = event.target.closest('input[name="q"]');
      if (!input) return;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => loadCities(input.value.trim()), 220);
    }

    container.addEventListener("click", onClick);
    container.addEventListener("input", onInput);
    render();
    loadCities("").then(() => loadFeed());

    return {
      reload() {
        if (!destroyed) loadFeed();
      },
      destroy() {
        destroyed = true;
        clearTimeout(searchTimer);
        container.removeEventListener("click", onClick);
        container.removeEventListener("input", onInput);
        container.classList.remove("cizgi-local");
        container.innerHTML = "";
      },
    };
  }

  return { mount };
});
