# Çizgi yerel gündem sözleşmesi

İl/ilçe yerel yüzey. GPS yok; şehir elle seçilir ve `localStorage` anahtarı `cizgi.local.v1` altında tutulur. Sahte haber üretilmez.

Web dosyaları:

- `/static/local/local.js`
- `/static/local/local.css`

`app.js` `#/yerel` ve `#/konu/yerel` rotalarında `window.CizgiLocal.mount` çağırır.

## Mount

```js
const handle = window.CizgiLocal.mount(container, {
  api,                 // (path, opts?) => Promise<data>  — gövde `data` veya `{data}`
  onOpenStory,         // (id) => void
  onOpenOriginal,      // (url) => void
  onSave,              // (id) => void
  savedIds,            // string[]
});
handle.reload();
handle.destroy();
```

## API

### `GET /v1/local/cities?q=&limit=`

Katalog araması. `items[]`: `{ slug, name, plate, districts[{slug,name}] }`.

### `GET /v1/local/feed?city=&district=&limit=&cursor=`

Yalnızca mevcut görünür feed kayıtlarını süzer:

- `topic_slug=yerel` **ve** şehir/ilçe adı başlık veya özet içinde, **veya**
- başlık/özette şehir (ve varsa ilçe) adı eşlemesi.

Kaynak yoksa `empty: true` ve `config_note` (yapılandırma notu). Tam metin yok.

Kart alanları (StoryCard + yerel):

| Alan | Anlam |
|------|--------|
| `publisher_name` | Kaynak adı (izin varsa) |
| `published_at` | Zaman |
| `canonical_url` | Yayıncı kanonik URL |
| `local_kind` | `haber` / `duyuru` / `servis` (başlıktan sezgisel) |
| `editorial_title` / `editorial_summary` | Editöryal spot; gövde değil |
| `license_note` | Yanıt düzeyinde lisans uyarısı |

## Tercih

```json
{ "city_slug": "istanbul", "district_slug": "kadikoy" }
```

Sunucu tercih saklamaz. Modül `cizgi.local.v1` okur/yazar.

## Lisans sınırları

- Tam makale HTML / kopya yok
- Spot özeti ve kaynak bağlantısı; `link` izni yoksa kart düşer
- Sentetik veya izin süresi dolmuş kayıtlar ana feed kurallarıyla gizlenir
