(function () {
  "use strict";

  const SLOW_MS = 2500;
  const cssHref = (function () {
    if (typeof document === "undefined" || !document.currentScript || !document.currentScript.src) {
      return "/static/discover/search.css";
    }
    return new URL("search.css", document.currentScript.src).href;
  })();

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[ch]));
  }

  function fold(value) {
    return String(value ?? "").toLocaleLowerCase("tr-TR");
  }

  function fiction(item) {
    if (!item || typeof item !== "object") return true;
    if (item.synthetic === true) return true;
    const label = fold(item.display_label);
    if (label.includes("sentetik") || label.includes("kurmaca")) return true;
    const title = String(item.editorial_title || "").trim();
    if (fold(title).startsWith("sentetik")) return true;
    if (fold(item.editorial_summary).includes("gerçek bir haber değildir")) return true;
    return false;
  }

  function listed(item) {
    return Boolean(item && item.id && String(item.editorial_title || "").trim() && !fiction(item));
  }

  function sourceLabel(item) {
    const label = String(item && item.authorship_label || "").trim();
    if (!label || fold(label) === "editoryal özet") return "Kaynak";
    return label;
  }

  function fieldHit(item, query) {
    const needle = fold(String(query || "").trim());
    if (!needle) return true;
    return [item.editorial_title, item.authorship_label, item.topic_name, item.topic_slug, item.editorial_summary]
      .some((value) => fold(value).includes(needle));
  }

  function stamp(iso) {
    const time = Date.parse(iso || "");
    return Number.isFinite(time) ? time : 0;
  }

  function byNewest(a, b) {
    return stamp(b.published_at) - stamp(a.published_at);
  }

  function dayStart(now, daysBack) {
    const date = new Date(now);
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() - daysBack);
    return date.getTime();
  }

  function inRange(iso, range, now) {
    if (!range || range === "all") return true;
    const time = stamp(iso);
    if (!time) return false;
    const clock = now == null ? Date.now() : now;
    if (range === "today") return time >= dayStart(clock, 0);
    if (range === "7d") return time >= dayStart(clock, 6);
    if (range === "30d") return time >= dayStart(clock, 29);
    return true;
  }

  function spot(summary) {
    const text = String(summary || "").replace(/\s+/g, " ").trim();
    if (!text) return "";
    const parts = text.split(/(?<=[.!?…])\s+/).filter(Boolean);
    const taken = (parts.length ? parts.slice(0, 2).join(" ") : text);
    if (taken.length <= 240) return taken;
    const cut = taken.slice(0, 240);
    const space = cut.lastIndexOf(" ");
    return `${(space > 160 ? cut.slice(0, space) : cut).trim()}…`;
  }

  function timeLabel(iso, now) {
    const time = stamp(iso);
    if (!time) return "";
    const clock = now == null ? Date.now() : now;
    const delta = clock - time;
    const minute = 60000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (delta >= 0 && delta < minute) return "az önce";
    if (delta >= minute && delta < hour) return `${Math.floor(delta / minute)} dk`;
    if (delta >= hour && delta < day) return `${Math.floor(delta / hour)} sa`;
    if (delta >= day && delta < 7 * day) return `${Math.floor(delta / day)} gün`;
    return new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "short" }).format(new Date(time));
  }

  function safeImage(url) {
    if (!url || typeof url !== "string") return "";
    try {
      const parsed = new URL(url);
      return parsed.protocol === "https:" ? parsed.href : "";
    } catch {
      return "";
    }
  }

  function mergeItems(searchItems, feedItems, query) {
    const map = new Map();
    const titles = new Set();
    const titleKey = (item) => fold(String(item && item.editorial_title || ""))
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
    const add = (item) => {
      const key = titleKey(item);
      if (!listed(item) || map.has(item.id) || (key && titles.has(key))) return;
      map.set(item.id, item);
      if (key) titles.add(key);
    };
    (searchItems || []).forEach(add);
    const needle = String(query || "").trim();
    (feedItems || []).forEach((item) => {
      if (!needle || fieldHit(item, needle)) add(item);
    });
    return [...map.values()];
  }

  function applyFilters(items, options) {
    const range = options && options.dateRange;
    const category = options && options.category;
    const publisher = options && options.publisher;
    const now = options && options.now;
    return (items || [])
      .filter((item) => listed(item) && inRange(item.published_at, range, now))
      .filter((item) => !category || item.topic_slug === category)
      .filter((item) => !publisher || sourceLabel(item) === publisher)
      .slice()
      .sort(byNewest);
  }

  function categoriesOf(items) {
    const map = new Map();
    (items || []).forEach((item) => {
      if (item.topic_slug) map.set(item.topic_slug, item.topic_name || item.topic_slug);
    });
    return [...map.entries()]
      .map(([slug, name]) => ({ slug, name }))
      .sort((a, b) => a.name.localeCompare(b.name, "tr"));
  }

  function publishersOf(items) {
    const labels = new Set();
    (items || []).forEach((item) => labels.add(sourceLabel(item)));
    return [...labels].sort((a, b) => a.localeCompare(b, "tr"));
  }

  function filterTopics(topics, query) {
    const needle = fold(String(query || "").trim());
    return (topics || []).filter((topic) => {
      if (!topic || !topic.slug || !topic.name) return false;
      if (!needle) return true;
      return fold(topic.name).includes(needle) || fold(topic.slug).includes(needle);
    });
  }

  function groupSources(items, query) {
    const groups = new Map();
    (items || []).forEach((item) => {
      const label = sourceLabel(item);
      if (!groups.has(label)) groups.set(label, []);
      groups.get(label).push(item);
    });
    const needle = fold(String(query || "").trim());
    return [...groups.entries()]
      .map(([label, stories]) => ({ label, stories: stories.slice().sort(byNewest) }))
      .sort((a, b) => {
        const rank = (group) => (needle.length >= 2 && fold(group.label).includes(needle) ? 1 : 0);
        return rank(b) - rank(a) || b.stories.length - a.stories.length || a.label.localeCompare(b.label, "tr");
      });
  }

  function unwrap(payload) {
    if (payload == null) return payload;
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload.items) || Object.prototype.hasOwnProperty.call(payload, "next_cursor")) return payload;
    if (payload.data) return unwrap(payload.data);
    return payload;
  }

  function classify(error) {
    const err = error instanceof Error ? error : new Error("Arama tamamlanamadı. Yeniden deneyin.");
    const status = Number(err.status || err.statusCode || 0);
    const code = String(err.code || "");
    const message = err.message || "Arama tamamlanamadı. Yeniden deneyin.";
    if (status === 429 || code === "rate_limited" || message.includes("sınır") || message.includes("kota")) {
      return { phase: "quota", message, retryable: true };
    }
    if (err.phase === "offline" || /failed to fetch|networkerror|bağlantı kurulamadı/i.test(message)) {
      return { phase: "offline", message: message || "Bağlantı kurulamadı. Yeniden deneyin.", retryable: true };
    }
    return { phase: "error", message, retryable: err.retryable !== false };
  }

  function ensureCss() {
    if (typeof document === "undefined") return;
    if (document.querySelector("link[data-cizgi-search-css]")) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = cssHref;
    link.dataset.cizgiSearchCss = "1";
    (document.head || document.documentElement).appendChild(link);
  }

  function countLabel(tab, count) {
    if (tab === "topics") return `${count} konu`;
    if (tab === "sources") return `${count} kaynak`;
    return `${count} sonuç`;
  }

  const mounts = new WeakMap();

  function mount(container, options) {
    if (!container || typeof container.addEventListener !== "function") {
      throw new Error("CizgiSearch.mount bir DOM öğesi ister.");
    }
    const previous = mounts.get(container);
    if (previous) previous.destroy();
    ensureCss();

    const opts = options || {};
    let api = opts.api;
    let recent = Array.isArray(opts.recent) ? opts.recent.slice(0, 8) : [];
    let saved = toSet(opts.savedIds);
    let query = "";
    let tab = "news";
    let dateRange = "all";
    let category = "";
    let publisher = "";
    let selectedTopic = "";
    let topics = [];
    let topicsError = "";
    let raw = [];
    let phase = "loading";
    let errorMessage = "";
    let hint = "";
    let feedNote = "";
    let searchCursor = null;
    let feedCursor = null;
    let primary = "feed";
    let signature = "";
    let requestGen = 0;
    let slowTimer = 0;
    let debounceTimer = 0;
    let alive = true;
    let topicsPromise = null;
    const abort = new AbortController();
    const DEBOUNCE_MS = 320;

    function toSet(value) {
      if (!value) return new Set();
      if (typeof value[Symbol.iterator] === "function" && !Array.isArray(value) && !(value instanceof Set)) {
        return new Set();
      }
      try { return new Set(value); } catch { return new Set(); }
    }

    function emit(fn, arg) {
      try { if (typeof fn === "function") fn(arg); } catch { /* çağıran hata verirse yüzey ayakta kalır */ }
    }

    function remember(term) {
      recent = [term, ...recent.filter((item) => item !== term)].slice(0, 8);
      emit(opts.onRecentChange, recent.slice());
    }

    function datedItems() {
      return raw.filter((item) => listed(item) && inRange(item.published_at, dateRange));
    }

    function shownItems() {
      return applyFilters(raw, { dateRange, category, publisher });
    }

    function activeTopics() {
      return filterTopics(topics, query);
    }

    function cardHtml(item) {
      const image = safeImage(item.image);
      const initial = fold(item.topic_name || item.editorial_title || "ç").trim().charAt(0).toLocaleUpperCase("tr-TR") || "Ç";
      const media = image
        ? `<img class="cizgi-photo" alt="" src="${esc(image)}" data-fallback="${esc(initial)}">`
        : `<span class="cizgi-fallback" aria-hidden="true">${esc(initial)}</span>`;
      const lead = spot(item.editorial_summary);
      const on = saved.has(item.id);
      return `<article class="cizgi-card">
        <button type="button" class="cizgi-open" data-open="${esc(item.id)}">
          <span class="cizgi-media">${media}</span>
          <span class="cizgi-body">
            <strong class="cizgi-title">${esc(item.editorial_title)}</strong>
            ${lead ? `<span class="cizgi-spot">${esc(lead)}</span>` : ""}
            <span class="cizgi-meta">${esc(sourceLabel(item))} · ${esc(timeLabel(item.published_at))}</span>
          </span>
        </button>
        <button type="button" class="cizgi-save" data-save="${esc(item.id)}" aria-pressed="${on ? "true" : "false"}" aria-label="${on ? "Kaydı kaldır" : "Kaydet"}">${on ? "Kayıtlı" : "Kaydet"}</button>
      </article>`;
    }

    function chips(items, attr, current) {
      return items.map((item) => {
        const value = item.value;
        const on = value === current;
        return `<button type="button" class="cizgi-chip" data-${attr}="${esc(value)}" aria-pressed="${on ? "true" : "false"}">${esc(item.label)}</button>`;
      }).join("");
    }

    function statusNote() {
      if (phase === "loading" && !raw.length) {
        return `<div class="cizgi-stack" aria-hidden="true"><div class="cizgi-skeleton"></div><div class="cizgi-skeleton"></div></div><p class="cizgi-hint">Başlıklar yükleniyor.</p>`;
      }
      if (phase === "slow") {
        const waiting = raw.length ? "Önceki sonuçlar duruyor. İstersen yeniden dene." : "İstek hâlâ sürüyor. İstersen yeniden dene.";
        return `<div class="cizgi-note" role="status"><h3>Arama uzun sürüyor</h3><p>${waiting}</p><button type="button" class="cizgi-btn alt" data-retry="1">Yeniden dene</button></div>`;
      }
      if (phase === "error" || phase === "offline" || phase === "quota") {
        const title = phase === "quota" ? "Arama sınırı" : phase === "offline" ? "Bağlantı yok" : "Arama tamamlanamadı";
        return `<div class="cizgi-note is-${phase}" role="alert"><h3>${title}</h3><p>${esc(errorMessage || "Yeniden deneyin.")}</p><button type="button" class="cizgi-btn alt" data-retry="1">Yeniden dene</button></div>`;
      }
      return "";
    }

    function emptyCopy() {
      const dated = datedItems();
      if (dated.length && !shownItems().length) return "Bu süzgeçte haber yok.";
      if (query.trim().length >= 2) return "Bu aramada haber yok.";
      if (selectedTopic) return "Bu konuda şu an haber yok.";
      return "Şu anda listelenecek haber yok.";
    }

    function resultsHtml() {
      const note = statusNote();
      if (tab === "topics") {
        const list = activeTopics();
        const stories = shownItems().filter((item) => !selectedTopic || item.topic_slug === selectedTopic);
        const waitingTopics = !list.length && !topicsError && (phase === "loading" || phase === "slow");
        const body = list.length
          ? `<div class="cizgi-chips">${list.map((topic) => `<button type="button" class="cizgi-chip" data-topic="${esc(topic.slug)}" aria-pressed="${topic.slug === selectedTopic ? "true" : "false"}">${esc(topic.name)}</button>`).join("")}</div>`
          : waitingTopics
            ? `<p class="cizgi-empty">Konular yükleniyor.</p>`
            : `<p class="cizgi-empty">${topicsError ? esc(topicsError) : "Eşleşen konu yok."}</p>${topicsError ? `<button type="button" class="cizgi-btn alt" data-retry="topics">Yeniden dene</button>` : ""}`;
        const under = selectedTopic
          ? (stories.length ? `<div class="cizgi-cards">${stories.map(cardHtml).join("")}</div>` : (phase === "loading" || phase === "slow" ? "" : `<p class="cizgi-empty">Bu konuda şu an haber yok.</p><button type="button" class="cizgi-btn alt" data-retry="1">Yeniden dene</button>`))
          : `<p class="cizgi-hint">Konuya dokununca o konunun haberleri listelenir.</p>`;
        return `${note}<p class="cizgi-count" role="status">${esc(countLabel("topics", list.length))}</p>${body}<div class="cizgi-block">${under}</div>`;
      }
      if (tab === "sources") {
        const groups = groupSources(shownItems(), query);
        const body = groups.length
          ? groups.map((group) => `<section class="cizgi-source"><h3>${esc(group.label)}</h3><p class="cizgi-meta">${group.stories.length} haber</p><div class="cizgi-cards">${group.stories.map(cardHtml).join("")}</div></section>`).join("")
          : (phase === "loading" || phase === "slow" ? "" : `<div class="cizgi-note"><h3>Eşleşen kaynak yok</h3><p>Kaynaklar, dönen haberlerdeki yayıncı adından çıkar.</p><button type="button" class="cizgi-btn alt" data-retry="1">Yeniden dene</button></div>`);
        return `${note}<p class="cizgi-count" role="status">${esc(countLabel("sources", groups.length))}</p><div class="cizgi-stack">${body}</div>`;
      }
      const stories = shownItems();
      if ((phase === "loading" || phase === "slow") && !stories.length) {
        return `${note}<p class="cizgi-count" role="status">${esc(countLabel("news", 0))}</p>`;
      }
      const hideEmpty = phase === "error" || phase === "offline" || phase === "quota";
      const cards = stories.length
        ? `<div class="cizgi-cards">${stories.map(cardHtml).join("")}</div>`
        : (hideEmpty ? "" : `<div class="cizgi-note"><h3>Sonuç yok</h3><p>${esc(emptyCopy())}</p><button type="button" class="cizgi-btn alt" data-retry="1">Yeniden dene</button></div>`);
      const cursor = primary === "search" ? searchCursor : feedCursor;
      const more = cursor && phase === "ready"
        ? `<button type="button" class="cizgi-btn alt cizgi-more" data-more="1">Daha fazla</button>`
        : "";
      return `${note}<p class="cizgi-count" role="status">${esc(countLabel("news", stories.length))}</p>${cards}${more}`;
    }

    function sideHtml() {
      const topicButtons = topics.length
        ? topics.map((topic) => `<button type="button" class="cizgi-chip" data-topic="${esc(topic.slug)}" aria-pressed="${topic.slug === selectedTopic ? "true" : "false"}">${esc(topic.name)}</button>`).join("")
        : `<p>${topicsError ? esc(topicsError) : "Konular yükleniyor."}</p>${topicsError ? `<button type="button" class="cizgi-btn alt" data-retry="topics">Yeniden dene</button>` : ""}`;
      const recentButtons = recent.length
        ? recent.map((item, index) => `<button type="button" class="cizgi-chip" data-recent="${index}">${esc(item)}</button>`).join("")
        : `<p>Henüz arama yok. Bir sorgu yazınca burada durur.</p>`;
      const clear = recent.length ? `<button type="button" class="cizgi-btn alt" data-clear-recent="1">Temizle</button>` : "";
      return `<aside class="cizgi-side">
        <section><h3>Popüler konular</h3><div class="cizgi-chips">${topicButtons}</div></section>
        <section class="cizgi-block"><h3>Son aramalar</h3><div class="cizgi-chips">${recentButtons}</div>${clear ? `<div class="cizgi-block">${clear}</div>` : ""}</section>
      </aside>`;
    }

    function filtersHtml() {
      const pool = datedItems();
      const categories = categoriesOf(pool);
      const publishers = publishersOf(pool);
      const dates = [
        { value: "all", label: "Tümü" },
        { value: "today", label: "Bugün" },
        { value: "7d", label: "7 gün" },
        { value: "30d", label: "30 gün" },
      ];
      const categoryChips = categories.length
        ? `<div><p class="cizgi-row-label">Kategori</p><div class="cizgi-chips">${chips([{ value: "", label: "Tümü" }, ...categories.map((item) => ({ value: item.slug, label: item.name }))], "category", category)}</div></div>`
        : "";
      const publisherChips = publishers.length
        ? `<div><p class="cizgi-row-label">Yayıncı</p><div class="cizgi-chips">${chips([{ value: "", label: "Tümü" }, ...publishers.map((label) => ({ value: label, label }))], "publisher", publisher)}</div></div>`
        : "";
      const topicName = topics.find((item) => item.slug === selectedTopic);
      const chosen = selectedTopic
        ? `<div class="cizgi-chips"><span class="cizgi-chip" aria-pressed="true">${esc(topicName ? topicName.name : selectedTopic)}</span><button type="button" class="cizgi-btn alt" data-clear-topic="1">Konuyu kaldır</button></div>`
        : "";
      return `<div class="cizgi-filters">
        ${chosen}
        <div><p class="cizgi-row-label">Tarih</p><div class="cizgi-chips">${chips(dates, "date", dateRange)}</div></div>
        <p class="cizgi-row-label">Sıra: en yeni</p>
        ${categoryChips}
        ${publisherChips}
      </div>`;
    }

    function template() {
      const trimmed = query.trim();
      const lengthHint = hint || (trimmed.length === 1 ? "Aramak için en az 2 karakter yaz." : "");
      return `<header class="cizgi-head"><p class="cizgi-kicker">Ara ve keşfet</p><h2>Aradığın gündemi bul.</h2><p class="cizgi-dek">Başlık, yayıncı, konu veya özette ara.</p></header>
        <form class="cizgi-form" id="cizgi-form" role="search">
          <label class="cizgi-label" for="cizgi-q">Sorgu</label>
          <input id="cizgi-q" name="q" type="search" enterkeyhint="search" autocomplete="off" placeholder="Örn. ekonomi, İstanbul, yayıncı" value="${esc(query)}">
          <div class="cizgi-form-actions">
            <button class="cizgi-btn" type="submit">Ara</button>
            ${query ? `<button class="cizgi-btn alt" type="button" data-clear-query="1">Sorguyu temizle</button>` : ""}
          </div>
        </form>
        ${lengthHint ? `<p class="cizgi-hint" role="status">${esc(lengthHint)}</p>` : ""}
        ${feedNote ? `<p class="cizgi-hint">${esc(feedNote)}</p>` : ""}
        <div class="cizgi-layout">
          ${sideHtml()}
          <div class="cizgi-main">
            <div class="cizgi-tabs" role="tablist" aria-label="Sonuç türü">
              <button type="button" class="cizgi-tab" role="tab" data-tab="news" aria-selected="${tab === "news" ? "true" : "false"}">Haberler</button>
              <button type="button" class="cizgi-tab" role="tab" data-tab="topics" aria-selected="${tab === "topics" ? "true" : "false"}">Konular</button>
              <button type="button" class="cizgi-tab" role="tab" data-tab="sources" aria-selected="${tab === "sources" ? "true" : "false"}">Kaynaklar</button>
            </div>
            ${filtersHtml()}
            <div id="cizgi-panel" role="tabpanel">${resultsHtml()}</div>
          </div>
        </div>`;
    }

    function render() {
      if (!alive) return;
      const input = container.querySelector("#cizgi-q");
      const focused = input && document.activeElement === input;
      const caret = focused ? input.selectionStart : null;
      container.classList.add("cizgi-search");
      container.setAttribute("aria-busy", phase === "loading" || phase === "slow" ? "true" : "false");
      container.innerHTML = template();
      if (focused) {
        const next = container.querySelector("#cizgi-q");
        if (next) {
          next.focus();
          if (caret != null) {
            const pos = Math.min(caret, next.value.length);
            next.setSelectionRange(pos, pos);
          }
        }
      }
      container.querySelectorAll("img.cizgi-photo").forEach((img) => {
        img.addEventListener("error", () => {
          const fallback = document.createElement("span");
          fallback.className = "cizgi-fallback";
          fallback.setAttribute("aria-hidden", "true");
          fallback.textContent = img.dataset.fallback || "Ç";
          img.replaceWith(fallback);
        });
      });
    }

    async function ensureTopics() {
      if (topics.length) return topics;
      if (!topicsPromise) {
        topicsPromise = Promise.resolve()
          .then(() => api("/v1/topics"))
          .then((payload) => {
            const list = unwrap(payload);
            topics = Array.isArray(list) ? list.filter((topic) => topic && topic.slug && topic.name) : [];
            topicsError = topics.length ? "" : "Yayında konu listesi yok.";
            return topics;
          })
          .catch((error) => {
            topicsPromise = null;
            topicsError = classify(error).message;
            throw error;
          });
      }
      return topicsPromise;
    }

    async function readPage(path) {
      const page = unwrap(await api(path));
      return {
        items: page && Array.isArray(page.items) ? page.items : [],
        cursor: page && page.next_cursor ? page.next_cursor : null,
      };
    }

    function endpoint(kind, cursor) {
      const params = new URLSearchParams({ limit: "30" });
      if (selectedTopic) params.set("topic", selectedTopic);
      if (cursor) params.set("cursor", cursor);
      if (kind === "search") {
        params.set("q", query.trim());
        return `/v1/search?${params.toString()}`;
      }
      return `/v1/feed?${params.toString()}`;
    }

    async function load(flags) {
      const append = Boolean(flags && flags.append);
      const storeRecent = Boolean(flags && flags.remember);
      const gen = ++requestGen;
      clearTimeout(slowTimer);
      const term = query.trim();
      hint = "";
      if (term.length === 1) hint = "Aramak için en az 2 karakter yaz.";
      if (term.length > 80) hint = "Arama 2 ile 80 karakter arasında olmalıdır.";
      const valid = term.length >= 2 && term.length <= 80;
      if (storeRecent && valid) remember(term);
      const nextSignature = `${term}|${selectedTopic}`;
      if (!append && nextSignature !== signature) {
        category = "";
        publisher = "";
        signature = nextSignature;
      }
      if (!append) {
        phase = "loading";
        errorMessage = "";
        raw = [];
        searchCursor = null;
        feedCursor = null;
      }
      primary = valid ? "search" : "feed";
      slowTimer = setTimeout(() => {
        if (alive && gen === requestGen && phase === "loading") {
          phase = "slow";
          render();
        }
      }, SLOW_MS);
      render();
      if (typeof api !== "function") {
        clearTimeout(slowTimer);
        phase = "error";
        errorMessage = "Arama servisi bağlı değil.";
        render();
        return;
      }
      let searchItems = [];
      let feedItems = [];
      let failed = null;
      try {
        try { await ensureTopics(); } catch { /* konu hatası ayrı durur */ }
        if (gen !== requestGen) return;
        if (!append) {
          try {
            const feedPage = await readPage(endpoint("feed"));
            if (gen !== requestGen) return;
            feedItems = feedPage.items;
            if (!valid) feedCursor = feedPage.cursor;
            feedNote = "";
          } catch (error) {
            const classified = classify(error);
            if (!valid) failed = classified;
            else feedNote = classified.message;
          }
        }
        if (valid) {
          try {
            const searchPage = await readPage(endpoint("search", append ? searchCursor : null));
            if (gen !== requestGen) return;
            searchItems = searchPage.items;
            searchCursor = searchPage.cursor;
          } catch (error) {
            failed = classify(error);
          }
        } else if (append && feedCursor) {
          const feedPage = await readPage(endpoint("feed", feedCursor));
          if (gen !== requestGen) return;
          feedItems = feedPage.items;
          feedCursor = feedPage.cursor;
        }
      } catch (error) {
        if (gen !== requestGen) return;
        failed = classify(error);
      }
      if (!alive || gen !== requestGen) return;
      clearTimeout(slowTimer);
      if (append) raw = mergeItems(raw.concat(searchItems, feedItems), [], valid ? term : "");
      else raw = mergeItems(searchItems, feedItems, valid ? term : "");
      if (failed && !raw.length) {
        phase = failed.phase;
        errorMessage = failed.message;
      } else if (failed) {
        phase = failed.phase;
        errorMessage = failed.message;
      } else {
        phase = "ready";
        errorMessage = "";
      }
      render();
    }

    function onInput(event) {
      const target = event.target;
      if (!target || target.id !== "cizgi-q") return;
      query = target.value;
      clearTimeout(debounceTimer);
      const term = String(query || "").trim();
      if (term.length === 1) {
        hint = "Aramak için en az 2 karakter yaz.";
        if (tab === "topics" || tab === "sources") render();
        else {
          phase = phase === "loading" || phase === "slow" ? phase : "ready";
          render();
        }
        return;
      }
      hint = term.length > 80 ? "Arama 2 ile 80 karakter arasında olmalıdır." : "";
      debounceTimer = setTimeout(() => {
        if (!alive) return;
        load({ remember: false });
      }, DEBOUNCE_MS);
    }

    function onSubmit(event) {
      const form = event.target && event.target.closest ? event.target.closest("#cizgi-form") : null;
      if (!form) return;
      event.preventDefault();
      const input = container.querySelector("#cizgi-q");
      query = String(input ? input.value : query).trim();
      load({ remember: true });
    }

    function onClick(event) {
      const target = event.target;
      if (!target || !target.closest) return;
      const retryTopics = target.closest("[data-retry='topics']");
      if (retryTopics) {
        topicsPromise = null;
        topics = [];
        load();
        return;
      }
      const retry = target.closest("[data-retry]");
      if (retry) { load(); return; }
      const more = target.closest("[data-more]");
      if (more) { load({ append: true }); return; }
      const clearRecent = target.closest("[data-clear-recent]");
      if (clearRecent) {
        recent = [];
        emit(opts.onRecentChange, []);
        render();
        return;
      }
      const clearQuery = target.closest("[data-clear-query]");
      if (clearQuery) {
        query = "";
        load();
        return;
      }
      const clearTopic = target.closest("[data-clear-topic]");
      if (clearTopic) {
        selectedTopic = "";
        load();
        return;
      }
      const recentBtn = target.closest("[data-recent]");
      if (recentBtn) {
        const index = Number(recentBtn.getAttribute("data-recent"));
        if (recent[index]) {
          query = recent[index];
          load({ remember: true });
        }
        return;
      }
      const tabBtn = target.closest("[data-tab]");
      if (tabBtn) {
        tab = tabBtn.getAttribute("data-tab") || "news";
        render();
        return;
      }
      const dateBtn = target.closest("[data-date]");
      if (dateBtn) {
        dateRange = dateBtn.getAttribute("data-date") || "all";
        render();
        return;
      }
      const categoryBtn = target.closest("[data-category]");
      if (categoryBtn) {
        category = categoryBtn.getAttribute("data-category") || "";
        render();
        return;
      }
      const publisherBtn = target.closest("[data-publisher]");
      if (publisherBtn) {
        publisher = publisherBtn.getAttribute("data-publisher") || "";
        render();
        return;
      }
      const topicBtn = target.closest("[data-topic]");
      if (topicBtn) {
        const slug = topicBtn.getAttribute("data-topic") || "";
        selectedTopic = selectedTopic === slug ? "" : slug;
        load();
        return;
      }
      const save = target.closest("[data-save]");
      if (save) {
        const id = save.getAttribute("data-save");
        if (!id) return;
        if (saved.has(id)) saved.delete(id);
        else saved.add(id);
        render();
        emit(opts.onSave, id);
        return;
      }
      const open = target.closest("[data-open]");
      if (open) emit(opts.onOpenStory, open.getAttribute("data-open"));
    }

    container.addEventListener("click", onClick, { signal: abort.signal });
    container.addEventListener("submit", onSubmit, { signal: abort.signal });
    container.addEventListener("input", onInput, { signal: abort.signal });

    const handle = {
      update(partial) {
        if (!alive || !partial) return;
        if (Array.isArray(partial.recent)) recent = partial.recent.slice(0, 8);
        if (partial.savedIds) saved = toSet(partial.savedIds);
        if (typeof partial.api === "function") api = partial.api;
        render();
      },
      destroy() {
        if (!alive) return;
        alive = false;
        requestGen += 1;
        clearTimeout(slowTimer);
        clearTimeout(debounceTimer);
        abort.abort();
        container.innerHTML = "";
        container.classList.remove("cizgi-search");
        container.removeAttribute("aria-busy");
        mounts.delete(container);
      },
    };
    mounts.set(container, handle);
    load();
    return handle;
  }

  const api = {
    mount,
    fiction,
    fieldHit,
    inRange,
    spot,
    mergeItems,
    applyFilters,
    filterTopics,
    groupSources,
    safeImage,
    classify,
  };
  if (typeof window !== "undefined") window.CizgiSearch = { mount };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
