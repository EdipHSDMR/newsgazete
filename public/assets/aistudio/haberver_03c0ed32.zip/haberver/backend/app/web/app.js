const KEY = "haberkesif.reader.v1";
const app = document.querySelector("#app");
const fallbackTopics = [
  ["ulusal", "Türkiye"], ["dunya", "Dünya"], ["ekonomi", "Ekonomi"],
  ["bilim-teknoloji", "Bilim ve teknoloji"], ["iklim-cevre", "İklim ve çevre"],
  ["kultur", "Kültür ve yaşam"], ["spor", "Spor"], ["yerel", "Yerel"],
];
let topics = fallbackTopics.map(([slug, name]) => ({ slug, name }));
let homeHandle = null;
let sportsHandle = null;
let weatherHandle = null;
let storyHandle = null;
let libraryHandle = null;
let localHandle = null;
let searchHandle = null;
let profileHandle = null;
const state = { ...blank(), ...read() };

function blank() {
  return { onboarded: false, followed: [], onlyFollowed: false, city: "", muted: [], theme: "light", themeChosen: false, font: "md", saved: [], recent: [], quietStart: 22, quietEnd: 7, notifications: false, breakingAlerts: false, followedAlerts: false, sportsAlerts: false, dailyDigest: false, followedTeams: [], analytics: false, chrono: true };
}
function read() {
  try {
    const stored = JSON.parse(localStorage.getItem(KEY) || "{}");
    return { ...stored, theme: stored.themeChosen ? stored.theme : "light" };
  } catch { return {}; }
}
function destroyHome() {
  if (homeHandle && typeof homeHandle.destroy === "function") homeHandle.destroy();
  homeHandle = null;
}
function destroySports() {
  if (sportsHandle && typeof sportsHandle.destroy === "function") sportsHandle.destroy();
  sportsHandle = null;
}
function destroyStory() {
  if (storyHandle && typeof storyHandle.destroy === "function") storyHandle.destroy();
  storyHandle = null;
}
function destroyLibrary() {
  if (libraryHandle && typeof libraryHandle.unmount === "function") libraryHandle.unmount();
  libraryHandle = null;
}
function libraryStore() {
  return window.CizgiLibrary && window.CizgiLibrary.store ? window.CizgiLibrary.store : null;
}
function isSaved(id) {
  if (state.saved.includes(id)) return true;
  const store = libraryStore();
  if (!store) return false;
  try {
    return (store.get().savedStories || []).some((row) => row.id === id);
  } catch {
    return false;
  }
}
function syncSave(id, saved, story) {
  state.saved = saved
    ? [id, ...state.saved.filter((item) => item !== id)]
    : state.saved.filter((item) => item !== id);
  localStorage.setItem(KEY, JSON.stringify(state));
  const store = libraryStore();
  if (!store) return;
  try {
    if (saved) {
      store.saveStory(id);
      if (story && typeof store.cacheSnippet === "function") {
        const sources = Array.isArray(story.sources) ? story.sources : [];
        let link = "";
        for (const source of sources) {
          try {
            const url = new URL(String(source.canonical_url || "").trim());
            if (url.protocol === "https:" && url.hostname && !url.username && !url.password) {
              link = url.href;
              break;
            }
          } catch { /* geç */ }
        }
        store.cacheSnippet(id, {
          title: story.editorial_title || "",
          summary: story.editorial_summary || "",
          link,
        });
      }
    } else if (typeof store.removeStory === "function") {
      store.removeStory(id);
    }
  } catch { /* kütüphane yazılamadı */ }
}
function migrateSavedIntoLibrary() {
  const store = libraryStore();
  if (!store || !state.saved.length) return;
  try {
    const have = new Set((store.get().savedStories || []).map((row) => row.id));
    state.saved.forEach((id) => {
      if (!have.has(id)) store.saveStory(id);
    });
  } catch { /* tek seferlik kopya */ }
}
function destroyWeather() {
  if (weatherHandle && typeof weatherHandle.destroy === "function") weatherHandle.destroy();
  weatherHandle = null;
}
function destroyLocal() {
  if (localHandle && typeof localHandle.destroy === "function") localHandle.destroy();
  localHandle = null;
}
function destroySearch() {
  if (searchHandle && typeof searchHandle.destroy === "function") searchHandle.destroy();
  searchHandle = null;
}
function destroyProfile() {
  profileHandle = null;
}
function inboxUnread() {
  try {
    if (typeof window.CizgiProfile?.unreadCount === "function") {
      return window.CizgiProfile.unreadCount();
    }
    const raw = JSON.parse(localStorage.getItem("cizgi.profile.v1") || "{}");
    const list = Array.isArray(raw.inbox) ? raw.inbox : [];
    return list.filter((item) => item && item.id && item.title && item.read !== true).length;
  } catch {
    return 0;
  }
}
function save() { localStorage.setItem(KEY, JSON.stringify(state)); paint(); }
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}
const TZ = "Europe/Istanbul";
function parsePublished(iso) {
  if (!iso) return null;
  let raw = String(iso).trim();
  if (!raw) return null;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(raw)) raw += "Z";
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}
function when(iso) {
  const date = parsePublished(iso);
  return date
    ? new Intl.DateTimeFormat("tr-TR", { timeZone: TZ, dateStyle: "medium", timeStyle: "short" }).format(date)
    : "";
}
function clock(iso) {
  const date = parsePublished(iso);
  return date
    ? new Intl.DateTimeFormat("tr-TR", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(date)
    : "";
}
function relativeAge(iso) {
  const date = parsePublished(iso);
  if (!date) return "";
  const mins = Math.max(0, Math.floor((Date.now() - date.getTime()) / 60000));
  if (mins < 1) return "az önce";
  if (mins < 60) return `${mins} dk önce`;
  if (mins < 1440) return `${Math.floor(mins / 60)} saat önce`;
  const dayFmt = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" });
  const today = Date.parse(`${dayFmt.format(new Date())}T12:00:00Z`);
  const that = Date.parse(`${dayFmt.format(date)}T12:00:00Z`);
  const days = Math.round((today - that) / 86400000);
  if (days <= 0) return clock(iso);
  if (days === 1) return "1 gün önce";
  if (days < 7) return `${days} gün önce`;
  return new Intl.DateTimeFormat("tr-TR", { timeZone: TZ, day: "numeric", month: "short" }).format(date);
}
function freshness(items) {
  const latest = (items || [])
    .map((item) => parsePublished(item.published_at)?.getTime() || NaN)
    .filter(Number.isFinite)
    .reduce((max, value) => Math.max(max, value), 0);
  if (!latest) return "";
  const ageMinutes = Math.max(0, Math.floor((Date.now() - latest) / 60000));
  const ageLabel = relativeAge(new Date(latest).toISOString());
  const stale = ageMinutes >= 720;
  return `<p class="freshness ${stale ? "stale" : "fresh"}" role="status">Kaynak akışındaki son başlık: ${esc(when(new Date(latest).toISOString()))} · ${esc(ageLabel)}${stale ? " · Yeni yayın bekleniyor" : ""}</p>`;
}
function today() {
  const date = new Date();
  const weekday = new Intl.DateTimeFormat("tr-TR", { weekday: "long" }).format(date);
  const rest = new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "long" }).format(date);
  const label = weekday.charAt(0).toLocaleUpperCase("tr-TR") + weekday.slice(1);
  return `${label}, ${rest}`;
}
function minutes(text) {
  const words = String(text || "").trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 35));
}
function paint() {
  document.documentElement.dataset.theme = state.theme === "light" ? "light" : "dark";
  document.documentElement.dataset.font = state.font || "md";
  const bar = document.querySelector("meta[name=theme-color]");
  if (bar) bar.setAttribute("content", state.theme === "light" ? "#f7f9fc" : "#07111c");
}
async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { ...options, headers: { Accept: "application/json", ...(options.body ? { "Content-Type": "application/json" } : {}) } });
  } catch {
    const error = new Error("Bağlantı kurulamadı. Yeniden deneyebilirsin.");
    error.phase = "offline";
    throw error;
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body.error?.message || "Akış şu an yenilenemedi.");
    error.phase = body.error?.code === "content_unavailable" ? "removed" : "error";
    throw error;
  }
  return body.data;
}
function mark() {
  return `<a class="mark" href="#/"><svg class="compass" viewBox="0 0 24 24" aria-hidden="true" fill="none"><path d="M2.5 12H10.5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M16 7.75L21.5 12L16 16.25" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg><span class="word">ÇİZGİ</span></a>`;
}
function navIcon(name) {
  const paths = {
    Akış: '<path d="M4 6h16M4 12h16M4 18h10" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
    Keşfet: '<circle cx="11" cy="11" r="6" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M16 16l4 4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
    Kaydedilen: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-3-6 3V5a1 1 0 0 1 1-1z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
    Profil: '<circle cx="12" cy="8" r="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5 19c1.5-3 3.5-4 7-4s5.5 1 7 4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
    Spor: '<path d="M4 17l5-6 4 3 7-9M14 5h6v6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]}</svg>`;
}
function navCurrent(current, id) {
  if (id === "/kesfet") return current === "/kesfet" || current === "/ara";
  return current === id;
}
function shell(current, inner, topicbar = "", opts = {}) {
  destroyHome();
  destroySports();
  destroyWeather();
  destroyStory();
  destroyLibrary();
  destroyLocal();
  destroySearch();
  destroyProfile();
  const links = [
    ["#/", "Akış", "/"],
    ["#/kesfet", "Keşfet", "/kesfet"],
    ["#/spor", "Spor", "/spor"],
    ["#/kaydedilenler", "Kaydedilen", "/kaydedilenler"],
    ["#/profil", "Profil", "/profil"],
  ];
  const nav = state.onboarded
    ? `<nav class="nav" aria-label="Ana gezinme">${links.map(([href, label, id]) => `<a href="${href}" ${navCurrent(current, id) ? 'aria-current="page"' : ""}>${navIcon(label)}<span>${label}</span></a>`).join("")}</nav>`
    : "";
  const unread = Number((window.CizgiProfile && window.CizgiProfile.unreadCount && window.CizgiProfile.unreadCount()) || 0);
  const bellBadge = unread > 0 ? `<span class="mast-bell-badge" aria-hidden="true">${unread > 99 ? "99+" : unread}</span>` : "";
  const bell = state.onboarded
    ? `<a class="mast-bell" href="#/bildirimler" aria-label="Bildirimler${unread ? `, ${unread} okunmamış` : ""}" ${navCurrent(current, "/bildirimler") ? 'aria-current="page"' : ""}><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>${bellBadge}</a>`
    : "";
  const offlineChip = `<span class="cizgi-offline-chip" data-offline-chip hidden>Çevrimdışı</span>`;
  if (opts.home) {
    /* Ana sayfa kendi üst araç şeridini taşır; 5’li alt nav sayfa geçişi içindir (mast-links yok). */
    app.innerHTML = `<div class="site site-home"><main class="shell shell-home" id="icerik">${inner}</main>${nav}</div>`;
    bindOfflineChip();
    return;
  }
  app.innerHTML = `<div class="site"><header class="mast"><div class="mast-bar">${mark()}<p class="promise">Gündemi bul, bağlamı gör.</p><div class="mast-end">${offlineChip}<time class="date">${esc(today())}</time><nav class="mast-links" aria-label="Sayfalar">${links.map(([href, label, id]) => `<a href="${href}" ${navCurrent(current, id) ? 'aria-current="page"' : ""}>${label}</a>`).join("")}</nav>${bell}<a class="search-btn" href="#/kesfet" aria-label="Keşfet">Keşfet</a></div></div>${topicbar}</header><main class="shell" id="icerik">${inner}</main>${nav}</div>`;
  bindSave();
  bindImages();
  bindOfflineChip();
}
let detachConnectivity = null;
function bindOfflineChip() {
  if (typeof detachConnectivity === "function") detachConnectivity();
  detachConnectivity = null;
  const boot = window.CizgiBoot;
  if (!boot || typeof boot.onConnectivityChange !== "function") return;
  const apply = (offline) => {
    document.querySelectorAll("[data-offline-chip]").forEach((chip) => {
      if (offline) chip.removeAttribute("hidden");
      else chip.setAttribute("hidden", "");
    });
  };
  apply(typeof boot.isOffline === "function" ? boot.isOffline() : false);
  detachConnectivity = boot.onConnectivityChange(apply);
}
function fiction(item) {
  return item.synthetic || String(item.display_label || "").includes("Sentetik") || String(item.editorial_title || "").startsWith("Örnek ") || String(item.editorial_title || "").startsWith("Sentetik");
}
function badges(item) {
  return `${fiction(item) ? '<span class="badge warn">KURMACA</span>' : ""}${item.updated_badge ? '<span class="badge gold">Güncellendi</span>' : ""}${item.content_warning ? `<span class="badge warn">${esc(item.content_warning)}</span>` : ""}`;
}
function hostLabel(source) {
  try {
    const host = new URL(source.canonical_url).hostname.replace(/^www\./, "");
    if (host && !host.endsWith("newsapi.org")) return host;
  } catch { /* yayıncı adı kullanılır */ }
  return source.publisher_name || "Kaynak";
}
function isLive(item) { return !fiction(item); }
function hidden(item) {
  return state.muted.length && (item.source_ids || []).length && (item.source_ids || []).every((id) => state.muted.includes(id));
}
function saveButton(id) {
  const on = state.saved.includes(id);
  return `<button class="save" data-save="${esc(id)}" aria-pressed="${on}" aria-label="${on ? "Kaydı kaldır" : "Kaydet"}">${on ? "✓" : "+"}</button>`;
}
function photo(url, klass) {
  return url ? `<img alt="" src="${esc(url)}">` : `<div class="${klass || "ph"}" aria-hidden="true"></div>`;
}
function status(kind, message) {
  const copy = {
    loading: `<div class="skeleton"></div><div class="skeleton"></div><p class="note">Başlıklar yükleniyor</p>`,
    empty: `<div class="state"><h2>Bu seçkide başlık yok</h2><p>Konu filtresini kaldırabilir veya akışı yenileyebilirsin.</p><p><a class="btn" href="#/">Gündeme dön</a></p></div>`,
    saved: `<div class="state"><h2>Kaydettiğin haberler burada durur</h2><p>Karttaki artı, kısa özeti ve kaynak bağlantısını bu tarayıcıya alır. Yayıncının tam metni saklanmaz.</p><p><a class="btn" href="#/">Akışa dön</a></p></div>`,
    offline: `<div class="state"><p class="kicker">Bağlantı</p><h2>Akış şu an yenilenemedi</h2><p>${esc(message)}</p><button id="retry">Yeniden dene</button></div>`,
    error: `<div class="state"><p class="kicker">Bağlantı</p><h2>Akış şu an yenilenemedi</h2><p>${esc(message)}</p><button id="retry">Yeniden dene</button></div>`,
    removed: `<div class="state"><p class="kicker">İzin</p><h2>Bu içerik artık gösterilemiyor</h2><p>${esc(message || "Kullanım izni sona erdiği veya içerik kaldırıldığı için özet gizlendi.")}</p><p><a class="btn" href="#/">Akışa dön</a></p></div>`,
  };
  return copy[kind];
}
function bindSave() {
  document.querySelectorAll("[data-save]").forEach((button) => {
    button.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      const id = button.dataset.save;
      state.saved = state.saved.includes(id) ? state.saved.filter((item) => item !== id) : [id, ...state.saved];
      save();
      const on = state.saved.includes(id);
      button.setAttribute("aria-pressed", String(on));
      button.setAttribute("aria-label", on ? "Kaydı kaldır" : "Kaydet");
      button.textContent = button.classList.contains("save") ? (on ? "✓" : "+") : (on ? "Kaydedildi" : "Kaydet");
      if (location.hash === "#/kaydedilenler") showSaved();
    };
  });
}
function bindImages() {
  document.querySelectorAll("img").forEach((img) => {
    img.addEventListener("error", () => {
      const ph = document.createElement("div");
      ph.className = "ph";
      ph.setAttribute("aria-hidden", "true");
      img.replaceWith(ph);
    });
  });
}
function filters(active) {
  const items = [{ slug: "", name: "Gündem" }, { slug: "sana", name: "Sana göre" }, ...topics];
  return `<div class="topicbar" role="toolbar" aria-label="Konu seçimi">${items.map((item) => {
    const on = active === item.slug;
    const href = item.slug === "sana" ? "#/sana-gore" : item.slug === "yerel" ? "#/yerel" : item.slug ? `#/konu/${encodeURIComponent(item.slug)}` : "#/";
    return `<a class="chip" href="${href}" aria-pressed="${on}" ${on ? 'aria-current="page"' : ""}>${esc(item.name)}</a>`;
  }).join("")}</div>`;
}
function feature(item) {
  return `<article class="feature"><a class="feature-media" href="#/haber/${esc(item.id)}">${photo(item.image, "ph")}</a><div class="feature-copy"><p class="kicker">Günün öne çıkanı · ${esc(item.topic_name || "Gündem")}</p>${badges(item)}<h1><a href="#/haber/${esc(item.id)}">${esc(item.editorial_title)}</a></h1><p class="deck">${esc(item.editorial_summary)}</p><div class="meta-row"><span>${item.source_count} kaynak</span><span>${esc(when(item.published_at))}</span><span>${esc(item.authorship_label || "Kaynak")}</span><span>${minutes(item.editorial_summary)} dk</span></div><div class="actions"><a class="btn" href="#/haber/${esc(item.id)}">Haberi aç</a><a class="ghost" href="#/karsilastir/${esc(item.id)}">Kaynakları karşılaştır</a>${saveButton(item.id)}</div></div></article>`;
}
function brief(items) {
  if (!items.length) return "";
  return `<aside class="brief"><header><div><p class="kicker">Günün kısa özeti</p><p class="dek">${items.length} başlık · yaklaşık 2 dakika</p></div></header><ol>${items.map((item, index) => `<li><a href="#/haber/${esc(item.id)}"><span class="num">${String(index + 1).padStart(2, "0")}</span><span><span class="eyebrow">${esc(item.topic_name || "")}</span><strong>${esc(item.editorial_title)}</strong><small>${item.source_count} kaynak · ${esc(clock(item.published_at))}</small></span></a></li>`).join("")}</ol></aside>`;
}
function mini(item) {
  return `<a class="mini" href="#/haber/${esc(item.id)}"><div class="media">${photo(item.image, "ph")}</div><div><span class="eyebrow">${esc(item.topic_name || "")} · ${item.source_count} kaynak</span><strong>${esc(item.editorial_title)}</strong><span class="dek">${esc(item.editorial_summary)}</span><span class="meta">${esc(item.authorship_label || "")} · ${esc(when(item.published_at))}</span></div></a>`;
}
function streamRow(item, index) {
  return `<article class="stream-row"><a class="stream-link" href="#/haber/${esc(item.id)}"><span class="idx">${String(index).padStart(2, "0")}</span><span><span class="eyebrow">${esc(item.topic_name || "")} · ${esc(item.authorship_label || "Kaynak")}</span><strong>${esc(item.editorial_title)}</strong><span class="dek">${esc(item.editorial_summary)}</span></span></a><span class="side">${item.source_count} kaynak<br>${esc(when(item.published_at))}</span>${saveButton(item.id)}</article>`;
}
function noteFor(mode) {
  if (mode === "sana" && state.followed.length) return "Takip ettiğin konulardan seçilen gelişmeler.";
  if (mode === "sana") return "İlgi alanlarını seçtiğinde bu akış sana göre düzenlenir.";
  if (mode) return "Bu konudaki öne çıkan gelişmeler.";
  return "Öne çıkan haberler ve son gelişmeler tek akışta.";
}

function showFeed(mode) {
  if (typeof window.CizgiHome?.mount !== "function") {
    shell("/", `<div class="state"><p class="kicker">Bağlantı</p><h2>Ana sayfa yüklenemedi</h2><p>home.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showFeed(mode);
    return;
  }
  shell("/", `<div id="cizgi-home-root"></div>`, "", { home: true });
  const root = document.querySelector("#cizgi-home-root");
  if (!root) return;
  const initialTopic = mode && mode !== "sana" ? mode : "";
  homeHandle = window.CizgiHome.mount(root, {
    api,
    topics,
    followedTopics: state.followed,
    savedIds: state.saved,
    unreadCount: inboxUnread(),
    initialTopic,
    onOpenStory: (id) => { location.hash = `#/haber/${id}`; },
    onOpenOriginal: (url) => { window.open(url, "_blank", "noopener,noreferrer"); },
    onSave: (id) => {
      state.saved = state.saved.includes(id) ? state.saved.filter((item) => item !== id) : [id, ...state.saved];
      localStorage.setItem(KEY, JSON.stringify(state));
    },
    onSearch: () => { location.hash = "#/kesfet"; },
    onOpenNotifications: () => { location.hash = "#/bildirimler"; },
    onOpenProfile: () => { location.hash = "#/profil"; },
    onStub: (name) => { location.hash = name === "hava" ? "#/hava" : "#/piyasalar"; },
  });
}

function showStub(kind) {
  const copy = { title: "Piyasalar", body: "Piyasa özeti yakında burada. Şimdilik gündeme dönebilirsin." };
  shell("/", `<div class="state"><p class="kicker">Yakında</p><h2>${esc(copy.title)}</h2><p>${esc(copy.body)}</p><p><a class="btn" href="#/">Gündeme dön</a></p></div>`);
}

function showWeather() {
  if (typeof window.CizgiWeather?.mount !== "function") {
    shell("/", `<div class="state"><p class="kicker">Bağlantı</p><h2>Hava merkezi yüklenemedi</h2><p>weather.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showWeather();
    return;
  }
  shell("/", `<div id="weather-root" data-cizgi-weather></div>`);
  const root = document.querySelector("#weather-root");
  if (!root) return;
  const weatherApi = typeof window.CizgiWeather.createApi === "function"
    ? window.CizgiWeather.createApi()
    : api;
  weatherHandle = window.CizgiWeather.mount(root, { api: weatherApi });
}

function mountStory(id, mode) {
  if (!/^[0-9a-f-]{32,36}$/i.test(id)) {
    shell("/", status("removed", "Bu bağlantı bir habere ait değil."));
    return;
  }
  if (typeof window.CizgiStory?.mount !== "function") {
    shell("/", `<div class="state"><p class="kicker">Bağlantı</p><h2>Haber ekranı yüklenemedi</h2><p>story.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => mountStory(id, mode);
    return;
  }
  const crumb = mode === "compare"
    ? `<p class="crumb"><a href="#/haber/${esc(id)}">Habere dön</a></p>`
    : `<p class="crumb"><a href="#/">Akış</a></p>`;
  shell("/", `${crumb}<div id="story-root" data-cizgi-story></div>`);
  const root = document.querySelector("#story-root");
  if (!root) return;
  const font = (typeof window.CizgiProfile?.read === "function" ? window.CizgiProfile.read().font : null) || state.font || "md";
  storyHandle = window.CizgiStory.mount(root, {
    api,
    storyId: id,
    mode: mode === "compare" ? "compare" : "detail",
    saved: isSaved(id),
    fontScale: font,
    onSave(storyId, saved, story) {
      syncSave(String(storyId || id), saved, story || null);
    },
    onReport(storyId) {
      location.hash = `#/bildir/${encodeURIComponent(String(storyId || id))}`;
    },
  });
}
function showStory(id) { mountStory(id, "detail"); }
function showCompare(id) { mountStory(id, "compare"); }

async function showSource(id) {
  shell("/", status("loading"));
  try {
    const source = await api(`/v1/sources/${id}`);
    const muted = state.muted.includes(source.id);
    const stories = (source.stories || []).filter((item) => isLive(item));
    shell("/", `<article class="detail"><p class="crumb"><a href="#/">Akış</a></p><p class="kicker">Yayıncı</p><h1>${esc(source.name)}</h1><p class="deck">${esc(source.editorial_description || "Tarafsız tanıtım. Güven puanı ve siyasi etiket yok.")}</p><div class="meta-row"><span>${esc(source.domain)}</span><span>${source.partnership_label ? esc(source.partnership_label) : "Ortaklık etiketi yok"}</span></div><div class="actions"><button id="mute" aria-pressed="${muted}">${muted ? "Sessizden çıkar" : "Bu yayını sessize al"}</button></div><div class="section-head"><h2>Bu kaynaktan başlıklar</h2></div><div class="cards">${stories.slice(0, 9).map(mini).join("") || "<p>Gösterilen başlık yok.</p>"}</div></article>`);
    document.querySelector("#mute").onclick = () => {
      state.muted = muted ? state.muted.filter((item) => item !== source.id) : [...state.muted, source.id];
      save();
      showSource(id);
    };
  } catch {
    shell("/", status("error", "Yayıncı sayfasına ulaşılamadı."));
  }
}

function showLocal() {
  if (typeof window.CizgiLocal?.mount !== "function") {
    shell("/yerel", `<div class="state"><p class="kicker">Bağlantı</p><h2>Yerel gündem yüklenemedi</h2><p>local.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showLocal();
    return;
  }
  shell("/yerel", `<div id="cizgi-local-root"></div>`);
  const root = document.querySelector("#cizgi-local-root");
  if (!root) return;
  localHandle = window.CizgiLocal.mount(root, {
    api,
    savedIds: state.saved,
    onOpenStory: (id) => { location.hash = `#/haber/${id}`; },
    onOpenOriginal: (url) => { window.open(url, "_blank", "noopener,noreferrer"); },
    onSave: (id) => {
      state.saved = state.saved.includes(id) ? state.saved.filter((item) => item !== id) : [id, ...state.saved];
      localStorage.setItem(KEY, JSON.stringify(state));
    },
  });
}

function showSports() {
  if (typeof window.CizgiSports?.mount !== "function") {
    shell("/spor", `<div class="state"><p class="kicker">Bağlantı</p><h2>Spor merkezi yüklenemedi</h2><p>sports.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showSports();
    return;
  }
  shell("/spor", `<div id="sports-root" data-cizgi-sports></div>`);
  const root = document.querySelector("#sports-root");
  if (!root) return;
  const sportsApi = typeof window.CizgiSports.createApi === "function"
    ? window.CizgiSports.createApi()
    : api;
  sportsHandle = window.CizgiSports.mount(root, {
    api: sportsApi,
    followedTeams: state.followedTeams || [],
    onFollowTeam(teamId, follow) {
      const id = String(teamId || "");
      if (!id) return;
      if (follow) {
        if (!state.followedTeams.includes(id)) state.followedTeams = [...state.followedTeams, id];
      } else {
        state.followedTeams = state.followedTeams.filter((item) => item !== id);
      }
      localStorage.setItem(KEY, JSON.stringify(state));
    },
    onOpenMatch() {},
  });
}

function showSearch() {
  if (typeof window.CizgiSearch?.mount !== "function") {
    shell("/kesfet", `<div class="state" role="alert"><p class="kicker">Bağlantı</p><h1>Keşfet yüklenemedi</h1><p>search.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showSearch();
    return;
  }
  shell("/kesfet", `<div id="cizgi-search-root" data-cizgi-search></div>`);
  const root = document.querySelector("#cizgi-search-root");
  if (!root) return;
  searchHandle = window.CizgiSearch.mount(root, {
    api,
    recent: state.recent || [],
    savedIds: state.saved,
    onOpenStory: (id) => { location.hash = `#/haber/${id}`; },
    onSave: (id) => {
      const on = !state.saved.includes(id);
      syncSave(String(id || ""), on, null);
    },
    onRecentChange: (recent) => {
      state.recent = Array.isArray(recent) ? recent.slice(0, 8) : [];
      localStorage.setItem(KEY, JSON.stringify(state));
    },
  });
}

function profileMountOptions(screen) {
  const store = libraryStore();
  return {
    api,
    screen: screen === "alerts" ? "alerts" : "profile",
    library: {
      snapshot() {
        const lib = store ? store.get() : { followedTopics: [], followedPublishers: [], followedTeams: [] };
        return {
          followedTopics: lib.followedTopics?.length ? lib.followedTopics : state.followed,
          followedSources: lib.followedPublishers || [],
          followedTeams: lib.followedTeams || state.followedTeams || [],
          recentSearches: state.recent || [],
        };
      },
      clearRecentSearches() {
        state.recent = [];
        localStorage.setItem(KEY, JSON.stringify(state));
      },
    },
    onWipe() {
      try { localStorage.removeItem(KEY); } catch { /* yok */ }
      try { localStorage.removeItem("cizgi.profile.v1"); } catch { /* yok */ }
      Object.assign(state, blank());
      paint();
    },
  };
}

function showNotifications() {
  if (typeof window.CizgiProfile?.mount !== "function") {
    shell("/bildirimler", `<div class="state" role="alert"><p class="kicker">Bağlantı</p><h1>Bildirim merkezi yüklenemedi</h1><p>profile.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showNotifications();
    return;
  }
  shell("/bildirimler", `<div id="cizgi-profile-root" data-cizgi-alerts></div>`);
  const root = document.querySelector("#cizgi-profile-root");
  if (!root) return;
  profileHandle = true;
  window.CizgiProfile.mount(root, profileMountOptions("alerts"));
}

function showSaved() {
  migrateSavedIntoLibrary();
  if (typeof window.CizgiLibrary?.mount !== "function") {
    shell("/kaydedilenler", `<div class="state" role="alert"><p class="kicker">Bağlantı</p><h1>Kayıtlılar yüklenemedi</h1><p>library.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showSaved();
    return;
  }
  shell("/kaydedilenler", `<div id="cizgi-library-root"></div>`);
  const root = document.querySelector("#cizgi-library-root");
  if (!root) return;
  libraryHandle = window.CizgiLibrary.mount(root, {
    api,
    onOpenStory: (id) => { location.hash = `#/haber/${id}`; },
  });
}

function showProfile() {
  if (typeof window.CizgiProfile?.mount !== "function") {
    shell("/profil", `<div class="state" role="alert"><p class="kicker">Bağlantı</p><h1>Profil yüklenemedi</h1><p>profile.js bulunamadı. Sayfayı yenile.</p><button id="retry" type="button">Yeniden dene</button></div>`);
    const retry = document.querySelector("#retry");
    if (retry) retry.onclick = () => showProfile();
    return;
  }
  shell("/profil", `<div id="cizgi-profile-root"></div>`);
  const root = document.querySelector("#cizgi-profile-root");
  if (!root) return;
  profileHandle = true;
  window.CizgiProfile.mount(root, profileMountOptions("profile"));
  if (typeof window.CizgiProfile.read === "function") {
    const prefs = window.CizgiProfile.read();
    if (prefs.font) state.font = prefs.font;
    if (prefs.theme === "light" || prefs.theme === "dark") {
      state.theme = prefs.theme;
      state.themeChosen = true;
    }
    paint();
  }
}

async function showAbout() {
  shell("/profil", status("loading"));
  try {
    const meta = await api("/v1/meta");
    shell("/profil", `<header class="page-head"><p class="kicker">İlkeler</p><h1>${esc(meta.name)}</h1><p class="deck">${esc(meta.promise)}</p></header><section class="block"><h2>Yayın</h2><p>${esc(meta.standards)}</p></section><section class="block"><h2>Düzeltme</h2><p>${esc(meta.corrections)}</p></section><section class="block"><h2>Gizlilik</h2><p>${esc(meta.privacy)}</p></section><section class="block"><h2>Gelir</h2><p>${esc(meta.revenue)}</p><p class="dek">${esc(meta.brand_status)} ${esc(meta.legal_notice)}</p></section><p><a href="#/profil">Profile dön</a></p>`);
  } catch (error) {
    shell("/profil", status("offline", error.message));
  }
}

function showReport(id) {
  shell("/", `<header class="page-head"><p class="kicker">Geri bildirim</p><h1>Sorun bildir</h1><p class="dek">İletişim bilgisi zorunlu değil. Bildirim kamuya açılmaz ve yayındaki metni otomatik değiştirmez.</p></header><form id="report" class="panel"><label>Bildirim türü<select name="category"><option value="wrong_summary">Özet hatası</option><option value="broken_link">Kaynak bağlantısı bozuk</option><option value="wrong_date">Tarih veya sayı hatası</option><option value="other">Diğer</option></select></label><label>Açıklama, isteğe bağlı<textarea name="description" maxlength="500" placeholder="Neyi kontrol etmeliyiz?"></textarea></label><button>Bildirimi gönder</button></form><div id="result"></div><p><a href="#/haber/${esc(id)}">Habere dön</a></p>`);
  document.querySelector("#report").onsubmit = async (event) => {
    event.preventDefault();
    const data = new FormData(event.target);
    try {
      const result = await api("/v1/reports", { method: "POST", body: JSON.stringify({ story_id: id, category: data.get("category"), description: data.get("description") || null }) });
      document.querySelector("#result").innerHTML = `<div class="state"><h2>Alındı</h2><p>Kayıt ${esc(result.id)}. Bu not yayınlanmaz; özet otomatik değişmez.</p></div>`;
    } catch (error) { document.querySelector("#result").innerHTML = `<p>${esc(error.message)}</p>`; }
  };
}

function showStart() {
  shell("", `<section class="welcome"><div class="welcome-mark">${mark()}<span>Gündem, net bir çizgide.</span></div><p class="kicker">Kişisel haber akışın</p><h1>Gündemi bul,<br>bağlamı gör.</h1><p class="deck">Farklı yayınlardaki gelişmeleri tek akışta keşfet. Her haberin kaynağı açık; okumak ve takip etmek senin elinde.</p><div class="welcome-points"><span>✓ Hesap açmadan başla</span><span>✓ İlgi alanlarını seç</span><span>✓ Bildirimleri sonra ayarla</span></div><h2>İlgini çeken konuları seç</h2><p class="dek">Akışını dilediğin zaman değiştirebilirsin.</p><div class="topicbar" id="pick">${topics.map((item) => `<button class="chip" data-pick="${esc(item.slug)}" aria-pressed="false">${esc(item.name)}</button>`).join("")}</div><div class="actions"><button id="go" type="button">Kişisel akışımı oluştur <span aria-hidden="true">→</span></button><button class="ghost" id="skip" type="button">Şimdilik atla</button></div></section>`);
  const picked = new Set();
  document.querySelector("#pick").onclick = (event) => {
    const slug = event.target?.dataset?.pick;
    if (!slug) return;
    picked.has(slug) ? picked.delete(slug) : picked.add(slug);
    event.target.setAttribute("aria-pressed", String(picked.has(slug)));
  };
  const enter = (use) => { state.onboarded = true; state.followed = use ? [...picked] : []; if (!state.themeChosen) state.theme = "light"; save(); location.hash = "#/"; };
  document.querySelector("#go").onclick = () => enter(true);
  document.querySelector("#skip").onclick = () => enter(false);
}

async function boot() {
  if (state.theme !== "light" && state.theme !== "dark") state.theme = "light";
  paint();
  try { topics = await api("/v1/topics"); } catch { topics = fallbackTopics.map(([slug, name]) => ({ slug, name })); }
  if (!location.hash) { location.hash = state.onboarded ? "#/" : "#/basla"; return; }
  if (!state.onboarded && location.hash !== "#/basla") { location.hash = "#/basla"; return; }
  const path = decodeURIComponent(location.hash.slice(1));
  if (path === "/basla" || path === "basla") return showStart();
  if (!state.onboarded) return showStart();
  if (path === "/" || path === "") return showFeed("");
  if (path === "/sana-gore") return showFeed("sana");
  if (path === "/hava") return showWeather();
  if (path === "/piyasalar") return showStub("piyasalar");
  if (path === "/spor" || path === "/sports") return showSports();
  if (path === "/yerel" || path === "/konu/yerel") return showLocal();
  if (path.startsWith("/konu/")) return showFeed(path.slice(6));
  if (path === "/ara" || path === "/kesfet") return showSearch();
  if (path === "/bildirimler") return showNotifications();
  if (path === "/kaydedilenler") return showSaved();
  if (path === "/profil") return showProfile();
  if (path === "/hakkinda") return showAbout();
  if (path.startsWith("/karsilastir/")) return showCompare(path.slice("/karsilastir/".length));
  if (path.startsWith("/haber/")) return showStory(path.slice(7));
  if (path.startsWith("/kaynak/")) return showSource(path.slice(8));
  if (path.startsWith("/bildir/")) return showReport(path.slice(8));
  location.hash = "#/";
}
window.addEventListener("hashchange", boot);
boot();
