/**
 * Çizgi ilk açılış yardımcısı.
 * Stale-while-revalidate: localStorage, parallel fetch, timeout, skeleton.
 * Ana sayfa: window.CizgiBoot.fetchParallel / cacheGet / cacheSet / withTimeout.
 */
(function (global) {
  "use strict";

  var STORAGE_PREFIX = "cizgi.boot.v1:";
  var DEFAULT_TIMEOUT_MS = 8000;
  var DEFAULT_TTL_MS = 30000;

  function nowMs() {
    return Date.now();
  }

  function storageKey(key) {
    return STORAGE_PREFIX + String(key || "");
  }

  /**
   * @param {string} key
   * @returns {{ value: *, fresh: boolean, expiresAt: number, savedAt: number } | null}
   */
  function cacheGet(key) {
    if (!key || typeof global.localStorage === "undefined") {
      return null;
    }
    try {
      var raw = global.localStorage.getItem(storageKey(key));
      if (!raw) {
        return null;
      }
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object" || !("value" in parsed)) {
        return null;
      }
      var expiresAt = Number(parsed.expiresAt) || 0;
      var savedAt = Number(parsed.savedAt) || 0;
      return {
        value: parsed.value,
        fresh: expiresAt > nowMs(),
        expiresAt: expiresAt,
        savedAt: savedAt,
      };
    } catch (_err) {
      return null;
    }
  }

  /**
   * @param {string} key
   * @param {*} value
   * @param {number} [ttlMs]
   */
  function cacheSet(key, value, ttlMs) {
    if (!key || typeof global.localStorage === "undefined") {
      return false;
    }
    var ttl = Number(ttlMs);
    if (!Number.isFinite(ttl) || ttl <= 0) {
      ttl = DEFAULT_TTL_MS;
    }
    try {
      global.localStorage.setItem(
        storageKey(key),
        JSON.stringify({
          value: value,
          expiresAt: nowMs() + ttl,
          savedAt: nowMs(),
        })
      );
      return true;
    } catch (_err) {
      return false;
    }
  }

  /**
   * @param {Promise<*>} promise
   * @param {number} ms
   * @returns {Promise<*>}
   */
  function withTimeout(promise, ms) {
    var limit = Number(ms);
    if (!Number.isFinite(limit) || limit <= 0) {
      limit = DEFAULT_TIMEOUT_MS;
    }
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = global.setTimeout(function () {
        if (settled) {
          return;
        }
        settled = true;
        var err = new Error("timeout");
        err.code = "timeout";
        err.name = "TimeoutError";
        reject(err);
      }, limit);
      Promise.resolve(promise).then(
        function (value) {
          if (settled) {
            return;
          }
          settled = true;
          global.clearTimeout(timer);
          resolve(value);
        },
        function (err) {
          if (settled) {
            return;
          }
          settled = true;
          global.clearTimeout(timer);
          reject(err);
        }
      );
    });
  }

  function normalizePath(entry) {
    if (typeof entry === "string") {
      return { path: entry, key: entry, ttlMs: DEFAULT_TTL_MS };
    }
    if (!entry || typeof entry !== "object" || !entry.path) {
      throw new Error("fetchParallel: path gerekli");
    }
    return {
      path: String(entry.path),
      key: entry.key != null ? String(entry.key) : String(entry.path),
      ttlMs: entry.ttlMs != null ? Number(entry.ttlMs) : DEFAULT_TTL_MS,
    };
  }

  function defaultFetch(path, options) {
    var opts = options || {};
    var headers = Object.assign({ Accept: "application/json" }, opts.headers || {});
    return global.fetch(path, {
      method: "GET",
      headers: headers,
      signal: opts.signal,
      credentials: opts.credentials || "same-origin",
    }).then(function (res) {
      if (!res.ok) {
        var err = new Error("http_" + res.status);
        err.status = res.status;
        err.code = "http_error";
        throw err;
      }
      return res.json();
    });
  }

  /**
   * Paralel istek. Hata/timeout'ta önceki cache (stale dahil) döner.
   * @param {Array<string|{path:string,key?:string,ttlMs?:number}>} paths
   * @param {{
   *   api?: function(string, object=): Promise<*>,
   *   timeoutMs?: number,
   *   ttlMs?: number,
   *   skeleton?: Element|null,
   * }} [options]
   * @returns {Promise<{ results: Array<{path:string,key:string,ok:boolean,fresh:boolean,fromCache:boolean,data:*,error:?*}>, ok: boolean }>}
   */
  function fetchParallel(paths, options) {
    var opts = options || {};
    var list = Array.isArray(paths) ? paths.map(normalizePath) : [];
    var timeoutMs = opts.timeoutMs != null ? Number(opts.timeoutMs) : DEFAULT_TIMEOUT_MS;
    var fetchFn = typeof opts.api === "function" ? opts.api : defaultFetch;
    var skeletonEl = opts.skeleton || null;

    setSkeleton(skeletonEl, true);

    var jobs = list.map(function (spec) {
      var ttl = Number.isFinite(spec.ttlMs) && spec.ttlMs > 0 ? spec.ttlMs : opts.ttlMs || DEFAULT_TTL_MS;
      var cached = cacheGet(spec.key);
      var network = withTimeout(
        Promise.resolve(fetchFn(spec.path, opts)),
        timeoutMs
      )
        .then(function (data) {
          cacheSet(spec.key, data, ttl);
          return {
            path: spec.path,
            key: spec.key,
            ok: true,
            fresh: true,
            fromCache: false,
            data: data,
            error: null,
          };
        })
        .catch(function (err) {
          if (cached) {
            return {
              path: spec.path,
              key: spec.key,
              ok: true,
              fresh: cached.fresh,
              fromCache: true,
              data: cached.value,
              error: err,
            };
          }
          return {
            path: spec.path,
            key: spec.key,
            ok: false,
            fresh: false,
            fromCache: false,
            data: null,
            error: err,
          };
        });

      // Taze cache varsa hemen onu göster (SWR); ağ arka planda yine de günceller.
      if (cached && cached.fresh) {
        network.catch(function () {});
        return Promise.resolve({
          path: spec.path,
          key: spec.key,
          ok: true,
          fresh: true,
          fromCache: true,
          data: cached.value,
          error: null,
          _revalidate: network,
        });
      }
      return network;
    });

    return Promise.all(jobs).then(function (results) {
      setSkeleton(skeletonEl, false);
      var revalidates = [];
      var cleaned = results.map(function (row) {
        if (row && row._revalidate) {
          revalidates.push(row._revalidate);
          var copy = Object.assign({}, row);
          delete copy._revalidate;
          return copy;
        }
        return row;
      });
      if (revalidates.length) {
        Promise.all(revalidates).catch(function () {});
      }
      return {
        results: cleaned,
        ok: cleaned.every(function (row) {
          return row && row.ok;
        }),
      };
    });
  }

  /**
   * Skeleton kancası: aria-busy + cizgi-boot-skeleton sınıfı.
   * @param {Element|null|undefined} el
   * @param {boolean} active
   */
  function setSkeleton(el, active) {
    if (!el || !el.classList) {
      return;
    }
    if (active) {
      el.classList.add("cizgi-boot-skeleton");
      el.setAttribute("aria-busy", "true");
    } else {
      el.classList.remove("cizgi-boot-skeleton");
      el.setAttribute("aria-busy", "false");
    }
  }

  /**
   * Azaltılmış hareket tercihi. Tüm bileşenler tek denetimden geçer.
   * @returns {boolean}
   */
  function prefersReducedMotion() {
    try {
      return typeof global.matchMedia === "function" && global.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch (_err) {
      return false;
    }
  }

  /**
   * Çevrimdışı durumu. Tarayıcı desteklemiyorsa çevrimiçi varsayılır.
   * @returns {boolean}
   */
  function isOffline() {
    try {
      return typeof global.navigator !== "undefined" && global.navigator.onLine === false;
    } catch (_err) {
      return false;
    }
  }

  /**
   * Çevrimiçi/çevrimdışı geçişinde geri çağırma. Temizleme işlevi döner.
   * @param {function(boolean): void} handler
   * @returns {function(): void}
   */
  function onConnectivityChange(handler) {
    if (typeof handler !== "function" || typeof global.addEventListener !== "function") {
      return function () {};
    }
    var online = function () { handler(false); };
    var offline = function () { handler(true); };
    global.addEventListener("online", online);
    global.addEventListener("offline", offline);
    return function () {
      global.removeEventListener("online", online);
      global.removeEventListener("offline", offline);
    };
  }

  /**
   * Tek yol stale-while-revalidate. Cache varsa hemen döner; ağ arka planda yeniler.
   * @param {string} path
   * @param {{
   *   api?: function(string, object=): Promise<*>,
   *   key?: string,
   *   ttlMs?: number,
   *   timeoutMs?: number,
   *   signal?: AbortSignal,
   *   swr?: boolean,
   * }} [options]
   * @returns {Promise<{ data: *, fromCache: boolean, fresh: boolean, savedAt: number, error: * }>}
   */
  function fetchOne(path, options) {
    var opts = options || {};
    var key = opts.key != null ? String(opts.key) : String(path || "");
    var ttl = Number(opts.ttlMs);
    if (!Number.isFinite(ttl) || ttl <= 0) {
      ttl = DEFAULT_TTL_MS;
    }
    var timeoutMs = opts.timeoutMs != null ? Number(opts.timeoutMs) : DEFAULT_TIMEOUT_MS;
    var fetchFn = typeof opts.api === "function" ? opts.api : defaultFetch;
    var cached = cacheGet(key);
    var swr = opts.swr !== false;

    var network = withTimeout(
      Promise.resolve(fetchFn(path, opts)),
      timeoutMs
    )
      .then(function (data) {
        cacheSet(key, data, ttl);
        return {
          data: data,
          fromCache: false,
          fresh: true,
          savedAt: nowMs(),
          error: null,
        };
      })
      .catch(function (err) {
        if (cached) {
          return {
            data: cached.value,
            fromCache: true,
            fresh: cached.fresh,
            savedAt: cached.savedAt || 0,
            error: err,
          };
        }
        throw err;
      });

    if (swr && cached) {
      network.catch(function () {});
      return Promise.resolve({
        data: cached.value,
        fromCache: true,
        fresh: cached.fresh,
        savedAt: cached.savedAt || 0,
        error: null,
        _revalidate: network,
      });
    }
    return network;
  }

  global.CizgiBoot = {
    fetch: fetchOne,
    fetchParallel: fetchParallel,
    cacheGet: cacheGet,
    cacheSet: cacheSet,
    withTimeout: withTimeout,
    setSkeleton: setSkeleton,
    prefersReducedMotion: prefersReducedMotion,
    isOffline: isOffline,
    onConnectivityChange: onConnectivityChange,
    DEFAULT_TIMEOUT_MS: DEFAULT_TIMEOUT_MS,
    DEFAULT_TTL_MS: DEFAULT_TTL_MS,
  };
})(typeof window !== "undefined" ? window : globalThis);
