# Çizgi marka sözleşmesi

Koyu lacivert varsayılan editoryal kimliktir. Bu dosya entegrasyon içindir. Gizli anahtar, ortam değişkeni veya kimlik bilgisi yoktur.

Marka dosyaları uygulama kabuğuna bağlı değildir. `index.html`, `app.css`, `app.js`, `Theme.kt` ve `HaberRoot.kt` bu teslimde değiştirilmez. Aşağıdaki bağlar o işin kapsamıdır.

## Dosyalar

| Yüzey | Repo yolu | Yayın / çağrı |
| --- | --- | --- |
| Token | `backend/app/web/brand/tokens.css` | `/static/brand/tokens.css` |
| Bileşen | `backend/app/web/brand/components.css` | `/static/brand/components.css` |
| İşaret | `backend/app/web/brand/logo.svg` | `/static/brand/logo.svg` |
| Renk, yazı, şema | `android/.../ui/brand/CizgiTokens.kt` | `dev.haberver.kesif.ui.brand` |
| İşaret | `android/.../ui/brand/CizgiMark.kt` | `CizgiMark` |
| Drawable | `android/app/src/main/res/drawable/ic_cizgi_mark.xml` | `@drawable/ic_cizgi_mark` |

Statik kök `backend/app/web` dizinidir ve `/static` altında servis edilir. Sınıflar `cz-` ile başlar; mevcut `app.css` seçicileriyle aynı adı taşımaz.

## Web

`app.css` durur. Marka sayfaları onun yerine geçmez; yeni kabuk `cz-` sınıflarını kullanır. İki satır, `app.css` bağlantısından sonra:

```html
<link rel="stylesheet" href="/static/brand/tokens.css">
<link rel="stylesheet" href="/static/brand/components.css">
```

Kök `lang="tr"` kalır. Tema niteliği yoksa palet koyudur. Açık tema: `html` üzerinde `data-theme="light"`. Koyu ada veya açık sayfada koyu blok: `data-theme="dark"`. Açık ada: `data-theme="light"` öğenin kendisinde de verilebilir.

Sayfa sarmalayıcısı `class="cz"`. Yazı puntoyu, satır yüksekliği ve 44px hedef buradan gelir.

### Sözcük

Marka adı metindir, eğriye çevrilmez: `ÇİZGİ`.

- Ç = U+00C7
- İ = U+0130 (noktalı büyük i, ASCII `I` değil)
- Z = U+005A
- G = U+0047
- İ = U+0130

`text-transform` kullanılmaz. `uppercase` Türkçe `i` harfini `I` yapabilir. Sözcük kaynakta doğru yazılır.

Kilit:

```html
<a class="cz-kilit" href="/">
  <svg class="cz-isaret" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path class="cz-isaret-cizgi" d="M2.5,12H10.5" fill="none" stroke-width="2.5" stroke-linecap="round"/>
    <path class="cz-isaret-yon" d="M16,7.75L21.5,12L16,16.25" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
  <span class="cz-sozcuk">ÇİZGİ</span>
</a>
```

Satır içi SVG tema rengini alır. `<img src="/static/brand/logo.svg">` yalnızca koyu zemindedir; dosyadaki boya açıktır (`#F7F9FC` çizgi, `#F1B548` yön). Açık zeminde `img` kullanılmaz. Sözcük yanındayken görselin adı gizlenir; işaret tek başınaysa `alt="Çizgi"`.

### Sınıflar

| Sınıf | Rol |
| --- | --- |
| `cz` | Kök. Zemin, 16/25 gövde, Türkçe için dönüşümsüz yazı. |
| `cz-manset` | Manşet 24/30, ağırlık 700. |
| `cz-ekran` | Ekran başlığı 22/28, ağırlık 700. |
| `cz-kart-baslik` | Kart başlığı 16/21, ağırlık 600. |
| `cz-govde` | Gövde 16/25. Ölçü en çok 66ch. |
| `cz-spot` | Spot 18/28. Gövdeden küçük değildir. |
| `cz-meta` | Meta 13/18. |
| `cz-ikincil` | İkincil 13/18. 12px altına inmez. |
| `cz-kaynak` | Kaynak satırı. En az 44px. İçinde `cz-kaynak-rol` ile görünen "Kaynak" sözcüğü zorunlu. |
| `cz-kilit` | İşaret + sözcük. En az 44px. |
| `cz-sozcuk` | Sözcük 22/28, ağırlık 800, iz 0.12em. |
| `cz-isaret` | 24px işaret kutusu. |
| `cz-kart` | Kart. 1px kenar, 16px iç boşluk, 12px köşe. |
| `cz-kart--one-cikan` | Üstte 4px vurgu çubuğu. Metin etiketi de gerekir, örneğin "Öne çıkan". |
| `cz-kart-link` | Kart başlığı bağlantısı. Altı çizili, en az 44px. |
| `cz-rozet` | Durum rozeti. Metin 13px. Kendisi kontrol değilse 44px olmak zorunda değildir. |
| `cz-rozet--canli` | Teal zemin, lacivert "Canlı" yazısı, `cz-rozet-cubuk` çubuğu. |
| `cz-rozet--uyari` | 2px vurgu kenarı. Yazı rengi metin rengidir; uyarı sözcüğü görünür. |
| `cz-etiket` | Konu etiketi. 13px. Kontrol değildir. |
| `cz-btn` | Dolgu düğme. Teal zemin, lacivert yazı, 16/25, en az 44px. |
| `cz-btn--ikincil` | Çerçeveli düğme. Dolgu yok. |
| `cz-btn--hayalet` | Altı çizili metin düğmesi. Kutu yok. |
| `cz-btn--ikon` | 44×44 ikon düğmesi. Görünür adı `aria-label` ile verilir. |
| `cz-chip` | Seçim çipi. En az 44px. Seçili: `aria-pressed="true"` veya `aria-current="page"`, kalın yazı ve alt iç çizgi. |
| `cz-iskelet` | `role="status"`. Görünür olmayan "Yükleniyor" için `cz-sr`. Satırlar: `cz-iskelet-satir`, ilki `cz-iskelet-satir--baslik`, kısa olan `cz-iskelet-satir--kisa`. |
| `cz-bos` | `role="status"`. Soldan hizalı başlık ve gövde. İşaret tek başına yeterli değildir. |
| `cz-hata` | `role="alert"`. 4px sol şerit, `cz-kicker` içinde "Hata", sonra ekran başlığı ve gövde. |
| `cz-kicker` | 13/18 etiket. `uppercase` yok. |
| `cz-cizgi` | `hr` ayırıcı. |
| `cz-sr` | Yalnızca ekran okuyucu. |

Örnek kart:

```html
<article class="cz-kart cz-kart--one-cikan">
  <p class="cz-kicker">Öne çıkan</p>
  <span class="cz-rozet cz-rozet--canli"><span class="cz-rozet-cubuk" aria-hidden="true"></span>Canlı</span>
  <h2 class="cz-kart-baslik"><a class="cz-kart-link" href="/story/ornek">Başlık</a></h2>
  <p class="cz-spot">Spot cümlesi burada, gövdeden küçük değil.</p>
  <p class="cz-kaynak"><span class="cz-kaynak-rol">Kaynak</span> Örnek kaynak</p>
</article>
```

Cümle içindeki bağlantı 44px olmak zorunda değildir. Ayrı duran her kontrol en az 44px’tir. Satır kısaltarak (`line-clamp`) veya punto düşürerek sıkıştırma yapılmaz.

### Renk rolleri

Sabit palet: lacivert `#10243A`, zemin `#07111C`, açık metin `#F7F9FC`, teal `#10A6A0`, mavi `#1769AA`, koyu temada bağlantı `#9FD0F5`, altın `#F1B548`, mist `#EAF2F9`.

Anlamlı değişkenler `--cz-renk-zemin`, `--cz-renk-kart`, `--cz-renk-metin`, `--cz-renk-baslik`, `--cz-renk-govde`, `--cz-renk-spot`, `--cz-renk-meta`, `--cz-renk-kaynak`, `--cz-renk-link`, `--cz-renk-canli-zemin`, `--cz-renk-canli-metin`, `--cz-renk-buton-zemin`, `--cz-renk-buton-metin`, `--cz-renk-cizgi`, `--cz-renk-vurgu`, `--cz-renk-odak`, `--cz-renk-hata`, `--cz-renk-isaret-cizgi`, `--cz-renk-isaret-yon`.

Yazı ve boşluk: `--cz-baslik-boyut` 24px / `--cz-baslik-satir` 30px, `--cz-ekran-*` 22/28, `--cz-kart-baslik-*` 16/21, `--cz-govde-*` 16/25, `--cz-spot-*` 18/28, `--cz-meta-*` 13/18, `--cz-bosluk-1` … `--cz-bosluk-7` (4, 8, 12, 16, 24, 32, 48), `--cz-hedef` 44px.

Teal, mist veya açık metin üstünde küçük yazı olmaz (yaklaşık 2,7:1). Altın, açık zeminde yazı olmaz (yaklaşık 1,7:1). Teal düğme zemindir; yazısı laciverttir. Bağlantı koyuda `#9FD0F5`, açıkta `#1769AA`, her zaman altı çizilidir. Kenar rengi `#728190` paletin yeni üyesi değil, mist ile lacivertin 3:1 veren karışımıdır. Hata rengi işlevseldir: koyuda `#FFB4AB`, açıkta `#8C2F2F`. Hata sözcüğü ve şerit birlikte durur.

Odak: `:focus-visible`, 3px metin rengi, 3px dış boşluk. `outline: none` yazılmaz. `prefers-reduced-motion: reduce` iskelet kaydırmasını ve canlı çubuk animasyonunu kapatır. `forced-colors` altında kenar ve çizgi sistem rengine döner.

Yazı ailesi: `"Outfit", "Segoe UI", "Noto Sans", "Helvetica Neue", Arial, sans-serif`. Okur sayfası Outfit’i zaten yükler. Bu sözleşme yeni bir yazı tipi indirmez. Outfit yoksa yığın Türkçe glifleri olan sistem yazısına düşer.

## Android

Paket: `dev.haberver.kesif.ui.brand`.

`Theme.kt` içinde, mevcut özel paletin yerine:

```kotlin
MaterialTheme(
    colorScheme = if (dark) cizgiDarkColorScheme() else cizgiLightColorScheme(),
    typography = cizgiTypography(),
    content = content,
)
```

`cizgiTypography()` bütün Material yuvalarını şu ölçeğe indirir: manşet 24/30, ekran 22/28, kart 16/21, gövde 16/25, meta 13/18. `displayLarge` dahil hiçbir yuva 12sp altına inmez. Spot Material yuvası değildir:

```kotlin
Text(spot, style = CizgiType.Spot)
```

Bağlantı rengi şemada `secondary` olur. Doğrudan renk için `cizgiLinkColor(dark)`.

```kotlin
@Composable
fun CizgiMark(
    modifier: Modifier = Modifier,
    lineColor: Color = CizgiColor.Ink,
    directionColor: Color = CizgiColor.Gold,
    contentDescription: String? = "Çizgi",
)
```

Açık zeminde varsayılan boya kullanılmaz:

```kotlin
CizgiMark(
    modifier = Modifier.size(24.dp),
    lineColor = cizgiLineColor(dark),
    directionColor = cizgiDirectionColor(dark),
    contentDescription = null,
)
```

Sözcük yanındayken `contentDescription` null olur; aksi halde `"Çizgi"`. Dokunulacak kilit `Modifier.cizgiHedef()` ile en az 44dp olur. İşaretin kendi boyu 24dp’dir.

Vektör üretici: `cizgiMarkVector(lineColor, directionColor): ImageVector`. `tint` verilmez; `CizgiMark` bunu `Color.Unspecified` yapar, çünkü çizgi ve yön ayrı boyanır.

`@drawable/ic_cizgi_mark` Compose dışı koyu zemin içindir (başlangıç, hakkında). Bildirim çubuğu ikonu değildir; iki renklidir ve `autoMirrored` kapalıdır. Açık temada `CizgiMark` kullanılır.

Açık temada Material `TextButton` varsayılanı birincil rengi (teal) yazı diye basar. Teal, mist üstünde yetersiz kalır. Açık temada metin düğmesinin `contentColor` değeri `CizgiColor.Blue` veya `CizgiColor.Navy` olur. Dolgu düğme teal zemin ve lacivert yazıdır; o eşleşme her iki temada da kalır.

Yazı tipi `FontFamily.SansSerif`. Punto ölçeği web ile aynıdır; dosya olarak aynı yazı tipi gömülü değildir.

## İşaret

24×24 görünüm, kontur 2.5, uçlar yuvarlak. İki path, üç dosyada aynıdır:

- Çizgi: `M2.5,12H10.5`
- Yön: `M16,7.75L21.5,12L16,16.25`

Uzun ince çizgi ile, arada boşluk bırakarak duran bir yön oku. Pusula, kalem, daire veya dolu üçgen yoktur. Bitmap yoktur. Yön, okun biçimindedir; altın veya mavi bunu tekrarlar, tek başına taşımaz.

## Anlam

Renk tek işaret değildir.

- Canlı: "Canlı" sözcüğü ve dik çubuk.
- Kaynak: "Kaynak" sözcüğü.
- Seçili çip: `aria-pressed` veya `aria-current`, kalın yazı, alt iç çizgi.
- Bağlantı: renk ve alt çizgi.
- Öne çıkan: üst çubuk ve "Öne çıkan".
- Hata: "Hata", sol şerit, başlık.
- Boş: başlık cümlesi; işaret dekor olabilir.
- Odak: kalın dış çizgi, yalnızca klavye odağında.

## Sınırlar

- Okur kabuğu ve `Theme.kt` henüz bu tokenlara alınmamıştır.
- `app.css` içindeki 12px altı kurallar durur; bu sözleşme onları değiştirmez.
- Form alanı, gezinme çubuğu ve yönetim sayfası bu sözleşmede yoktur.
- Koyu boyalı `logo.svg` ve `ic_cizgi_mark.xml` açık zeminde yeniden boyanmaz.
- Android derlemesi bu teslimde çalıştırılmamıştır.
