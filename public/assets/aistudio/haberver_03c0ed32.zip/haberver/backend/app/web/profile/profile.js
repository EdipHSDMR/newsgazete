"use strict";

(function () {
  const KEY = "cizgi.profile.v1";
  const COPY = "Bu sürümde bildirimler cihazdaki tercihlerdir, anlık sunucu push gönderilmez.";

  const host = {
    container: null,
    api: null,
    library: null,
    onWipe: null,
    notices: null,
  };
  let state = blank();
  let extras = {};
  let screen = "profile";
  let inboxFilter = "all";
  let flash = "";
  let meta = null;

  function blank() {
    return {
      theme: "light",
      font: "md",
      notifyTopics: false,
      notifyMatches: false,
      quietStart: 22,
      quietEnd: 7,
      analytics: false,
      notifyBreaking: false,
      notifyMatchStart: false,
      notifyScore: false,
      frequency: "off",
      notificationsEnabled: false,
      permissionDeferred: false,
    };
  }

  function flag(value, fallback) {
    if (typeof value === "boolean") return value;
    if (value === "true") return true;
    if (value === "false") return false;
    return fallback;
  }

  function hour(value, fallback) {
    const number = Number(value);
    return Number.isInteger(number) && number >= 0 && number <= 23 ? number : fallback;
  }

  function load() {
    const defaults = blank();
    let raw = {};
    try {
      const parsed = JSON.parse(localStorage.getItem(KEY) || "{}");
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) raw = parsed;
    } catch {
      raw = {};
    }
    const known = new Set(Object.keys(defaults));
    extras = {};
    Object.keys(raw).forEach((key) => {
      if (!known.has(key)) extras[key] = raw[key];
    });
    const next = {
      ...defaults,
      theme: raw.theme === "dark" ? "dark" : "light",
      font: raw.font === "lg" || raw.font === "xl" ? raw.font : "md",
      notifyTopics: flag(raw.notifyTopics, false),
      notifyBreaking: flag(raw.notifyBreaking, false),
      notifyMatchStart: flag(raw.notifyMatchStart, false),
      notifyScore: flag(raw.notifyScore, false),
      quietStart: hour(raw.quietStart, 22),
      quietEnd: hour(raw.quietEnd, 7),
      analytics: flag(raw.analytics, false),
      frequency: raw.frequency === "device_refresh" ? "device_refresh" : "off",
      notificationsEnabled: flag(raw.notificationsEnabled, false),
      permissionDeferred: flag(raw.permissionDeferred, false),
    };
    if (raw.notifyMatchStart === undefined && raw.notifyScore === undefined && flag(raw.notifyMatches, false)) {
      next.notifyMatchStart = true;
    }
    next.notifyMatches = next.notifyMatchStart || next.notifyScore;
    return next;
  }

  function snapshot() {
    return {
      theme: state.theme,
      font: state.font,
      notifyTopics: state.notifyTopics,
      notifyMatches: state.notifyMatchStart || state.notifyScore,
      quietStart: state.quietStart,
      quietEnd: state.quietEnd,
      analytics: state.analytics,
      notifyBreaking: state.notifyBreaking,
      notifyMatchStart: state.notifyMatchStart,
      notifyScore: state.notifyScore,
      frequency: state.frequency,
      notificationsEnabled: state.notificationsEnabled,
      permissionDeferred: state.permissionDeferred,
    };
  }

  function persist() {
    state.notifyMatches = state.notifyMatchStart || state.notifyScore;
    try {
      localStorage.setItem(KEY, JSON.stringify({ ...extras, ...snapshot() }));
      return true;
    } catch {
      flash = "Tercih bu tarayıcıya yazılamadı.";
      return false;
    }
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[ch]));
  }

  function inQuietHours(now, start, end) {
    if (start === end) return false;
    if (start < end) return now >= start && now < end;
    return now >= start || now < end;
  }

  function labels(value) {
    const list = Array.isArray(value) ? value : [];
    return list.map((item) => {
      if (typeof item === "string") return item.trim();
      if (item && typeof item === "object") {
        return String(item.name || item.title || item.label || item.slug || item.id || "").trim();
      }
      return "";
    }).filter(Boolean);
  }

  function libraryView(library) {
    if (!library) return null;
    const source = typeof library.snapshot === "function" ? (library.snapshot() || {}) : library;
    const follows = source.follows && typeof source.follows === "object" ? source.follows : {};
    const clear = source.clearRecentSearches || source.clearSearches || source.clearRecent
      || library.clearRecentSearches || library.clearSearches || library.clearRecent;
    return {
      topics: labels(source.followedTopics || source.topics || follows.topics),
      sources: labels(source.followedSources || source.sources || follows.sources),
      teams: labels(source.followedTeams || source.teams || follows.teams),
      recent: labels(source.recentSearches || source.recent || source.searches),
      clear: typeof clear === "function" ? clear : null,
      clearThis: source.clearRecentSearches || source.clearSearches || source.clearRecent ? source : library,
    };
  }

  function normalizeNotice(item) {
    if (!item || typeof item !== "object") return null;
    const id = String(item.id || "").trim();
    const title = String(item.title || "").trim();
    if (!id || !title) return null;
    return {
      id,
      title,
      body: String(item.body || "").trim(),
      read: item.read === true,
      createdAt: String(item.createdAt || item.at || "").trim(),
    };
  }

  function listedNotices(value) {
    const source = typeof value === "function" ? value() : value;
    const list = Array.isArray(source) ? source : [];
    return list.map(normalizeNotice).filter(Boolean);
  }

  function loadInbox() {
    const stored = listedNotices(extras.inbox);
    const injected = listedNotices(host.notices);
    if (!injected.length) return stored;
    const map = new Map();
    stored.forEach((item) => map.set(item.id, item));
    injected.forEach((item) => {
      const prev = map.get(item.id);
      map.set(item.id, prev ? { ...item, read: prev.read || item.read } : item);
    });
    return [...map.values()];
  }

  function saveInbox(items) {
    extras.inbox = listedNotices(items);
    persist();
  }

  function unreadCount(items) {
    return items.filter((item) => item.read !== true).length;
  }

  function filteredInbox(items) {
    if (inboxFilter === "unread") return items.filter((item) => item.read !== true);
    if (inboxFilter === "read") return items.filter((item) => item.read === true);
    return items;
  }

  function permissionLabel() {
    const preference = state.notificationsEnabled ? "Uygulama tercihi açık." : "Uygulama tercihi kapalı.";
    if (typeof Notification === "undefined") {
      return `Tarayıcı bildirim izni sunmuyor. ${preference}`;
    }
    if (Notification.permission === "granted") return `Tarayıcı izni açık. ${preference}`;
    if (Notification.permission === "denied") return `Tarayıcı izni kapalı. ${preference}`;
    return `Henüz sorulmadı. ${preference}`;
  }

  function choice(action, value, label, selected) {
    return `<button type="button" data-action="${action}" data-value="${esc(value)}" aria-pressed="${selected ? "true" : "false"}">${esc(label)}${selected ? ", seçili" : ""}</button>`;
  }

  function onOff(value) {
    return value ? "açık" : "kapalı";
  }

  function followMarkup(view) {
    if (!view) {
      return "<p>Takip özeti kütüphane modülünden gelir. Bu ekrana kütüphane bağlı değil.</p>";
    }
    if (!view.topics.length && !view.sources.length && !view.teams.length) {
      return "<p>Takip edilen konu, kaynak veya takım yok.</p>";
    }
    const block = (title, items) => (items.length
      ? `<h3>${esc(title)}</h3><ul>${items.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>`
      : "");
    return block("Konular", view.topics) + block("Kaynaklar", view.sources) + block("Takımlar", view.teams);
  }

  function searchMarkup(view) {
    if (!view) return "<p>Arama geçmişi bu profil kaydında tutulmaz.</p>";
    if (!view.recent.length) return "<p>Kayıtlı arama yok.</p>";
    return `<ul>${view.recent.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>`;
  }

  function inboxMarkup(items) {
    const unread = unreadCount(items);
    const shown = filteredInbox(items);
    const filters = [
      ["all", "Tümü"],
      ["unread", "Okunmadı"],
      ["read", "Okundu"],
    ].map(([value, label]) => (
      `<button type="button" class="cizgi-chip" data-action="inbox-filter" data-value="${value}" aria-pressed="${inboxFilter === value ? "true" : "false"}">${esc(label)}</button>`
    )).join("");
    const head = `<p class="cizgi-unread" role="status">Okunmamış: ${unread}</p>
      <div class="cizgi-inbox-filters" role="toolbar" aria-label="Bildirim süzgeci">${filters}</div>`;
    if (!items.length) {
      return `${head}<p class="cizgi-empty">Liste boş. ${esc(COPY)} Teslim edilmiş bildirim olmadığı için gösterilecek kayıt yok.</p>`;
    }
    if (!shown.length) {
      return `${head}<p class="cizgi-empty">Bu süzgeçte bildirim yok.</p>${unread ? `<button type="button" data-action="mark-all-read">Tümünü okundu say</button>` : ""}`;
    }
    const rows = shown.map((item) => (
      `<li class="${item.read ? "is-read" : "is-unread"}">
        <button type="button" data-action="mark-read" data-id="${esc(item.id)}" aria-pressed="${item.read ? "true" : "false"}">
          <p class="cizgi-kicker">${item.read ? "Okundu" : "Okunmadı · dokununca okundu"}</p>
          <h3>${esc(item.title)}</h3>
          ${item.body ? `<p>${esc(item.body)}</p>` : ""}
        </button>
      </li>`
    )).join("");
    return `${head}<ul class="cizgi-inbox">${rows}</ul>${unread ? `<button type="button" data-action="mark-all-read">Tümünü okundu say</button>` : ""}`;
  }

  function appInfo() {
    const name = meta && typeof meta.name === "string" && meta.name.trim() ? meta.name.trim() : "Çizgi";
    const promise = meta && typeof meta.promise === "string" && meta.promise.trim()
      ? meta.promise.trim()
      : "Gündemi bul, bağlamı gör.";
    const brandDetail = meta && typeof meta.brand_status === "string" && meta.brand_status.trim()
      ? `<p>${esc(meta.brand_status.trim())}</p>`
      : "<p>Ticari marka ve alan adı uygunluğu yayın öncesinde doğrulanmalıdır.</p>";
    return `<h2>Uygulama</h2><p class="cizgi-brand">${esc(name)}</p><p>${esc(promise)}</p><p>Marka: TBD</p>${brandDetail}`;
  }

  function profileScreen(view) {
    const quiet = inQuietHours(new Date().getHours(), state.quietStart, state.quietEnd);
    return `<header class="cizgi-head"><p class="cizgi-kicker">Misafir</p><h1>Profil</h1></header>
      <section class="cizgi-card"><h2>Takip özeti</h2>${followMarkup(view)}</section>
      <section class="cizgi-card"><h2>Bildirim tercihleri</h2>
        <p>${esc(COPY)}</p>
        <ul>
          <li>Son dakika: ${onOff(state.notifyBreaking)}</li>
          <li>Takip konu ve kaynak: ${onOff(state.notifyTopics)}</li>
          <li>Maç başlangıcı: ${onOff(state.notifyMatchStart)}</li>
          <li>Skor değişimi: ${onOff(state.notifyScore)}</li>
        </ul>
        <p>Sessiz saat ${String(state.quietStart).padStart(2, "0")}:00–${String(state.quietEnd).padStart(2, "0")}:00. ${quiet ? "Şu an sessiz saat içindesin." : "Şu an sessiz saat dışındasın."} Başlangıç ve bitiş aynıysa sessiz saat yok sayılır.</p>
        <button type="button" data-action="show-alerts">Bildirim merkezinde düzenle</button>
      </section>
      <section class="cizgi-card"><h2>Görünüm</h2>
        <p>Açık lacivert-beyaz varsayılan okuma zeminidir.</p>
        ${choice("theme", "light", "Açık", state.theme === "light")}
        ${choice("theme", "dark", "Koyu lacivert", state.theme === "dark")}
        <h3>Yazı boyutu</h3>
        ${choice("font", "md", "Standart", state.font === "md")}
        ${choice("font", "lg", "Büyük", state.font === "lg")}
        ${choice("font", "xl", "Daha büyük", state.font === "xl")}
        <div class="cizgi-preview" data-size="${esc(state.font)}"><p class="cizgi-kicker">Önizleme</p><p>Gündemi bul, bağlamı gör.</p></div>
      </section>
      <section class="cizgi-card"><h2>Gizlilik</h2>
        <p>Hesap yok. Takip, bildirim tercihleri ve arama geçmişi bu cihazda durur.</p>
        <p>Konum izni istenmez.</p>
        <label class="cizgi-check"><input data-field="analytics" type="checkbox" ${state.analytics ? "checked" : ""}> <span>İsteğe bağlı kullanım ölçümü</span></label>
        <p>Ölçüm kapalı başlar. Açıkken de bu ekran ölçüm göndermez; seçim yalnızca bu tarayıcıya yazılır.</p>
        <h3>Arama geçmişi</h3>
        ${searchMarkup(view)}
        <button type="button" data-action="clear-searches">Arama geçmişini temizle</button>
        <button type="button" data-action="wipe-profile">Profil tercihlerini sil</button>
      </section>
      <section class="cizgi-card">${appInfo()}</section>`;
  }

  function alertScreen() {
    const quiet = inQuietHours(new Date().getHours(), state.quietStart, state.quietEnd);
    const items = loadInbox();
    return `<header class="cizgi-head"><p class="cizgi-kicker">Cihaz</p><h1>Bildirim merkezi</h1></header>
      <section class="cizgi-card">${inboxMarkup(items)}<p>${esc(COPY)}</p></section>
      <section class="cizgi-card"><h2>Kategoriler</h2>
        <p>Anahtarlar bu tarayıcıda durur. Web bu sürümde bildirim zamanlamaz.</p>
        <label class="cizgi-check"><input data-field="notify-breaking" type="checkbox" ${state.notifyBreaking ? "checked" : ""}> <span>Son dakika</span></label>
        <label class="cizgi-check"><input data-field="notify-topics" type="checkbox" ${state.notifyTopics ? "checked" : ""}> <span>Takip konu ve kaynak</span></label>
        <label class="cizgi-check"><input data-field="notify-match-start" type="checkbox" ${state.notifyMatchStart ? "checked" : ""}> <span>Maç başlangıcı</span></label>
        <label class="cizgi-check"><input data-field="notify-score" type="checkbox" ${state.notifyScore ? "checked" : ""}> <span>Skor değişimi</span></label>
      </section>
      <section class="cizgi-card"><h2>Sıklık</h2>
        ${choice("frequency", "off", "Gönderim yok", state.frequency === "off")}
        ${choice("frequency", "device_refresh", "Cihaz yenilemesi", state.frequency === "device_refresh")}
        <p>Sıklık kaydı gönderim zamanını değiştirmez. Bu tarayıcıda yenileme işçisi yoktur.</p>
      </section>
      <section class="cizgi-card"><h2>Sessiz saat</h2>
        <div class="cizgi-quiet">
          <label class="cizgi-field">Başlangıç<input data-field="quiet-start" type="number" min="0" max="23" step="1" inputmode="numeric" value="${state.quietStart}"></label>
          <label class="cizgi-field">Bitiş<input data-field="quiet-end" type="number" min="0" max="23" step="1" inputmode="numeric" value="${state.quietEnd}"></label>
        </div>
        <p>${quiet ? "Şu an sessiz saat içindesin." : "Şu an sessiz saat dışındasın."} Saatler 0 ile 23 arasındadır. Başlangıç ve bitiş aynıysa sessiz saat yok sayılır. Bu kayıt Android uygulamasına kendiliğinden yazılmaz.</p>
      </section>
      <section class="cizgi-card"><h2>İzin</h2>
        <p role="status">${esc(permissionLabel())}</p>
        <p>${esc(COPY)}</p>
        <button type="button" data-action="enable-notifications">Bildirimleri aç</button>
        <button type="button" data-action="defer-notifications">Şimdi değil</button>
      </section>`;
  }

  function render() {
    const container = host.container;
    if (!container) return;
    const view = libraryView(host.library);
    const profileOn = screen === "profile";
    container.innerHTML = `<section class="cizgi-profile" data-theme="${esc(state.theme)}" data-font="${esc(state.font)}" lang="tr">
      <div class="cizgi-tabs" role="tablist" aria-label="Profil bölümleri">
        <button type="button" role="tab" data-action="show-profile" aria-selected="${profileOn ? "true" : "false"}">Profil</button>
        <button type="button" role="tab" data-action="show-alerts" aria-selected="${profileOn ? "false" : "true"}">Bildirim merkezi</button>
      </div>
      ${flash ? `<p class="cizgi-flash" role="status">${esc(flash)}</p>` : ""}
      <div role="tabpanel">${profileOn ? profileScreen(view) : alertScreen()}</div>
    </section>`;
  }

  async function enableNotifications() {
    state.permissionDeferred = false;
    let permission = "unsupported";
    if (typeof Notification !== "undefined" && typeof Notification.requestPermission === "function") {
      try {
        permission = await Notification.requestPermission();
      } catch {
        permission = "denied";
      }
    }
    if (permission === "denied") {
      state.notificationsEnabled = false;
      flash = "Tarayıcı izni verilmedi. Uygulama tercihi kapalı kaldı.";
    } else {
      state.notificationsEnabled = true;
      flash = permission === "granted"
        ? "Tercih bu tarayıcıda açıldı. Anlık sunucu push gönderilmez."
        : "Tercih bu tarayıcıda açıldı. Tarayıcı izin penceresi yok. Anlık sunucu push gönderilmez.";
    }
    persist();
    render();
  }

  function deferNotifications() {
    state.permissionDeferred = true;
    if (!state.notificationsEnabled) flash = "İzin şimdi istenmedi.";
    else flash = "İzin isteği yapılmadı. Kayıtlı tercih duruyor.";
    persist();
    render();
  }

  async function clearSearches() {
    const view = libraryView(host.library);
    if (!view) {
      flash = "Bu profil kaydı arama sorgusu tutmaz. Silinecek liste yok.";
      render();
      return;
    }
    if (!view.clear) {
      flash = view.recent.length
        ? "Kütüphane temizleme işlevi vermedi. Liste bu ekrandan silinmedi."
        : "Silinecek arama kaydı yok.";
      render();
      return;
    }
    try {
      await view.clear.call(view.clearThis);
    } catch {
      flash = "Arama geçmişi silinemedi.";
      render();
      return;
    }
    const after = libraryView(host.library);
    flash = after && after.recent.length
      ? "Temizleme çağrısı döndü. Listede hâlâ kayıt görünüyor."
      : "Arama geçmişi temizlendi.";
    render();
  }

  function wipeProfile() {
    try {
      localStorage.removeItem(KEY);
    } catch {
      flash = "Profil kaydı silinemedi.";
      render();
      return;
    }
    extras = {};
    state = blank();
    let wipeError = false;
    if (typeof host.onWipe === "function") {
      try {
        host.onWipe();
      } catch {
        wipeError = true;
      }
    }
    flash = wipeError
      ? "Profil kaydı silindi. Uygulama geri çağrısı tamamlanamadı."
      : "Profil tercihleri silindi.";
    render();
  }

  function onClick(event) {
    const origin = event.target && event.target.closest ? event.target : event.target && event.target.parentElement;
    const button = origin && origin.closest ? origin.closest("[data-action]") : null;
    if (!button || !host.container || !host.container.contains(button)) return;
    const action = button.dataset.action;
    const value = button.dataset.value;
    if (action === "show-profile") {
      screen = "profile";
      flash = "";
      render();
    } else if (action === "show-alerts") {
      screen = "alerts";
      flash = "";
      render();
    } else if (action === "inbox-filter") {
      inboxFilter = value === "unread" || value === "read" ? value : "all";
      flash = "";
      render();
    } else if (action === "mark-read") {
      const id = button.dataset.id;
      if (!id) return;
      const next = loadInbox().map((item) => (item.id === id ? { ...item, read: true } : item));
      saveInbox(next);
      flash = "";
      render();
    } else if (action === "mark-all-read") {
      saveInbox(loadInbox().map((item) => ({ ...item, read: true })));
      flash = "Görünen kayıtlar okundu sayıldı.";
      render();
    } else if (action === "theme") {
      state.theme = value === "light" ? "light" : "dark";
      persist();
      render();
    } else if (action === "font") {
      state.font = value === "lg" || value === "xl" ? value : "md";
      persist();
      render();
    } else if (action === "frequency") {
      state.frequency = value === "device_refresh" ? "device_refresh" : "off";
      persist();
      render();
    } else if (action === "enable-notifications") {
      enableNotifications();
    } else if (action === "defer-notifications") {
      deferNotifications();
    } else if (action === "clear-searches") {
      clearSearches();
    } else if (action === "wipe-profile") {
      wipeProfile();
    }
  }

  function onChange(event) {
    const field = event.target && event.target.dataset ? event.target.dataset.field : "";
    if (field === "analytics") state.analytics = Boolean(event.target.checked);
    else if (field === "notify-breaking") state.notifyBreaking = Boolean(event.target.checked);
    else if (field === "notify-topics") state.notifyTopics = Boolean(event.target.checked);
    else if (field === "notify-match-start") {
      state.notifyMatchStart = Boolean(event.target.checked);
      state.notifyMatches = state.notifyMatchStart || state.notifyScore;
    } else if (field === "notify-score") {
      state.notifyScore = Boolean(event.target.checked);
      state.notifyMatches = state.notifyMatchStart || state.notifyScore;
    } else return;
    persist();
    render();
  }

  function onInput(event) {
    const field = event.target && event.target.dataset ? event.target.dataset.field : "";
    if (field !== "quiet-start" && field !== "quiet-end") return;
    if (String(event.target.value).trim() === "") return;
    const next = hour(event.target.value, -1);
    if (next < 0) return;
    if (field === "quiet-start") state.quietStart = next;
    else state.quietEnd = next;
    persist();
  }

  async function loadMeta(api) {
    if (typeof api !== "function") return null;
    try {
      const body = await api("/v1/meta");
      if (!body || typeof body !== "object") return null;
      return body.data && typeof body.data === "object" ? body.data : body;
    } catch {
      return null;
    }
  }

  function mount(container, options) {
    if (!container || !("innerHTML" in container)) return;
    const settings = options || {};
    host.container = container;
    host.api = settings.api || null;
    host.library = settings.library || null;
    host.onWipe = settings.onWipe || null;
    host.notices = settings.notices || null;
    try {
      state = load();
    } catch {
      state = blank();
    }
    screen = (settings.initialScreen === "alerts" || settings.screen === "alerts") ? "alerts" : "profile";
    inboxFilter = "all";
    flash = "";
    persist();
    container.onclick = onClick;
    container.onchange = onChange;
    container.oninput = onInput;
    render();
    const requested = host.api;
    loadMeta(requested).then((next) => {
      if (host.container !== container || host.api !== requested) return;
      meta = next;
      const active = typeof document !== "undefined" ? document.activeElement : null;
      if (active && container.contains(active)) return;
      render();
    });
  }

  try {
    state = load();
  } catch {
    state = blank();
  }
  const root = typeof globalThis !== "undefined" ? globalThis : window;
  function publicUnread() {
    try {
      state = load();
    } catch {
      state = blank();
    }
    return unreadCount(loadInbox());
  }

  root.CizgiProfile = {
    mount,
    read: snapshot,
    unreadCount: publicUnread,
    KEY,
  };
}());
