(function () {
  "use strict";

  const KEY = "cizgi.library.v1";
  const LEGACY_KEY = "haberkesif.reader.v1";
  const LATER_ID = "later";
  const LATER_NAME = "Daha sonra oku";
  const HIDE_CODES = new Set(["content_unavailable", "not_found", "rights_blocked"]);
  const HIDDEN_TEXT = "Kayıt duruyor. Metin yayında değil veya izin bittiği için gizlendi.";
  const UNAVAILABLE_TEXT = "Metin şu an alınamadı. Kayıt duruyor.";
  const CACHE_LABEL = "Çevrimdışı / önbellek";
  const CACHE_NOTE = "Özet ve bağlantı cihaz önbelleğinden. Tam makale yok.";
  const SUMMARY_LIMIT = 2000;
  const LOAD_MS = 12000;
  const LIMITS = { stories: 400, folders: 24, follows: 80, moves: 400, id: 80, label: 160 };

  const listeners = new Set();
  let memory = null;
  let sessionNote = "";
  let damaged = false;

  function storageGet(key) {
    try {
      return globalThis.localStorage ? globalThis.localStorage.getItem(key) : null;
    } catch {
      return null;
    }
  }

  function storageSet(key, value) {
    try {
      if (globalThis.localStorage) globalThis.localStorage.setItem(key, value);
    } catch {
      /* bellek kopyası durur; eski anahtar silinmez */
    }
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[ch]));
  }

  function escText(value) {
    return esc(value).replace(/\n/g, "<br>");
  }

  function fold(value) {
    return String(value).toLocaleLowerCase("tr-TR");
  }

  function cleanLabel(value) {
    const label = String(value ?? "").replace(/[\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim();
    if (!label || label.length > LIMITS.label) return "";
    return label;
  }

  function cleanId(value) {
    const id = String(value ?? "").trim();
    if (!id || id.length > LIMITS.id || /[\u0000-\u001f\s]/.test(id)) return "";
    return id;
  }

  function asLabel(item) {
    if (typeof item === "string") return cleanLabel(item);
    if (item && typeof item === "object") return cleanLabel(item.slug || item.id || item.name || "");
    return "";
  }

  function uniqueLabels(list) {
    const out = [];
    const seen = new Set();
    for (const item of Array.isArray(list) ? list : []) {
      const label = asLabel(item);
      const key = fold(label);
      if (!label || seen.has(key)) continue;
      seen.add(key);
      out.push(label);
      if (out.length >= LIMITS.follows) break;
    }
    return out;
  }

  function cleanFolders(list) {
    const out = [];
    const seen = new Set();
    for (const item of Array.isArray(list) ? list : []) {
      if (!item || typeof item !== "object") continue;
      const id = cleanId(item.id);
      const name = cleanLabel(item.name);
      if (!id || !name || seen.has(id)) continue;
      seen.add(id);
      out.push({ id, name });
      if (out.length >= LIMITS.folders) break;
    }
    if (!seen.has(LATER_ID)) out.unshift({ id: LATER_ID, name: LATER_NAME });
    const later = out.find((folder) => folder.id === LATER_ID);
    const rest = out.filter((folder) => folder.id !== LATER_ID);
    return [later, ...rest].slice(0, LIMITS.folders);
  }

  function cleanSummary(value) {
    const text = String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001f]/g, " ").trim();
    if (!text) return "";
    return text.length > SUMMARY_LIMIT ? text.slice(0, SUMMARY_LIMIT).trim() : text;
  }

  function cleanHttps(raw) {
    try {
      const url = new URL(String(raw || "").trim());
      if (url.protocol !== "https:") return "";
      if (url.username || url.password) return "";
      if (!url.hostname) return "";
      return url.href;
    } catch {
      return "";
    }
  }

  function cleanStory(raw, folderIds) {
    const source = typeof raw === "string" ? { id: raw } : raw;
    if (!source || typeof source !== "object") return null;
    const id = cleanId(source.id);
    if (!id) return null;
    const requested = cleanId(source.folderId);
    const folderId = requested && folderIds.has(requested) ? requested : LATER_ID;
    const savedAt = typeof source.savedAt === "string" && !Number.isNaN(Date.parse(source.savedAt))
      ? source.savedAt
      : "1970-01-01T00:00:00.000Z";
    const cachedAt = typeof source.cachedAt === "string" && !Number.isNaN(Date.parse(source.cachedAt))
      ? source.cachedAt
      : "";
    const cacheTitle = cleanLabel(source.cacheTitle);
    const cacheSummary = cleanSummary(source.cacheSummary);
    const cacheLink = cleanHttps(source.cacheLink);
    return {
      id,
      savedAt,
      folderId,
      read: source.read === true,
      archived: source.archived === true,
      cacheTitle,
      cacheSummary,
      cacheLink,
      cachedAt,
    };
  }

  function cleanStories(list, folderIds) {
    const out = [];
    const seen = new Set();
    for (const item of Array.isArray(list) ? list : []) {
      const story = cleanStory(item, folderIds);
      if (!story || seen.has(story.id)) continue;
      seen.add(story.id);
      out.push(story);
      if (out.length >= LIMITS.stories) break;
    }
    return out;
  }

  function cleanUndo(raw, folderIds) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const undoFolders = [];
    const seenFolders = new Set();
    for (const item of Array.isArray(raw.folders) ? raw.folders : []) {
      if (!item || typeof item !== "object") continue;
      const id = cleanId(item.id);
      const name = cleanLabel(item.name);
      if (!id || !name || id === LATER_ID || seenFolders.has(id)) continue;
      seenFolders.add(id);
      undoFolders.push({ id, name });
    }
    const allowed = new Set([...folderIds, ...undoFolders.map((folder) => folder.id), LATER_ID]);
    const savedStories = cleanStories(raw.savedStories, allowed).slice(0, LIMITS.stories);
    const folderMoves = [];
    const seenMoves = new Set();
    for (const item of Array.isArray(raw.folderMoves) ? raw.folderMoves : []) {
      if (!item || typeof item !== "object") continue;
      const id = cleanId(item.id);
      const folderId = cleanId(item.folderId);
      if (!id || !folderId || seenMoves.has(id) || !allowed.has(folderId)) continue;
      seenMoves.add(id);
      folderMoves.push({ id, folderId });
      if (folderMoves.length >= LIMITS.moves) break;
    }
    const topics = uniqueLabels(raw.topics);
    const publishers = uniqueLabels(raw.publishers);
    const teams = uniqueLabels(raw.teams);
    const competitions = uniqueLabels(raw.competitions);
    const muted = uniqueLabels(raw.muted);
    if (!savedStories.length && !undoFolders.length && !folderMoves.length && !topics.length && !publishers.length && !teams.length && !competitions.length && !muted.length) {
      return null;
    }
    return {
      label: cleanLabel(raw.label) || "Son silme geri alınabilir",
      savedStories,
      folders: undoFolders,
      folderMoves,
      topics,
      publishers,
      teams,
      competitions,
      muted,
    };
  }

  function blankUndo() {
    return {
      label: "",
      savedStories: [],
      folders: [],
      folderMoves: [],
      topics: [],
      publishers: [],
      teams: [],
      competitions: [],
      muted: [],
    };
  }

  function normalize(input) {
    const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const folders = cleanFolders(source.folders);
    const folderIds = new Set(folders.map((folder) => folder.id));
    const savedStories = cleanStories(source.savedStories, folderIds);
    return {
      version: 1,
      legacyImported: source.legacyImported === true,
      savedStories,
      folders,
      followedTopics: uniqueLabels(source.followedTopics),
      followedPublishers: uniqueLabels(source.followedPublishers),
      followedTeams: uniqueLabels(source.followedTeams),
      followedCompetitions: uniqueLabels(source.followedCompetitions),
      muted: uniqueLabels(source.muted),
      undo: cleanUndo(source.undo, folderIds),
    };
  }

  function defaultState() {
    return normalize({
      legacyImported: false,
      savedStories: [],
      folders: [{ id: LATER_ID, name: LATER_NAME }],
      followedTopics: [],
      followedPublishers: [],
      followedTeams: [],
      followedCompetitions: [],
      muted: [],
      undo: null,
    });
  }

  function importLegacy(state) {
    if (state.legacyImported) return { state, copied: 0 };
    const rawText = storageGet(LEGACY_KEY);
    if (rawText == null) return { state, copied: 0 };
    let raw;
    try {
      raw = JSON.parse(rawText);
    } catch {
      return { state, copied: 0 };
    }
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { state, copied: 0 };
    const saved = Array.isArray(raw.saved) ? raw.saved : [];
    const followed = Array.isArray(raw.followed) ? raw.followed : [];
    const muted = Array.isArray(raw.muted) ? raw.muted : [];
    const have = new Set(state.savedStories.map((story) => story.id));
    const importedStories = [];
    const savedAt = new Date().toISOString();
    for (const item of saved) {
      const id = cleanId(typeof item === "string" ? item : item && item.id);
      if (!id || have.has(id)) continue;
      have.add(id);
      importedStories.push({ id, savedAt, folderId: LATER_ID, read: false, archived: false });
    }
    const next = normalize({
      ...state,
      legacyImported: true,
      savedStories: [...importedStories, ...state.savedStories],
      followedTopics: [...followed, ...state.followedTopics],
      muted: [...muted, ...state.muted],
    });
    return { state: next, copied: importedStories.length + followed.length + muted.length };
  }

  function freeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.values(value).forEach(freeze);
    return Object.freeze(value);
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function persist(state) {
    if (damaged) return;
    memory = normalize(state);
    storageSet(KEY, JSON.stringify(memory));
  }

  function get() {
    return freeze(clone(memory));
  }

  function emit() {
    const snapshot = get();
    listeners.forEach((listener) => {
      try {
        listener(snapshot);
      } catch {
        /* bir dinleyici store'u düşürmesin */
      }
    });
  }

  function set(patch) {
    const current = get();
    let next;
    if (typeof patch === "function") next = patch(current);
    else if (patch && typeof patch === "object" && !Array.isArray(patch)) next = { ...current, ...patch };
    else return get();
    if (!next || typeof next !== "object" || Array.isArray(next)) return get();
    persist(next);
    emit();
    return get();
  }

  function subscribe(listener) {
    if (typeof listener !== "function") return function () {};
    listeners.add(listener);
    return function () {
      listeners.delete(listener);
    };
  }

  function commit(recipe, undo) {
    const draft = clone(memory);
    const result = recipe(draft) || draft;
    if (arguments.length > 1) result.undo = undo;
    persist(result);
    emit();
    return get();
  }

  function hasLabel(list, label) {
    const key = fold(label);
    return list.some((item) => fold(item) === key);
  }

  const followKey = {
    topic: "followedTopics",
    publisher: "followedPublishers",
    team: "followedTeams",
    competition: "followedCompetitions",
  };
  const undoKey = {
    topic: "topics",
    publisher: "publishers",
    team: "teams",
    competition: "competitions",
  };

  function follow(kind, value) {
    const field = followKey[kind];
    const label = cleanLabel(value);
    if (!field || !label || hasLabel(memory[field], label)) return get();
    return commit((state) => {
      state[field] = [...state[field], label];
      return state;
    });
  }

  function unfollow(kind, value) {
    const field = followKey[kind];
    const slot = undoKey[kind];
    const label = cleanLabel(value);
    if (!field || !label || !hasLabel(memory[field], label)) return get();
    const kept = memory[field].find((item) => fold(item) === fold(label));
    const undo = blankUndo();
    undo.label = "Takip kaldırıldı";
    undo[slot] = [kept];
    return commit((state) => {
      state[field] = state[field].filter((item) => fold(item) !== fold(label));
      return state;
    }, undo);
  }

  function saveStory(id, folderId) {
    const clean = cleanId(id);
    if (!clean) return get();
    return commit((state) => {
      const folders = new Set(state.folders.map((folder) => folder.id));
      const target = folders.has(folderId) ? folderId : LATER_ID;
      const index = state.savedStories.findIndex((story) => story.id === clean);
      if (index === -1) {
        state.savedStories.unshift({
          id: clean,
          savedAt: new Date().toISOString(),
          folderId: target,
          read: false,
          archived: false,
          cacheTitle: "",
          cacheSummary: "",
          cacheLink: "",
          cachedAt: "",
        });
      } else {
        const current = state.savedStories[index];
        state.savedStories[index] = { ...current, folderId: target, archived: false };
      }
      return state;
    });
  }

  function cacheSnippet(id, snippet) {
    const clean = cleanId(id);
    if (!clean || !memory.savedStories.some((story) => story.id === clean)) return get();
    const source = snippet && typeof snippet === "object" ? snippet : {};
    const cacheTitle = cleanLabel(source.title || source.cacheTitle);
    const cacheSummary = cleanSummary(source.summary || source.cacheSummary);
    const cacheLink = cleanHttps(source.link || source.cacheLink);
    if (!cacheTitle && !cacheSummary && !cacheLink) return get();
    return updateStory(clean, (story) => ({
      ...story,
      cacheTitle: cacheTitle || story.cacheTitle || "",
      cacheSummary: cacheSummary || story.cacheSummary || "",
      cacheLink: cacheLink || story.cacheLink || "",
      cachedAt: new Date().toISOString(),
    }));
  }

  function updateStory(id, recipe) {
    const clean = cleanId(id);
    if (!clean || !memory.savedStories.some((story) => story.id === clean)) return get();
    return commit((state) => {
      state.savedStories = state.savedStories.map((story) => (story.id === clean ? recipe(story) : story));
      return state;
    });
  }

  function setRead(id, read) {
    return updateStory(id, (story) => ({ ...story, read: Boolean(read) }));
  }

  function setArchived(id, archived) {
    return updateStory(id, (story) => ({ ...story, archived: Boolean(archived) }));
  }

  function moveStory(id, folderId) {
    const target = cleanId(folderId);
    if (!memory.folders.some((folder) => folder.id === target)) return get();
    return updateStory(id, (story) => ({ ...story, folderId: target }));
  }

  function readLater(id) {
    return updateStory(id, (story) => ({ ...story, folderId: LATER_ID, archived: false }));
  }

  function removeStory(id) {
    const clean = cleanId(id);
    const story = memory.savedStories.find((item) => item.id === clean);
    if (!story) return get();
    const undo = blankUndo();
    undo.label = "Kayıt silindi";
    undo.savedStories = [clone(story)];
    return commit((state) => {
      state.savedStories = state.savedStories.filter((item) => item.id !== clean);
      return state;
    }, undo);
  }

  function addFolder(name) {
    const label = cleanLabel(name);
    if (!label || memory.folders.some((folder) => fold(folder.name) === fold(label))) return get();
    return commit((state) => {
      const used = new Set(state.folders.map((folder) => folder.id));
      let id = "";
      do {
        const cryptoApi = globalThis.crypto;
        const seed = (cryptoApi && typeof cryptoApi.randomUUID === "function" ? cryptoApi.randomUUID() : Math.random().toString(16).slice(2)).replace(/-/g, "");
        id = "fld-" + seed.slice(0, 8);
      } while (used.has(id));
      state.folders.push({ id, name: label });
      return state;
    });
  }

  function renameFolder(id, name) {
    const clean = cleanId(id);
    const label = cleanLabel(name);
    if (!clean || !label) return get();
    if (!memory.folders.some((folder) => folder.id === clean)) return get();
    if (memory.folders.some((folder) => folder.id !== clean && fold(folder.name) === fold(label))) return get();
    return commit((state) => {
      state.folders = state.folders.map((folder) => (folder.id === clean ? { ...folder, name: label } : folder));
      return state;
    });
  }

  function removeFolder(id) {
    const clean = cleanId(id);
    if (!clean || clean === LATER_ID) return get();
    const folder = memory.folders.find((item) => item.id === clean);
    if (!folder) return get();
    const moves = memory.savedStories.filter((story) => story.folderId === clean).map((story) => ({ id: story.id, folderId: story.folderId }));
    const undo = blankUndo();
    undo.label = "Klasör silindi";
    undo.folders = [clone(folder)];
    undo.folderMoves = moves;
    return commit((state) => {
      state.folders = state.folders.filter((item) => item.id !== clean);
      state.savedStories = state.savedStories.map((story) => (story.folderId === clean ? { ...story, folderId: LATER_ID } : story));
      return state;
    }, undo);
  }

  function removeMuted(value) {
    const label = cleanLabel(value);
    if (!label || !hasLabel(memory.muted, label)) return get();
    const kept = memory.muted.find((item) => fold(item) === fold(label));
    const undo = blankUndo();
    undo.label = "Sessiz yayıncı listeden çıkarıldı";
    undo.muted = [kept];
    return commit((state) => {
      state.muted = state.muted.filter((item) => fold(item) !== fold(label));
      return state;
    }, undo);
  }

  function undo() {
    const action = memory.undo;
    if (!action) return get();
    return commit((state) => {
      const have = new Set(state.savedStories.map((story) => story.id));
      for (const story of action.savedStories) {
        if (!have.has(story.id)) {
          state.savedStories.unshift(clone(story));
          have.add(story.id);
        }
      }
      const folderIds = new Set(state.folders.map((folder) => folder.id));
      for (const folder of action.folders) {
        if (!folderIds.has(folder.id)) state.folders.push(clone(folder));
      }
      const moves = new Map(action.folderMoves.map((move) => [move.id, move.folderId]));
      state.savedStories = state.savedStories.map((story) => {
        const folderId = moves.get(story.id);
        if (!folderId || story.folderId !== LATER_ID) return story;
        return { ...story, folderId };
      });
      state.followedTopics = [...state.followedTopics, ...action.topics];
      state.followedPublishers = [...state.followedPublishers, ...action.publishers];
      state.followedTeams = [...state.followedTeams, ...action.teams];
      state.followedCompetitions = [...state.followedCompetitions, ...action.competitions];
      state.muted = [...state.muted, ...action.muted];
      state.undo = null;
      return state;
    }, null);
  }

  function boot() {
    const rawText = storageGet(KEY);
    if (rawText != null) {
      try {
        const parsed = JSON.parse(rawText);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("shape");
        const imported = importLegacy(normalize(parsed));
        if (imported.copied > 0) sessionNote = "Eski okuyucudaki kayıt, konu ve sessiz yayıncılar bu listeye kopyalandı.";
        damaged = false;
        memory = imported.state;
        storageSet(KEY, JSON.stringify(memory));
        return;
      } catch {
        damaged = true;
        memory = defaultState();
        sessionNote = "Kayıt dosyası okunamadı. Üzerine yazılmadı.";
        return;
      }
    }
    const imported = importLegacy(defaultState());
    if (imported.copied > 0) sessionNote = "Eski okuyucudaki kayıt, konu ve sessiz yayıncılar bu listeye kopyalandı.";
    damaged = false;
    memory = imported.state;
    storageSet(KEY, JSON.stringify(memory));
  }

  boot();

  if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("storage", (event) => {
      if (event.key !== KEY || (event.storageArea && globalThis.localStorage && event.storageArea !== globalThis.localStorage)) return;
      if (event.newValue == null) {
        damaged = false;
        memory = defaultState();
        emit();
        return;
      }
      try {
        const parsed = JSON.parse(event.newValue);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("shape");
        damaged = false;
        memory = normalize(parsed);
      } catch {
        damaged = true;
        memory = defaultState();
      }
      emit();
    });
  }

  function unwrapStory(payload) {
    if (!payload || typeof payload !== "object") return null;
    if (payload.data && typeof payload.data === "object" && payload.editorial_title == null && payload.data.editorial_title != null) {
      return payload.data;
    }
    return payload;
  }

  function primaryLink(story) {
    const sources = Array.isArray(story && story.sources) ? story.sources : [];
    for (const source of sources) {
      const href = cleanHttps(source && source.canonical_url);
      if (href) return href;
    }
    return cleanHttps(story && (story.canonical_url || story.original_url));
  }

  function judgeStory(payload) {
    const story = unwrapStory(payload);
    if (!story) return { kind: "hidden" };
    const expiry = Date.parse(story.rights_expires_at || "");
    if (Number.isFinite(expiry) && expiry <= Date.now()) return { kind: "hidden" };
    const title = typeof story.editorial_title === "string" ? story.editorial_title.trim() : "";
    if (!title) return { kind: "hidden" };
    const summary = typeof story.editorial_summary === "string" ? story.editorial_summary.trim() : "";
    return {
      kind: "visible",
      title,
      summary,
      link: primaryLink(story),
      topic: typeof story.topic_name === "string" ? story.topic_name : "",
      authorship: typeof story.authorship_label === "string" ? story.authorship_label : "",
      sourceCount: Number.isFinite(story.source_count) ? story.source_count : 0,
      synthetic: story.synthetic === true,
      displayLabel: typeof story.display_label === "string" ? story.display_label : "",
    };
  }

  function cachedFromStory(story) {
    if (!story) return null;
    const title = cleanLabel(story.cacheTitle);
    const summary = cleanSummary(story.cacheSummary);
    const link = cleanHttps(story.cacheLink);
    if (!title && !summary) return null;
    return {
      kind: "cached",
      title: title || "Kayıtlı özet",
      summary,
      link,
      cachedAt: story.cachedAt || "",
    };
  }

  function classifyFailure(error) {
    const status = Number(error && (error.status || error.statusCode) || 0);
    const code = String((error && (error.code || (error.body && error.body.error && error.body.error.code))) || "");
    const phase = error && error.phase;
    if (phase === "offline") return { kind: "unavailable" };
    if (phase === "removed" || status === 404 || status === 410 || HIDE_CODES.has(code)) return { kind: "hidden" };
    const message = String((error && error.message) || "");
    if (/izin|kaldır|yayında değil|bulunamadı/i.test(message)) return { kind: "hidden" };
    return { kind: "unavailable" };
  }

  function presentStory(payload, failure) {
    if (failure) return classifyFailure(failure);
    return judgeStory(payload);
  }

  async function fetchStory(api, id) {
    const path = "/v1/stories/" + encodeURIComponent(id);
    const timed = (promise) => Promise.race([
      promise,
      new Promise((_, reject) => {
        setTimeout(() => {
          const error = new Error("Yükleme uzun sürdü.");
          error.phase = "offline";
          reject(error);
        }, LOAD_MS);
      }),
    ]);
    try {
      if (typeof api === "function") {
        try {
          return judgeStory(await timed(api(path)));
        } catch (error) {
          return classifyFailure(error);
        }
      }
      const response = await timed(fetch(path, { headers: { Accept: "application/json" } }));
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        const failure = new Error(body.error && body.error.message || "");
        failure.status = response.status;
        failure.code = body.error && body.error.code || "";
        return classifyFailure(failure);
      }
      return judgeStory(body);
    } catch (error) {
      if (error && error.phase === "offline") return { kind: "unavailable" };
      return { kind: "unavailable" };
    }
  }

  async function fetchTopics(api) {
    try {
      const payload = typeof api === "function"
        ? await api("/v1/topics")
        : await fetch("/v1/topics", { headers: { Accept: "application/json" } }).then((response) => (response.ok ? response.json() : []));
      const list = Array.isArray(payload) ? payload : (payload && Array.isArray(payload.data) ? payload.data : []);
      return list.map((item) => {
        if (!item || typeof item !== "object") return null;
        const slug = cleanId(item.slug) || cleanLabel(item.slug);
        const name = cleanLabel(item.name || item.slug);
        if (!slug || !name) return null;
        return { slug, name };
      }).filter(Boolean);
    } catch {
      return [];
    }
  }

  function visibleStories(state, view) {
    return state.savedStories.filter((story) => {
      if (view.filter === "archived") return story.archived;
      if (story.archived) return false;
      if (view.filter === "unread") return !story.read;
      if (view.filter === "read") return story.read;
      if (view.filter === "folder") return story.folderId === view.folderId;
      return true;
    });
  }

  function folderName(state, id) {
    const folder = state.folders.find((item) => item.id === id);
    return folder ? folder.name : LATER_NAME;
  }

  function storyCard(story, text, state) {
    const id = esc(story.id);
    let body;
    if (!text || text.kind === "loading") {
      body = `<p class="cizgi-status" role="status">Metin sunucudan yükleniyor.</p><p class="cizgi-id">Kayıt kimliği: ${id}</p>`;
    } else if (text.kind === "hidden") {
      body = `<p class="cizgi-status">${esc(HIDDEN_TEXT)}</p><p class="cizgi-id">Kayıt kimliği: ${id}</p>`;
    } else if (text.kind === "cached") {
      const summary = text.summary ? `<p class="cizgi-summary">${escText(text.summary)}</p>` : "";
      const link = text.link
        ? `<p><a class="cizgi-btn" href="${esc(text.link)}" target="_blank" rel="noopener noreferrer">Kaynağında oku</a></p>`
        : `<p class="cizgi-status">Güvenli kaynak bağlantısı yok.</p>`;
      body = `<span class="cizgi-badge cizgi-offline">${esc(CACHE_LABEL)}</span><h3><a href="#/haber/${id}" data-action="open-story" data-id="${id}">${esc(text.title)}</a></h3>${summary}<p class="cizgi-status">${esc(CACHE_NOTE)}</p>${link}`;
    } else if (text.kind !== "visible") {
      body = `<p class="cizgi-status">${esc(UNAVAILABLE_TEXT)}</p><p class="cizgi-id">Kayıt kimliği: ${id}</p>`;
    } else {
      const badge = `${text.synthetic ? '<span class="cizgi-badge">KURMACA</span>' : ""}${text.displayLabel ? `<span class="cizgi-badge">${esc(text.displayLabel)}</span>` : ""}`;
      const summary = text.summary ? `<p class="cizgi-summary">${escText(text.summary)}</p>` : "";
      const meta = [text.topic, text.authorship, text.sourceCount > 0 ? `${text.sourceCount} kaynak` : ""].filter(Boolean).map((item) => `<span>${esc(item)}</span>`).join("");
      body = `${badge}<h3><a href="#/haber/${id}" data-action="open-story" data-id="${id}">${esc(text.title)}</a></h3>${summary}${meta ? `<p class="cizgi-meta">${meta}</p>` : ""}`;
    }
    const folders = state.folders.map((folder) => `<option value="${esc(folder.id)}"${folder.id === story.folderId ? " selected" : ""}>${esc(folder.name)}</option>`).join("");
    const laterOn = story.folderId === LATER_ID && !story.archived;
    return `<article class="cizgi-card${text && text.kind === "hidden" ? " cizgi-hidden" : ""}" data-story="${id}">
      ${body}
      <p class="cizgi-meta"><span>${story.read ? "Okundu" : "Okunmadı"}</span><span>${esc(folderName(state, story.folderId))}</span>${story.archived ? "<span>Arşiv</span>" : ""}</p>
      <div class="cizgi-actions">
        <button type="button" data-action="toggle-read" data-id="${id}" aria-pressed="${story.read ? "true" : "false"}">${story.read ? "Okunmadı işaretle" : "Okundu işaretle"}</button>
        <button type="button" data-action="read-later" data-id="${id}" aria-pressed="${laterOn ? "true" : "false"}">Daha sonra oku</button>
        <button type="button" data-action="toggle-archive" data-id="${id}" aria-pressed="${story.archived ? "true" : "false"}">${story.archived ? "Arşivden çıkar" : "Arşivle"}</button>
        <button type="button" data-action="remove-story" data-id="${id}">Sil</button>
        <a class="cizgi-btn" href="#/haber/${id}" data-action="open-story" data-id="${id}">Haberi aç</a>
      </div>
      <label class="cizgi-move">Klasöre taşı
        <select data-action="move-folder" data-id="${id}" aria-label="Klasöre taşı">${folders}</select>
      </label>
    </article>`;
  }

  function filterButton(view, id, label, folderId) {
    const pressed = view.filter === id && (id !== "folder" || view.folderId === folderId);
    const folderAttr = folderId ? ` data-folder="${esc(folderId)}"` : "";
    return `<button type="button" class="cizgi-chip" data-action="filter" data-filter="${esc(id)}"${folderAttr} aria-pressed="${pressed ? "true" : "false"}">${esc(label)}</button>`;
  }

  function followList(kind, labels) {
    if (!labels.length) return `<p class="cizgi-dek">Liste boş.</p>`;
    return `<ul class="cizgi-follow">${labels.map((label) => `<li><span>${esc(label)}</span><button type="button" data-action="unfollow" data-kind="${esc(kind)}" data-value="${esc(label)}">Takibi bırak</button></li>`).join("")}</ul>`;
  }

  function mount(container, options) {
    if (!container || typeof container.appendChild !== "function") return { unmount() {} };
    if (container.__cizgiUnmount) container.__cizgiUnmount();
    const api = options && options.api;
    const onOpenStory = options && typeof options.onOpenStory === "function" ? options.onOpenStory : null;
    const root = document.createElement("div");
    root.className = "cizgi-library";
    root.setAttribute("role", "region");
    root.setAttribute("aria-label", "Kayıtlılar ve takipler");
    container.appendChild(root);
    const view = { filter: "open", folderId: LATER_ID };
    const textCache = new Map();
    let topics = [];
    let disposed = false;
    let note = sessionNote;

    function cssEscape(value) {
      if (typeof CSS !== "undefined" && typeof CSS.escape === "function") return CSS.escape(value);
      return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
    }

    function ensureText(id) {
      const cached = textCache.get(id);
      if (cached) return cached;
      const storyRow = memory.savedStories.find((item) => item.id === id);
      const pending = { kind: "loading" };
      textCache.set(id, pending);
      fetchStory(api, id).then((result) => {
        if (disposed) return;
        let next = result;
        if (result.kind === "visible") {
          cacheSnippet(id, { title: result.title, summary: result.summary, link: result.link });
        } else if (result.kind === "unavailable") {
          const offline = cachedFromStory(storyRow || memory.savedStories.find((item) => item.id === id));
          if (offline) next = offline;
        }
        textCache.set(id, next);
        const node = root.querySelector(`[data-story="${cssEscape(id)}"]`);
        const story = memory.savedStories.find((item) => item.id === id);
        if (!node || !story) return;
        const template = document.createElement("template");
        template.innerHTML = storyCard(story, next, get());
        const el = template.content.firstElementChild;
        if (el) node.replaceWith(el);
      });
      return pending;
    }

    function render() {
      if (disposed) return;
      const state = get();
      if (view.filter === "folder" && !state.folders.some((folder) => folder.id === view.folderId)) {
        view.filter = "open";
        view.folderId = LATER_ID;
      }
      const stories = visibleStories(state, view);
      const activeFolder = state.folders.find((folder) => folder.id === view.folderId);
      const filters = [
        filterButton(view, "open", "Açık kayıtlar"),
        filterButton(view, "unread", "Okunmadı"),
        filterButton(view, "read", "Okundu"),
        filterButton(view, "archived", "Arşiv"),
        ...state.folders.map((folder) => filterButton(view, "folder", folder.name, folder.id)),
      ].join("");
      const cards = stories.map((story) => storyCard(story, ensureText(story.id), state)).join("");
      let listHtml;
      if (!state.savedStories.length) {
        listHtml = `<div class="cizgi-empty"><h3>Henüz kayıtlı haber yok</h3><p>Kaydettiğin haber bu cihazda durur.</p><p><a class="cizgi-btn" href="#/">Akışa dön</a></p></div>`;
      } else if (!stories.length) {
        listHtml = `<div class="cizgi-empty"><h3>Bu görünümde kayıt yok</h3><p><a class="cizgi-btn" href="#/">Akışa dön</a></p></div>`;
      } else {
        listHtml = `<div class="cizgi-list">${cards}</div>`;
      }
      const folderTools = view.filter === "folder" && activeFolder ? `<form class="cizgi-form" data-action="rename-folder">
          <label>Klasör adı
            <input name="name" maxlength="160" autocomplete="off" value="${esc(activeFolder.name)}" aria-label="Klasör adı">
          </label>
          <button type="submit">Klasör adını kaydet</button>
          ${activeFolder.id === LATER_ID ? "" : `<button type="button" data-action="remove-folder" data-folder="${esc(activeFolder.id)}">Klasörü sil</button>`}
        </form>` : "";
      const catalog = new Set(topics.map((topic) => fold(topic.slug)));
      const extraTopics = state.followedTopics.filter((slug) => !catalog.has(fold(slug)));
      const topicChips = topics.length ? `<div class="cizgi-filters">${topics.map((topic) => {
        const on = hasLabel(state.followedTopics, topic.slug);
        return `<button type="button" class="cizgi-chip" data-action="toggle-topic" data-value="${esc(topic.slug)}" aria-pressed="${on ? "true" : "false"}">${esc(topic.name)}</button>`;
      }).join("")}</div>` : "";
      const undo = state.undo ? `<div class="cizgi-undo" role="status" aria-live="polite"><p>${esc(state.undo.label)}</p><button type="button" data-action="undo">Geri al</button></div>` : "";
      const notice = note ? `<div class="cizgi-note" role="status"><p>${esc(note)}</p>${damaged ? "" : `<button type="button" data-action="dismiss-note">Tamam</button>`}</div>` : "";
      const muted = state.muted.length ? `<section class="cizgi-block" aria-labelledby="cizgi-muted-title"><h2 id="cizgi-muted-title">Sessize alınan yayıncılar</h2><p class="cizgi-dek">Eski okuyucudan kopyalandı.</p><ul class="cizgi-follow">${state.muted.map((label) => `<li><span>${esc(label)}</span><button type="button" data-action="remove-muted" data-value="${esc(label)}">Listeden çıkar</button></li>`).join("")}</ul></section>` : "";
      root.innerHTML = `<header class="cizgi-head"><p class="cizgi-kicker">Bu cihaz</p><h1>Kayıtlılar</h1><p class="cizgi-dek">Kayıtlar ve takipler bu tarayıcıda durur.</p></header>
        ${notice}${undo}
        <section class="cizgi-block" aria-labelledby="cizgi-saved-title">
          <h2 id="cizgi-saved-title">Kayıtlı haberler</h2>
          <p class="cizgi-dek">${state.savedStories.length} kayıt</p>
          <div class="cizgi-filters">${filters}</div>
          <form class="cizgi-form" data-action="add-folder"><label>Yeni klasör<input name="name" maxlength="160" autocomplete="off" aria-label="Yeni klasör adı"></label><button type="submit">Klasör ekle</button></form>
          ${folderTools}
          ${listHtml}
        </section>
        <section class="cizgi-block" aria-labelledby="cizgi-topics-title"><h2 id="cizgi-topics-title">Konu takibi</h2>${topicChips}${extraTopics.length ? followList("topic", extraTopics) : ""}${topics.length ? "" : `<p class="cizgi-dek">Konu listesi alınamadı. Slug yazarak takip edebilirsin.</p>`}<form class="cizgi-form" data-action="add-follow" data-kind="topic"><label>Konu slug<input name="value" maxlength="160" autocomplete="off" aria-label="Konu slug"></label><button type="submit">Konuyu takip et</button></form></section>
        <section class="cizgi-block" aria-labelledby="cizgi-publishers-title"><h2 id="cizgi-publishers-title">Yayıncı takibi</h2><p class="cizgi-dek">Kaynak kimliği veya yayıncı etiketi.</p>${followList("publisher", state.followedPublishers)}<form class="cizgi-form" data-action="add-follow" data-kind="publisher"><label>Yayıncı<input name="value" maxlength="160" autocomplete="off" aria-label="Kaynak kimliği veya yayıncı etiketi"></label><button type="submit">Yayıncıyı takip et</button></form></section>
        <section class="cizgi-block" aria-labelledby="cizgi-teams-title"><h2 id="cizgi-teams-title">Takım takibi</h2>${followList("team", state.followedTeams)}<form class="cizgi-form" data-action="add-follow" data-kind="team"><label>Takım<input name="value" maxlength="160" autocomplete="off" aria-label="Takım adı"></label><button type="submit">Takımı takip et</button></form></section>
        <section class="cizgi-block" aria-labelledby="cizgi-competitions-title"><h2 id="cizgi-competitions-title">Lig takibi</h2>${followList("competition", state.followedCompetitions)}<form class="cizgi-form" data-action="add-follow" data-kind="competition"><label>Lig<input name="value" maxlength="160" autocomplete="off" aria-label="Lig veya turnuva"></label><button type="submit">Ligi takip et</button></form></section>
        ${muted}`;
    }

    function onClick(event) {
      const target = event.target.closest("[data-action]");
      if (!target || !root.contains(target)) return;
      const action = target.dataset.action;
      const id = target.dataset.id || "";
      if (action === "open-story") {
        if (onOpenStory) {
          event.preventDefault();
          onOpenStory(id);
        }
        return;
      }
      if (action === "filter") {
        view.filter = target.dataset.filter || "open";
        if (view.filter === "folder") view.folderId = target.dataset.folder || LATER_ID;
        render();
        return;
      }
      if (action === "toggle-read") {
        const story = memory.savedStories.find((item) => item.id === id);
        if (story) setRead(id, !story.read);
        return;
      }
      if (action === "read-later") {
        readLater(id);
        return;
      }
      if (action === "toggle-archive") {
        const story = memory.savedStories.find((item) => item.id === id);
        if (story) setArchived(id, !story.archived);
        return;
      }
      if (action === "remove-story") {
        removeStory(id);
        return;
      }
      if (action === "remove-folder") {
        removeFolder(target.dataset.folder || "");
        view.filter = "open";
        return;
      }
      if (action === "undo") {
        undo();
        return;
      }
      if (action === "dismiss-note") {
        note = "";
        sessionNote = "";
        render();
        return;
      }
      if (action === "toggle-topic") {
        const slug = target.dataset.value || "";
        if (hasLabel(memory.followedTopics, slug)) unfollow("topic", slug);
        else follow("topic", slug);
        return;
      }
      if (action === "unfollow") {
        unfollow(target.dataset.kind || "", target.dataset.value || "");
        return;
      }
      if (action === "remove-muted") {
        removeMuted(target.dataset.value || "");
      }
    }

    function onSubmit(event) {
      const form = event.target;
      if (!(form instanceof HTMLFormElement) || !root.contains(form)) return;
      event.preventDefault();
      const action = form.dataset.action;
      const data = new FormData(form);
      if (action === "add-folder") {
        addFolder(String(data.get("name") || ""));
        form.reset();
        return;
      }
      if (action === "rename-folder") {
        renameFolder(view.folderId, String(data.get("name") || ""));
        return;
      }
      if (action === "add-follow") {
        follow(form.dataset.kind || "", String(data.get("value") || ""));
        form.reset();
      }
    }

    function onChange(event) {
      const select = event.target;
      if (!select || select.dataset.action !== "move-folder") return;
      moveStory(select.dataset.id || "", select.value);
    }

    root.addEventListener("click", onClick);
    root.addEventListener("submit", onSubmit);
    root.addEventListener("change", onChange);
    const unsubscribe = subscribe(() => render());
    fetchTopics(api).then((list) => {
      if (disposed) return;
      topics = list;
      render();
    });
    render();

    function unmount() {
      if (disposed) return;
      disposed = true;
      unsubscribe();
      root.removeEventListener("click", onClick);
      root.removeEventListener("submit", onSubmit);
      root.removeEventListener("change", onChange);
      root.remove();
      if (container.__cizgiUnmount === unmount) delete container.__cizgiUnmount;
    }
    container.__cizgiUnmount = unmount;
    return { unmount };
  }

  const api = {
    mount,
    presentStory,
    store: {
      get,
      set,
      subscribe,
      saveStory,
      cacheSnippet,
      setRead,
      setArchived,
      moveStory,
      readLater,
      removeStory,
      addFolder,
      renameFolder,
      removeFolder,
      follow,
      unfollow,
      removeMuted,
      undo,
    },
  };

  const rootObject = typeof globalThis !== "undefined" ? globalThis : window;
  rootObject.CizgiLibrary = api;
  if (typeof window !== "undefined") window.CizgiLibrary = api;
})();
