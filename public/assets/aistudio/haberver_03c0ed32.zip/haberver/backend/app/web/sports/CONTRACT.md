# Çizgi spor merkezi sözleşmesi

İstemci futbol verisini doğrudan football-data.org adresinden almaz. Yalnızca bu uygulamanın `/v1/sports` uçlarını çağırır. Anahtar, belirteç veya `Authorization` başlığı istemcide yoktur; sunucu sağlayıcıya kendisi gider.

Web dosyaları statik kökten yayınlanır:

- `/static/sports/sports.js`
- `/static/sports/sports.css`

**`app.js` bu teslimde değiştirilmez.** `sports.js` self-boot ile `#/spor` hash’inde veya `#sports-root` / `[data-cizgi-sports]` / `#sports-data` üzerinde kendini bağlar.

## Self-boot (önerilen)

`index.html` (veya kabuk) yalnızca betiği yükler; rota bağlama `app.js` içinde yapılmaz:

```html
<script src="/static/sports/sports.js"></script>
```

Betik yüklendiğinde:

1. `hash === #/spor` (veya `#/spor?...`) ise host arar: `#sports-root`, `[data-cizgi-sports]`, `#sports-data`.
2. Host yoksa `#icerik` / `#app` içine `#sports-root` ekler.
3. `CizgiSports.mount(host, { api: CizgiSports.createApi(), ... })` çağırır.
4. SportScore iframe’i yalnızca bu yüzey açıkken lazy yüklenir.

## Manuel entegrasyon snippet (app.js yazılmayacaksa referans)

```js
// Yalnızca #/spor için — home ajanı app.js'e yazıyorsa bunu kullanma; self-boot yeter.
function ensureSportsCss() {
  if (document.querySelector("link[data-cizgi-sports-css]")) return;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "/static/sports/sports.css";
  link.dataset.cizgiSportsCss = "1";
  document.head.appendChild(link);
}

function showCizgiSports(container) {
  ensureSportsCss();
  return window.CizgiSports.mount(container, {
    api: window.CizgiSports.createApi(),
    followedTeams: [],
    onFollowTeam(teamId, follow) { /* üst katman */ },
    onOpenMatch(match) { /* üst katman */ },
  });
}
```

## Web mount API

```js
const handle = window.CizgiSports.mount(container, {
  api,                 // (path, { signal }) => Promise<data>
  followedTeams,       // string[] takım kimlikleri
  onFollowTeam,        // (teamId, follow) => void
  onOpenMatch,         // (match) => void
});
handle.setFollowedTeams(ids);
handle.destroy();
```

`api` gövdedeki `data` nesnesini döndürebilir veya `{ request_id, data }` zarfını döndürebilir. Hata fırlatırsa `error.status` (sayı) ve `error.code` (dize) dolu olmalıdır. `CizgiSports.createApi()` bunu `fetch` ile kurar ve istekte yalnızca `Accept: application/json` ile `X-Request-ID` gönderir.

Takip kalıcılığı bu modülde yoktur. Modül `onFollowTeam` çağırır; üst katman cihazdaki listeyi günceller ve gerekirse `setFollowedTeams` ile geri yazar.

**Kullanıcıya açık debug / mock düğmesi yok** (Canlı veri, Boş lig, Kota, Servis yok testleri UI’da yoktur).

## SportScore embed (ZIP v1.0.4 + resmi terms)

Kaynak: `sportscore-embed-v1.0.4` WordPress eklentisi + [sportscore.com/embed](https://sportscore.com/embed/) + [developers/terms](https://sportscore.com/developers/terms/). PHP FastAPI’de çalıştırılmaz; yalnızca URL kalıbı ve atıf uyarlanır.

### URL kalıpları (anahtar yok)

Entity widget (`tracker` | `match` | `fixtures`):

```
https://sportscore.com/embed/{widget}/{sport}/{team|competition}/{slug}/
```

Tek-slug widget (`standings` | `topscorers` | `bracket` | `player` | `lineups`):

```
https://sportscore.com/embed/{widget}/{sport}/{slug}/
```

Doğrulanmış competition slug’lar (ZIP showcase + canlı embed title eşleşmesi; uydurma yok):

| Slug | Doğrulama |
| --- | --- |
| `turkish-super-league` | canlı fixtures/standings title |
| `english-premier-league` | resmi embed showcase + readme |
| `premier-league` | ZIP block hint |
| `italian-serie-a` | canlı title (ham `serie-a` yanlış lig) |
| `bundesliga` | canlı title |
| `spanish-la-liga` | canlı title (`la-liga` 404) |
| `french-ligue-1` | canlı title (`ligue-1` 404) |
| `brazilian-serie-a` | canlı title (`brasileirao` 404 → Widget unavailable) |
| `uefa-champions-league` | canlı title |
| `uefa-europa-league` | canlı title |
| `copa-libertadores` | canlı title |
| `fifa-world-cup` | canlı title |

Örnekler:

- `https://sportscore.com/embed/fixtures/football/competition/turkish-super-league/`
- `https://sportscore.com/embed/fixtures/football/competition/english-premier-league/`
- `https://sportscore.com/embed/standings/football/english-premier-league/`

İsteğe bağlı `?src=` yalnızca genel site hostname (adoption sinyali). `localhost`, `127.0.0.1`, özel IP ve PII koyulmaz; ZIP’te de opsiyoneldir. Allowlist dışı slug’da iframe basılmaz; sağlayıcı linki + Yeniden dene gösterilir.

Shortcode karşılığı (referans, çalıştırılmaz): `[sportscore sport="football" type="competition" slug="turkish-super-league" widget="fixtures"]`

### Atıf (zorunlu, free tier)

Her SportScore yüzeyinde görünür, crawlable, `rel="dofollow"` link:

- Metin: `Powered by SportScore` veya `Data by SportScore`
- `href="https://sportscore.com/"`
- `title` korunabilir: `Live sports scores by SportScore`

### Yenileme

Resmi embed ~5 dk otomatik yeniler. İstemci iframe `src`’ini 5 dakikadan sık değiştirmez. football-data canlı sekmesi 60 sn yoklar (ayrı sağlayıcı).

### Layout

Masaüstü: `max-width` ≥ 1200, native + SportScore yan yana (veya yüzey sekmeleri). Tek dar sütun yasak. Mobil ~412 okunaklı; iframe yüksekliği `clamp` / `vh` ile ayarlı. Her native kartta provider etiketi.

## Türkiye lig sınırı

`backend/app/sports/coverage.md`: bu football-data anahtarında Türkiye (Süper Lig / 1. Lig) yok. Native sütun uydurma skor üretmez; boş/limited dürüst durum gösterir. SportScore sütunu `turkish-super-league` slug’ı ile Türkiye fikstürüne izinli gömü sunar.

## Android

```kotlin
@Composable
fun SportsCenterScreen(
  apiBase: String,
  followedTeamIds: Set<String>,
  onFollowTeam: (String, Boolean) -> Unit,
)
```

`apiBase` örneği `http://10.0.2.2:8000/v1/`. Sonda `/v1` yoksa istemci ekler. Adresteki kullanıcı bilgisi, sorgu ve parça atılır; istemci anahtar eklemez.

## Uçlar

Başarılı gövde:

```json
{ "request_id": "abc", "data": { } }
```

Ortak alanlar, her başarılı `data` içinde:

| Alan | Tip | Anlam |
| --- | --- | --- |
| `provider` | string | `football-data.org` |
| `attribution` | string veya null | Kısa kaynak cümlesi |
| `timezone` | string | `Europe/Istanbul` |
| `refreshed_at` | string veya null | ISO-8601 |
| `from_cache` | boolean | Yanıt önbellekten |
| `stale` | boolean | Sağlayıcı yenilenemedi, son başarılı veri |
| `limited` | boolean | Kota veya pencere sınırladı |
| `limitation` | string veya null | İnsan dilinde sınır notu |

### `GET /v1/sports/competitions`

Seçici yalnızca bu dizideki ligleri gösterir. Dizi boşsa veya uç hata verirse istemci Süper Lig eklemez (SportScore ayrı sütundadır).

### `GET /v1/sports/matches`

Sorgu: `date=YYYY-MM-DD`, `competition=<id>`, `bucket=live|today|scheduled|finished`.

Başlamamış maçta `score` ve `minute` `null` olur. Skor `0` gerçek sıfırdır; istemci uydurmaz.

### `GET /v1/sports/standings?competition=`

### `GET /v1/sports/teams?competition=`

## Hatalar

| HTTP | Kod örneği | Ekran metni |
| --- | --- | --- |
| 429 | `rate_limited` | Çok fazla istek atıldı… |
| 403 veya 401 | `forbidden` | Skor verisine erişim kapalı… |
| 404 | `not_found` | Spor servisi henüz hazır değil… |
| 503, 502, 504 | `source_unavailable` | Skor servisi şu an yanıt vermiyor… |
| bağlantı yok | `offline` | Bağlantı kurulamadı… |

`Retry-After` 1–900 saniye ise 429 metni yaklaşık dakikayı söyler. 200 içinde `limited: true` ve `limitation` doluysa bu cümle gösterilir; skor tamamlanmaz.

## İstemci davranışı

Sekmeler: Canlı, Bugün, Fikstür, Sonuçlar, Puan Durumu, Takımlar.

Canlı boşsa sıra: bugünün fikstürü → yaklaşan → son sonuçlar. Skor uydurulmaz.

Kaynak satırı provider + yenilenme + önbellek durumu içerir.

Arma yalnızca `https`. Canlı sekmede 60 sn yoklama; 429/403/404 sonrası otomatik yoklama durur.
