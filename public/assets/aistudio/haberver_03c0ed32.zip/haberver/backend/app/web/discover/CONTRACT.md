# Çizgi arama

Bağımsız arama yüzeyi. Yalnızca mevcut okuma uçlarını kullanır: `GET /v1/search`, `GET /v1/topics`, `GET /v1/feed`. Yeni alan veya uç yok.

## Mount

```js
window.CizgiSearch.mount(container, { api, recent, onRecentChange, onOpenStory, onSave, savedIds })
```

`container` bir DOM öğesidir. Stil `search.css` içindedir; betik yüklenirken kardeş `search.css` bağlanır. Klasik `script` etiketi kullanın (`type="module"` değil).

```html
<script src="/static/discover/search.js"></script>
```

```js
async function api(path) {
  const response = await fetch(path, { headers: { Accept: "application/json" } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body.error?.message || "Arama tamamlanamadı. Yeniden deneyin.");
    error.status = response.status;
    error.code = body.error?.code;
    error.retryable = body.error?.retryable;
    throw error;
  }
  return body.data;
}

const view = window.CizgiSearch.mount(document.querySelector("#arama"), {
  api,
  recent: [],
  onRecentChange(next) {},
  onOpenStory(id) {},
  onSave(id) {},
  savedIds: [],
});
```

`api(path)` `data` gövdesini döndürür. Zarf (`{ data }`) gelirse bir kez açılır.

| Uç | Sorgu | `data` |
| --- | --- | --- |
| `GET /v1/search` | `q` (2–80), isteğe bağlı `topic`, `cursor`, `limit` (1–30) | `{ items: StoryCard[], next_cursor }` |
| `GET /v1/topics` | — | `[{ slug, name }]` |
| `GET /v1/feed` | isteğe bağlı `topic`, `cursor`, `limit` (1–30) | `{ items: StoryCard[], next_cursor }` |

Hata gövdesi: `{ error: { code, message, retryable } }`. `429` / `rate_limited` kota durumudur. `error.status`, `error.code`, `error.retryable`, `error.phase` (`offline`) isteğe bağlıdır; yoksa `message` gösterilir.

### Seçenekler

- `recent`: `string[]` — bu cihazdaki son aramalar.
- `onRecentChange(next: string[])` — en fazla 8 kayıt. Temizle `[]` gönderir.
- `onOpenStory(id: string)` — kart açılışı.
- `onSave(id: string)` — kaydet / kaydı kaldır. Kalıcılık çağırana aittir.
- `savedIds`: `string[]` veya `Set`.

Dönüş: `{ update(partial), destroy() }`. `update` yalnızca `recent` ve `savedIds` yeniler. Aynı kabı tekrar `mount` etmek önceki yüzeyi kapatır ve sorguyu sıfırlar.

## Kartta kullanılan alanlar

`id`, `editorial_title`, `editorial_summary`, `authorship_label`, `published_at`, `topic_slug`, `topic_name`, `image`, `synthetic`, `display_label`.

Görsel yalnızca `https` ise basılır; aksi halde konu baş harfiyle yedek alan gösterilir. Spot, özetteki ilk iki cümledir.

## İstemci davranışı

- Sekmeler: Haberler, Konular, Kaynaklar.
- Tarih (bugün / 7 gün / 30 gün) ve sıra (en yeni) `published_at` üzerinde, istemcide.
- Kategori (`topic_slug`) ve yayıncı (`authorship_label`) yalnız dönen kümeden çıkar.
- Konu seçilince `GET /v1/feed?topic={slug}&limit=30`. Sorgu varsa `GET /v1/search?q&topic&limit=30`.
- Sunucu araması başlık, özet, konu adı ve kaynak adını tarar. `authorship_label` eşlemesi, aynı anda dönen akış sayfasındaki kayıtlara uygulanır. Bu iki yanıtın dışında sonuç üretilmez.
- `synthetic`, «Sentetik» başlık/etiket ve «gerçek bir haber değildir» özeti listelenmez.
- Boş sonuç, kota (`429`), bağlantı hatası, 2,5 sn üzeri yavaş istek ve yeniden dene durumları gösterilir.

## Android

```kotlin
@Composable
fun DiscoverSearchScreen(onOpenStory: (String) -> Unit)
```

Paket: `dev.haberver.kesif.ui.discover`. `HaberApp.container.repository` üzerinden `search`, `topics`, `refresh` (`GET /v1/feed`) ve `setSaved` kullanılır. Kayıt veritabanında yoksa `refreshDetail` (`GET /v1/stories/{id}`) bir kez çağrılır. `Api.kt` ve repository dosyası değiştirilmez.

`StoryCard` görsel ve `next_cursor` taşımaz; kart yedek harf gösterir, ikinci sayfa istenmez. `authorship_label` tam olarak `Editoryal özet` ise kaynak satırında «Kaynak» yazılır.
