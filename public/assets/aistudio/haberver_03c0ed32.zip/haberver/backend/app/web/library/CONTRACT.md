# Kayıtlılar ve takip

Hesap yok. Giriş yok. Bulut senkronu yok. Kayıt bu cihazda kalır.

Haber metni store'a yazılmaz. Başlık ve özet yalnız `GET /v1/stories/{id}` yanıtından gösterilir. 404, 410, `content_unavailable`, `not_found` veya `rights_blocked` olursa metin gizlenir; kayıt durur. Özet uydurulmaz. `rights_expires_at` geçmişse metin yine gizlenir.

## Dosyalar

- `backend/app/web/library/library.js`
- `backend/app/web/library/library.css`
- `android/.../core/data/LibraryStore.kt`
- `android/.../ui/library/LibraryScreen.kt`

Web betiği `window.CizgiLibrary` yazar. Statik kök `backend/app/web` olduğu için adres `/static/library/library.js` ve `/static/library/library.css` olur. `index.html` ve `app.js` bu dosyayı henüz yüklemez.

## Şema

Web anahtarı: `cizgi.library.v1`  
Android DataStore dosyası: `cizgi_library`  
Android tercih anahtarı: `snapshot` (tek JSON belge; silme ve liste aynı yazmada güncellenir)

`haberkesif` DataStore dosyasına ve `haberkesif.db` Room veritabanına yazılmaz.

```json
{
  "version": 1,
  "legacyImported": false,
  "savedStories": [
    { "id": "story-id", "savedAt": "2026-10-23T00:00:00.000Z", "folderId": "later", "read": false, "archived": false }
  ],
  "folders": [
    { "id": "later", "name": "Daha sonra oku" }
  ],
  "followedTopics": [],
  "followedPublishers": [],
  "followedTeams": [],
  "followedCompetitions": [],
  "muted": [],
  "undo": null
}
```

- `savedStories`: en fazla 400. `id` en fazla 80 karakter, boşluksuz. `savedAt` ISO-8601. `folderId` yoksa `later`.
- `folders`: `later` her zaman durur, silinemez, adı değişebilir. En fazla 24 klasör. Yeni kimlik `fld-` ile başlar.
- `followedTopics`: konu slug.
- `followedPublishers`: kaynak kimliği veya yayıncı etiketi (`authorship_label`). Ayrı tür alanı yok.
- `followedTeams`, `followedCompetitions`: serbest etiket.
- Etiket en fazla 160 karakter. Aynı etiket büyük-küçük harf duyarsız tektir (`tr-TR`).
- `muted`: eski okuyucudan kopyalanan sessiz kaynak kimlikleri. Takip değildir.
- `undo`: son silmenin tek adımı. Yeni silme eskisinin üzerine yazar. `null` ise geri alınacak bir şey yoktur.
- `legacyImported`: bir kez kopyalandıysa `true`.

`undo` alanları: `label`, `savedStories`, `folders`, `folderMoves` (`{id, folderId}`), `topics`, `publishers`, `teams`, `competitions`, `muted`.

Hesap, e-posta, belirteç ve senkron alanları `set` ile gelse de atılır.

## Web

```js
window.CizgiLibrary.mount(container, { api, onOpenStory });
window.CizgiLibrary.store.get();
window.CizgiLibrary.store.set(patchOrFunction);
window.CizgiLibrary.store.subscribe(listener);
```

`get()` donmuş bir kopyadır. `set` fonksiyon alırsa mevcut kopyayı görür ve yeni durum döndürmelidir; nesne alırsa üst alanları birleştirir. `subscribe` hemen çağırmaz, aboneliği kaldıran fonksiyon döner. JSON bozuksa bellek boş kalır ve dosyanın üzerine yazılmaz.

`mount` `{ unmount }` döner. `api` verilirse `api("/v1/stories/{id}")` ve `api("/v1/topics")` çağrılır; dönüş `data` gövdesi olmalıdır (`app.js` ile aynı). `api` yoksa aynı yollara `fetch` yapılır. `onOpenStory(id)` varsa haber bağlantısı kabuğa bırakılmaz, geri çağrı çalışır. Yoksa bağlantı `#/haber/{id}` kalır. Boş listede akış bağlantısı `#/` dir.

`CizgiLibrary.presentStory(payload, failure)` metin kararını verir. `failure` yoksa ve başlık duruyorsa `{kind:"visible", title, summary, ...}` döner. 404, 410, izin kodu, geçmiş `rights_expires_at` veya boş başlık `{kind:"hidden"}` döner; özet alanı yoktur. Ağ hatası `{kind:"unavailable"}` döner.

Ortak store yardımcıları (ana sayfa ve spor aynı nesneyi kullanır):

- `saveStory(id, folderId?)`
- `setRead(id, read)`
- `setArchived(id, archived)`
- `moveStory(id, folderId)`
- `readLater(id)` — klasör `later`, arşiv kalkar
- `removeStory(id)`
- `addFolder(name)` / `renameFolder(id, name)` / `removeFolder(id)`
- `follow(kind, value)` / `unfollow(kind, value)` — `kind`: `topic`, `publisher`, `team`, `competition`
- `removeMuted(value)`
- `undo()`

Takım örneği: `CizgiLibrary.store.follow("team", "Takım")`, okuma `CizgiLibrary.store.get().followedTeams`.

## Android

`LibraryStore(context).flow: Flow<LibrarySnapshot>`  
`LibraryStore(context).state: Flow<LibraryView>` — `damaged == true` ise belge okunamadı, `flow` boş görünür ve yazma yapılmaz. Bozuk dosyanın üzerine yazılmaz.

Askıya alınan yazmalar: `saveStory`, `setRead`, `setArchived`, `moveStory`, `readLater`, `removeStory`, `addFolder`, `renameFolder`, `removeFolder`, `follow`, `unfollow`, `removeMuted`, `undo`, `importLegacyOnce`, `repair`.

`FollowKind`: `Topic`, `Publisher`, `Team`, `Competition`.

```kotlin
@Composable fun LibraryScreen(onOpenStory: (String) -> Unit)
```

Ekran `HaberApp.container.api` ile `/v1/stories/{id}` okur. Metin Room önbelleğinden basılmaz. Koyu lacivert (`#07111C`) ve en az 44 dp hedef kullanılır.

## Eski kayıttan bir kez kopya

Web: `haberkesif.reader.v1` varsa `saved`, `followed`, `muted` okunur. `saved` dizi öğesi kimlikse `savedStories` kaydı olur (`folderId` `later`, okunmadı, arşiv değil, `savedAt` kopya anı). `followed` konu listesine, `muted` sessiz listeye eklenir. `followedTeams` bu anahtardan alınmaz. Anahtar silinmez. `legacyImported` true olduktan sonra tekrar kopyalanmaz. Anahtar hiç yoksa bayrak false kalır; sonraki açılışta tekrar bakılır.

Android: `LibraryScreen` açılınca mevcut `Preferences` akışından `followedTopics`, `followedTeams`, `mutedSources` ve Room `observeSaved()` kimlikleri bir kez okunur. O store'lara yazılmaz. İkinci bir `haberkesif` DataStore açılmaz. Uygulama `HaberApp` değilse veya Room okunamazsa bayrak yazılmaz.

## Eksikler

- Kabuk `app.js` hâlâ `haberkesif.reader.v1` içindeki `saved` dizisini kullanır. Bu modül mount edilmeden kayıtlılar sayfası eski listeyi gösterir. İki liste kendiliğinden canlı kalmaz.
- `HaberRoot` hâlâ Room `saved` bayrağıyla `SavedScreen` açar. `LibraryScreen` gezinmeye bağlı değildir.
- `LibraryStore`, `AppContainer` içine konmadı. Ekran kendi `LibraryStore(applicationContext)` örneğini tutar. DataStore delegate dosyada tektir.
- Android boş durumunda `#/` linki yoktur. Kabuğa dokunulmadığı için akış sekmesine giden bir geri çağrı da yoktur.
- Geri alma tek adımdır. Üst üste iki silmede yalnız sonuncusu döner.
- Çevrimdışı veya 5xx yanıtta kayıt durur, metin gösterilmez.
- Eski kayıttaki `savedAt` yoktur; kopya anının zamanı yazılır.
- Sessize alma bu ekrandan eklenmez. Yalnız kopyalanmış kayıt listeden çıkarılabilir.
