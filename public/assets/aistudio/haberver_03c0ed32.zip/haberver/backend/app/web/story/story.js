(function (factory) {
  "use strict";
  const api = factory();
  if (typeof window !== "undefined") window.CizgiStory = { mount: api.mount };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(function () {
  "use strict";

  const SINGLE = "Tek yayın. Başka kaynakla karşılaştırılmadı.";
  const NO_NOTE = "Kayıtlı bir belirsizlik notu yok.";
  const NO_CORRECTION = "Kayıtlı düzeltme yok.";
  const COUNT_NOT_SCORE = "Kaynak sayısı doğruluk puanı değildir.";
  const LINK_UNSAFE = "Kaynak bağlantısı bu kayıtta güvenli açılmıyor.";
  const NO_SOURCES = "Bu kayıtta kaynak satırı yok.";
  const SCROLL_KEY = "cizgi.story.scroll.v1";
  const SIMPLE_KEY = "cizgi.story.simple.v1";
  const FONT_KEY = "cizgi.story.font.v1";
  const LOAD_MS = 12000;
  const cleanups = new WeakMap();

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[ch]));
  }

  function fold(value) {
    return String(value || "").trim().toLocaleLowerCase("tr-TR").replace(/ı/g, "i");
  }

  function normalizeFont(value) {
    const font = String(value || "md").toLowerCase();
    return font === "lg" || font === "xl" ? font : "md";
  }

  function storageGet(key) {
    try {
      return globalThis.localStorage ? globalThis.localStorage.getItem(key) : null;
    } catch (_) {
      return null;
    }
  }

  function storageSet(key, value) {
    try {
      if (globalThis.localStorage) globalThis.localStorage.setItem(key, value);
    } catch (_) { /* tercih kaybolabilir */ }
  }

  function readScrollMap() {
    try {
      const parsed = JSON.parse(storageGet(SCROLL_KEY) || "{}");
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
    } catch (_) {
      return {};
    }
  }

  function scrollFor(id) {
    const key = String(id || "").trim();
    if (!key) return 0;
    const value = Number(readScrollMap()[key]);
    return Number.isFinite(value) && value > 0 ? value : 0;
  }

  function saveScroll(id, y) {
    const key = String(id || "").trim();
    if (!key) return;
    const map = readScrollMap();
    const next = Math.max(0, Math.round(Number(y) || 0));
    if (next < 24) delete map[key];
    else map[key] = next;
    const keys = Object.keys(map);
    if (keys.length > 80) {
      keys.slice(0, keys.length - 80).forEach((old) => { delete map[old]; });
    }
    storageSet(SCROLL_KEY, JSON.stringify(map));
  }

  function readSimple() {
    return storageGet(SIMPLE_KEY) === "1";
  }

  function writeSimple(on) {
    storageSet(SIMPLE_KEY, on ? "1" : "0");
  }

  function readStoredFont(fallback) {
    return normalizeFont(storageGet(FONT_KEY) || fallback || "md");
  }

  function writeStoredFont(font) {
    storageSet(FONT_KEY, normalizeFont(font));
  }

  function each(list, fn) {
    Array.prototype.forEach.call(list || [], fn);
  }

  function httpsCanonical(raw) {
    try {
      const url = new URL(String(raw || "").trim());
      if (url.protocol !== "https:") return "";
      if (url.username || url.password) return "";
      if (!url.hostname) return "";
      return url.href;
    } catch (_) {
      return "";
    }
  }

  function formatTime(iso) {
    const date = new Date(iso || "");
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short" }).format(date);
  }

  function readingMinutes(text) {
    const words = String(text || "").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return null;
    return Math.max(1, Math.round(words.length / 35));
  }

  function knownText(summary) {
    const text = String(summary || "").trim();
    if (!text) return { text: "", same: true };
    const match = text.match(/^([\s\S]+?[.!?…])\s+\S/);
    if (!match) return { text: text, same: true };
    const sentence = match[1].trim();
    if (sentence.length < 40 || sentence.length >= text.length - 1) return { text: text, same: true };
    return { text: sentence, same: false };
  }

  function spotLabel(story) {
    const label = String((story && story.authorship_label) || "").trim();
    if (!label) return "Kayıtlı imza yok";
    if (story && story.ai_assisted === true) return label;
    const folded = fold(label);
    if (folded === "editoryal özet" || folded.startsWith("editoryal")) return label;
    if (folded.includes("otomatik") || folded.includes("yapay zeka")) return label;
    return "Kaynak spotu";
  }

  function sourceCountOf(story) {
    const sources = Array.isArray(story && story.sources) ? story.sources : [];
    if (!story || story.source_count === undefined || story.source_count === null || story.source_count === "") {
      return sources.length;
    }
    const value = Number(story.source_count);
    return Number.isFinite(value) ? value : sources.length;
  }

  function uncertaintyLines(story) {
    const lines = [];
    const note = String((story && story.uncertainty_note) || "").trim();
    const singleNote = String((story && story.single_source_note) || "").trim();
    if (note) lines.push(note);
    if (singleNote && lines.indexOf(singleNote) === -1) lines.push(singleNote);
    if (!note && sourceCountOf(story) < 2 && lines.indexOf(SINGLE) === -1) lines.push(SINGLE);
    if (!lines.length) lines.push(NO_NOTE);
    return lines;
  }

  function publisherNames(story) {
    const names = [];
    const sources = Array.isArray(story.sources) ? story.sources : [];
    sources.forEach((source) => {
      const name = String((source && (source.publisher_name || source.domain)) || "").trim();
      if (name && names.indexOf(name) === -1) names.push(name);
    });
    if (!names.length && spotLabel(story) === "Kaynak spotu") {
      const authorship = String(story.authorship_label || "").trim();
      if (authorship) names.push(authorship);
    }
    return names;
  }

  function countLine(story) {
    const count = sourceCountOf(story);
    const visible = Array.isArray(story.sources) ? story.sources.length : 0;
    if (count < 2) return SINGLE;
    if (visible !== count) return count + " yayın. Bu ekranda " + visible + " kaynak bağlantısı var.";
    return count + " yayın.";
  }

  function scopeLead(story) {
    return COUNT_NOT_SCORE + " " + countLine(story);
  }

  function sharePayload(story, origin) {
    const title = String((story && story.editorial_title) || "");
    const id = String((story && story.id) || "");
    const root = String(origin || "").replace(/\/$/, "");
    const url = root + "/#/haber/" + id;
    return { title: title, url: url, text: title + "\n" + url };
  }

  function unwrap(body) {
    if (!body || typeof body !== "object" || Array.isArray(body)) return null;
    const data = body.data;
    if (data && typeof data === "object" && !Array.isArray(data) && ("editorial_title" in data || "editorial_summary" in data || "sources" in data)) {
      return data;
    }
    if ("editorial_title" in body || "editorial_summary" in body || "sources" in body) return body;
    return null;
  }

  function copyHtml(text, klass) {
    const body = String(text || "").trim();
    const cls = klass ? "cz-copy " + klass : "cz-copy";
    return '<p class="' + cls + '">' + esc(body || "Bu kayıtta kısa özet yok.") + "</p>";
  }

  function summaryBits(story) {
    const summary = String(story.editorial_summary || "").trim();
    const known = knownText(summary);
    return {
      summaryHtml: copyHtml(summary, "cz-summary"),
      knownHtml: copyHtml(known.text, "cz-known"),
      caption: known.same ? "Kısa özetle aynı metin." : "Kısa özetteki ilk cümle.",
    };
  }

  function uncertaintyInner(story) {
    return uncertaintyLines(story).map((line) => '<p class="cz-copy">' + esc(line) + "</p>").join("");
  }

  function knownUncertainHtml(story, multi) {
    const bits = summaryBits(story);
    const uncertain = '<div class="cz-block cz-uncertain"><h3>Belirsiz</h3>' + uncertaintyInner(story) + "</div>";
    if (multi) {
      const left = '<div class="cz-block"><h3>Neler biliniyor</h3><p class="cz-caption">Kayıtlı kısa özettir. Kaynak metinlerinin kesişimi hesaplanmaz.</p><h3>Kısa özet</h3>' + bits.summaryHtml + "<h3>Bilinenler</h3>" + bits.knownHtml + '<p class="cz-caption">' + esc(bits.caption) + "</p></div>";
      return '<section class="cz-block cz-trust"><h2>Neler biliniyor / belirsiz</h2><p class="cz-caption">Ortak metin ve belirsiz not yan yana. Yalnızca kayıtlı alanlar gösterilir.</p><div class="cz-pair">' + left + uncertain + "</div></section>";
    }
    return '<section class="cz-block cz-trust"><h2>Neler biliniyor / belirsiz</h2><h3>Kısa özet</h3>' + bits.summaryHtml + "<h3>Bilinenler</h3>" + bits.knownHtml + '<p class="cz-caption">' + esc(bits.caption) + "</p><h3>Belirsiz</h3>" + uncertaintyInner(story) + "</section>";
  }

  function imageHtml(story) {
    const href = httpsCanonical(story.image);
    if (!href) return '<div class="cz-figure"><div class="cz-fallback">Görsel yok</div></div>';
    return '<figure class="cz-figure"><img alt="Kayıtlı görsel" src="' + esc(href) + '"></figure>';
  }

  function metaHtml(story) {
    const names = publisherNames(story);
    const publisher = names.length ? names.join(" · ") : "Yayıncı adı bu kayıtta yok.";
    const published = formatTime(story.published_at);
    const updated = formatTime(story.updated_at);
    const showUpdated = updated && String(story.updated_at || "") !== String(story.published_at || "");
    const minutes = readingMinutes(story.editorial_summary);
    const bits = ['<span>' + esc(publisher) + "</span>"];
    if (published) bits.push('<span><time datetime="' + esc(story.published_at || "") + '">' + esc(published) + "</time></span>");
    if (showUpdated) bits.push("<span>Güncellendi <time datetime=\"" + esc(story.updated_at || "") + '">' + esc(updated) + "</time></span>");
    if (minutes) bits.push("<span>" + minutes + " dk okuma</span>");
    return '<div class="cz-meta">' + bits.join("") + "</div>";
  }

  function fontHtml(ui) {
    const button = (id, label) => '<button type="button" data-font="' + id + '" aria-pressed="' + (ui.font === id ? "true" : "false") + '">' + label + "</button>";
    return '<div class="cz-fonts" role="group" aria-label="Yazı boyutu">' + button("md", "Orta") + button("lg", "Büyük") + button("xl", "En büyük") + "</div>";
  }

  function readerToolsHtml(ui) {
    const simpleOn = ui.simple === true;
    return '<div class="cz-reader-tools">' + fontHtml(ui)
      + '<button type="button" class="cz-btn ghost" data-action="simple" aria-pressed="' + (simpleOn ? "true" : "false") + '">'
      + (simpleOn ? "Sade okuma açık" : "Sade okuma") + "</button></div>";
  }

  function primaryHttps(story) {
    const urls = [];
    (Array.isArray(story.sources) ? story.sources : []).forEach((source) => {
      const href = httpsCanonical(source && source.canonical_url);
      if (href && urls.indexOf(href) === -1) urls.push(href);
    });
    return urls.length === 1 ? urls[0] : "";
  }

  function actionsHtml(story, ui) {
    if (ui.mode === "compare") {
      const id = String((story && story.id) || "").trim();
      const back = id ? '<a class="cz-btn" href="#/haber/' + esc(id) + '">Habere dön</a>' : "";
      return back ? '<div class="cz-actions">' + back + "</div>" : "";
    }
    const pressed = ui.saved ? "true" : "false";
    const label = ui.saved ? "Kaydedildi" : "Kaydet";
    const read = primaryHttps(story);
    const link = read ? '<a class="cz-btn" href="' + esc(read) + '" target="_blank" rel="noopener noreferrer">Kaynağında oku</a>' : "";
    const report = ui.report
      ? '<button type="button" class="cz-btn ghost" data-action="report">Sorun bildir</button>'
      : "";
    const compare = String((story && story.id) || "").trim()
      ? '<a class="cz-btn ghost" href="#/karsilastir/' + esc(String(story.id)) + '">Kaynak karşılaştırması</a>'
      : "";
    return '<div class="cz-actions"><button type="button" class="cz-btn" data-action="save" aria-pressed="' + pressed + '">' + label + '</button><button type="button" class="cz-btn ghost" data-action="share">Paylaş</button>' + link + compare + report + "</div>";
  }

  function flagsHtml(story) {
    const parts = [];
    if (story.synthetic === true) {
      parts.push('<p class="cz-kurmaca" role="status">KURMACA</p>');
      const label = String(story.display_label || "").trim();
      if (label) parts.push('<p class="cz-copy">' + esc(label) + "</p>");
    }
    const warning = String(story.content_warning || "").trim();
    if (warning) parts.push('<p class="cz-warning" role="note">Uyarı: ' + esc(warning) + "</p>");
    if (story.ai_assisted === true) {
      parts.push('<p class="cz-ai" role="note">Yapay zeka destekli</p>');
      const role = String(story.ai_role_note || "").trim();
      if (role) parts.push('<p class="cz-copy">' + esc(role) + "</p>");
    }
    if (sourceCountOf(story) < 2) {
      parts.push('<p class="cz-status" role="status">' + esc(SINGLE) + "</p>");
    }
    return parts.join("");
  }

  function orderedCorrections(rows) {
    const copy = rows.slice();
    const times = copy.map((row) => Date.parse(row && row.created_at || ""));
    if (times.every((time) => Number.isFinite(time))) {
      copy.sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at));
    }
    return copy;
  }

  function updatesHtml(story) {
    const rows = Array.isArray(story.corrections) ? story.corrections : [];
    if (!rows.length) {
      return '<section class="cz-block cz-trust"><h2>Güncellemeler ve düzeltmeler</h2><p class="cz-copy">' + NO_CORRECTION + '</p><p class="cz-caption">Okur bildirimi yayındaki metni otomatik değiştirmez.</p></section>';
    }
    const items = orderedCorrections(rows).map((row) => {
      const when = formatTime(row.created_at);
      const reason = String(row.reason || "").trim() || "Gerekçe metni yok.";
      const editor = String(row.editor || "").trim();
      const who = editor ? '<p class="cz-caption">' + esc(editor) + "</p>" : "";
      return '<li><time datetime="' + esc(row.created_at || "") + '">' + esc(when || "Zaman yok") + "</time><p class=\"cz-copy\">" + esc(reason) + "</p>" + who + "</li>";
    }).join("");
    return '<section class="cz-block cz-trust"><h2>Güncellemeler ve düzeltmeler</h2><ol class="cz-timeline">' + items + '</ol><p class="cz-caption">Okur bildirimi yayındaki metni otomatik değiştirmez.</p></section>';
  }

  function sourcesScopeHtml(story) {
    const sources = Array.isArray(story.sources) ? story.sources : [];
    const context = String(story.context_note || "").trim();
    const contextHtml = context
      ? '<h3>Kapsam</h3><p class="cz-copy">' + esc(context) + "</p>"
      : '<p class="cz-caption">Kayıtlı bir kapsam notu yok. Tam makale burada yoktur.</p>';
    const cards = sources.map((source, index) => {
      const href = httpsCanonical(source && source.canonical_url);
      const title = String((source && source.source_title) || "").trim();
      const publisher = String((source && source.publisher_name) || "").trim() || "Yayıncı adı yok";
      const domain = String((source && source.domain) || "").trim();
      const when = formatTime(source && source.published_at);
      const link = href
        ? '<p><a class="cz-btn" href="' + esc(href) + '" target="_blank" rel="noopener noreferrer">Kaynağında oku</a></p>'
        : '<p class="cz-copy">' + LINK_UNSAFE + "</p>";
      const titleHtml = '<p class="cz-copy cz-source-title">' + esc(title || "Kaynak başlığı bu kayıtta yok.") + "</p>";
      const domainHtml = domain ? '<p class="cz-domain">' + esc(domain) + "</p>" : "";
      const timeHtml = when ? '<p class="cz-meta-line"><time datetime="' + esc(source.published_at || "") + '">' + esc(when) + "</time></p>" : "";
      const sourceId = String((source && source.source_id) || "").trim();
      const attr = sourceId ? ' data-source-id="' + esc(sourceId) + '"' : "";
      const publisherLink = sourceId
        ? '<p><a href="#/kaynak/' + esc(sourceId) + '">Yayıncı sayfası</a></p>'
        : "";
      return '<article class="cz-source"' + attr + '><p class="cz-kicker">Kaynak ' + (index + 1) + "</p><h3>" + esc(publisher) + "</h3>" + domainHtml + titleHtml + timeHtml + link + publisherLink + "</article>";
    }).join("");
    const body = cards || '<p class="cz-copy">' + NO_SOURCES + "</p>";
    return '<section class="cz-block cz-trust"><h2>Kaynaklar ve kapsam</h2><p class="cz-status" role="status">' + esc(scopeLead(story)) + '</p><p class="cz-caption">Her satır kendi kaynağına aittir. Tam makale burada yok.</p>' + contextHtml + '<div class="cz-sources">' + body + "</div></section>";
  }

  function simpleBodyHtml(story) {
    const bits = summaryBits(story);
    const read = primaryHttps(story) || firstHttps(story);
    const link = read
      ? '<p><a class="cz-btn" href="' + esc(read) + '" target="_blank" rel="noopener noreferrer">Kaynağında oku</a></p>'
      : '<p class="cz-caption">' + LINK_UNSAFE + "</p>";
    return '<section class="cz-block cz-trust"><h2>Kısa özet</h2>' + bits.summaryHtml
      + '<p class="cz-caption">Sade okuma: görsel ve kaynak listesi gizli. Tam makale yok.</p>' + link
      + "<h3>Belirsiz</h3>" + uncertaintyInner(story) + "</section>";
  }

  function firstHttps(story) {
    const sources = Array.isArray(story.sources) ? story.sources : [];
    for (let i = 0; i < sources.length; i += 1) {
      const href = httpsCanonical(sources[i] && sources[i].canonical_url);
      if (href) return href;
    }
    return "";
  }

  function render(story, ui) {
    const view = ui || { mode: "detail", font: "md", saved: false, report: false, simple: false };
    const multi = sourceCountOf(story) >= 2;
    const title = String(story.editorial_title || "").trim() || "Başlık bu kayıtta yok.";
    const simple = view.mode === "detail" && view.simple === true;
    const spot = view.mode === "detail" ? '<p class="cz-kicker">' + esc(spotLabel(story)) + "</p>" + copyHtml(story.editorial_summary, "cz-spot") : '<p class="cz-kicker">' + esc(spotLabel(story)) + "</p>";
    const figure = view.mode === "detail" && !simple ? imageHtml(story) : "";
    const kicker = view.mode === "compare" ? '<p class="cz-kicker">Kaynak karşılaştırması</p>' : "";
    const trust = simple
      ? simpleBodyHtml(story)
      : knownUncertainHtml(story, multi) + sourcesScopeHtml(story) + updatesHtml(story);
    return kicker + flagsHtml(story) + '<h1 class="cz-title">' + esc(title) + "</h1>" + spot + metaHtml(story) + figure
      + readerToolsHtml(view) + actionsHtml(story, view) + trust
      + '<p class="cz-caption">Kaynağı göstermek yeniden kullanım izni değildir.</p>';
  }

  function stateHtml(title, message, retry) {
    const button = retry ? '<button type="button" data-action="retry">Yeniden dene</button>' : "";
    return '<div class="cz-state" role="alert"><h1>' + esc(title) + "</h1><p class=\"cz-copy\">" + esc(message || "") + "</p>" + button + "</div>";
  }

  function originOf() {
    const location = globalThis.location;
    return location && location.origin ? location.origin : "";
  }

  async function doShare(story, onShare, button) {
    if (!story) return;
    const payload = sharePayload(story, originOf());
    if (typeof onShare === "function") {
      try { onShare(payload); } catch (_) { /* host */ }
      return;
    }
    const nav = globalThis.navigator;
    try {
      if (nav && typeof nav.share === "function") {
        await nav.share({ title: payload.title, text: payload.text });
        return;
      }
    } catch (error) {
      if (error && error.name === "AbortError") return;
    }
    try {
      if (nav && nav.clipboard && typeof nav.clipboard.writeText === "function") {
        await nav.clipboard.writeText(payload.text);
        if (button) button.textContent = "Bağlantı kopyalandı";
      }
    } catch (_) { /* kopyalanamadı */ }
  }

  function mount(container, options) {
    const opts = options || {};
    if (!container || typeof container.replaceChildren !== "function") return { destroy: function () {} };
    if (typeof document === "undefined" || typeof document.createElement !== "function") return { destroy: function () {} };
    const previous = cleanups.get(container);
    if (typeof previous === "function") previous();

    let alive = true;
    let ticket = 0;
    let current = null;
    let restored = false;
    let scrollTimer = 0;
    const storyId = String(opts.storyId || "").trim();
    const ui = {
      mode: opts.mode === "compare" ? "compare" : "detail",
      font: readStoredFont(opts.fontScale),
      saved: Boolean(opts.saved),
      report: typeof opts.onReport === "function",
      simple: opts.simple === true || (opts.simple !== false && readSimple()),
    };
    const view = document.createElement("div");
    view.className = "cizgi-story";
    if (typeof view.setAttribute === "function") {
      view.setAttribute("role", "article");
      view.setAttribute("aria-label", "Haber okuma");
    }
    container.replaceChildren(view);

    function pageY() {
      const win = globalThis;
      if (typeof win.scrollY === "number") return win.scrollY;
      const doc = globalThis.document;
      return doc && doc.documentElement ? doc.documentElement.scrollTop : 0;
    }

    function persistScroll() {
      if (!storyId) return;
      saveScroll(storyId, pageY());
    }

    function restoreScroll() {
      if (restored || !storyId) return;
      const y = scrollFor(storyId);
      if (y < 24) {
        restored = true;
        return;
      }
      restored = true;
      const win = globalThis;
      if (typeof win.requestAnimationFrame === "function") {
        win.requestAnimationFrame(function () {
          if (!alive) return;
          if (typeof win.scrollTo === "function") win.scrollTo(0, y);
        });
      } else if (typeof win.scrollTo === "function") {
        win.scrollTo(0, y);
      }
    }

    function onScroll() {
      if (!alive || !current) return;
      if (scrollTimer) clearTimeout(scrollTimer);
      scrollTimer = setTimeout(persistScroll, 180);
    }

    function paint(html, busy) {
      if (!alive) return;
      view.dataset.font = ui.font;
      view.dataset.mode = ui.mode;
      view.dataset.simple = ui.simple ? "true" : "false";
      if (typeof view.setAttribute === "function") view.setAttribute("aria-busy", busy ? "true" : "false");
      view.innerHTML = html;
      bind();
      if (!busy && current) restoreScroll();
    }

    function bind() {
      each(view.querySelectorAll("[data-font]"), (button) => {
        button.addEventListener("click", () => {
          ui.font = normalizeFont(button.getAttribute("data-font"));
          writeStoredFont(ui.font);
          if (current) paint(render(current, ui), false);
        });
      });
      const simpleBtn = view.querySelector("[data-action='simple']");
      if (simpleBtn) {
        simpleBtn.addEventListener("click", () => {
          ui.simple = !ui.simple;
          writeSimple(ui.simple);
          if (current) paint(render(current, ui), false);
        });
      }
      const save = view.querySelector("[data-action='save']");
      if (save) {
        save.addEventListener("click", () => {
          ui.saved = !ui.saved;
          const id = String((current && current.id) || storyId || "");
          try {
            if (typeof opts.onSave === "function") opts.onSave(id, ui.saved, current || null);
          } catch (_) { /* host */ }
          if (current) paint(render(current, ui), false);
        });
      }
      const share = view.querySelector("[data-action='share']");
      if (share) share.addEventListener("click", () => { doShare(current, opts.onShare, share); });
      const report = view.querySelector("[data-action='report']");
      if (report) {
        report.addEventListener("click", () => {
          const id = String((current && current.id) || storyId || "");
          try {
            if (typeof opts.onReport === "function") opts.onReport(id);
          } catch (_) { /* host */ }
        });
      }
      const retry = view.querySelector("[data-action='retry']");
      if (retry) retry.addEventListener("click", () => { load(); });
      each(view.querySelectorAll("img"), (img) => {
        img.addEventListener("error", () => {
          const fallback = document.createElement("div");
          fallback.className = "cz-fallback";
          fallback.textContent = "Görsel yok";
          if (typeof img.replaceWith === "function") img.replaceWith(fallback);
        });
      });
    }

    async function load() {
      const mine = ++ticket;
      restored = false;
      const id = storyId;
      paint('<p class="cz-status" role="status">Haber yükleniyor</p>', true);
      if (!/^[0-9a-fA-F-]{32,36}$/.test(id)) {
        paint(stateHtml("Haber açılamadı", "Geçersiz bağlantı.", false), false);
        return;
      }
      if (typeof opts.api !== "function") {
        paint(stateHtml("Haber açılamadı", "Bu ekran veri almak için api işlevi ister.", false), false);
        return;
      }
      let timedOut = false;
      const timer = setTimeout(function () {
        if (!alive || mine !== ticket || current) return;
        timedOut = true;
        paint(stateHtml("Haber açılamadı", "Yükleme uzun sürdü. Yeniden deneyebilirsin.", true), false);
      }, LOAD_MS);
      try {
        const body = await opts.api("/v1/stories/" + encodeURIComponent(id));
        clearTimeout(timer);
        if (!alive || mine !== ticket) return;
        if (timedOut) return;
        const story = unwrap(body);
        if (!story) {
          paint(stateHtml("Haber açılamadı", "Haber kaydı boş.", true), false);
          return;
        }
        current = story;
        paint(render(story, ui), false);
      } catch (error) {
        clearTimeout(timer);
        if (!alive || mine !== ticket || timedOut) return;
        const removed = Boolean(error && error.phase === "removed");
        const message = error && error.message ? String(error.message) : "Haber alınamadı.";
        paint(stateHtml(removed ? "Bu içerik artık gösterilemiyor" : "Haber açılamadı", message, !removed), false);
      }
    }

    function destroy() {
      persistScroll();
      alive = false;
      ticket += 1;
      current = null;
      if (scrollTimer) clearTimeout(scrollTimer);
      if (typeof globalThis.removeEventListener === "function") {
        globalThis.removeEventListener("scroll", onScroll);
      }
      if (typeof view.replaceChildren === "function") view.replaceChildren();
    }

    if (typeof globalThis.addEventListener === "function") {
      globalThis.addEventListener("scroll", onScroll, { passive: true });
    }
    cleanups.set(container, destroy);
    load();
    return {
      destroy: function () {
        destroy();
        cleanups.delete(container);
      },
    };
  }

  return {
    mount: mount,
    render: render,
    spotLabel: spotLabel,
    uncertaintyLines: uncertaintyLines,
    httpsCanonical: httpsCanonical,
    sharePayload: sharePayload,
    readingMinutes: readingMinutes,
    knownText: knownText,
    sourceCountOf: sourceCountOf,
    scopeLead: scopeLead,
  };
});
