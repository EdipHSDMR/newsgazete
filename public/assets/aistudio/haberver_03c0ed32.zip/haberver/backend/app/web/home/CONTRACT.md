# Çizgi günün gazetesi

`home.js` ve `home.css` ana sayfa kapağını çizer. Host `index.html` şu bağları yükler (`app.css` düğme stillerinden sonra `home.css`):

```html
<link rel="stylesheet" href="/static/brand/tokens.css?v=cizgi11">
<link rel="stylesheet" href="/static/app.css?v=cizgi11">
<link rel="stylesheet" href="/static/home/home.css?v=cizgi11">
<script src="/static/home/home.js?v=cizgi11"></script>
<script src="/static/app.js?v=cizgi11"></script>
```

Statik kök `backend/app/web` olduğu için tarayıcı yolu `/static/home/...` olur. `app.js` `#/` rotasında `CizgiHome.mount` çağırır; eski zayıf `showFeed` bu modüle delege eder.

## mount

```js
var handle = window.CizgiHome.mount(container, {
  api: api,
  onOpenStory: function (id) {},
  onOpenOriginal: function (url) {},
  onSave: function (id) {},
  savedIds: [],
  topics: [],
  followedTopics: [],
  unreadCount: 0,
  initialTopic: "",
  onSearch: function () {},
  onOpenNotifications: function () {},
  onOpenProfile: function () {},
  onStub: function (name) {}
});
```

`container` bir HTML öğesidir. `mount` öğeye `cizgi-home` sınıfını ve yoksa `lang="tr"` ile `aria-label="Günün gazetesi"` ekler. Dönüş: `{ reload, selectTopic, destroy }`. Aynı öğeye yeniden `mount` önceki oturumu iptal eder.

### Seçenekler

| Alan | Davranış |
| --- | --- |
| `api(path)` | Fetch yardımcısı. `{ items, next_cursor }` veya `{ data: { … } }`. |
| `onOpenStory(id)` | Başlık / manşet / son dakika. |
| `onOpenOriginal(url)` | Yalnızca `https://`. |
| `onSave(id)` | Kaydet. Kalıcılık host'ta. |
| `savedIds` | Dizi veya `Set`. |
| `topics` | Host konu kataloğu. Boşsa `/v1/topics`, o da yoksa yerleşik. |
| `followedTopics` | Slug veya ad. |
| `unreadCount` | `≤0` ise rozet yok. |
| `initialTopic` | Açılışta seçili konu slug. |
| `onSearch` / `onOpenNotifications` / `onOpenProfile` | Masthead araçları. |
| `onStub(name)` | `hava` veya `piyasalar`. |

Olaylar: `cizgi-home:story`, `cizgi-home:original`, `cizgi-home:save`, `cizgi-home:search`, `cizgi-home:notifications`, `cizgi-home:profile`, `cizgi-home:stub`.

## Veri

`GET /v1/feed?limit=30` (+ cursor), en fazla 4 sayfa / 120 kart. Bölümde az başlık varsa konu sayfası istenir. `CizgiBoot.fetch` varsa kullanılır; yoksa 45 sn stale-while-revalidate önbellek.

Ana akışa alınmayanlar: `synthetic`, Sentetik/Kurmaca etiket, "Örnek "/"Sentetik"/"Kurmaca" başlık.

Sayılar `tr-TR` ile gerçek tam sayı; milyon kısaltması yok.

## Kapak

- Masthead: marka işareti + ÇİZGİ, tarih, arama, bildirim (0’da rozet yok), profil.
- Konu çubuğu: Gündem, Türkiye (`ulusal`), Dünya, Ekonomi, Spor, Magazin (`kultur`), Teknoloji (`bilim-teknoloji`), Yaşam, Yerel, Hava (stub), Piyasalar (stub).
- Son dakika şeridi; reduced-motion’da kaymaz.
- Hero: 3–5 gerçek manşet slider (nokta, önce/sonra, duraklat; reduced-motion ve dokunuşta pause).
- Yan 3–4 başlık, bölümler, Sana göre / Son dakika / kaynak öne çıkanlar.

Tema: açık varsayılan (beyaz/kırık beyaz, lacivert yazı). `html[data-theme="dark"]` altında koyu palet.

## Yerleşim

412 px tek kolon. ≥1040 px üç sütun; max-width 1240–1280. Dar 400 px + boş alan yok. Dokunma ≥44 px.
