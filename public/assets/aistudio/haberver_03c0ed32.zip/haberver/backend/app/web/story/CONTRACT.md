# Çizgi haber okuma sözleşmesi

Bu modül haberi yeniden yazmaz. Gösterilen her cümle `StoryDetail` kaydındandır. Yeni olgu, ilgili haber, güven puanı ve siyasi etiket üretilmez. Tam makale kopyalanmaz. Kaynak sayısı doğruluk puanı değildir.

## Web

```js
window.CizgiStory.mount(container, {
  api,       // (path) => Promise<StoryDetail | { data: StoryDetail }>
  storyId,   // UUID
  mode,      // "detail" | "compare"
  saved,     // boolean, ilk durum
  onSave,    // (storyId, saved) => void  — saved tıklamadan sonraki durumdur
  onShare,   // ({ title, url, text }) => void
  onReport,  // (storyId) => void — yalnızca detail; metni değiştirmez, host /v1/reports yoluna gider
  fontScale, // "md" | "lg" | "xl"
})
```

Dönüş: `{ destroy() }`. Aynı kapsayıcıya yeniden `mount` önceki isteği iptal eder.

`api` yalnızca `/v1/stories/${storyId}` ile çağrılır. Adres ve anahtar bu dosyada yoktur. `api` yoksa istek atılmaz.

Betik ve stil, mevcut statik kökten:

- `/static/story/story.js`
- `/static/story/story.css`

`index.html` ve `app.js` host bağlar: `#/haber/{id}` detail, `#/karsilastir/{id}` compare. Okur bildirimi `#/bildir/{id}` → `POST /v1/reports`; yayındaki metin otomatik değişmez.

Paylaşım metni: `başlık` + satır sonu + `location.origin/#/haber/${id}`. `onShare` varsa host çalışır; yoksa `navigator.share`, o da yoksa pano.

Yazı `md` iken başlık 44px seriftir. `lg` 1.18, `xl` 1.36 kat büyür. Satır kısaltılmaz, kutu yüksekliği metinle artar. Düğmeler en az 44px. Zemin koyu lacivert `#07111c`.

## Android

```kotlin
@Composable
fun StoryDetailScreen(
    storyId: String,
    onOpenSource: (String) -> Unit,
    onReport: (String) -> Unit,
    onBack: () -> Unit,
)

@Composable
fun CompareSourcesScreen(
    storyId: String,
    onBack: () -> Unit,
)
```

İkisi de `HaberApp.container.repository.observe` ve `refreshDetail` kullanır. Yeni istemci veya ağ anahtarı yok. Kayıt `repository.setSaved`. Paylaşım metni `başlık` + satır sonu + `API_BASE_URL` kökeni + `/#/haber/${id}` (`/v1` soneki düşülür). Kaynağında oku yalnızca `https` ve mevcut `openExternal`.

Başlık `md` iken 44sp serif. `lg` / `xl` aynı katsayılarla büyür, `maxLines` yoktur. Zemin `#07111C`.

`HaberRoot` hâlâ kendi `StoryScreen` / `CompareScreen` işlevlerini çağırır. Bu iki composable oraya bağlanmadı.

## Alanlar

Okunanlar: `editorial_title`, `editorial_summary`, `context_note`, `uncertainty_note`, `single_source_note`, `sources[]` (`publisher_name`, `domain`, `source_title`, `canonical_url`, `published_at`, `source_id`), `corrections`, `image`, `source_count`, `authorship_label`, `published_at`, `updated_at`, `synthetic`, `content_warning`. Web ayrıca `ai_assisted`, `ai_role_note`, `display_label`.

### Editoryal güven bölümleri (yalnızca gerçek alanlar)

1. **Neler biliniyor / belirsiz**
   - Spot / kısa özet = `editorial_summary`. Yayıncı imzası editoryal değilse etiket **Kaynak spotu** olur. `ai_assisted` değilse otomatik özet denmez. Yapay zeka bayrağı varsa web “Yapay zeka destekli” der ve varsa `ai_role_note` olduğu gibi durur.
   - Bilinenler = aynı metin, ya da 40 karakteri aşan ilk cümle. Ek cümle yok.
   - Belirsiz = `uncertainty_note`. Not yoksa ve `source_count < 2` ise tam olarak: `Tek yayın. Başka kaynakla karşılaştırılmadı.` Kayıtlı `single_source_note` varsa o da yazılır. Çok kaynakta not yoksa: `Kayıtlı bir belirsizlik notu yok.`
   - Çok kaynakta (`source_count >= 2`) ortak metin ile belirsiz not yan yanadır. Ortak metin, kayıtlı kısa özettir; kaynakların kesişimi hesaplanmaz.

2. **Kaynaklar ve kapsam**
   - Açılış: `Kaynak sayısı doğruluk puanı değildir.` + yayın sayısı satırı.
   - Kapsam = `context_note` (yoksa kısa boş durum).
   - Kaynaklar: her kaynak kendi `source_title` ve kendi `canonical_url` değeriyle. `https` değilse bağlantı açılmaz; metin: `Kaynak bağlantısı bu kayıtta güvenli açılmıyor.`

3. **Güncellemeler ve düzeltmeler**
   - Düzeltme varsa zaman çizelgesi (`corrections[].reason`, `created_at`, `editor`), yoksa `Kayıtlı düzeltme yok.`
   - Okur bildirimi metni otomatik değiştirmez.

- `synthetic == true` ise görünen **KURMACA**.
- Okuma süresi: spotun kelime sayısı / 35, en yakın dakika. Boş metinde süre yok.
- Görsel yalnızca `https`. Değilse ya da yüklenemezse “Görsel yok”.
- Karşılaştırma modunda kaydet, paylaş ve bildir yok; habere dönüş vardır.

## Eksikler

- Android `StoryCard` / `StoryDetailDto` `image` taşımıyor. Ayrıntı önbelleği görseli düşürür. Ekranda her zaman fallback vardır.
- Android `SourceLink` içinde `source_id` yok. `onOpenSource` yalnızca `sources.size == sourceIds.size` iken indeksle çağrılır. Sayılar uyuşmazsa yayıncı sayfası uydurulmaz; `https` bağlantı durur.
- `ai_assisted` Android modele yazılmıyor. İmza yayıncı adıysa ekran **Kaynak spotu** der. Web `ai_assisted` alanını kullanır.
- Ayrıntı önbelleği dolmadan belirsizlik, düzeltme ve kaynak listesi `Kayıt kontrol ediliyor.` diyebilir. `refreshDetail` bitince kayıtlı metne döner.
- Android paylaşım kökeni tarayıcı `origin` değil, mevcut `API_BASE_URL` köküdür.
- Bu makinede Android derlemesi yok (Java 8, SDK ve Gradle wrapper yok).
