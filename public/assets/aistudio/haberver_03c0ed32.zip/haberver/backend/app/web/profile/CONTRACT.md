# Çizgi profil ve bildirim sözleşmesi

Bu modül hesap açmaz, konum istemez, dil seçici sunmaz ve anlık sunucu push'u göndermez. Bildirimler bu sürümde cihazdaki tercihlerdir.

## Push gerçeği

- Android Gradle kataloğunda `firebase-messaging` yoktur. İstemci FCM jetonu almaz.
- Sunucu `push_outbox` kaydını `skipped_no_provider` durumunda bırakır; gerekçe kodda "FCM projesi TBD; gönderim yapılmadı" şeklindedir. Cihazın bu kuyruğu okuduğu bir uç nokta yoktur.
- Web `Notification` iznini yalnızca "Bildirimleri aç" düğmesinde sorar. Service worker, `PushManager` veya yerel `new Notification()` yoktur.
- Android `POST_NOTIFICATIONS` ilk açılışta sorulmaz. İstek yalnızca bildirim merkezindeki "Bildirimleri aç" düğmesindedir. "Şimdi değil" izin penceresini açmaz.
- `LocalAlertsWorker` WorkManager API'sine uyar, kuyruğa alınmaz ve `NotificationManager.notify` çağırmaz. `delivered` her zaman 0'dır.
- Takip edilen konu veya takım adı için yerel bildirim, bu dosyaların dışında kalan `RefreshWorker` içindedir: yaklaşık 30 dakika, `notifications` açık, sistem izni var, sessiz saat dışı. Bu modül o işçiyi ikinci kez kurmaz. Son dakika, maç başlangıcı ve skor değişimi o işçiye bağlı değildir.

## Web

`/static/profile/profile.js` ve `/static/profile/profile.css` mevcut statik kökten servis edilir. `index.html` ve `app.js` bu modülü bağlamak zorunda değildir; kabuk bağlayana kadar ekran görünmez.

```html
<link rel="stylesheet" href="/static/profile/profile.css">
<script src="/static/profile/profile.js"></script>
<script>
  CizgiProfile.mount(document.querySelector("#profil-kok"), {
    api: api,
    library: window.CizgiLibrary,
    onWipe: function () {}
  });
</script>
```

`mount(container, { api, library, onWipe, notices })`

- `api(path)` isteğe bağlıdır. Varsa `GET /v1/meta` çağrılır. Dönüş `data` zarfı ya da düz nesne olabilir. Hata olursa ad "Çizgi", söz "Gündemi bul, bağlamı gör.", marka satırı "Marka: TBD" kalır.
- `library` yoksa takip özeti uydurulmaz. Varsa alanlar: `followedTopics` / `topics` / `follows.topics`, `followedSources` / `sources` / `follows.sources`, `followedTeams` / `teams` / `follows.teams`, `recentSearches` / `recent` / `searches`. `snapshot()` fonksiyonu varsa onun dönüşü okunur. Temizleme: `clearRecentSearches`, `clearSearches` veya `clearRecent`.
- `onWipe` yalnızca "Profil tercihlerini sil" ile, `cizgi.profile.v1` silindikten sonra çağrılır. Arama temizliği bunu çağırmaz.
- `notices` isteğe bağlı dizi veya fonksiyondur. Yalnızca dolu `id` ve `title` olan öğeler listelenir. Okunmamış sayı bu listenin `read !== true` öğeleridir. Parametre yoksa liste boştur ve boşluk metni gösterilir.

`CizgiProfile.read()` bellekteki tercihi döndürür. `CizgiProfile.KEY` değeri `cizgi.profile.v1`dir.

Tema ve yazı boyutu modül kökünde `data-theme` ve `data-font` olarak durur. `documentElement` ve `haberkesif.reader.v1` yazılmaz. Kabuk temayı kendisi uygulamadıkça uygulamanın geri kalanı değişmez.

### localStorage `cizgi.profile.v1`

| Alan | Anlam | Varsayılan |
| --- | --- | --- |
| `theme` | `dark` veya `light` | `dark` |
| `font` | `md`, `lg`, `xl` | `md` |
| `notifyTopics` | Takip konu ve kaynak | `false` |
| `notifyMatches` | Maç başlangıcı veya skor açıksa `true` | `false` |
| `quietStart` | 0–23 | `22` |
| `quietEnd` | 0–23 | `7` |
| `analytics` | Kullanım ölçümü tercihi; ekran ölçüm göndermez | `false` |
| `notifyBreaking` | Son dakika | `false` |
| `notifyMatchStart` | Maç başlangıcı | `false` |
| `notifyScore` | Skor değişimi | `false` |
| `frequency` | `off` veya `device_refresh`; web'de zamanlama yapmaz | `off` |
| `notificationsEnabled` | Uygulama tercihi | `false` |
| `permissionDeferred` | "Şimdi değil" | `false` |

Bilinmeyen alanlar silinmeden korunur. `theme` için `system` yazılmaz; kayıtlı değer `light` değilse `dark` olur.

## Android

Composable'lar `dev.haberver.kesif.ui.profile.ProfileScreens.kt` içindedir. `HaberRoot` bunları henüz çağırmaz; mevcut ayar ekranı durur.

```kotlin
CizgiProfileScreen(preferences, prefs, onOpenNotifications = { /* kabuğun rotası */ })
CizgiNotificationCenterScreen(preferences, prefs, notices)
```

`onOpenNotifications` null ise profil, bildirim merkezini kendi içinde açar. `notices` varsayılanı boş listedir. Okunmamış sayı, dolu `id` ve `title` taşıyan öğelerin okunmamış olanlarıdır.

`Preferences.kt` değiştirilmez. `UserPrefs` akışındaki alanlar kendi tipleriyle `preferences.update { }` üzerinden yazılır:

| Anahtar | Tip | Ne zaman |
| --- | --- | --- |
| `theme` | string | `dark` veya `light` |
| `notifications` | boolean | Yalnızca izin verildikten veya sistem zaten açıksa |
| `quiet_start`, `quiet_end` | int | 0–23 |
| `analytics_opt_in` | boolean | Gizlilik anahtarı |
| `followed_topics` | string set | Takibi bırak |
| `followed_teams` | string set | Takibi bırak; mevcut anahtar |
| `recent_searches` | string | Temizlemede `""` |
| `breaking_alerts` | boolean | Son dakika; yenileme işçisi okumaz |
| `followed_topic_alerts` | boolean | Konu yenileme eşlemesi bunu okur |

Yeni anahtarlar stringdir. `Preferences.flow` onları `UserPrefs`e koymaz. Ekran açılınca aynı `update { }` anlık görüntüsünden okunur; dönüşüm anahtarı değiştirmeden değeri yakalar. Veri deposu eşit içerikte yazımı atlayabilir. Atlamazsa aynı içerik yeniden yazılır, anahtar silinmez.

| Anahtar | Değer |
| --- | --- |
| `font` | `md`, `lg`, `xl` |
| `followed_source_alerts` | `true` veya `false`; konu anahtarıyla birlikte yazılır, kaynak kimliği eşlemesi yoktur |
| `match_start_alerts` | `true` veya `false` |
| `score_change_alerts` | `true` veya `false` |
| `alert_frequency` | `off` veya `device_refresh`; `RefreshWorker` periyodunu değiştirmez |

`sports_alerts` maç başlangıcı sanılıp yazılmaz. O anahtar, yenileme işçisinde spor konusu ve takım adı eşlemesidir. `city` yazılmaz, konum izni istenmez, dil listesi yoktur.

Sessiz saat kuralı `inQuietHours` ile aynıdır: başlangıç ve bitiş eşitse pencere yoktur; aksi halde başlangıç dahil, bitiş hariç, gece yarısını saran aralık desteklenir.

## Eksikler

- Kabuk (`app.js`, `index.html`, `HaberRoot`) bu ekranları göstermez.
- Yeni string anahtarlar `UserPrefs` alanlarına bağlı değildir. Başka bir ekran onları okuyamaz; bu modül açılışta `update` anlık görüntüsünden okur.
- `followed_source_alerts` kaynak listesini taşımaz. Android profilinde kaynak özeti yoktur.
- Web kütüphanesi yokken takip ve arama listesi boş açıklamasıdır. `haberkesif.reader.v1` içindeki aramalar bu modülden silinmez.
- Web teması belgenin tamamına uygulanmaz.
- Maç başlangıcı, skor ve son dakika için olay kaynağı yoktur. Sıklık anahtarı zamanlayıcı kurmaz.
- `LocalAlertsWorker` uygulama başlangıcında işe konmaz.
