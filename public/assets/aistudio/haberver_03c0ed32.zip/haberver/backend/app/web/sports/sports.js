/* Çizgi spor merkezi. window.CizgiSports.mount — ayrıntı CONTRACT.md
   Self-boot: #/spor hash veya #sports-root / [data-cizgi-sports]. app.js'e yazılmaz. */
(function (factory) {
  const api = factory();
  const pub = { mount: api.mount, createApi: api.createApi };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof window !== "undefined") {
    window.CizgiSports = pub;
    if (typeof document !== "undefined") api.bootSelf();
  }
})(function () {
  "use strict";

  const TZ = "Europe/Istanbul";
  const SS_ORIGIN = "https://sportscore.com";
  const SS_REFRESH_MS = 5 * 60 * 1000;
  const CSS_HREF = "/static/sports/sports.css?v=cizgi17";
  const TABS = [
    ["live", "Canlı"],
    ["today", "Bugün"],
    ["scheduled", "Fikstür"],
    ["finished", "Sonuçlar"],
    ["standings", "Puan Durumu"],
    ["teams", "Takımlar"],
  ];
  const GOLD = new Set(["IN_PLAY", "LIVE", "EXTRA_TIME", "ET", "PENALTY_SHOOTOUT", "PENALTIES"]);
  const STATUS = {
    IN_PLAY: "Canlı",
    LIVE: "Canlı",
    PAUSED: "Devre arası",
    HALFTIME: "Devre arası",
    HT: "Devre arası",
    EXTRA_TIME: "Uzatma",
    ET: "Uzatma",
    PENALTY_SHOOTOUT: "Penaltılar",
    PENALTIES: "Penaltılar",
    SCHEDULED: "Başlamadı",
    TIMED: "Başlamadı",
    NS: "Başlamadı",
    FINISHED: "Bitti",
    FT: "Bitti",
    AWARDED: "Hükmen",
    POSTPONED: "Ertelendi",
    SUSPENDED: "Durduruldu",
    INTERRUPTED: "Durduruldu",
    CANCELLED: "İptal",
    CANCELED: "İptal",
  };
  const EMPTY = {
    today: "Bu günde maç yok.",
    scheduled: "Bu günde planlanmış maç yok.",
    finished: "Bu günde sonuç yok.",
    standings: "Bu lig için puan durumu yok.",
    teams: "Bu lig için takım listesi yok.",
    live: "Gösterilecek canlı maç, fikstür veya sonuç yok.",
  };
  /**
   * SportScore competition slug allowlist — yalnızca ZIP v1.0.4 / sportscore.com/embed
   * showcase veya canlı embed yanıtı (title eşleşmesi) ile doğrulanmış slug’lar.
   * Uydurma veya yanlış lig dönen eşadlı slug’lar (ör. serie-a → Cup Women) yok.
   */
  const SS_VERIFIED = new Set([
    "turkish-super-league",
    "english-premier-league",
    "premier-league",
    "italian-serie-a",
    "bundesliga",
    "spanish-la-liga",
    "french-ligue-1",
    "brazilian-serie-a",
    "uefa-champions-league",
    "uefa-europa-league",
    "copa-libertadores",
    "fifa-world-cup",
  ]);
  /** football-data kod → doğrulanmış SportScore competition slug. Eşleşme yoksa dokunma. */
  const SS_BY_FD = {
    PL: "english-premier-league",
    BL1: "bundesliga",
    SA: "italian-serie-a",
    PD: "spanish-la-liga",
    FL1: "french-ligue-1",
    BSA: "brazilian-serie-a",
    CL: "uefa-champions-league",
    CLI: "copa-libertadores",
    WC: "fifa-world-cup",
  };
  const SS_PRESETS = [
    { id: "turkish-super-league", label: "Süper Lig (Türkiye) · SportScore" },
    { id: "english-premier-league", label: "Premier League" },
    { id: "spanish-la-liga", label: "La Liga" },
    { id: "bundesliga", label: "Bundesliga" },
    { id: "italian-serie-a", label: "Serie A" },
    { id: "french-ligue-1", label: "Ligue 1" },
    { id: "uefa-champions-league", label: "Şampiyonlar Ligi" },
    { id: "brazilian-serie-a", label: "Brasileirão" },
  ];
  const SS_WIDGETS = new Set(["tracker", "match", "fixtures", "standings", "topscorers", "bracket", "player", "lineups"]);
  const SS_SINGLE = new Set(["standings", "topscorers", "bracket", "player", "lineups"]);
  const SS_SPORTS = new Set(["football", "basketball", "cricket", "tennis"]);

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[ch]));
  }
  function text(value) {
    if (value === null || value === undefined) return "";
    if (typeof value === "number" && Number.isFinite(value)) return String(value);
    if (typeof value === "string") return value.trim();
    return "";
  }
  function asArray(value) {
    return Array.isArray(value) ? value : [];
  }
  function looksSecret(value) {
    return /api[_-]?key|token|secret|bearer|authorization|x-auth/i.test(String(value || ""));
  }
  function intLoose(value, min, max) {
    if (value === null || value === undefined || value === "" || typeof value === "boolean") return null;
    const n = typeof value === "number" ? value : Number(String(value).trim());
    if (!Number.isInteger(n) || n < min || n > max) return null;
    return n;
  }
  function httpsUrl(value) {
    const raw = text(value);
    if (!raw.startsWith("https://")) return "";
    try {
      const url = new URL(raw);
      if (url.protocol !== "https:" || url.username || url.password || !url.hostname) return "";
      return url.href;
    } catch {
      return "";
    }
  }
  function initialOf(name) {
    const chars = Array.from(text(name));
    return chars.length ? chars[0].toLocaleUpperCase("tr-TR") : "?";
  }
  function istanbulToday(now) {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit",
    }).formatToParts(now || new Date());
    const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return `${map.year}-${map.month}-${map.day}`;
  }
  function shiftDate(iso, days) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || "");
    if (!match) return istanbulToday();
    const utc = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]) + days));
    const month = String(utc.getUTCMonth() + 1).padStart(2, "0");
    const day = String(utc.getUTCDate()).padStart(2, "0");
    return `${utc.getUTCFullYear()}-${month}-${day}`;
  }
  function formatDay(iso) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || "");
    if (!match) return "";
    const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12));
    const label = new Intl.DateTimeFormat("tr-TR", {
      timeZone: "UTC", weekday: "long", day: "numeric", month: "long",
    }).format(date);
    return label.split(" ").map((word) => word.charAt(0).toLocaleUpperCase("tr-TR") + word.slice(1)).join(" ");
  }
  function formatClock(value) {
    const raw = text(value);
    if (!raw) return "";
    const hm = /^(\d{1,2}):(\d{2})$/.exec(raw);
    if (hm) {
      const hour = Number(hm[1]);
      const minute = Number(hm[2]);
      if (hour > 23 || minute > 59) return "";
      return `${String(hour).padStart(2, "0")}:${hm[2]}`;
    }
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ, hour: "2-digit", minute: "2-digit", hourCycle: "h23",
    }).format(date);
  }
  function formatRefreshed(value) {
    const raw = text(value);
    if (!raw) return "bilinmiyor";
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return "bilinmiyor";
    const label = new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ, day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
    }).format(date);
    return label.split(" ").map((word) => word.charAt(0).toLocaleUpperCase("tr-TR") + word.slice(1)).join(" ");
  }
  function side(value) {
    if (typeof value === "string") return { id: "", name: text(value) || "—", crest: "" };
    if (value && typeof value === "object") {
      return {
        id: cleanId(value.id),
        name: text(value.name) || text(value.short_name) || text(value.shortName) || text(value.tla) || "—",
        crest: httpsUrl(value.crest || value.emblem || value.logo),
      };
    }
    return { id: "", name: "—", crest: "" };
  }
  function cleanId(value) {
    const id = text(value);
    return id && id.length <= 80 ? id : "";
  }
  function sanitizeSlug(value) {
    return String(value || "").toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 80);
  }
  /** ZIP: ?src= isteğe bağlı adoption sinyali. Localhost / özel IP gönderme. PII yok. */
  function siteSrcParam() {
    try {
      const host = typeof location !== "undefined" ? String(location.hostname || "") : "";
      if (!host || host.length > 80) return "";
      if (/[&=?#/@]|user|email|token|id=/i.test(host)) return "";
      const h = host.toLowerCase();
      if (h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]") return "";
      if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h)) return "";
      if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return "";
      return host;
    } catch {
      return "";
    }
  }
  /** ZIP v1.0.4 PHP ile aynı URL şekilleri. Anahtar yok. PII yok. Yalnızca allowlist slug. */
  function sportScoreEmbedUrl(opts) {
    const widget = text(opts && opts.widget).toLowerCase() || "fixtures";
    const sport = text(opts && opts.sport).toLowerCase() || "football";
    const type = text(opts && opts.type).toLowerCase() || "competition";
    const slug = sanitizeSlug(opts && opts.slug);
    if (!SS_WIDGETS.has(widget) || !SS_SPORTS.has(sport) || !slug) return "";
    if (!SS_VERIFIED.has(slug)) return "";
    let path;
    if (SS_SINGLE.has(widget)) {
      path = `/embed/${encodeURIComponent(widget)}/${encodeURIComponent(sport)}/${encodeURIComponent(slug)}/`;
    } else {
      if (type !== "team" && type !== "competition") return "";
      path = `/embed/${encodeURIComponent(widget)}/${encodeURIComponent(sport)}/${encodeURIComponent(type)}/${encodeURIComponent(slug)}/`;
    }
    try {
      const url = new URL(path, SS_ORIGIN);
      const src = siteSrcParam();
      if (src) url.searchParams.set("src", src);
      return url.href;
    } catch {
      return "";
    }
  }
  function normalizeScore(score) {
    if (!score || typeof score !== "object") return null;
    const full = score.fullTime || score.full_time;
    const source = full && typeof full === "object" ? full : score;
    const home = intLoose(source.home, 0, 99);
    const away = intLoose(source.away, 0, 99);
    if (home === null && away === null) return null;
    return { home, away };
  }
  function normalizeMinute(value) {
    if (value === null || value === undefined || value === "") return null;
    if (typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 130) return String(value);
    const raw = text(value);
    return /^\d{1,3}(\+\d{1,2})?$/.test(raw) ? raw : null;
  }
  function normalizeStatus(value) {
    if (typeof value === "string") return value.trim().toUpperCase().replace(/\s+/g, "_");
    if (value && typeof value === "object") return normalizeStatus(value.short || value.code || "");
    return "";
  }
  function normalizeCompetition(row) {
    if (!row || typeof row !== "object") return null;
    // football-data: matches/standings competition= kod ister (PL); sayısal id yedek.
    const id = cleanId(row.code) || cleanId(row.id);
    if (!id) return null;
    const area = typeof row.area === "object" && row.area ? text(row.area.name) : text(row.area);
    return { id, name: text(row.name) || id, area, emblem: httpsUrl(row.emblem || row.crest) };
  }
  function normalizeMatch(row) {
    if (!row || typeof row !== "object") return null;
    const home = side(row.home || row.home_team || row.homeTeam);
    const away = side(row.away || row.away_team || row.awayTeam);
    if (home.name === "—" && text(row.home_name)) home.name = text(row.home_name);
    if (away.name === "—" && text(row.away_name)) away.name = text(row.away_name);
    if (!home.crest) home.crest = httpsUrl(row.home_crest);
    if (!away.crest) away.crest = httpsUrl(row.away_crest);
    if (home.name === "—" && away.name === "—") return null;
    const competition = row.competition;
    const competitionName = text(row.competition_name) || text(row.competitionName) || (competition && typeof competition === "object" ? text(competition.name) : "");
    const score = Object.prototype.hasOwnProperty.call(row, "score")
      ? normalizeScore(row.score)
      : normalizeScore({ home: row.home_score, away: row.away_score });
    return {
      id: cleanId(row.id),
      home,
      away,
      score,
      minute: normalizeMinute(row.minute),
      status: normalizeStatus(row.status),
      localTime: formatClock(row.local_time || row.localTime || row.kickoff || row.utc_date || row.utcDate),
      competitionName,
      provider: text(row.provider) || "",
    };
  }
  function normalizeStanding(row) {
    if (!row || typeof row !== "object") return null;
    const team = side(row.team);
    if (!team.id) team.id = cleanId(row.team_id);
    if (team.name === "—" && text(row.team_name)) team.name = text(row.team_name);
    if (team.name === "—") return null;
    if (!team.crest) team.crest = httpsUrl(row.crest);
    return {
      rank: intLoose(row.rank, 1, 200),
      team,
      played: intLoose(row.played, 0, 200),
      won: intLoose(row.won, 0, 200),
      drawn: intLoose(row.drawn, 0, 200),
      lost: intLoose(row.lost, 0, 200),
      goalsDiff: intLoose(row.goals_diff ?? row.goalsDiff ?? row.goal_difference, -500, 500),
      points: intLoose(row.points, 0, 400),
    };
  }
  function normalizeTeam(row) {
    if (!row || typeof row !== "object") return null;
    const name = text(row.name) || text(row.short_name) || text(row.shortName);
    if (!name) return null;
    const venue = row.venue && typeof row.venue === "object" ? text(row.venue.name) : text(row.venue);
    return {
      id: cleanId(row.id),
      name,
      shortName: text(row.short_name) || text(row.shortName) || text(row.tla),
      crest: httpsUrl(row.crest || row.emblem),
      venue,
    };
  }
  function normalizeMeta(payload) {
    const body = payload && typeof payload === "object" ? payload : {};
    const limitation = text(body.limitation);
    return {
      provider: text(body.provider) || "football-data.org",
      attribution: looksSecret(body.attribution) ? "" : text(body.attribution),
      timezone: text(body.timezone) || TZ,
      refreshedAt: text(body.refreshed_at) || text(body.refreshedAt),
      fromCache: Boolean(body.from_cache || body.fromCache),
      stale: Boolean(body.stale),
      limited: Boolean(body.limited),
      limitation: looksSecret(limitation) ? "" : limitation,
    };
  }
  function limitationText(meta) {
    if (!meta) return "";
    if (meta.limitation) return meta.limitation;
    if (meta.limited) return "Sağlayıcı bu yanıtı sınırladı. Eksik skor tamamlanmaz.";
    return "";
  }
  function freshness(meta) {
    if (meta.stale && meta.fromCache) return "Önbellek · son başarılı veri";
    if (meta.stale) return "Son başarılı veri";
    if (meta.fromCache) return "Önbellekten";
    return "Güncel";
  }
  function sourceLine(meta, refreshing) {
    if (!meta) return "Kaynak: football-data.org";
    const credit = meta.attribution
      ? (meta.attribution.toLowerCase().includes("football-data.org") || meta.attribution.toLowerCase().includes("api-football")
        ? meta.attribution
        : `${meta.attribution} · ${meta.provider || "football-data.org"}`)
      : `Kaynak: ${meta.provider || "football-data.org"}`;
    const line = `${credit} · Son yenilenme: ${formatRefreshed(meta.refreshedAt)} · ${freshness(meta)}`;
    return refreshing ? `${line} · yenileniyor` : line;
  }
  function statusView(status, minute) {
    const known = STATUS[status];
    const label = known || (/^[A-Z0-9_]{1,24}$/.test(status || "") ? status : "Durum bilinmiyor");
    const minuteLabel = minute ? `${minute}′` : "";
    return {
      label: minuteLabel ? `${label} · ${minuteLabel}` : label,
      gold: GOLD.has(status),
    };
  }
  function scoreCell(score, sideName) {
    if (!score || score[sideName] === null || score[sideName] === undefined) return "–";
    return String(score[sideName]);
  }
  function cell(value) {
    return value === null || value === undefined ? "–" : String(value);
  }
  function diffCell(value) {
    if (value === null || value === undefined) return "–";
    return value > 0 ? `+${value}` : String(value);
  }
  function humanError(error) {
    if (!error || error.name === "AbortError") return "";
    const status = Number(error.status || error.statusCode || 0);
    const code = String(error.code || "");
    const phase = String(error.phase || "");
    const retry = Number(error.retryAfter);
    if (status === 429 || code === "rate_limited") {
      if (Number.isFinite(retry) && retry >= 1 && retry <= 900) {
        const minutes = Math.max(1, Math.ceil(retry / 60));
        return `Çok fazla istek atıldı. Yaklaşık ${minutes} dakika sonra Yenile ile tekrar dene.`;
      }
      return "Çok fazla istek atıldı. Birkaç dakika sonra Yenile ile tekrar dene.";
    }
    if (status === 401 || status === 403 || code === "forbidden" || code === "provider_forbidden") {
      return "Skor verisine erişim kapalı. Bu ekran anahtar tutmaz; erişim sunucuda açıldığında veriler gelir.";
    }
    if (status === 404 || code === "not_found") {
      return "Spor servisi henüz hazır değil. Biraz sonra Yenile ile tekrar dene.";
    }
    if (status === 502 || status === 503 || status === 504 || code === "source_unavailable" || code === "service_unavailable") {
      return "Skor servisi şu an yanıt vermiyor. Kısa süre sonra yeniden dene.";
    }
    if (code === "timeout") return "Skor servisi zamanında yanıt vermedi. Yenile ile tekrar dene.";
    if (status === 0 || phase === "offline" || code === "offline" || code === "bad_base") {
      return "Bağlantı kurulamadı. Ağını kontrol edip Yenile.";
    }
    if (status === 500 || code === "server_error") return "Spor servisinde bir hata oluştu. Biraz sonra Yenile.";
    const message = text(error.message);
    if (!message || message.length > 280 || looksSecret(message) || /^not found$/i.test(message)) {
      return "Skorlar şu an alınamadı. Yenile ile tekrar dene.";
    }
    if (/akış şu an yenilenemedi/i.test(message)) return "Skorlar şu an alınamadı. Yenile ile tekrar dene.";
    return message;
  }
  function hardStatus(error) {
    const status = Number(error && error.status || 0);
    return status === 401 || status === 403 || status === 404 || status === 429;
  }
  function unwrap(body) {
    if (!body || typeof body !== "object") return {};
    const data = body.data;
    if (data && typeof data === "object" && !Array.isArray(data)) {
      const keys = ["matches", "competitions", "standings", "teams", "provider", "limited", "limitation"];
      if (keys.some((key) => Object.prototype.hasOwnProperty.call(data, key))) return data;
    }
    if (body.error && data == null) {
      const error = new Error(text(body.error.message));
      error.status = Number(body.status || 503);
      error.code = text(body.error.code);
      throw error;
    }
    return body;
  }
  function sportsPath(kind, params) {
    const search = new URLSearchParams();
    Object.entries(params || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") search.set(key, String(value));
    });
    const query = search.toString();
    return `/v1/sports/${kind}${query ? `?${query}` : ""}`;
  }
  function requestId() {
    const cryptoObj = globalThis.crypto;
    if (cryptoObj && typeof cryptoObj.randomUUID === "function") return cryptoObj.randomUUID().replace(/-/g, "");
    return `r${Date.now().toString(16)}${Math.floor(Math.random() * 1e8).toString(16)}`;
  }
  function createApi(fetchImpl) {
    const doFetch = fetchImpl || globalThis.fetch;
    return async function api(path, options) {
      const opts = options || {};
      if (typeof doFetch !== "function") {
        const error = new Error("Bağlantı kurulamadı.");
        error.status = 0;
        error.code = "offline";
        throw error;
      }
      let response;
      try {
        response = await doFetch(path, {
          method: "GET",
          signal: opts.signal,
          headers: { Accept: "application/json", "X-Request-ID": requestId() },
        });
      } catch (cause) {
        if (cause && cause.name === "AbortError") throw cause;
        const error = new Error("Bağlantı kurulamadı.");
        error.status = 0;
        error.code = "offline";
        throw error;
      }
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = new Error(text(body && body.error && body.error.message) || text(body && body.detail));
        error.status = response.status;
        error.code = text(body && body.error && body.error.code);
        const retry = response.headers && response.headers.get && response.headers.get("Retry-After");
        if (retry) error.retryAfter = retry;
        throw error;
      }
      return unwrap(body);
    };
  }

  function ensureCss() {
    if (typeof document === "undefined") return;
    if (document.querySelector("link[data-cizgi-sports-css]")) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = CSS_HREF;
    link.dataset.cizgiSportsCss = "1";
    (document.head || document.documentElement).appendChild(link);
  }

  function mount(container, options) {
    const settings = options || {};
    const api = settings.api;
    const onFollowTeam = typeof settings.onFollowTeam === "function" ? settings.onFollowTeam : function () {};
    const onOpenMatch = typeof settings.onOpenMatch === "function" ? settings.onOpenMatch : function () {};
    const uid = `cizgi-sports-${Math.floor(Math.random() * 1e9).toString(36)}`;
    const state = {
      tab: "live",
      surface: "both",
      competition: "",
      competitions: [],
      compError: "",
      date: istanbulToday(),
      followed: new Set(asArray(settings.followedTeams).map(cleanId).filter(Boolean)),
      liveCount: null,
      loading: true,
      refreshing: false,
      pausePoll: false,
      limited: false,
      error: "",
      banner: "",
      notice: "",
      matches: [],
      standings: [],
      teams: [],
      meta: null,
      teamQuery: "",
      failure: false,
      destroyed: false,
      ssSlug: "turkish-super-league",
      ssWidget: "fixtures",
      ssLoaded: false,
      ssSrc: "",
      ssLoadedAt: 0,
    };
    let viewGen = 0;
    let viewAbort = null;
    let compAbort = null;
    let pollTimer = 0;
    let ssTimer = 0;

    ensureCss();

    if (!container || typeof api !== "function") {
      if (container) {
        container.innerHTML = `<section class="cizgi-sports"><p class="cs-alert">Spor servisi bağlanamadı.</p></section>`;
      }
      return { destroy() {}, setFollowedTeams() {} };
    }

    function providerLabel() {
      return (state.meta && state.meta.provider) || "football-data.org";
    }
    function syncSsFromCompetition() {
      const mapped = SS_BY_FD[String(state.competition || "").toUpperCase()];
      if (mapped && SS_VERIFIED.has(mapped)) state.ssSlug = mapped;
    }
    function ssUrl() {
      return sportScoreEmbedUrl({
        widget: state.ssWidget,
        sport: "football",
        type: "competition",
        slug: state.ssSlug,
      });
    }
    function ssUnavailablePanel() {
      return `<div class="cs-ss-error" role="alert">
        <p class="cs-ss-error-title">SportScore gömüsü kullanılamıyor</p>
        <p class="cs-ss-error-body">Bu lig için doğrulanmış bir gömü yok. Kırık iframe gösterilmiyor. Slug’ları <a href="https://sportscore.com/embed/" rel="noopener noreferrer" target="_blank">sportscore.com/embed</a> üzerinden kontrol edebilirsin.</p>
        <button type="button" class="cs-ss-retry" data-ss-retry>Yeniden dene</button>
      </div>`;
    }
    function shouldReloadSs(nextSrc) {
      if (!state.ssLoaded || !state.ssSrc) return true;
      if (state.ssSrc !== nextSrc) return true;
      return (Date.now() - state.ssLoadedAt) >= SS_REFRESH_MS;
    }
    function markSsLoaded(src) {
      state.ssLoaded = true;
      state.ssSrc = src;
      state.ssLoadedAt = Date.now();
      clearTimeout(ssTimer);
      ssTimer = setTimeout(() => {
        if (state.destroyed) return;
        state.ssLoaded = false;
        render();
      }, SS_REFRESH_MS);
      if (ssTimer && typeof ssTimer.unref === "function") ssTimer.unref();
    }
    function crestHtml(url, name) {
      const letter = esc(initialOf(name));
      if (!url) return `<span class="cs-crest cs-crest-fallback" aria-hidden="true">${letter}</span>`;
      return `<img class="cs-crest" alt="" data-initial="${letter}" referrerpolicy="no-referrer" src="${esc(url)}">`;
    }
    function followButton(id, name, pressed) {
      if (!id) return "";
      const label = pressed ? "Takipte" : "Takip et";
      const spoken = pressed ? `${name} takibi kapat` : `${name} takip et`;
      return `<button class="cs-follow" type="button" data-follow="${esc(id)}" aria-pressed="${pressed ? "true" : "false"}" aria-label="${esc(spoken)}">${label}</button>`;
    }
    function renderMatch(match, index) {
      const view = statusView(match.status, match.minute);
      const badge = `<span class="cs-badge${view.gold ? " cs-badge-live" : ""}">${esc(view.label)}</span>`;
      const comp = match.competitionName ? `<span class="cs-comp">${esc(match.competitionName)}</span>` : "";
      const tag = `<span class="cs-provider-tag">${esc(match.provider || providerLabel())}</span>`;
      const row = (club) => `<span class="cs-side">${crestHtml(club.crest, club.name)}<span class="cs-name" title="${esc(club.name)}">${esc(club.name)}</span><span class="cs-score">${esc(scoreCell(match.score, club === match.home ? "home" : "away"))}</span></span>`;
      const kick = match.localTime ? `${match.localTime} TSİ` : "Saat yok";
      return `<button class="cs-match" type="button" data-match="${index}"><span class="cs-match-top">${badge}${comp}${tag}</span>${row(match.home)}${row(match.away)}<span class="cs-kick"><span>${esc(kick)}</span><span>Europe/Istanbul</span></span></button>`;
    }
    function renderStanding(row) {
      const pressed = row.team.id && state.followed.has(row.team.id);
      const stats = [
        ["O", cell(row.played)], ["G", cell(row.won)], ["B", cell(row.drawn)],
        ["M", cell(row.lost)], ["Av", diffCell(row.goalsDiff)], ["P", cell(row.points)],
      ].map(([key, value]) => `<span class="cs-stat"><span class="cs-stat-k">${key}</span>${esc(value)}</span>`).join("");
      return `<article class="cs-standing"><span class="cs-rank">${esc(cell(row.rank))}</span><div class="cs-team-id">${crestHtml(row.team.crest, row.team.name)}<span class="cs-name" title="${esc(row.team.name)}">${esc(row.team.name)}</span></div><div class="cs-stats">${stats}</div>${followButton(row.team.id, row.team.name, pressed)}</article>`;
    }
    function renderTeam(team) {
      const pressed = team.id && state.followed.has(team.id);
      const venue = team.venue ? `<p class="cs-venue">${esc(team.venue)}</p>` : "";
      return `<article class="cs-team"><div class="cs-team-id">${crestHtml(team.crest, team.name)}<div><span class="cs-name">${esc(team.name)}</span>${venue}</div></div>${followButton(team.id, team.name, pressed)}</article>`;
    }
    function leagueControl() {
      if (state.compError) return `<p class="cs-alert">${esc(state.compError)}</p>`;
      if (!state.competitions.length) {
        return `<p class="cs-limit" role="status">Lig listesi boş. Bu anahtarla Türkiye ligleri (Süper Lig / 1. Lig) football-data.org kapsamında yok. SportScore sütunundan Türkiye skorlarına bakabilirsin.</p>`;
      }
      const current = state.competitions.find((item) => item.id === state.competition);
      const emblem = current && current.emblem ? crestHtml(current.emblem, current.name) : "";
      const optionsHtml = state.competitions.map((item) => {
        const label = item.area ? `${item.name} · ${item.area}` : item.name;
        return `<option value="${esc(item.id)}"${item.id === state.competition ? " selected" : ""}>${esc(label)}</option>`;
      }).join("");
      return `<div class="cs-league-row">${emblem}<label class="cs-field"><span>Lig (football-data)</span><select id="${uid}-league">${optionsHtml}</select></label></div>`;
    }
    function dayControl() {
      if (state.tab === "live" || state.tab === "standings" || state.tab === "teams") return "";
      return `<div class="cs-day"><button type="button" data-shift="-1">Önceki</button><button type="button" data-shift="1">Sonraki</button><button type="button" data-today>Bugün</button><label class="cs-field"><span class="cs-sr">Gün</span><input id="${uid}-date" type="date" value="${esc(state.date)}"></label><p class="cs-day-label">${esc(formatDay(state.date))}</p></div>`;
    }
    function tabs() {
      return TABS.map(([id, label]) => {
        const selected = state.tab === id;
        let extra = "";
        let spoken = label;
        if (id === "live" && state.liveCount !== null) {
          extra = `<span class="cs-count${state.liveCount > 0 ? " cs-count-live" : ""}">${state.liveCount}</span>`;
          spoken = `Canlı, ${state.liveCount} maç`;
        }
        return `<button class="cs-tab" type="button" role="tab" id="${uid}-tab-${id}" data-tab="${id}" aria-selected="${selected ? "true" : "false"}" aria-controls="${uid}-panel" tabindex="${selected ? "0" : "-1"}" aria-label="${esc(spoken)}">${esc(label)}${extra}</button>`;
      }).join("");
    }
    function messageBox(textMsg) {
      const klass = state.failure ? "cs-alert" : "cs-empty";
      const role = state.failure ? "alert" : "status";
      return `<div class="${klass}" role="${role}"><p>${esc(textMsg)}</p><button class="cs-refresh" type="button" data-refresh>Yenile</button></div>`;
    }
    function panelBody() {
      if (state.loading && !state.refreshing) {
        return `<p class="cs-loading">Yükleniyor</p><div class="cs-skel"></div><div class="cs-skel"></div><div class="cs-skel"></div>`;
      }
      const bits = [];
      if (state.banner) bits.push(`<div class="cs-banner" role="status"><p>${esc(state.banner)}</p></div>`);
      if (state.notice) bits.push(`<div class="cs-limit" role="note"><p>${esc(state.notice)}</p></div>`);
      if (state.error && !state.matches.length && !state.standings.length && !state.teams.length && state.tab !== "standings" && state.tab !== "teams") {
        bits.push(messageBox(state.error));
        return bits.join("");
      }
      if (state.tab === "standings") {
        if (!state.standings.length) {
          bits.push(messageBox(state.error || EMPTY.standings));
          return bits.join("");
        }
        const head = `<div class="cs-table-head" aria-hidden="true"><span>#</span><span>Takım</span><span>O</span><span>G</span><span>B</span><span>M</span><span>Av</span><span>P</span><span></span></div>`;
        bits.push(`<div class="cs-standings">${head}${state.standings.map(renderStanding).join("")}</div>`);
        return bits.join("");
      }
      if (state.tab === "teams") {
        const query = state.teamQuery.trim().toLocaleLowerCase("tr-TR");
        const teams = state.teams.filter((team) => {
          if (!query) return true;
          return team.name.toLocaleLowerCase("tr-TR").includes(query) || team.shortName.toLocaleLowerCase("tr-TR").includes(query);
        }).slice().sort((a, b) => Number(b.id && state.followed.has(b.id)) - Number(a.id && state.followed.has(a.id)));
        bits.push(`<label class="cs-field"><span>Takım ara</span><input id="${uid}-team-filter" type="search" maxlength="40" value="${esc(state.teamQuery)}" placeholder="Ad yaz"></label>`);
        if (!state.teams.length) {
          bits.push(messageBox(state.error || EMPTY.teams));
          return bits.join("");
        }
        if (!teams.length) {
          bits.push(`<p class="cs-limit" role="status">Bu aramayla eşleşen takım yok.</p>`);
          return bits.join("");
        }
        bits.push(`<div class="cs-teams">${teams.map(renderTeam).join("")}</div>`);
        return bits.join("");
      }
      if (!state.matches.length) {
        bits.push(messageBox(state.error || EMPTY[state.tab] || EMPTY.live));
        return bits.join("");
      }
      bits.push(`<div class="cs-matches">${state.matches.map(renderMatch).join("")}</div>`);
      return bits.join("");
    }
    function ssPanel() {
      const next = ssUrl();
      const loadNow = Boolean(next) && shouldReloadSs(next);
      if (loadNow && next) markSsLoaded(next);
      const src = next ? (loadNow ? next : (state.ssSrc || next)) : "";
      const options = SS_PRESETS.map((item) => (
        `<option value="${esc(item.id)}"${item.id === state.ssSlug ? " selected" : ""}>${esc(item.label)}</option>`
      )).join("");
      const widgetOpts = [
        ["fixtures", "Fikstür"],
        ["standings", "Puan durumu"],
        ["tracker", "Canlı izleyici"],
      ].map(([id, label]) => `<option value="${esc(id)}"${id === state.ssWidget ? " selected" : ""}>${esc(label)}</option>`).join("");
      const frame = src
        ? `<iframe class="cs-ss-frame" src="${esc(src)}" title="SportScore ${esc(state.ssWidget)} widget" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`
        : ssUnavailablePanel();
      return `<div class="cs-ss-card">
        <div class="cs-ss-head">
          <span class="cs-provider-tag">SportScore</span>
          <p class="cs-ss-note">Gömü yalnızca bu sekmede yüklenir · en az 5 dk yenileme</p>
        </div>
        <div class="cs-ss-controls">
          <label class="cs-field"><span>Lig (SportScore)</span><select id="${uid}-ss-slug">${options}</select></label>
          <label class="cs-field"><span>Widget</span><select id="${uid}-ss-widget">${widgetOpts}</select></label>
        </div>
        ${frame}
        <p class="cs-ss-attr">
          <a href="https://sportscore.com/" rel="dofollow" title="Live sports scores by SportScore">Powered by SportScore</a>
          · <a href="https://sportscore.com/" rel="dofollow">Data by SportScore</a>
        </p>
      </div>`;
    }
    function surfaceTabs() {
      const items = [
        ["native", "Çizgi skorlar"],
        ["sportscore", "SportScore"],
        ["both", "Yan yana"],
      ];
      return `<div class="cs-surface-tabs" role="tablist" aria-label="Skor sağlayıcıları">${items.map(([id, label]) => (
        `<button type="button" class="cs-surface-tab" data-surface="${id}" aria-selected="${state.surface === id ? "true" : "false"}">${esc(label)}</button>`
      )).join("")}</div>`;
    }
    function render() {
      let activeId = "";
      let selectionStart = null;
      let selectionEnd = null;
      if (typeof document !== "undefined" && document.activeElement && container.contains(document.activeElement)) {
        activeId = document.activeElement.id || "";
        if (typeof document.activeElement.selectionStart === "number") {
          selectionStart = document.activeElement.selectionStart;
          selectionEnd = document.activeElement.selectionEnd;
        }
      }
      const tabId = `${uid}-tab-${state.tab}`;
      const showNative = state.surface === "native" || state.surface === "both";
      const showSs = state.surface === "sportscore" || state.surface === "both";
      const nativeCol = showNative ? `<div class="cs-col cs-col-native" data-surface-panel="native">
        <div class="cs-col-head"><span class="cs-provider-tag">${esc(providerLabel())}</span></div>
        <div class="cs-toolbar"><div class="cs-league">${leagueControl()}</div>${dayControl()}</div>
        <div class="cs-tabs" role="tablist" aria-label="Spor bölümleri">${tabs()}</div>
        <div class="cs-panel" role="tabpanel" id="${uid}-panel" aria-labelledby="${tabId}">${panelBody()}</div>
      </div>` : "";
      const ssCol = showSs ? `<div class="cs-col cs-col-ss" data-surface-panel="sportscore">${ssPanel()}</div>` : "";
      container.innerHTML = `<section class="cizgi-sports" aria-busy="${state.loading ? "true" : "false"}">
        <header class="cs-head">
          <div>
            <p class="cs-kicker">Spor merkezi</p>
            <h2 id="${uid}-title">Skorlar</h2>
            <p class="cs-source" role="status">${esc(sourceLine(state.meta, state.refreshing))}</p>
          </div>
          <button class="cs-refresh" type="button" data-refresh>Yenile</button>
        </header>
        ${surfaceTabs()}
        <div class="cs-split cs-split-${esc(state.surface)}">${nativeCol}${ssCol}</div>
      </section>`;
      if (activeId && typeof document !== "undefined") {
        const next = document.getElementById(activeId);
        if (next && container.contains(next)) {
          next.focus();
          if (selectionStart !== null && next.setSelectionRange) {
            try { next.setSelectionRange(selectionStart, selectionEnd); } catch { /* date */ }
          }
        }
      }
    }
    function params(extra) {
      return Object.assign({ competition: state.competition }, extra);
    }
    async function call(kind, query, signal) {
      return unwrap(await api(sportsPath(kind, query), { signal }));
    }
    async function loadMatches(bucket, date, signal) {
      const payload = await call("matches", params({ bucket, date }), signal);
      return {
        meta: normalizeMeta(payload),
        matches: asArray(payload.matches).map(normalizeMatch).filter(Boolean),
        standings: [],
        teams: [],
      };
    }
    async function attempt(run) {
      try {
        return { page: await run(), fail: null };
      } catch (error) {
        if (error && error.name === "AbortError") throw error;
        return { page: null, fail: error };
      }
    }
    function fromPage(page, banner, empty) {
      const matches = page.matches.slice(0, 80);
      const notes = [];
      const limitation = limitationText(page.meta);
      if (limitation) notes.push(limitation);
      if (page.matches.length > 80) notes.push("İlk 80 karşılaşma gösteriliyor.");
      const note = notes.join(" ");
      const noRows = !matches.length && !page.standings.length && !page.teams.length;
      return {
        meta: page.meta,
        matches,
        standings: page.standings,
        teams: page.teams,
        banner: banner || "",
        notice: noRows ? "" : note,
        error: noRows ? (note || empty) : "",
      };
    }
    async function fetchLive(signal) {
      const live = await attempt(() => loadMatches("live", "", signal));
      if (live.fail && hardStatus(live.fail)) {
        state.liveCount = null;
        throw live.fail;
      }
      state.liveCount = live.page ? live.page.matches.length : null;
      if (live.page && live.page.matches.length) return fromPage(live.page, "", "");
      const today = await attempt(() => loadMatches("today", istanbulToday(), signal));
      if (today.page && today.page.matches.length) {
        return fromPage(today.page, "Şu an canlı maç yok. Bugünün fikstürü gösteriliyor.", "");
      }
      const upcoming = await attempt(() => loadMatches("scheduled", "", signal));
      if (upcoming.page && upcoming.page.matches.length) {
        return fromPage(upcoming.page, "Şu an canlı maç yok. Yaklaşan maçlar gösteriliyor.", "");
      }
      const finished = await attempt(() => loadMatches("finished", "", signal));
      if (finished.page && finished.page.matches.length) {
        return fromPage(finished.page, "Şu an canlı maç yok. Son sonuçlar gösteriliyor.", "");
      }
      const pages = [live, today, upcoming, finished].map((item) => item.page).filter(Boolean);
      const limitation = pages.map((page) => limitationText(page.meta)).find(Boolean) || "";
      const failure = [live, today, upcoming, finished].map((item) => item.fail).find(Boolean);
      if (!limitation && failure) throw failure;
      return {
        meta: pages[0] ? pages[0].meta : null,
        matches: [],
        standings: [],
        teams: [],
        banner: "",
        notice: "",
        error: limitation || EMPTY.live,
      };
    }
    async function fetchTab(signal) {
      if (state.tab === "live") return fetchLive(signal);
      if (state.tab === "standings") {
        const payload = await call("standings", params({}), signal);
        const page = {
          meta: normalizeMeta(payload),
          matches: [],
          standings: asArray(payload.standings).map(normalizeStanding).filter(Boolean),
          teams: [],
        };
        return fromPage(page, "", EMPTY.standings);
      }
      if (state.tab === "teams") {
        const payload = await call("teams", params({}), signal);
        const page = {
          meta: normalizeMeta(payload),
          matches: [],
          standings: [],
          teams: asArray(payload.teams).map(normalizeTeam).filter(Boolean),
        };
        return fromPage(page, "", EMPTY.teams);
      }
      const page = await loadMatches(state.tab, state.date, signal);
      return fromPage(page, "", EMPTY[state.tab] || EMPTY.live);
    }
    function apply(result) {
      state.meta = result.meta;
      state.matches = result.matches;
      state.standings = result.standings;
      state.teams = result.teams;
      state.banner = result.banner;
      state.notice = result.notice;
      state.error = result.error;
      state.limited = Boolean(result.meta && result.meta.limited);
      state.pausePoll = state.limited;
      state.failure = false;
      state.loading = false;
      state.refreshing = false;
    }
    function schedulePoll() {
      clearTimeout(pollTimer);
      pollTimer = 0;
      if (state.destroyed || state.tab !== "live" || state.pausePoll || state.limited) return;
      pollTimer = setTimeout(() => {
        if (state.destroyed) return;
        if (typeof document !== "undefined" && document.visibilityState === "hidden") {
          schedulePoll();
          return;
        }
        loadView({ silent: true });
      }, 60000);
      if (pollTimer && typeof pollTimer.unref === "function") pollTimer.unref();
    }
    async function refreshLiveCount(signal, gen) {
      if (state.tab === "live") return;
      try {
        const page = await loadMatches("live", "", signal);
        if (gen !== viewGen || signal.aborted) return;
        state.liveCount = page.matches.length;
      } catch (error) {
        if (gen !== viewGen || (error && error.name === "AbortError")) return;
        state.liveCount = null;
      }
      if (gen === viewGen && !state.destroyed) render();
    }
    async function loadView(flags) {
      const silent = Boolean(flags && flags.silent);
      viewAbort?.abort();
      viewAbort = new AbortController();
      const signal = viewAbort.signal;
      const gen = ++viewGen;
      if (!silent) {
        state.loading = true;
        state.refreshing = false;
        state.error = "";
        state.banner = "";
        state.notice = "";
        state.matches = [];
        state.standings = [];
        state.teams = [];
      } else {
        state.refreshing = true;
      }
      render();
      try {
        const result = await fetchTab(signal);
        if (gen !== viewGen || state.destroyed) return;
        apply(result);
      } catch (error) {
        if (signal.aborted || (error && error.name === "AbortError") || state.destroyed || gen !== viewGen) return;
        state.loading = false;
        state.refreshing = false;
        state.pausePoll = hardStatus(error);
        const keep = silent && (state.matches.length || state.standings.length || state.teams.length);
        if (keep) {
          state.notice = humanError(error);
          state.failure = false;
        } else {
          state.failure = true;
          state.error = humanError(error);
          state.matches = [];
          state.standings = [];
          state.teams = [];
          state.banner = "";
        }
      }
      if (gen === viewGen && !state.destroyed) {
        render();
        schedulePoll();
        refreshLiveCount(signal, gen);
      }
    }
    async function loadCompetitions() {
      compAbort?.abort();
      compAbort = new AbortController();
      const signal = compAbort.signal;
      try {
        const payload = await call("competitions", {}, signal);
        if (signal.aborted || state.destroyed) return;
        const rows = asArray(payload.competitions).map(normalizeCompetition).filter(Boolean);
        state.competitions = rows;
        state.compError = "";
        if (!rows.some((item) => item.id === state.competition)) state.competition = rows.length ? rows[0].id : "";
        /* SportScore varsayılanı turkish-super-league; native ilk lig (BSA vb.) SS slug’unu ezmesin. */
        if (payload && typeof payload === "object") {
          const meta = normalizeMeta(payload);
          if (meta.limited && meta.limitation && !state.notice) {
            /* competitions limited flag is informational for Turkey gap */
          }
        }
      } catch (error) {
        if (signal.aborted || (error && error.name === "AbortError") || state.destroyed) return;
        state.competitions = [];
        state.competition = "";
        state.compError = humanError(error);
      }
    }
    function onClick(event) {
      const target = event.target.closest("button");
      if (!target || !container.contains(target)) return;
      if (target.hasAttribute("data-refresh")) {
        state.pausePoll = false;
        state.ssLoaded = false;
        boot();
        return;
      }
      if (target.hasAttribute("data-ss-retry")) {
        if (!SS_VERIFIED.has(state.ssSlug)) state.ssSlug = "turkish-super-league";
        state.ssLoaded = false;
        state.ssSrc = "";
        render();
        return;
      }
      if (target.hasAttribute("data-surface")) {
        state.surface = target.getAttribute("data-surface") || "both";
        if (state.surface === "sportscore" || state.surface === "both") {
          /* lazy: first paint of ss panel loads iframe */
        }
        render();
        return;
      }
      if (target.hasAttribute("data-tab")) {
        state.tab = target.getAttribute("data-tab");
        loadView();
        return;
      }
      if (target.hasAttribute("data-shift")) {
        state.date = shiftDate(state.date, Number(target.getAttribute("data-shift")));
        loadView();
        return;
      }
      if (target.hasAttribute("data-today")) {
        state.date = istanbulToday();
        loadView();
        return;
      }
      if (target.hasAttribute("data-follow")) {
        const id = target.getAttribute("data-follow");
        if (!id) return;
        const next = target.getAttribute("aria-pressed") !== "true";
        try {
          onFollowTeam(id, next);
        } catch {
          state.error = "Takip güncellenemedi.";
          render();
          return;
        }
        if (next) state.followed.add(id);
        else state.followed.delete(id);
        render();
        return;
      }
      if (target.hasAttribute("data-match")) {
        const match = state.matches[Number(target.getAttribute("data-match"))];
        if (!match) return;
        try {
          onOpenMatch({
            id: match.id,
            competition: match.competitionName,
            status: match.status,
            minute: match.minute && /^\d+$/.test(match.minute) ? Number(match.minute) : match.minute,
            local_time: match.localTime,
            home: { id: match.home.id, name: match.home.name, crest: match.home.crest },
            away: { id: match.away.id, name: match.away.name, crest: match.away.crest },
            score: match.score ? { home: match.score.home, away: match.score.away } : null,
          });
        } catch { /* üst katman */ }
      }
    }
    function onChange(event) {
      if (event.target.id === `${uid}-league`) {
        state.competition = event.target.value;
        syncSsFromCompetition();
        state.ssLoaded = false;
        loadView();
        return;
      }
      if (event.target.id === `${uid}-date` && /^\d{4}-\d{2}-\d{2}$/.test(event.target.value)) {
        state.date = event.target.value;
        loadView();
        return;
      }
      if (event.target.id === `${uid}-ss-slug`) {
        const picked = sanitizeSlug(event.target.value);
        state.ssSlug = SS_VERIFIED.has(picked) ? picked : "turkish-super-league";
        state.ssLoaded = false;
        state.ssSrc = "";
        render();
        return;
      }
      if (event.target.id === `${uid}-ss-widget`) {
        const w = String(event.target.value || "").toLowerCase();
        state.ssWidget = SS_WIDGETS.has(w) ? w : "fixtures";
        state.ssLoaded = false;
        render();
      }
    }
    function onInput(event) {
      if (event.target.id !== `${uid}-team-filter`) return;
      state.teamQuery = String(event.target.value || "").slice(0, 40);
      render();
    }
    function onKeydown(event) {
      if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
      const current = event.target.closest && event.target.closest("[data-tab]");
      if (!current || !container.contains(current)) return;
      const tabsEl = Array.from(container.querySelectorAll("[data-tab]"));
      const index = tabsEl.indexOf(current);
      if (index < 0) return;
      event.preventDefault();
      const next = tabsEl[(index + (event.key === "ArrowRight" ? 1 : tabsEl.length - 1)) % tabsEl.length];
      next.focus();
      next.click();
    }
    function onError(event) {
      const img = event.target;
      if (!img || img.tagName !== "IMG" || !container.contains(img)) return;
      const fallback = document.createElement("span");
      fallback.className = "cs-crest cs-crest-fallback";
      fallback.setAttribute("aria-hidden", "true");
      fallback.textContent = img.getAttribute("data-initial") || "?";
      img.replaceWith(fallback);
    }
    function onVisible() {
      if (typeof document !== "undefined" && document.visibilityState === "visible" && state.tab === "live" && !state.pausePoll) {
        loadView({ silent: true });
      }
    }
    async function boot() {
      state.pausePoll = false;
      await loadCompetitions();
      if (!state.destroyed) await loadView();
    }
    function destroy() {
      state.destroyed = true;
      viewAbort?.abort();
      compAbort?.abort();
      clearTimeout(pollTimer);
      clearTimeout(ssTimer);
      container.removeEventListener("click", onClick);
      container.removeEventListener("change", onChange);
      container.removeEventListener("input", onInput);
      container.removeEventListener("keydown", onKeydown);
      container.removeEventListener("error", onError, true);
      if (typeof document !== "undefined") document.removeEventListener("visibilitychange", onVisible);
      container.innerHTML = "";
    }
    function setFollowedTeams(ids) {
      state.followed = new Set(asArray(ids).map(cleanId).filter(Boolean));
      if (!state.destroyed) render();
    }

    container.addEventListener("click", onClick);
    container.addEventListener("change", onChange);
    container.addEventListener("input", onInput);
    container.addEventListener("keydown", onKeydown);
    container.addEventListener("error", onError, true);
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", onVisible);
    render();
    boot();
    return { destroy, setFollowedTeams };
  }

  /* ——— Self-boot: app.js'e yazmadan #/spor ——— */
  let selfHandle = null;
  let selfHost = null;
  let selfObserver = null;
  let selfQueued = false;

  function isSportsHash() {
    const hash = String((typeof location !== "undefined" && location.hash) || "");
    return hash === "#/spor" || hash.startsWith("#/spor?") || hash.startsWith("#/spor/")
      || hash === "#/sports" || hash.startsWith("#/sports?") || hash.startsWith("#/sports/");
  }

  function findHost() {
    if (typeof document === "undefined") return null;
    return document.querySelector("#sports-root")
      || document.querySelector("[data-cizgi-sports]")
      || document.querySelector("#sports-data");
  }

  function ensureHost() {
    let host = findHost();
    if (host) return host;
    const main = document.querySelector("#icerik") || document.querySelector("#app");
    if (!main) return null;
    host = document.createElement("div");
    host.id = "sports-root";
    host.setAttribute("data-cizgi-sports", "");
    main.insertBefore(host, main.firstChild);
    return host;
  }

  function tearDownSelf() {
    if (selfHandle && typeof selfHandle.destroy === "function") {
      try { selfHandle.destroy(); } catch { /* ignore */ }
    }
    selfHandle = null;
    selfHost = null;
  }

  function mountSelf() {
    if (!isSportsHash()) {
      tearDownSelf();
      if (selfObserver) {
        selfObserver.disconnect();
        selfObserver = null;
      }
      return;
    }
    ensureCss();
    const host = ensureHost();
    if (!host) {
      if (!selfQueued) {
        selfQueued = true;
        requestAnimationFrame(() => {
          selfQueued = false;
          mountSelf();
        });
      }
      return;
    }
    if (selfHandle && selfHost === host && host.querySelector(".cizgi-sports")) return;
    tearDownSelf();
    selfHost = host;
    selfHandle = mount(host, {
      api: createApi(),
      followedTeams: [],
      onFollowTeam() {},
      onOpenMatch() {},
    });
    if (!selfObserver && typeof MutationObserver === "function") {
      const root = document.querySelector("#app");
      if (root) {
        selfObserver = new MutationObserver(() => {
          if (!isSportsHash()) return;
          const next = findHost();
          if (!next || !next.querySelector(".cizgi-sports")) {
            tearDownSelf();
            mountSelf();
          }
        });
        selfObserver.observe(root, { childList: true, subtree: true });
      }
    }
  }

  let selfPoll = 0;

  function bootSelf() {
    if (typeof window === "undefined" || typeof document === "undefined") return;
    const run = () => {
      try { mountSelf(); } catch { /* self-boot sessiz */ }
    };
    const reclaim = () => {
      clearInterval(selfPoll);
      selfPoll = 0;
      if (!isSportsHash()) return;
      let ticks = 0;
      selfPoll = setInterval(() => {
        ticks += 1;
        if (!isSportsHash() || ticks > 40) {
          clearInterval(selfPoll);
          selfPoll = 0;
          return;
        }
        const host = findHost();
        if (host && !host.querySelector(".cizgi-sports")) {
          tearDownSelf();
          run();
        }
      }, 250);
      if (selfPoll && typeof selfPoll.unref === "function") selfPoll.unref();
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => { run(); reclaim(); }, { once: true });
    } else {
      run();
      reclaim();
    }
    window.addEventListener("hashchange", () => { run(); reclaim(); });
    setTimeout(run, 0);
    setTimeout(run, 120);
    setTimeout(run, 400);
    setTimeout(run, 1000);
  }

  return {
    mount,
    createApi,
    bootSelf,
    sportScoreEmbedUrl,
    _internal: {
      humanError, normalizeMatch, normalizeCompetition, normalizeStanding, normalizeTeam,
      normalizeMeta, httpsUrl, scoreCell, istanbulToday, shiftDate, sourceLine, statusView,
      sanitizeSlug, sportScoreEmbedUrl,
    },
  };
});
