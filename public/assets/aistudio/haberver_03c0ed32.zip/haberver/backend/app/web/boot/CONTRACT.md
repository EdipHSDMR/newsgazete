# Çizgi boot — ilk açılış

Stale-while-revalidate istemci yardımcısı. Ana sayfa ajanı bu modülü kullanır; `home.js` / spor / hava bu teslimde değişmez.

## Dosyalar

- `/static/boot/boot.js` → `window.CizgiBoot`
- `/static/boot/boot.css` → `.cizgi-boot-skeleton`, `.cizgi-boot-bone*`

```html
<link rel="stylesheet" href="/static/boot/boot.css">
<script src="/static/boot/boot.js"></script>
```

## API

| Üye | Sözleşme |
| --- | --- |
| `cacheGet(key)` | `{ value, fresh, expiresAt }` veya `null`. Süresi dolmuş kayıt da döner (`fresh: false`). |
| `cacheSet(key, value, ttlMs)` | `localStorage` anahtarı `cizgi.boot.v1:{key}`. Varsayılan TTL 30000 ms. |
| `withTimeout(promise, ms)` | Süre aşımında `Error` (`code: "timeout"`). Varsayılan 8000 ms. |
| `fetchParallel(paths, options)` | Paralel GET. Hata/timeout’ta önceki cache (stale dahil) döner. |
| `setSkeleton(el, active)` | `cizgi-boot-skeleton` sınıfı + `aria-busy`. |

### `fetchParallel`

```js
window.CizgiBoot.fetchParallel(
  [
    "/v1/feed/bootstrap?limit=12",
    "/v1/topics",
    { path: "/v1/meta/inventory", key: "meta.inventory", ttlMs: 60000 }
  ],
  {
    api: hostApi,           // isteğe bağlı (path) => Promise
    timeoutMs: 8000,
    ttlMs: 30000,
    skeleton: containerEl   // isteğe bağlı
  }
).then(function (batch) {
  // batch.ok — hepsi ok (ağ veya cache)
  // batch.results[i] = { path, key, ok, fresh, fromCache, data, error }
});
```

- Taze cache varsa hemen döner; ağ arka planda yeniler (SWR).
- Ağ başarısız / timeout ve cache yoksa `ok: false`, `data: null`.
- Anahtar, belirteç veya kimlik bilgisi saklanmaz.

## Sunucu bootstrap sözleşmesi

### `GET /v1/feed/bootstrap?limit=12`

`limit` 1–30 (varsayılan 12). Konu ve imleç yok; sonraki sayfa `GET /v1/feed?cursor=...&limit=...`.

```json
{
  "request_id": "...",
  "data": {
    "items": [ /* StoryCard */ ],
    "next_cursor": "..." | null,
    "inventory": {
      "stored_public": 0,
      "provider_note": "..."
    },
    "cache_ttl_seconds": 30
  }
}
```

- `Cache-Control: public, max-age={cache_ttl_seconds}` (config `feed_cache_ttl_seconds`, varsayılan 30; hak bitişine göre kısalabilir).
- Sunucu önce bellek önbelleğine bakar; isabette `expire_due` çalışmaz.
- `items` / `next_cursor` biçimi `GET /v1/feed` ile aynıdır.

### `GET /v1/meta/inventory`

```json
{
  "request_id": "...",
  "data": {
    "stored_public": 0,
    "provider_note": "..."
  }
}
```

`feed_inventory(session)` çıktısıdır. `GET /v1/feed` gövdesine zorunlu eklenmez; isteğe bağlı `?include_inventory=true` ile feed’e de eklenebilir.

### `GET /v1/feed?include_inventory=true`

Mevcut `items` + `next_cursor` aynen kalır; `true` ise `data.inventory` eklenir.
