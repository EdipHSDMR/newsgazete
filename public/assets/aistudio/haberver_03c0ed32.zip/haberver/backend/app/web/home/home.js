/* Çizgi günün gazetesi. window.CizgiHome.mount — ayrıntı CONTRACT.md */
(function () {
  "use strict";

  var root = globalThis;

  var TOPIC_BAR = [
    { slug: "", name: "Gündem" },
    { slug: "ulusal", name: "Türkiye" },
    { slug: "dunya", name: "Dünya" },
    { slug: "ekonomi", name: "Ekonomi" },
    { slug: "spor", name: "Spor" },
    { slug: "kultur", name: "Magazin" },
    { slug: "bilim-teknoloji", name: "Teknoloji" },
    { slug: "yasam", name: "Yaşam" },
    { slug: "yerel", name: "Yerel" },
    { slug: "__hava", name: "Hava", stub: "hava" },
    { slug: "__piyasalar", name: "Piyasalar", stub: "piyasalar" },
  ];

  var FALLBACK_TOPICS = [
    { slug: "ulusal", name: "Türkiye" },
    { slug: "dunya", name: "Dünya" },
    { slug: "ekonomi", name: "Ekonomi" },
    { slug: "bilim-teknoloji", name: "Teknoloji" },
    { slug: "kultur", name: "Magazin" },
    { slug: "yasam", name: "Yaşam" },
    { slug: "spor", name: "Spor" },
    { slug: "yerel", name: "Yerel" },
  ];

  var SECTIONS = [
    { id: "turkiye", title: "Türkiye" },
    { id: "dunya", title: "Dünya" },
    { id: "ekonomi", title: "Ekonomi" },
    { id: "teknoloji", title: "Teknoloji" },
    { id: "yasam", title: "Yaşam / Kültür" },
    { id: "spor", title: "Spor" },
  ];

  var sessions = new WeakMap();
  var generation = 0;
  var numberFormat = new Intl.NumberFormat("tr-TR");
  var responseCache = new Map();
  var CACHE_TTL_MS = 45000;
  var TZ = "Europe/Istanbul";
  var FIRST_LIMIT = 24;
  var BOOTSTRAP_PATH = "/v1/feed/bootstrap?limit=" + FIRST_LIMIT;
  var PAGE_LIMIT = 30;

  function clean(value) {
    return String(value == null ? "" : value).replace(/[\u0000-\u001F]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function esc(value) {
    return clean(value).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }

  function formatCount(value) {
    var n = Number(value);
    if (!Number.isFinite(n)) return "0";
    return numberFormat.format(Math.trunc(n));
  }

  function httpsUrl(value) {
    if (typeof value !== "string") return "";
    var trimmed = value.trim();
    if (!trimmed || trimmed.length > 2000) return "";
    try {
      var url = new URL(trimmed);
      if (url.protocol !== "https:" || url.username || url.password || !url.hostname) return "";
      return url.href;
    } catch (error) {
      return "";
    }
  }

  function isFiction(item) {
    if (!item || typeof item !== "object") return true;
    if (item.synthetic === true || item.synthetic === 1 || item.synthetic === "true") return true;
    var label = clean(item.display_label || "");
    if (/sentetik|kurmaca/i.test(label)) return true;
    var title = clean(item.editorial_title || "");
    if (/^örnek\s/i.test(title) || /^sentetik\b/i.test(title) || /^kurmaca\b/i.test(title)) return true;
    return false;
  }

  function isLive(item) {
    if (!item || typeof item !== "object") return false;
    if (!clean(item.id) || !clean(item.editorial_title)) return false;
    return !isFiction(item);
  }

  function titleOf(item) {
    return clean(item.editorial_title);
  }

  function priorityOf(item) {
    var value = Number(item && item.editor_priority);
    return Number.isFinite(value) ? value : 0;
  }

  function sourceCount(item) {
    var value = Number(item && item.source_count);
    return Number.isFinite(value) ? value : 0;
  }

  function isUpdated(item) {
    return item.updated_badge === true || item.updated_badge === 1 || item.updated_badge === "true";
  }

  function publisherName(item) {
    var name = clean(item && item.authorship_label);
    if (!name) return "";
    if (/sentetik|kurmaca/i.test(name) || /^örnek\b/i.test(name)) return "";
    return name;
  }

  function originalUrl(item) {
    if (!item || typeof item !== "object") return "";
    var candidates = [item.canonical_url, item.original_url, item.source_url, item.external_url];
    if (Array.isArray(item.sources)) {
      item.sources.forEach(function (source) {
        if (source) candidates.push(source.canonical_url);
      });
    }
    for (var i = 0; i < candidates.length; i += 1) {
      var url = httpsUrl(candidates[i]);
      if (url) return url;
    }
    return "";
  }

  function spot(text) {
    var cleanText = clean(text);
    if (!cleanText) return "";
    var sentences = cleanText.match(/[^.!?…]+[.!?…]+(?:\s|$)|[^.!?…]+$/g) || [];
    var out = "";
    var count = 0;
    for (var i = 0; i < sentences.length; i += 1) {
      var piece = sentences[i].trim();
      if (!piece) continue;
      var next = out ? out + " " + piece : piece;
      if (next.length > 280 && out) break;
      out = next.length > 280 ? next.slice(0, 277).trim() + "…" : next;
      count += 1;
      if (count >= 2 || out.endsWith("…")) break;
    }
    return out;
  }

  function oneSentence(text) {
    var cleanText = clean(text);
    if (!cleanText) return "";
    var match = cleanText.match(/^[^.!?…]+[.!?…]?/);
    var sentence = match ? match[0].trim() : cleanText;
    if (sentence.length > 160) sentence = sentence.slice(0, 157).trim() + "…";
    return sentence;
  }

  function parsePublished(iso) {
    if (iso == null || iso === "") return null;
    if (iso instanceof Date) {
      return Number.isNaN(iso.getTime()) ? null : iso;
    }
    var raw = String(iso).trim();
    if (!raw) return null;
    // Offset yoksa UTC kabul et (API ISO); yerel kayma "1 gün önce" hatasını önler.
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(raw)) {
      raw += "Z";
    }
    var date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatClock(msOrIso) {
    var date = typeof msOrIso === "number" ? new Date(msOrIso) : parsePublished(msOrIso);
    if (!date) return "";
    return new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ,
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    }).format(date);
  }

  function formatTime(iso) {
    return formatClock(iso);
  }

  function istanbulDayKey(date) {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(date);
  }

  function relativeWhen(iso) {
    var date = parsePublished(iso);
    if (!date) return "";
    var now = new Date();
    var mins = Math.max(0, Math.floor((now.getTime() - date.getTime()) / 60000));
    if (mins < 1) return "az önce";
    if (mins < 60) return mins + " dk önce";
    if (mins < 24 * 60) return Math.floor(mins / 60) + " saat önce";
    var todayKey = istanbulDayKey(now);
    var thatKey = istanbulDayKey(date);
    var todayNoon = Date.parse(todayKey + "T12:00:00Z");
    var thatNoon = Date.parse(thatKey + "T12:00:00Z");
    var days = Math.round((todayNoon - thatNoon) / 86400000);
    if (days <= 0) return formatClock(date);
    if (days === 1) return "1 gün önce";
    if (days < 7) return days + " gün önce";
    return new Intl.DateTimeFormat("tr-TR", {
      timeZone: TZ,
      day: "numeric",
      month: "short",
    }).format(date);
  }

  function todayLabel() {
    var date = new Date();
    var iso = date.getFullYear() + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
    var weekday = new Intl.DateTimeFormat("tr-TR", { weekday: "long" }).format(date);
    var rest = new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "long", year: "numeric" }).format(date);
    var label = weekday.charAt(0).toLocaleUpperCase("tr-TR") + weekday.slice(1);
    return { iso: iso, label: label + ", " + rest };
  }

  function sectionFor(item) {
    var slug = clean(item && item.topic_slug).toLocaleLowerCase("tr");
    var name = clean(item && item.topic_name).toLocaleLowerCase("tr");
    if (slug === "ulusal" || slug === "turkiye" || slug === "türkiye" || name === "türkiye" || name === "turkiye") return "turkiye";
    if (slug === "dunya" || slug === "dünya" || name === "dünya" || name === "dunya") return "dunya";
    if (slug === "ekonomi" || name === "ekonomi") return "ekonomi";
    if (slug === "bilim-teknoloji" || slug === "teknoloji" || slug === "bilim" || name.indexOf("bilim") !== -1 || name.indexOf("teknoloji") !== -1) return "teknoloji";
    if (slug === "kultur" || slug === "yasam" || slug === "yaşam" || slug === "kultur-yasam" || slug === "kultur-yaşam" || name.indexOf("kültür") !== -1 || name.indexOf("kultur") !== -1 || name.indexOf("magazin") !== -1 || name.indexOf("yaşam") !== -1 || name.indexOf("yasam") !== -1) return "yasam";
    if (slug === "spor" || name === "spor") return "spor";
    return "";
  }

  function normalizeTopics(value) {
    if (!Array.isArray(value)) return [];
    var rows = [];
    value.forEach(function (item) {
      if (typeof item === "string" && clean(item)) rows.push({ slug: clean(item), name: clean(item) });
      else if (Array.isArray(item) && item.length >= 2 && clean(item[0]) && clean(item[1])) rows.push({ slug: clean(item[0]), name: clean(item[1]) });
      else if (item && clean(item.slug) && clean(item.name)) rows.push({ slug: clean(item.slug), name: clean(item.name) });
    });
    return uniqueTopics(rows);
  }

  function uniqueTopics(rows) {
    var seen = new Set();
    var out = [];
    rows.forEach(function (row) {
      if (!row || seen.has(row.slug)) return;
      seen.add(row.slug);
      out.push(row);
    });
    return out;
  }

  function normalizeIdList(value) {
    var list = value instanceof Set ? Array.from(value) : Array.isArray(value) ? value : [];
    return list.filter(function (id) { return id != null && clean(id); }).map(function (id) { return String(id); });
  }

  function asList(payload) {
    if (Array.isArray(payload)) return payload;
    if (payload && Array.isArray(payload.items)) return payload.items;
    if (payload && Array.isArray(payload.data)) return payload.data;
    if (payload && payload.data && Array.isArray(payload.data.items)) return payload.data.items;
    return [];
  }

  function asPage(payload) {
    var source = payload;
    if (payload && typeof payload === "object" && !Array.isArray(payload.items) && payload.data && typeof payload.data === "object") source = payload.data;
    return {
      items: source && Array.isArray(source.items) ? source.items : [],
      next_cursor: source && source.next_cursor ? String(source.next_cursor) : "",
    };
  }

  function errorMessage(error) {
    var message = error && typeof error.message === "string" ? clean(error.message) : "";
    if (!message || message.length > 240) return "Bağlantı kurulamadı. Yeniden deneyebilirsin.";
    return message;
  }

  function unreadOf(options) {
    var value = Number(options && options.unreadCount);
    if (!Number.isFinite(value) || value <= 0) return 0;
    return Math.floor(value);
  }

  function publishedMs(item) {
    var date = parsePublished(item && item.published_at);
    return date ? date.getTime() : 0;
  }

  function dedupeFingerprint(item) {
    var title = titleOf(item).toLocaleLowerCase("tr");
    var canon = "";
    if (item && typeof item === "object") {
      canon = httpsUrl(item.canonical_url) || originalUrl(item);
    }
    return title + "\0" + canon;
  }

  function byNewest(list) {
    return list.slice().sort(function (a, b) {
      var dt = publishedMs(b) - publishedMs(a);
      if (dt) return dt;
      return String(b.id).localeCompare(String(a.id));
    });
  }

  function byRank(list) {
    return list.slice().sort(function (a, b) {
      var dp = priorityOf(b) - priorityOf(a);
      if (dp) return dp;
      var dt = publishedMs(b) - publishedMs(a);
      if (dt) return dt;
      return String(b.id).localeCompare(String(a.id));
    });
  }

  function mergeItems(bucket, batch) {
    var seenId = new Set();
    var seenFp = new Set();
    bucket.forEach(function (item) {
      if (!item || item.id == null) return;
      seenId.add(String(item.id));
      seenFp.add(dedupeFingerprint(item));
    });
    (batch || []).forEach(function (item) {
      if (!item || item.id == null) return;
      var id = String(item.id);
      if (seenId.has(id)) return;
      var fp = dedupeFingerprint(item);
      if (fp && seenFp.has(fp)) return;
      seenId.add(id);
      if (fp) seenFp.add(fp);
      bucket.push(item);
    });
  }

  function layoutTop(rows) {
    var slideCount = rows.length >= 5 ? 5 : rows.length >= 3 ? Math.min(5, rows.length) : rows.length;
    var slides = rows.slice(0, slideCount);
    var used = new Set(slides.map(function (item) { return String(item.id); }));
    var rest = rows.filter(function (item) { return !used.has(String(item.id)); });
    var sides = rest.slice(0, 4);
    var summary = rest.slice(4, 9);
    return { slides: slides, sides: sides, summary: summary };
  }

  function prefersReducedMotion() {
    return typeof root.matchMedia === "function" && root.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function brandMark() {
    return '<span class="cizgi-home-mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="28" height="28" focusable="false"><path class="cizgi-home-mark-line" d="M2.5,12H10.5" fill="none" stroke-width="2.5" stroke-linecap="round"/><path class="cizgi-home-mark-arrow" d="M16,7.75L21.5,12L16,16.25" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
  }

  function iconSearch() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="6.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M16 16.2 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
  }

  function iconBell() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 16V10a6 6 0 1 1 12 0v6l1.5 2h-15L6 16z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M10 19a2 2 0 0 0 4 0" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>';
  }

  function iconPerson() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="3.1" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5.5 19.4c1.4-3 3.5-4.5 6.5-4.5s5.1 1.5 6.5 4.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>';
  }

  function unwrapBoot(result) {
    if (result && typeof result === "object" && "data" in result && ("fromCache" in result || "fresh" in result)) {
      return result;
    }
    return { data: result, fromCache: false, fresh: true, savedAt: Date.now(), error: null };
  }

  function cachedFetch(api, path, signal, opts) {
    opts = opts || {};
    if (root.CizgiBoot && typeof root.CizgiBoot.fetch === "function") {
      return root.CizgiBoot.fetch(path, {
        api: api,
        signal: signal,
        key: opts.key || path,
        ttlMs: opts.ttlMs || CACHE_TTL_MS,
        swr: opts.swr !== false,
      }).then(unwrapBoot);
    }
    var hit = responseCache.get(path);
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) {
      Promise.resolve().then(function () {
        api(path).then(function (fresh) {
          responseCache.set(path, { at: Date.now(), data: fresh });
        }).catch(function () { /* stale kalır */ });
      });
      return Promise.resolve({ data: hit.data, fromCache: true, fresh: true, savedAt: hit.at, error: null });
    }
    return api(path).then(function (data) {
      var at = Date.now();
      responseCache.set(path, { at: at, data: data });
      return { data: data, fromCache: false, fresh: true, savedAt: at, error: null };
    });
  }

  function payloadData(result) {
    return result && Object.prototype.hasOwnProperty.call(result, "data") ? result.data : result;
  }

  function mount(container, options) {
    if (!container || container.nodeType !== 1) throw new TypeError("CizgiHome.mount bir HTML öğesi ister.");
    options = options && typeof options === "object" ? options : {};
    var token = ++generation;
    var session = { abort: new AbortController(), renderAbort: new AbortController(), token: token, heroTimer: null };
    var previous = sessions.get(container);
    if (previous) {
      previous.abort.abort();
      previous.renderAbort.abort();
      if (previous.heroTimer) clearInterval(previous.heroTimer);
    }
    sessions.set(container, session);

    var rid = "cizgi" + token;
    var items = [];
    var topics = [];
    var fetchedTopics = new Set();
    var topicErrors = new Set();
    var activeSlug = clean(options.initialTopic || "");
    if (activeSlug === "sana") activeSlug = "";
    var incomplete = false;
    var capped = false;
    var failMessage = "";
    var loadId = 0;
    var topicSeq = 0;
    var heroIndex = 0;
    var heroPaused = prefersReducedMotion();
    var saved = new Set(normalizeIdList(options.savedIds));
    var moreCursor = "";
    var moreLoading = false;
    var showingCache = false;
    var cacheStampMs = 0;
    var uniqueLive = 0;

    container.classList.add("cizgi-home");
    if (!container.getAttribute("aria-label")) container.setAttribute("aria-label", "Günün gazetesi");
    if (!container.lang) container.lang = "tr";

    function stale() {
      return generation !== token || session.abort.signal.aborted;
    }

    function followSet() {
      var set = new Set();
      var byName = new Map(topics.map(function (topic) { return [topic.name.toLocaleLowerCase("tr"), topic.slug]; }));
      var list = Array.isArray(options.followedTopics) ? options.followedTopics : [];
      list.forEach(function (entry) {
        if (typeof entry === "string" && clean(entry)) {
          var key = clean(entry);
          set.add(byName.get(key.toLocaleLowerCase("tr")) || key);
        } else if (entry && clean(entry.slug)) set.add(clean(entry.slug));
      });
      return set;
    }

    function pool() {
      var rows = items.filter(isLive);
      if (!activeSlug) return rows;
      return byRank(rows.filter(function (item) { return String(item.topic_slug) === activeSlug; }));
    }

    function topicName(slug) {
      var chip = TOPIC_BAR.find(function (topic) { return topic.slug === slug; });
      if (chip) return chip.name;
      var row = topics.find(function (topic) { return topic.slug === slug; });
      return row ? row.name : "";
    }

    function preferredSlug(section) {
      var known = topics.filter(function (topic) {
        return sectionFor({ topic_slug: topic.slug, topic_name: topic.name }) === section.id;
      });
      if (known.length) return known[0].slug;
      var fallback = {
        turkiye: "ulusal",
        dunya: "dunya",
        ekonomi: "ekonomi",
        teknoloji: "bilim-teknoloji",
        yasam: "kultur",
        spor: "spor",
      };
      return fallback[section.id] || "";
    }

    function metaLine(item) {
      var parts = [];
      parts.push(publisherName(item) || "Kaynak");
      var relative = relativeWhen(item.published_at);
      var clock = formatClock(item.published_at);
      if (relative) parts.push(relative);
      else if (clock) parts.push(clock);
      if (item.source_count != null && item.source_count !== "" && Number.isFinite(Number(item.source_count))) {
        parts.push(formatCount(item.source_count) + " kaynak");
      }
      if (isUpdated(item)) {
        var updated = relativeWhen(item.updated_at) || formatClock(item.updated_at);
        parts.push(updated ? "Güncellendi " + updated : "Güncellendi");
      }
      if (priorityOf(item) > 0 && sourceCount(item) <= 1) parts.push("Öne alınan");
      return parts.map(esc).join(" · ");
    }

    function mediaHtml(item) {
      var label = clean(item.topic_name) || "Gündem";
      var src = httpsUrl(item.image);
      if (!src) return '<div class="cizgi-home-fallback" aria-hidden="true"><span>' + esc(label) + "</span></div>";
      return '<img class="cizgi-home-photo" alt="" decoding="async" data-fallback="' + esc(label) + '" src="' + esc(src) + '">';
    }

    function saveButton(item) {
      var on = saved.has(String(item.id));
      return '<button type="button" class="cizgi-home-save" data-save="' + esc(item.id) + '" aria-pressed="' + (on ? "true" : "false") + '" aria-label="' + (on ? "Kaydı kaldır" : "Kaydet") + '"><span class="cizgi-home-save-label">' + (on ? "Kaydedildi" : "Kaydet") + "</span></button>";
    }

    function originalButton(item) {
      var url = originalUrl(item);
      if (!url) return "";
      return '<button type="button" class="cizgi-home-original" data-original="' + esc(url) + '">Kaynağında</button>';
    }

    function mastHtml() {
      var unread = unreadOf(options);
      var bellLabel = unread ? "Bildirimler, " + formatCount(unread) + " okunmamış" : "Bildirimler";
      var badge = unread ? '<span class="cizgi-home-badge" aria-hidden="true">' + esc(formatCount(unread)) + "</span>" : "";
      return '<header class="cizgi-home-top"><div class="cizgi-home-mast"><a class="cizgi-home-brand" href="#/" data-trigger="home">' + brandMark() + '<span class="cizgi-home-word">ÇİZGİ</span></a><div class="cizgi-home-tools"><button type="button" class="cizgi-home-icon" data-trigger="search" aria-label="Arama">' + iconSearch() + '</button><button type="button" class="cizgi-home-icon" data-trigger="notifications" aria-label="' + esc(bellLabel) + '">' + iconBell() + badge + '</button><button type="button" class="cizgi-home-icon" data-trigger="profile" aria-label="Profil">' + iconPerson() + "</button></div></div>";
    }

    function topicHtml() {
      return '<nav class="cizgi-home-topics" aria-label="Konular">' + TOPIC_BAR.map(function (topic) {
        var on = !topic.stub && (topic.slug || "") === (activeSlug || "");
        var attrs = topic.stub
          ? ' data-stub="' + esc(topic.stub) + '"'
          : ' data-topic="' + esc(topic.slug) + '" aria-pressed="' + (on ? "true" : "false") + '"';
        return '<button type="button" class="cizgi-home-chip"' + attrs + ">" + esc(topic.name) + "</button>";
      }).join("") + "</nav></header>";
    }

    function lineHtml(item, index) {
      var marker = index >= 0 ? '<span class="cizgi-home-index" aria-hidden="true">' + String(index + 1).padStart(2, "0") + "</span>" : "";
      return '<div class="cizgi-home-line"><button type="button" class="cizgi-home-row" data-open="' + esc(item.id) + '">' + marker + '<span class="cizgi-home-row-copy"><span class="cizgi-home-row-title">' + esc(titleOf(item)) + '</span><span class="cizgi-home-meta">' + metaLine(item) + "</span></span></button>" + saveButton(item) + originalButton(item) + "</div>";
    }

    function storyList(list) {
      return '<ul class="cizgi-home-stories">' + list.map(function (item, index) {
        return '<li class="cizgi-home-story' + (index === 0 ? " cizgi-home-story-main" : "") + '">' + lineHtml(item) + "</li>";
      }).join("") + "</ul>";
    }

    function summaryHtml(list) {
      var body = list.length
        ? '<ol class="cizgi-home-summary-list">' + list.map(function (item, index) { return "<li>" + lineHtml(item, index) + "</li>"; }).join("") + "</ol>"
        : '<p class="cizgi-home-empty">Özet için ayrı başlık yok.</p>';
      return '<section class="cizgi-home-summary" aria-labelledby="' + rid + '-ozet"><div class="cizgi-home-block-head"><h2 id="' + rid + '-ozet">Günün özeti</h2><p class="cizgi-home-aside">' + formatCount(list.length) + " başlık</p></div>" + body + "</section>";
    }

    function slideHtml(item, index, total) {
      var deck = spot(item.editorial_summary);
      var topic = clean(item.topic_name) || "Gündem";
      var hidden = index === heroIndex ? "" : " hidden";
      return '<article class="cizgi-home-slide" data-slide-index="' + index + '"' + hidden + ' aria-roledescription="slide" aria-label="' + esc(String(index + 1) + " / " + total) + '"><button type="button" class="cizgi-home-open" data-open="' + esc(item.id) + '"><span class="cizgi-home-lead-media">' + mediaHtml(item) + '</span><span class="cizgi-home-kicker">Manşet · ' + esc(topic) + '</span><span class="cizgi-home-headline">' + esc(titleOf(item)) + '</span></button>' + (deck ? '<p class="cizgi-home-deck">' + esc(deck) + "</p>" : "") + '<p class="cizgi-home-meta">' + metaLine(item) + '</p><div class="cizgi-home-actions">' + saveButton(item) + originalButton(item) + "</div></article>";
    }

    function heroHtml(slides) {
      if (!slides.length) return "";
      if (slides.length === 1) {
        var only = slides[0];
        var deck = spot(only.editorial_summary);
        var topic = clean(only.topic_name) || "Gündem";
        return '<article class="cizgi-home-lead"><h1><button type="button" class="cizgi-home-open" data-open="' + esc(only.id) + '"><span class="cizgi-home-lead-media">' + mediaHtml(only) + '</span><span class="cizgi-home-kicker">Manşet · ' + esc(topic) + '</span><span class="cizgi-home-headline">' + esc(titleOf(only)) + '</span></button></h1>' + (deck ? '<p class="cizgi-home-deck">' + esc(deck) + "</p>" : "") + '<p class="cizgi-home-meta">' + metaLine(only) + '</p><div class="cizgi-home-actions">' + saveButton(only) + originalButton(only) + "</div></article>";
      }
      if (heroIndex >= slides.length) heroIndex = 0;
      var dots = slides.map(function (_item, index) {
        return '<button type="button" class="cizgi-home-dot" data-hero-goto="' + index + '" aria-label="Manşet ' + (index + 1) + '" aria-current="' + (index === heroIndex ? "true" : "false") + '"></button>';
      }).join("");
      return '<section class="cizgi-home-hero" aria-roledescription="carousel" aria-label="Manşetler"><div class="cizgi-home-hero-stage">' + slides.map(function (item, index) {
        return slideHtml(item, index, slides.length);
      }).join("") + '</div><div class="cizgi-home-hero-controls"><button type="button" class="cizgi-home-hero-btn" data-hero-prev aria-label="Önceki manşet">Önce</button><button type="button" class="cizgi-home-hero-btn" data-hero-pause aria-pressed="' + (heroPaused ? "true" : "false") + '">' + (heroPaused ? "Oynat" : "Duraklat") + '</button><button type="button" class="cizgi-home-hero-btn" data-hero-next aria-label="Sonraki manşet">Sonra</button><div class="cizgi-home-hero-dots" role="group" aria-label="Manşet seç">' + dots + "</div></div></section>";
    }

    function cardHtml(item) {
      var deck = oneSentence(item.editorial_summary);
      return '<article class="cizgi-home-card"><button type="button" class="cizgi-home-open" data-open="' + esc(item.id) + '"><span class="cizgi-home-card-media">' + mediaHtml(item) + '</span><span class="cizgi-home-card-body"><span class="cizgi-home-headline">' + esc(titleOf(item)) + '</span>' + (deck ? '<span class="cizgi-home-deck">' + esc(deck) + '</span>' : '') + '<span class="cizgi-home-meta">' + metaLine(item) + '</span></span></button><div class="cizgi-home-actions">' + saveButton(item) + '</div></article>';
    }

    function sideHtml(item, kind) {
      return '<div class="cizgi-home-side-item cizgi-home-side-' + kind + '">' + cardHtml(item) + "</div>";
    }

    function tickerHtml(list) {
      if (!list.length) return "";
      var reduce = prefersReducedMotion();
      var animate = false;
      var duration = Math.max(28, list.length * 7);
      function group(clone) {
        return '<div class="cizgi-home-ticker-group' + (clone ? " cizgi-home-ticker-clone" : "") + '"' + (clone ? ' aria-hidden="true"' : "") + ">" + list.map(function (item) {
          var time = formatTime(item.published_at);
          return '<button type="button" class="cizgi-home-ticker-open" data-open="' + esc(item.id) + '"' + (clone ? ' tabindex="-1"' : "") + ">" + (time ? '<span class="cizgi-home-ticker-time">' + esc(time) + "</span>" : "") + "<span>" + esc(titleOf(item)) + "</span></button>";
        }).join("") + "</div>";
      }
      return '<div class="cizgi-home-ticker" role="region" aria-label="Son dakika"><p class="cizgi-home-ticker-label">Son dakika</p><div class="cizgi-home-ticker-window"><div class="cizgi-home-ticker-track' + (animate ? " is-animated" : "") + '" style="--cizgi-duration:' + duration + 's">' + group(false) + (animate ? group(true) : "") + "</div></div></div>";
    }

    function renderSection(section, rows, used) {
      var all = byRank(rows.filter(function (item) { return sectionFor(item) === section.id; }));
      var fresh = all.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 4);
      fresh.forEach(function (item) { used.add(String(item.id)); });
      var slug = preferredSlug(section);
      var body;
      if (fresh.length) body = storyList(fresh);
      else if (!all.length && slug && topicErrors.has(slug)) body = '<p class="cizgi-home-empty">Bu konunun başlıkları alınamadı.</p>';
      else if (!all.length) body = '<p class="cizgi-home-empty">Bu konuda gösterilecek başlık yok.</p>';
      else body = '<p class="cizgi-home-empty">Bu konunun başlıkları yukarıda.</p>';
      return '<section class="cizgi-home-section cizgi-home-section-' + section.id + '" aria-labelledby="' + rid + "-" + section.id + '"><h2 class="cizgi-home-section-title" id="' + rid + "-" + section.id + '">' + esc(section.title) + "</h2>" + body + "</section>";
    }

    function renderLoose(title, rows, used) {
      var fresh = rows.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 8);
      fresh.forEach(function (item) { used.add(String(item.id)); });
      var body = fresh.length
        ? storyList(fresh)
        : (rows.length ? '<p class="cizgi-home-empty">Bu konunun başlıkları yukarıda.</p>' : '<p class="cizgi-home-empty">Bu konuda gösterilecek başlık yok.</p>');
      return '<section class="cizgi-home-section cizgi-home-section-topic" aria-labelledby="' + rid + '-konu"><h2 class="cizgi-home-section-title" id="' + rid + '-konu">' + esc(title) + "</h2>" + body + "</section>";
    }

    function sectionsHtml(rows, used) {
      if (activeSlug) {
        var sectionId = sectionFor({ topic_slug: activeSlug, topic_name: topicName(activeSlug) });
        var section = SECTIONS.find(function (entry) { return entry.id === sectionId; });
        var inner = section ? renderSection(section, rows, used) : renderLoose(topicName(activeSlug) || activeSlug, rows, used);
        return '<div class="cizgi-home-sections is-single">' + inner + "</div>";
      }
      return '<div class="cizgi-home-sections">' + SECTIONS.map(function (section) { return renderSection(section, rows, used); }).join("") + "</div>";
    }

    function strip(id, title, note, body) {
      return '<section class="cizgi-home-strip cizgi-home-strip-' + id + '" aria-labelledby="' + rid + "-" + id + '"><div class="cizgi-home-block-head"><h2 id="' + rid + "-" + id + '">' + esc(title) + "</h2>" + (note ? '<p class="cizgi-home-note">' + esc(note) + "</p>" : "") + "</div>" + (body || "") + "</section>";
    }

    function personalHtml(rows, used) {
      var follows = followSet();
      if (!follows.size) {
        return strip(
          "sana",
          "Sana göre",
          "Takip seçilmedi. Kişisel şerit için profil veya kayıtlılarda konu takip et.",
          '<p class="cizgi-home-empty">Sahte kişiselleştirme yok. Takip edilmeyen konular burada listelenmez.</p>'
        );
      }
      var matched = rows.filter(function (item) { return follows.has(String(item.topic_slug)); });
      var picked = matched.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 4);
      var note;
      if (picked.length) note = "Takip ettiğin konulardan.";
      else if (matched.length) note = "Takip ettiğin konuların başlıkları yukarıda.";
      else note = "Takip ettiğin konularda gösterilecek başlık yok.";
      picked.forEach(function (item) { used.add(String(item.id)); });
      return strip("sana", "Sana göre", note, picked.length ? storyList(picked) : "");
    }

    function breakingHtml(rows, used) {
      var newest = byNewest(rows);
      var picked = newest.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 4);
      if (!picked.length) picked = newest.slice(0, 4);
      picked.forEach(function (item) { used.add(String(item.id)); });
      var body = picked.length ? '<ul class="cizgi-home-breaking">' + picked.map(function (item) { return "<li>" + lineHtml(item) + "</li>"; }).join("") + "</ul>" : '<p class="cizgi-home-empty">Gösterilecek son dakika başlığı yok.</p>';
      return strip("dakika", "Son dakika", "", body);
    }

    function talkedHtml(rows, used) {
      var talked = rows.filter(function (item) { return sourceCount(item) > 1 || priorityOf(item) > 0; });
      if (!talked.length) return "";
      var ranked = talked.slice().sort(function (a, b) {
        var ds = sourceCount(b) - sourceCount(a);
        if (ds) return ds;
        var dp = priorityOf(b) - priorityOf(a);
        if (dp) return dp;
        return publishedMs(b) - publishedMs(a);
      });
      var picked = ranked.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 4);
      ranked.forEach(function (item) {
        if (picked.length >= 4) return;
        if (picked.indexOf(item) === -1) picked.push(item);
      });
      picked.forEach(function (item) { used.add(String(item.id)); });
      return strip("konusulan", "Çok konuşulanlar", "Birden fazla kaynağı olan veya editörün öne aldığı başlıklar.", storyList(picked));
    }

    function publishersHtml(rows, used) {
      var groups = new Map();
      byNewest(rows).forEach(function (item) {
        var name = publisherName(item);
        if (!name) return;
        if (!groups.has(name)) groups.set(name, []);
        groups.get(name).push(item);
      });
      if (!groups.size) return "";
      var ranked = Array.from(groups.entries()).sort(function (a, b) {
        return b[1].length - a[1].length || a[0].localeCompare(b[0], "tr");
      }).slice(0, 4);
      var cards = ranked.map(function (entry, index) {
        var name = entry[0];
        var stories = entry[1];
        var item = stories[0];
        used.add(String(item.id));
        return '<article class="cizgi-home-publisher' + (index === 0 ? " is-lead" : "") + '"><p class="cizgi-home-kicker">' + esc(name) + '</p><p class="cizgi-home-aside">Bu kapakta ' + formatCount(stories.length) + ' başlık</p><button type="button" class="cizgi-home-headline" data-open="' + esc(item.id) + '">' + esc(titleOf(item)) + '</button><p class="cizgi-home-meta">' + metaLine(item) + "</p></article>";
      }).join("");
      return strip("kaynaklar", "Kaynaklardan öne çıkanlar", "", '<div class="cizgi-home-publishers">' + cards + "</div>");
    }

    function missHtml(rows, used) {
      var picked = rows.filter(function (item) { return !used.has(String(item.id)); }).slice(0, 4);
      picked.forEach(function (item) { used.add(String(item.id)); });
      var note = picked.length ? formatCount(picked.length) + " başlık" : "Bugün için ayrılmış başka öne çıkan başlık kalmadı.";
      var body = picked.length ? '<div class="cizgi-home-miss">' + picked.map(function (item, index) {
        return '<article class="cizgi-home-story' + (index === 0 ? " cizgi-home-story-main" : "") + '">' + lineHtml(item) + "</article>";
      }).join("") + "</div>" : "";
      return strip("kacirma", "Bugün kaçırma", note, body);
    }

    function footHtml() {
      var failedTopic = Boolean(activeSlug && topicErrors.has(activeSlug) && !pool().length);
      var label = incomplete || failedTopic ? "Yeniden dene" : "Akışı yenile";
      var more = moreCursor
        ? '<button type="button" class="cizgi-home-more" data-more' + (moreLoading ? " disabled aria-busy=\"true\"" : "") + ">" + (moreLoading ? "Yükleniyor…" : "Daha fazla") + "</button>"
        : "";
      return '<footer class="cizgi-home-foot"><p class="cizgi-home-count" data-count-live role="status"></p><p class="cizgi-home-footnote">Başlık ve kısa spot gösterilir. Tam metin yayıncıda kalır. Aynı başlık bir kez sayılır.</p>' + more + '<button type="button" class="cizgi-home-retry" data-retry>' + label + "</button></footer>";
    }

    function bannerHtml() {
      var parts = [];
      if (showingCache) {
        var stamp = cacheStampMs ? formatClock(cacheStampMs) : "";
        parts.push(stamp ? "önbellekten · " + stamp : "önbellekten");
      }
      if (incomplete) parts.push((failMessage || "Sonraki sayfa alınamadı.") + " Ekrandaki başlıklar duruyor.");
      if (capped && !moreCursor) parts.push("Daha eski sayfalar bu kapağa alınmadı.");
      if (!parts.length) return "";
      return '<p class="cizgi-home-banner" role="status">' + esc(parts.join(" · ")) + "</p>";
    }

    function paper(rows) {
      var ranked = byRank(rows);
      var top = layoutTop(ranked);
      var used = new Set();
      top.slides.concat(top.sides, top.summary).forEach(function (item) {
        if (item) used.add(String(item.id));
      });
      var sideKinds = ["a", "b", "c", "d"];
      var sides = top.sides.length ? '<div class="cizgi-home-side" aria-label="Öne çıkanlar">' + top.sides.map(function (item, index) {
        return sideHtml(item, sideKinds[index] || "c");
      }).join("") + "</div>" : "";
      var spreadClass = top.sides.length ? "cizgi-home-spread" : "cizgi-home-spread is-two";
      /* Mobil tek kolon DOM sırası: manşet → özet → kartlar (CSS order hack yok). */
      return '<div class="cizgi-home-body">' + bannerHtml() + tickerHtml(byNewest(rows).slice(0, 12)) + '<div class="' + spreadClass + '">' + heroHtml(top.slides) + summaryHtml(top.summary) + sides + "</div>" + sectionsHtml(rows, used) + '<div class="cizgi-home-strips">' + personalHtml(rows, used) + breakingHtml(rows, used) + "</div>" + footHtml() + "</div>";
    }

    function emptyPaper() {
      var failed = Boolean(activeSlug && topicErrors.has(activeSlug));
      var heading = failed ? "Bu konunun başlıkları alınamadı" : "Gösterilecek başlık yok";
      var copy = failed ? "Yeniden deneyebilirsin." : "Bu konuda gösterilecek başlık yok.";
      return '<div class="cizgi-home-body"><div class="cizgi-home-empty-cover"><h1>' + esc(heading) + "</h1><p>" + esc(copy) + "</p></div>" + footHtml() + "</div>";
    }

    function applyCount() {
      var node = container.querySelector("[data-count-live]");
      if (!node) return;
      var ids = new Set();
      var fps = new Set();
      var byId = new Map(items.map(function (item) { return [String(item.id), item]; }));
      container.querySelectorAll("[data-open]").forEach(function (el) {
        if (el.closest("[aria-hidden='true']") || el.closest(".cizgi-home-ticker-clone") || el.closest(".cizgi-home-slide[hidden]")) return;
        var id = el.getAttribute("data-open");
        if (!id) return;
        ids.add(id);
        var item = byId.get(id);
        if (item) fps.add(dedupeFingerprint(item));
      });
      uniqueLive = fps.size || ids.size;
      var note = "Ekranda " + formatCount(uniqueLive) + " benzersiz başlık";
      if (showingCache && cacheStampMs) note += " · önbellekten · " + formatClock(cacheStampMs);
      else if (showingCache) note += " · önbellekten";
      if (moreCursor) note += " · daha fazla yüklenebilir";
      node.textContent = note + ".";
    }

    function bindImages(signal) {
      container.querySelectorAll("img.cizgi-home-photo").forEach(function (img) {
        var fail = function () {
          if (!img.isConnected) return;
          var panel = document.createElement("div");
          panel.className = "cizgi-home-fallback";
          panel.setAttribute("aria-hidden", "true");
          var label = document.createElement("span");
          label.textContent = img.getAttribute("data-fallback") || "Gündem";
          panel.append(label);
          img.replaceWith(panel);
        };
        img.addEventListener("error", fail, { signal: signal });
        if (img.complete && img.naturalWidth === 0) fail();
      });
    }

    function stopHero() {
      if (session.heroTimer) {
        clearInterval(session.heroTimer);
        session.heroTimer = null;
      }
    }

    function syncHeroDom() {
      var slides = container.querySelectorAll(".cizgi-home-slide");
      slides.forEach(function (slide) {
        var index = Number(slide.getAttribute("data-slide-index"));
        var on = index === heroIndex;
        if (on) slide.removeAttribute("hidden");
        else slide.setAttribute("hidden", "");
      });
      container.querySelectorAll("[data-hero-goto]").forEach(function (dot) {
        var index = Number(dot.getAttribute("data-hero-goto"));
        dot.setAttribute("aria-current", index === heroIndex ? "true" : "false");
      });
      var pauseBtn = container.querySelector("[data-hero-pause]");
      if (pauseBtn) {
        pauseBtn.setAttribute("aria-pressed", heroPaused ? "true" : "false");
        pauseBtn.textContent = heroPaused ? "Oynat" : "Duraklat";
      }
      applyCount();
    }

    function startHero() {
      stopHero();
      var slides = container.querySelectorAll(".cizgi-home-slide");
      if (slides.length < 2 || heroPaused || prefersReducedMotion()) return;
      session.heroTimer = setInterval(function () {
        if (stale() || heroPaused) return;
        heroIndex = (heroIndex + 1) % slides.length;
        syncHeroDom();
      }, 7000);
    }

    function paint(html, busy) {
      stopHero();
      session.renderAbort.abort();
      session.renderAbort = new AbortController();
      container.setAttribute("aria-busy", busy ? "true" : "false");
      container.innerHTML = html;
      applyCount();
      bindImages(session.renderAbort.signal);
      startHero();
    }

    function render() {
      var rows = pool();
      paint(mastHtml() + topicHtml() + (rows.length ? paper(rows) : emptyPaper()), false);
    }

    function renderSkeleton() {
      var bones = new Array(6).fill('<span class="cizgi-home-bone"></span>').join("");
      paint(mastHtml() + '<div class="cizgi-home-topics" aria-hidden="true">' + bones + '</div></header><div class="cizgi-home-skeleton cizgi-home-skeleton-short" role="status"><span class="cizgi-home-sr">Başlıklar yükleniyor</span><div class="cizgi-home-bone cizgi-home-bone-lead"></div><div class="cizgi-home-bone cizgi-home-bone-summary"></div></div>', true);
    }

    function renderLoadingTopic() {
      paint(mastHtml() + topicHtml() + '<div class="cizgi-home-body"><div class="cizgi-home-skeleton cizgi-home-skeleton-short" role="status"><span class="cizgi-home-sr">Başlıklar yükleniyor</span><div class="cizgi-home-bone cizgi-home-bone-lead"></div></div></div>', true);
    }

    function renderError(error) {
      paint(mastHtml() + '</header><div class="cizgi-home-error" role="alert"><p class="cizgi-home-kicker">Bağlantı</p><h1>Akış şu an yenilenemedi</h1><p>' + esc(errorMessage(error)) + '</p><button type="button" class="cizgi-home-retry" data-retry>Yeniden dene</button><p class="cizgi-home-count" data-count-live role="status"></p></div>', false);
    }

    async function ensureTopic(slug, bucket, seenTopics, errors, alive) {
      if (!slug || seenTopics.has(slug) || slug.indexOf("__") === 0) return;
      seenTopics.add(slug);
      try {
        var result = await cachedFetch(options.api, "/v1/feed?limit=" + PAGE_LIMIT + "&topic=" + encodeURIComponent(slug), session.abort.signal, { swr: false });
        if (!alive()) return;
        mergeItems(bucket, asPage(payloadData(result)).items);
        errors.delete(slug);
      } catch (error) {
        if (!alive()) return;
        errors.add(slug);
      }
    }

    function applyBootstrapPayload(bucket, payload, meta) {
      var parsed = asPage(payload);
      mergeItems(bucket, parsed.items);
      moreCursor = parsed.next_cursor || "";
      showingCache = Boolean(meta && meta.fromCache);
      cacheStampMs = meta && meta.savedAt ? Number(meta.savedAt) : 0;
      capped = false;
      incomplete = false;
      failMessage = "";
    }

    function readLocalBootstrap() {
      if (!root.CizgiBoot || typeof root.CizgiBoot.cacheGet !== "function") return null;
      return root.CizgiBoot.cacheGet(BOOTSTRAP_PATH);
    }

    async function resolveTopics(alive) {
      var given = normalizeTopics(options.topics);
      if (given.length) return given;
      try {
        var result = await cachedFetch(options.api, "/v1/topics", session.abort.signal, { swr: true });
        if (!alive()) return FALLBACK_TOPICS.map(function (row) { return { slug: row.slug, name: row.name }; });
        var rows = normalizeTopics(asList(payloadData(result)));
        if (rows.length) return rows;
      } catch (error) {
        /* katalog yoksa yerleşik konu listesi */
      }
      return FALLBACK_TOPICS.map(function (row) { return { slug: row.slug, name: row.name }; });
    }

    async function fillSections(bucket, seenTopics, errors, alive) {
      await Promise.all(SECTIONS.map(async function (section) {
        if (!alive()) return;
        var slug = preferredSlug(section);
        if (!slug) return;
        var count = bucket.filter(function (item) { return isLive(item) && sectionFor(item) === section.id; }).length;
        if (count >= 4) {
          seenTopics.add(slug);
          return;
        }
        await ensureTopic(slug, bucket, seenTopics, errors, alive);
      }));
    }

    async function revalidateBootstrap(bucket, alive) {
      if (!alive() || typeof options.api !== "function") return null;
      var result = await cachedFetch(options.api, BOOTSTRAP_PATH, session.abort.signal, {
        key: BOOTSTRAP_PATH,
        ttlMs: CACHE_TTL_MS,
        swr: false,
      });
      if (!alive()) return null;
      return result;
    }

    async function loadMore() {
      if (!moreCursor || moreLoading || stale()) return;
      moreLoading = true;
      render();
      var current = loadId;
      var alive = function () { return !stale() && current === loadId; };
      try {
        var path = "/v1/feed?limit=" + PAGE_LIMIT + "&cursor=" + encodeURIComponent(moreCursor);
        var result = await cachedFetch(options.api, path, session.abort.signal, { swr: false });
        if (!alive()) return;
        var parsed = asPage(payloadData(result));
        var before = items.length;
        mergeItems(items, parsed.items);
        if (items.length === before || !parsed.next_cursor || parsed.next_cursor === moreCursor) {
          moreCursor = "";
          if (items.length === before) capped = true;
        } else {
          moreCursor = parsed.next_cursor;
        }
        showingCache = false;
      } catch (error) {
        if (!alive()) return;
        incomplete = true;
        failMessage = errorMessage(error);
      } finally {
        moreLoading = false;
        if (alive()) render();
      }
    }

    async function load() {
      var current = ++loadId;
      topicSeq += 1;
      var bucket = [];
      var seenTopics = new Set();
      var errors = new Set();
      items = bucket;
      fetchedTopics = seenTopics;
      topicErrors = errors;
      incomplete = false;
      capped = false;
      failMessage = "";
      moreCursor = "";
      moreLoading = false;
      showingCache = false;
      cacheStampMs = 0;
      heroIndex = 0;
      var alive = function () { return !stale() && current === loadId; };
      var painted = false;

      try {
        if (typeof options.api !== "function") throw new Error("Akış bağlantısı yok.");

        var local = readLocalBootstrap();
        if (local && local.value) {
          applyBootstrapPayload(bucket, local.value, { fromCache: true, savedAt: local.savedAt || 0 });
          topics = uniqueTopics(normalizeTopics(options.topics).length ? options.topics : FALLBACK_TOPICS);
          render();
          painted = true;
        } else {
          renderSkeleton();
        }

        var bootResult = await revalidateBootstrap(bucket, alive);
        if (!alive()) return;

        if (bootResult) {
          bucket.length = 0;
          applyBootstrapPayload(bucket, payloadData(bootResult), bootResult);
          if (bootResult._revalidate && typeof bootResult._revalidate.then === "function") {
            bootResult._revalidate.then(function (fresh) {
              if (!alive() || !fresh || fresh.fromCache) return;
              bucket.length = 0;
              applyBootstrapPayload(bucket, payloadData(fresh), fresh);
              render();
            }).catch(function () { /* stale kalır */ });
          }
        }

        topics = uniqueTopics(await resolveTopics(alive));
        if (!alive()) return;
        render();
        painted = true;

        fillSections(bucket, seenTopics, errors, alive).then(function () {
          if (!alive()) return;
          if (activeSlug && activeSlug.indexOf("__") !== 0) {
            return ensureTopic(activeSlug, bucket, seenTopics, errors, alive);
          }
        }).then(function () {
          if (alive()) render();
        }).catch(function () {
          if (alive()) render();
        });
      } catch (error) {
        if (!alive()) return;
        if (painted && bucket.length) {
          incomplete = true;
          failMessage = errorMessage(error);
          render();
        } else {
          renderError(error);
        }
      }
    }

    async function selectTopic(slug) {
      var seq = ++topicSeq;
      var bucket = items;
      var seenTopics = fetchedTopics;
      var errors = topicErrors;
      var count = slug ? bucket.filter(function (item) { return isLive(item) && String(item.topic_slug) === slug; }).length : 0;
      var needs = Boolean(slug) && count < 4 && !seenTopics.has(slug);
      if (slug === activeSlug && !needs) return;
      activeSlug = slug;
      heroIndex = 0;
      if (needs) {
        renderLoadingTopic();
        await ensureTopic(slug, bucket, seenTopics, errors, function () {
          return !stale() && seq === topicSeq && items === bucket;
        });
        if (stale() || seq !== topicSeq || items !== bucket) return;
      }
      if (stale() || seq !== topicSeq) return;
      render();
    }

    function toggleSave(id) {
      if (!id) return;
      var key = String(id);
      if (saved.has(key)) saved.delete(key);
      else saved.add(key);
      var on = saved.has(key);
      container.querySelectorAll("[data-save]").forEach(function (button) {
        if (button.getAttribute("data-save") !== key) return;
        button.setAttribute("aria-pressed", on ? "true" : "false");
        button.setAttribute("aria-label", on ? "Kaydı kaldır" : "Kaydet");
        var label = button.querySelector(".cizgi-home-save-label");
        if (label) label.textContent = on ? "Kaydedildi" : "Kaydet";
      });
      container.dispatchEvent(new CustomEvent("cizgi-home:save", { bubbles: true, detail: { id: key } }));
      if (typeof options.onSave === "function") options.onSave(key);
    }

    function openOriginal(value) {
      var url = httpsUrl(value);
      if (!url) return;
      container.dispatchEvent(new CustomEvent("cizgi-home:original", { bubbles: true, detail: { url: url } }));
      if (typeof options.onOpenOriginal === "function") options.onOpenOriginal(url);
    }

    function fireTrigger(name) {
      if (name === "home") {
        if (location.hash !== "#/" && location.hash !== "") location.hash = "#/";
        else selectTopic("");
        return;
      }
      if (name !== "search" && name !== "notifications" && name !== "profile") return;
      container.dispatchEvent(new CustomEvent("cizgi-home:" + name, { bubbles: true }));
      var fn = name === "search" ? options.onSearch : name === "notifications" ? options.onOpenNotifications : options.onOpenProfile;
      if (typeof fn === "function") fn();
    }

    function fireStub(name) {
      container.dispatchEvent(new CustomEvent("cizgi-home:stub", { bubbles: true, detail: { name: name } }));
      if (typeof options.onStub === "function") options.onStub(name);
    }

    function onClick(event) {
      var target = event.target instanceof Element ? event.target : event.target && event.target.parentElement;
      if (!target || !container.contains(target)) return;

      var heroPrev = target.closest("[data-hero-prev]");
      if (heroPrev && container.contains(heroPrev)) {
        event.preventDefault();
        var slideCount = container.querySelectorAll(".cizgi-home-slide").length;
        if (!slideCount) return;
        heroIndex = (heroIndex - 1 + slideCount) % slideCount;
        syncHeroDom();
        return;
      }
      var heroNext = target.closest("[data-hero-next]");
      if (heroNext && container.contains(heroNext)) {
        event.preventDefault();
        var total = container.querySelectorAll(".cizgi-home-slide").length;
        if (!total) return;
        heroIndex = (heroIndex + 1) % total;
        syncHeroDom();
        return;
      }
      var heroPause = target.closest("[data-hero-pause]");
      if (heroPause && container.contains(heroPause)) {
        event.preventDefault();
        heroPaused = !heroPaused;
        if (heroPaused) stopHero();
        else startHero();
        syncHeroDom();
        return;
      }
      var heroGoto = target.closest("[data-hero-goto]");
      if (heroGoto && container.contains(heroGoto)) {
        event.preventDefault();
        heroIndex = Number(heroGoto.getAttribute("data-hero-goto")) || 0;
        syncHeroDom();
        return;
      }

      var moreBtn = target.closest("[data-more]");
      if (moreBtn && container.contains(moreBtn)) {
        event.preventDefault();
        loadMore();
        return;
      }
      var retry = target.closest("[data-retry]");
      if (retry && container.contains(retry)) {
        event.preventDefault();
        responseCache.clear();
        if (root.CizgiBoot && typeof root.CizgiBoot.cacheSet === "function") {
          try { root.localStorage.removeItem("cizgi.boot.v1:" + BOOTSTRAP_PATH); } catch (_err) { /* yok */ }
        }
        load();
        return;
      }
      var save = target.closest("[data-save]");
      if (save && container.contains(save)) {
        event.preventDefault();
        toggleSave(save.getAttribute("data-save"));
        return;
      }
      var original = target.closest("[data-original]");
      if (original && container.contains(original)) {
        event.preventDefault();
        openOriginal(original.getAttribute("data-original"));
        return;
      }
      var stub = target.closest("[data-stub]");
      if (stub && container.contains(stub)) {
        event.preventDefault();
        fireStub(stub.getAttribute("data-stub"));
        return;
      }
      var trigger = target.closest("[data-trigger]");
      if (trigger && container.contains(trigger)) {
        event.preventDefault();
        fireTrigger(trigger.getAttribute("data-trigger"));
        return;
      }
      var chip = target.closest("[data-topic]");
      if (chip && container.contains(chip)) {
        event.preventDefault();
        selectTopic(chip.getAttribute("data-topic") || "");
        return;
      }
      var opener = target.closest("[data-open]");
      if (opener && container.contains(opener)) {
        event.preventDefault();
        var id = opener.getAttribute("data-open");
        if (!id) return;
        container.dispatchEvent(new CustomEvent("cizgi-home:story", { bubbles: true, detail: { id: id } }));
        if (typeof options.onOpenStory === "function") options.onOpenStory(id);
      }
    }

    function clearPause() {
      if (!container.isConnected) return;
      container.querySelectorAll(".cizgi-home-ticker-window.is-paused").forEach(function (node) {
        node.classList.remove("is-paused");
      });
    }

    container.addEventListener("click", onClick, { signal: session.abort.signal });
    container.addEventListener("pointerdown", function (event) {
      var target = event.target instanceof Element ? event.target : null;
      var win = target && target.closest(".cizgi-home-ticker-window");
      if (win && container.contains(win)) win.classList.add("is-paused");
      var hero = target && target.closest(".cizgi-home-hero");
      if (hero && container.contains(hero) && !heroPaused) {
        heroPaused = true;
        stopHero();
        syncHeroDom();
      }
    }, { signal: session.abort.signal });
    if (typeof root.addEventListener === "function") {
      root.addEventListener("pointerup", clearPause, { signal: session.abort.signal });
      root.addEventListener("pointercancel", clearPause, { signal: session.abort.signal });
    }

    load();

    return {
      reload: function () { if (!stale()) { responseCache.clear(); load(); } },
      selectTopic: function (slug) { if (!stale()) selectTopic(clean(slug || "")); },
      destroy: function () {
        loadId += 1;
        topicSeq += 1;
        stopHero();
        session.renderAbort.abort();
        session.abort.abort();
        if (sessions.get(container) === session) {
          sessions.delete(container);
          container.replaceChildren();
          container.classList.remove("cizgi-home");
          container.removeAttribute("aria-busy");
        }
      },
    };
  }

  root.CizgiHome = { mount: mount };
})();
