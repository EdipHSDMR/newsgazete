"""Yayınlanabilir modeller. Ham akış açıklaması bu katmana girmez."""

from __future__ import annotations

import base64
from datetime import datetime, timedelta

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.clock import as_utc
from app.config import Settings
from app.errors import ApiError
from app.models import Correction, Source, SourceItem, Story, StorySource, Topic
from app.news.counts import PROVIDER_NOTE, PUBLIC_STATUSES, count_stored_public, live_feed_clauses
from app.news.dedupe import suppressed_duplicate_ids
from app.rights import active_grant, entitlement_allowed
from app.schemas import CorrectionOut, SourceLink, SourceProfile, StoryCard, StoryDetail
from app.services import _active_members


def feed(session: Session, settings: Settings, now: datetime, *, topic: str | None, cursor: str | None, limit: int):
    if limit < 1 or limit > 30:
        raise ApiError(400, "limit_invalid", "Sayfa boyutu 1 ile 30 arasında olmalıdır.", retryable=False)
    topic_row = None
    if topic:
        topic_row = session.scalar(select(Topic).where(Topic.slug == topic))
        if topic_row is None:
            raise ApiError(400, "topic_invalid", "Konu filtresi listede yok.", retryable=False)
    # Limit SQL'de erken: sayfa + imleç için bir fazla satır.
    stmt = select(Story).where(*_visible(session, settings, now))
    if topic_row:
        stmt = stmt.where(Story.topic_id == topic_row.id)
    if cursor:
        priority, moment, story_id = _decode_cursor(cursor)
        stmt = stmt.where(
            or_(
                Story.editor_priority < priority,
                and_(Story.editor_priority == priority, Story.published_at < moment),
                and_(
                    Story.editor_priority == priority,
                    Story.published_at == moment,
                    Story.id < story_id,
                ),
            )
        )
    stmt = stmt.order_by(Story.editor_priority.desc(), Story.published_at.desc(), Story.id.desc()).limit(limit + 1)
    rows = session.scalars(stmt).all()
    page = rows[:limit]
    next_cursor = _encode_cursor(page[-1]) if len(rows) > limit and page else None
    cards = [card_for(session, story, now) for story in page]
    # İlk ekran: config TTL (varsayılan 30s); hak bitişine göre kısaltılır, imleç bozulmaz.
    ttl = _ttl(settings, now, page)
    return cards, next_cursor, ttl


def feed_bootstrap(session: Session, settings: Settings, now: datetime, *, limit: int = 12):
    """İlk ekran: konu/imleç yok, limit erken, envanter helper ile.

    Dönüş: cards, next_cursor, ttl_seconds, inventory (feed_inventory).
    Sayfalama imleci feed ile aynıdır; sonraki sayfa GET /v1/feed?cursor=... kullanır.
    """
    if limit < 1 or limit > 30:
        raise ApiError(400, "limit_invalid", "Sayfa boyutu 1 ile 30 arasında olmalıdır.", retryable=False)
    cards, next_cursor, ttl = feed(session, settings, now, topic=None, cursor=None, limit=limit)
    return cards, next_cursor, ttl, feed_inventory(session)


def feed_inventory(session: Session) -> dict[str, int | str]:
    """Canlı akış envanteri. GET /v1/feed gövdesine eklenmez.

    Dönüş anahtarları: stored_public, provider_note. Ayrıntı app/news/CONTRACT.md.
    Ayrı uç: GET /v1/meta/inventory. Bootstrap yanıtına gömülebilir.
    """
    return {"stored_public": count_stored_public(session), "provider_note": PROVIDER_NOTE}


def story_detail(session: Session, settings: Settings, now: datetime, story_id: str) -> StoryDetail:
    story = session.get(Story, story_id)
    if story is None or not _is_visible(session, story, settings, now):
        raise ApiError(
            404,
            "content_unavailable",
            "İçerik yayında değil veya izin süresi dolduğu için kaldırıldı.",
            retryable=False,
        )
    base = card_for(session, story, now)
    corrections = session.scalars(
        select(Correction).where(Correction.story_id == story.id, Correction.public.is_(True)).order_by(Correction.created_at)
    ).all()
    sources = _public_sources(session, story, now, settings)
    if not sources:
        raise ApiError(404, "content_unavailable", "Gösterilebilir kaynak izni kalmadı.", retryable=False)
    return StoryDetail(
        **base.model_dump(),
        context_note=story.context_note,
        developing=story.developing,
        uncertainty_note=story.uncertainty_note,
        single_source_note=story.single_source_note,
        content_warning=story.content_warning,
        risk_level=story.risk_level,
        ai_assisted=story.ai_assisted,
        ai_role_note=story.ai_role_note,
        corrections=[
            CorrectionOut(
                id=row.id,
                reason=row.reason,
                editor=row.editor,
                created_at=as_utc(row.created_at),
                previous_summary_version_id=row.previous_summary_version_id,
            )
            for row in corrections
        ],
        sources=sources,
    )


def source_profile(session: Session, settings: Settings, now: datetime, source_id: str) -> SourceProfile:
    source = session.get(Source, source_id)
    if source is None or source.status in {"rejected", "suspended"}:
        raise ApiError(404, "not_found", "Yayıncı bulunamadı.", retryable=False)
    if source.synthetic and not settings.synthetic_allowed:
        raise ApiError(404, "not_found", "Yayıncı bulunamadı.", retryable=False)
    grant = active_grant(session, source, now)
    if not entitlement_allowed(session, grant, "metadata"):
        raise ApiError(404, "not_found", "Yayıncı bilgisi için izin yok.", retryable=False)
    stories = []
    for story in session.scalars(select(Story).where(*_visible(session, settings, now)).order_by(Story.published_at.desc())).all():
        member_ids = {item.source_id for item, _src in _active_members(session, story.id)}
        if source.id in member_ids:
            stories.append(card_for(session, story, now))
    return SourceProfile(
        id=source.id,
        name=source.name,
        domain=source.domain,
        editorial_description=source.editorial_description,
        partnership_label=source.partnership_label,
        partnership_note=source.partnership_note,
        stories=stories,
    )


def search(session: Session, settings: Settings, now: datetime, *, q: str, topic: str | None, source_id: str | None, date_from: datetime | None, date_to: datetime | None, cursor: str | None, limit: int):
    query = " ".join(q.split())
    if len(query) < 2 or len(query) > 80:
        raise ApiError(400, "query_invalid", "Arama 2 ile 80 karakter arasında olmalıdır.", retryable=False)
    return _search_query(session, settings, now, query, topic, source_id, date_from, date_to, cursor, limit)


def _search_query(session, settings, now, query, topic, source_id, date_from, date_to, cursor, limit):
    if limit < 1 or limit > 30:
        raise ApiError(400, "limit_invalid", "Sayfa boyutu 1 ile 30 arasında olmalıdır.", retryable=False)
    topic_row = None
    if topic:
        topic_row = session.scalar(select(Topic).where(Topic.slug == topic))
        if topic_row is None:
            raise ApiError(400, "topic_invalid", "Konu filtresi listede yok.", retryable=False)
    stmt = select(Story).where(*_visible(session, settings, now))
    if topic_row:
        stmt = stmt.where(Story.topic_id == topic_row.id)
    if date_from:
        stmt = stmt.where(Story.published_at >= date_from)
    if date_to:
        stmt = stmt.where(Story.published_at <= date_to)
    rows = session.scalars(stmt).all()
    matched = []
    for story in rows:
        haystack = f"{story.editorial_title} {story.editorial_summary}".casefold()
        topic_name = session.get(Topic, story.topic_id).name.casefold()
        if source_id:
            member_sources = {item.source_id for item, _s in _active_members(session, story.id)}
            if source_id not in member_sources:
                continue
        publisher_hit = any(
            query.casefold() in source.name.casefold()
            for _item, source in _active_members(session, story.id)
        )
        if query.casefold() in haystack or query.casefold() in topic_name or publisher_hit:
            matched.append(story)
    if cursor:
        _priority, moment, story_id = _decode_cursor(cursor)
        matched = [story for story in matched if _search_after(story, moment, story_id)]
    matched.sort(key=lambda story: (as_utc(story.published_at), story.id), reverse=True)
    page_plus = matched[: limit + 1]
    page = page_plus[:limit]
    next_cursor = _encode_cursor(page[-1]) if len(page_plus) > limit else None
    return [card_for(session, story, now) for story in page], next_cursor


def card_for(session: Session, story: Story, now: datetime) -> StoryCard:
    topic = session.get(Topic, story.topic_id)
    members = _active_members(session, story.id)
    published = as_utc(story.published_at) if story.published_at else now
    updated = as_utc(story.updated_at)
    image = _licensed_image(session, story, members, now)
    return StoryCard(
        id=story.id,
        editorial_title=story.editorial_title,
        editorial_summary=story.editorial_summary,
        authorship_label=story.authorship_label,
        published_at=published,
        updated_at=updated,
        source_count=len(members),
        topic_slug=topic.slug,
        topic_name=topic.name,
        synthetic=story.synthetic,
        display_label="Sentetik demo — gerçek haber değildir" if story.synthetic else None,
        updated_badge=updated - published > timedelta(seconds=60),
        placeholder="no_image_rights" if image is None else "licensed_remote",
        ranking_reason=story.ranking_reason,
        editor_priority=story.editor_priority,
        source_ids=[item.source_id for item, _source in members],
        rights_expires_at=as_utc(story.rights_expires_at) if story.rights_expires_at else None,
        image=image,
    )


def _licensed_image(session, story: Story, members, now: datetime) -> str | None:
    """Görsel yalnız https ve image izni varsa döner. Dosya indirilmez."""
    if not members:
        return None
    source = members[0][1]
    grant = active_grant(session, source, now)
    if not entitlement_allowed(session, grant, "image"):
        return None
    from app.models import Asset

    asset = session.scalar(select(Asset).where(Asset.owner_type == "story", Asset.owner_id == story.id, Asset.kind == "remote_image"))
    if asset is None or not asset.storage_ref or not asset.storage_ref.startswith("https://"):
        return None
    return asset.storage_ref


def _public_sources(session, story, now, settings: Settings) -> list[SourceLink]:
    links = []
    for item, source in _active_members(session, story.id):
        if source.synthetic and not settings.synthetic_allowed:
            continue
        grant = active_grant(session, source, now)
        if not entitlement_allowed(session, grant, "link"):
            continue
        show_meta = entitlement_allowed(session, grant, "metadata")
        show_title = entitlement_allowed(session, grant, "source_title")
        links.append(
            SourceLink(
                id=item.id,
                source_id=source.id,
                publisher_name=source.name if show_meta else None,
                domain=source.domain if show_meta else None,
                source_title=item.source_title if show_title and item.source_title else None,
                published_at=as_utc(item.published_at),
                canonical_url=item.canonical_url,
                partnership_label=source.partnership_label if show_meta else None,
                partnership_note=source.partnership_note if show_meta else None,
            )
        )
    return links


def _visibility_clauses(settings: Settings, now: datetime):
    # Sentetik kural gevşetilmez: üretimde allow_synthetic zaten kapalıdır.
    # NewsAPI geliştirici kayıtları üretim akışına girmez.
    return live_feed_clauses(
        now,
        hide_synthetic=not settings.synthetic_allowed,
        hide_newsapi=settings.app_env == "production",
    )


def _visible(session: Session, settings: Settings, now: datetime):
    clauses = _visibility_clauses(settings, now)
    hidden = suppressed_duplicate_ids(session, clauses)
    if hidden:
        clauses.append(Story.id.notin_(tuple(hidden)))
    return clauses


def _is_visible(session: Session, story: Story, settings: Settings, now: datetime) -> bool:
    if story.status not in PUBLIC_STATUSES:
        return False
    if story.rights_expires_at and as_utc(story.rights_expires_at) <= now:
        return False
    if not settings.synthetic_allowed:
        if story.synthetic or _linked_source(session, story.id, synthetic=True):
            return False
    if settings.app_env == "production" and _linked_source(session, story.id, domain="newsapi.org"):
        return False
    hidden = suppressed_duplicate_ids(session, _visibility_clauses(settings, now))
    return story.id not in hidden


def _linked_source(session: Session, story_id: str, *, synthetic: bool = False, domain: str | None = None) -> bool:
    stmt = (
        select(Source.id)
        .join(SourceItem, SourceItem.source_id == Source.id)
        .join(StorySource, StorySource.source_item_id == SourceItem.id)
        .where(StorySource.story_id == story_id, StorySource.removed_at.is_(None))
    )
    if synthetic:
        stmt = stmt.where(Source.synthetic.is_(True))
    if domain is not None:
        stmt = stmt.where(Source.domain == domain)
    if not synthetic and domain is None:
        return False
    return session.scalar(stmt.limit(1)) is not None


def _encode_cursor(story: Story) -> str:
    moment = as_utc(story.published_at).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    raw = f"{story.editor_priority}|{moment}|{story.id}"
    return base64.urlsafe_b64encode(raw.encode()).decode()


def _decode_cursor(cursor: str):
    try:
        raw = base64.urlsafe_b64decode(cursor.encode()).decode()
        priority_raw, moment_raw, story_id = raw.split("|", 2)
        priority = int(priority_raw)
        moment = datetime.fromisoformat(moment_raw.replace("Z", "+00:00"))
        if len(story_id) < 32:
            raise ValueError
        return priority, moment, story_id
    except (ValueError, UnicodeError):
        raise ApiError(400, "cursor_invalid", "Sayfalama imleci geçersiz.", retryable=False) from None


def _ttl(settings: Settings, now: datetime, stories: list[Story]) -> int:
    ttl = settings.feed_cache_ttl_seconds
    for story in stories:
        if story.rights_expires_at:
            remaining = int((as_utc(story.rights_expires_at) - now).total_seconds())
            ttl = min(ttl, max(remaining, 0))
    return ttl


def _search_after(story: Story, moment: datetime, story_id: str) -> bool:
    published = as_utc(story.published_at)
    if published < moment:
        return True
    if published == moment and story.id < story_id:
        return True
    return False
