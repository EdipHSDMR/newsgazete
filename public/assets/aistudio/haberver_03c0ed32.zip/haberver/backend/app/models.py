"""Kalıcı model. Tam metin sütunu yoktur; hak kaydı birinci sınıf varlıktır."""

from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

ITEM_STATUSES = (
    "candidate",
    "quarantined",
    "needs_rights",
    "editorial_review",
    "scheduled",
    "published",
    "corrected",
    "withdrawn",
    "expired",
)
SOURCE_STATUSES = (
    "candidate",
    "domain_verified",
    "rights_review",
    "scope_defined",
    "testing",
    "approved",
    "canary",
    "active",
    "paused",
    "suspended",
    "rejected",
)


class Base(DeclarativeBase):
    pass


def _status_check(name: str, values: tuple[str, ...]) -> CheckConstraint:
    quoted = ", ".join(f"'{value}'" for value in values)
    return CheckConstraint(f"status IN ({quoted})", name=name)


class Topic(Base):
    __tablename__ = "topics"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    slug: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(80))
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Source(Base):
    __tablename__ = "sources"
    __table_args__ = (_status_check("ck_source_status", SOURCE_STATUSES),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    domain: Mapped[str] = mapped_column(String(255))
    allowed_host: Mapped[str] = mapped_column(String(255))
    feed_url: Mapped[str] = mapped_column(Text)
    source_type: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(40), default="candidate")
    editorial_description: Mapped[str] = mapped_column(Text, default="")
    partnership_label: Mapped[str | None] = mapped_column(String(120), nullable=True)
    partnership_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String(200), nullable=True)
    terms_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    legal_approved_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    legal_approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    source_admin_approved_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    source_admin_approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    user_agent: Mapped[str] = mapped_column(String(240))
    rate_limit_per_minute: Mapped[int] = mapped_column(Integer, default=6)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=10)
    etag: Mapped[str | None] = mapped_column(String(240), nullable=True)
    last_modified_header: Mapped[str | None] = mapped_column(String(240), nullable=True)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_fetch_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(400), nullable=True)
    paused_reason: Mapped[str | None] = mapped_column(String(300), nullable=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class LicenseGrant(Base):
    __tablename__ = "license_grants"
    __table_args__ = (UniqueConstraint("source_id", "version", name="uq_grant_version"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("sources.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    kind: Mapped[str] = mapped_column(String(40))
    document_ref: Mapped[str] = mapped_column(Text)
    rights_holder: Mapped[str] = mapped_column(String(200))
    signed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    platform: Mapped[str] = mapped_column(String(40))
    country: Mapped[str] = mapped_column(String(8))
    purpose: Mapped[str] = mapped_column(String(80))
    attribution_required: Mapped[bool] = mapped_column(Boolean, default=True)
    attribution_text: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="draft")
    supersedes_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_by: Mapped[str] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Entitlement(Base):
    __tablename__ = "entitlements"
    __table_args__ = (UniqueConstraint("grant_id", "key", "surface", name="uq_entitlement"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    grant_id: Mapped[str] = mapped_column(ForeignKey("license_grants.id"), index=True)
    key: Mapped[str] = mapped_column(String(40))
    allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    region: Mapped[str] = mapped_column(String(8), default="TR")
    surface: Mapped[str] = mapped_column(String(40), default="android")
    purpose: Mapped[str] = mapped_column(String(80), default="editorial_discovery")


class RightsDecision(Base):
    __tablename__ = "rights_decisions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("sources.id"), index=True)
    grant_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    source_item_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    field_key: Mapped[str] = mapped_column(String(40))
    allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    reason: Mapped[str] = mapped_column(String(300))
    decided_by: Mapped[str] = mapped_column(String(120))
    decided_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SourceItem(Base):
    __tablename__ = "source_items"
    __table_args__ = (
        UniqueConstraint("source_id", "external_id", name="uq_source_external"),
        UniqueConstraint("source_id", "canonical_hash", name="uq_source_canonical"),
        _status_check("ck_item_status", ITEM_STATUSES),
        Index("ix_item_source_status", "source_id", "status"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("sources.id"), index=True)
    external_id: Mapped[str] = mapped_column(String(400))
    canonical_url: Mapped[str] = mapped_column(Text)
    original_url: Mapped[str] = mapped_column(Text)
    canonical_hash: Mapped[str] = mapped_column(String(64))
    source_title: Mapped[str] = mapped_column(Text, default="")
    source_description: Mapped[str] = mapped_column(Text, default="")
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    locale: Mapped[str] = mapped_column(String(16), default="tr")
    content_hash: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(40), default="candidate")
    quarantine_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    grant_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    possible_duplicate_of: Mapped[str | None] = mapped_column(String(36), nullable=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Story(Base):
    __tablename__ = "stories"
    __table_args__ = (
        _status_check("ck_story_status", ITEM_STATUSES),
        Index("ix_story_published", "published_at", "id"),
        Index("ix_story_topic", "topic_id", "published_at"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    editorial_title: Mapped[str] = mapped_column(Text)
    editorial_summary: Mapped[str] = mapped_column(Text)
    context_note: Mapped[str] = mapped_column(Text, default="")
    topic_id: Mapped[str] = mapped_column(ForeignKey("topics.id"), index=True)
    authorship_label: Mapped[str] = mapped_column(String(160), default="Editoryal özet")
    editor_actor: Mapped[str] = mapped_column(String(120))
    verification_note: Mapped[str] = mapped_column(Text, default="")
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(40), default="editorial_review")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    single_source_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    developing: Mapped[bool] = mapped_column(Boolean, default=False)
    uncertainty_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    risk_level: Mapped[str] = mapped_column(String(20), default="normal")
    content_warning: Mapped[str | None] = mapped_column(Text, nullable=True)
    second_approver: Mapped[str | None] = mapped_column(String(120), nullable=True)
    editor_priority: Mapped[int] = mapped_column(Integer, default=0)
    ranking_reason: Mapped[str] = mapped_column(String(160), default="güncellik")
    ai_assisted: Mapped[bool] = mapped_column(Boolean, default=False)
    ai_role_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    rights_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class StorySource(Base):
    __tablename__ = "story_sources"
    __table_args__ = (Index("ix_story_source_story", "story_id"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(ForeignKey("stories.id"))
    source_item_id: Mapped[str] = mapped_column(ForeignKey("source_items.id"))
    added_by: Mapped[str] = mapped_column(String(120))
    added_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    removed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    removed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)


class SummaryVersion(Base):
    __tablename__ = "summary_versions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(ForeignKey("stories.id"), index=True)
    editorial_title: Mapped[str] = mapped_column(Text)
    editorial_summary: Mapped[str] = mapped_column(Text)
    context_note: Mapped[str] = mapped_column(Text, default="")
    author: Mapped[str] = mapped_column(String(120))
    reason: Mapped[str] = mapped_column(String(300))
    ai_assisted: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Correction(Base):
    __tablename__ = "corrections"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(ForeignKey("stories.id"), index=True)
    summary_version_id: Mapped[str] = mapped_column(ForeignKey("summary_versions.id"))
    previous_summary_version_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    reason: Mapped[str] = mapped_column(Text)
    editor: Mapped[str] = mapped_column(String(120))
    public: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner_type: Mapped[str] = mapped_column(String(40))
    owner_id: Mapped[str] = mapped_column(String(36))
    kind: Mapped[str] = mapped_column(String(40))
    rights_decision_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    storage_ref: Mapped[str | None] = mapped_column(Text, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Complaint(Base):
    __tablename__ = "complaints"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    source_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    url: Mapped[str] = mapped_column(Text, default="")
    claim: Mapped[str] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(40), default="received")
    decision: Mapped[str | None] = mapped_column(String(40), nullable=True)
    decision_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    response_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class ReaderReport(Base):
    __tablename__ = "reader_reports"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(ForeignKey("stories.id"), index=True)
    category: Mapped[str] = mapped_column(String(40))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="received")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    actor: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(80))
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str] = mapped_column(String(36))
    reason: Mapped[str] = mapped_column(Text, default="")
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class IngestJob(Base):
    __tablename__ = "ingest_jobs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("sources.id"), index=True)
    idempotency_key: Mapped[str] = mapped_column(String(200), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="queued")
    attempt: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=5)
    next_run_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    lease_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    leased_by: Mapped[str | None] = mapped_column(String(80), nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(400), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class PushOutbox(Base):
    __tablename__ = "push_outbox"
    __table_args__ = (UniqueConstraint("dedupe_key", name="uq_push_dedupe"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(ForeignKey("stories.id"), index=True)
    dedupe_key: Mapped[str] = mapped_column(String(80))
    title: Mapped[str] = mapped_column(String(180))
    body: Mapped[str] = mapped_column(String(240))
    deep_link: Mapped[str] = mapped_column(String(240))
    status: Mapped[str] = mapped_column(String(40))
    reason: Mapped[str] = mapped_column(String(200), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class AnalyticsEvent(Base):
    __tablename__ = "analytics_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(40))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    app_version: Mapped[str] = mapped_column(String(40))
    installation_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    story_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    topic_slug: Mapped[str | None] = mapped_column(String(40), nullable=True)


class IdempotencyRecord(Base):
    __tablename__ = "idempotency_records"
    key: Mapped[str] = mapped_column(String(200), primary_key=True)
    actor_name: Mapped[str] = mapped_column(String(120))
    request_hash: Mapped[str] = mapped_column(String(64))
    status_code: Mapped[int] = mapped_column(Integer)
    response_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
