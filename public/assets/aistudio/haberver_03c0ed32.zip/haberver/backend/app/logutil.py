import logging

ALLOWED_LOG_FIELDS = {
    "event",
    "source_id",
    "story_id",
    "status",
    "code",
    "attempt",
    "request_id",
    "job_id",
}

logger = logging.getLogger("haberver")


def safe_log(event: str, **fields: object) -> None:
    clean = {key: value for key, value in fields.items() if key in ALLOWED_LOG_FIELDS}
    logger.info("%s %s", event, clean)
