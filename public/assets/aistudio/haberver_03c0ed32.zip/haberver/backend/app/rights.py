"""Hak kararı. Bilinmeyen hak kapalıdır. Sentetik kayıt hukuki lisans değildir."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import as_utc
from app.models import Entitlement, LicenseGrant, RightsDecision, Source

ENTITLEMENT_KEYS = (
    "link",
    "metadata",
    "source_title",
    "excerpt",
    "image",
    "logo",
    "push_quote",
)


def active_grant(session: Session, source: Source, now: datetime) -> LicenseGrant | None:
    grants = session.scalars(
        select(LicenseGrant)
        .where(LicenseGrant.source_id == source.id, LicenseGrant.status == "active")
        .order_by(LicenseGrant.version.desc())
    ).all()
    for grant in grants:
        if as_utc(grant.starts_at) <= now < as_utc(grant.expires_at):
            if grant.kind == "synthetic_demo" and not source.synthetic:
                continue
            return grant
    return None


def entitlement_allowed(session: Session, grant: LicenseGrant | None, key: str) -> bool:
    if grant is None or key not in ENTITLEMENT_KEYS:
        return False
    row = session.scalar(
        select(Entitlement).where(
            Entitlement.grant_id == grant.id,
            Entitlement.key == key,
            Entitlement.surface == "android",
        )
    )
    return bool(row and row.allowed)


def decide(
    session: Session,
    source: Source,
    key: str,
    now: datetime,
    actor: str,
    *,
    synthetic_allowed: bool,
    item_id: str | None = None,
) -> RightsDecision:
    grant = active_grant(session, source, now)
    allowed = False
    reason = "izin kaydı yok"
    expires = None
    grant_id = None
    if source.status in {"paused", "suspended", "rejected"}:
        reason = "kaynak kapalı"
    elif source.synthetic and not synthetic_allowed:
        reason = "sentetik veri bu ortamda kapalı"
    elif grant is None:
        reason = "yürürlükte izin yok veya süre doldu"
    elif grant.kind == "synthetic_demo" and not synthetic_allowed:
        reason = "sentetik demo izni üretimde geçersiz"
    else:
        grant_id = grant.id
        expires = grant.expires_at
        allowed = entitlement_allowed(session, grant, key)
        reason = "izin kapsamı açık" if allowed else "bu alan için izin kaydı kapalı veya yok"
    decision = RightsDecision(
        id=_new_id(),
        source_id=source.id,
        grant_id=grant_id,
        source_item_id=item_id,
        field_key=key,
        allowed=allowed,
        reason=reason,
        decided_by=actor,
        decided_at=now,
        expires_at=expires,
    )
    session.add(decision)
    return decision


def _new_id() -> str:
    import uuid

    return str(uuid.uuid4())
