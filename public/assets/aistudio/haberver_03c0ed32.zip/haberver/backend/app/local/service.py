"""Yerel gündem süzme. Sahte haber üretmez; mevcut görünür feed kayıtlarını süzer."""

from __future__ import annotations

import re
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import as_utc
from app.config import Settings
from app.local.catalog import match_tokens, resolve_place, search_cities
from app.models import Story
from app.reading import _decode_cursor, _encode_cursor, _public_sources, _visible, card_for
from app.schemas import StoryCard

LICENSE_NOTE = (
    "Yalnızca izin kaydı açık özet, kaynak adı, zaman ve kanonik bağlantı gösterilir. "
    "Tam metin kopyalanmaz; okumak için yayıncı sayfasına gidilir."
)
CONFIG_NOTE_EMPTY = (
    "Bu şehir/ilçe için yayında eşleşen yerel özet yok. "
    "Akış yalnızca mevcut feed kayıtlarından topic_slug=yerel veya başlık/şehir adı eşlemesiyle süzülür; "
    "yeni yerel kaynak yapılandırılmadan başlık üretilmez."
)
KIND_DUYURU = re.compile(
    r"\b(duyuru|ilan|bilgilendirme|mahalle panosu|resmi a[cç][iı]klama)\b",
    re.IGNORECASE,
)
KIND_SERVIS = re.compile(
    r"\b(ula[sş][iı]m|sefer|elektrik|do[gğ]algaz|su kesint|trafi[kğ]|bak[iı]m|kapal[iı]|yol [cç]al[iı][sş]m)\b",
    re.IGNORECASE,
)


def list_cities(q: str | None = None, *, limit: int = 40) -> dict:
    items = search_cities(q, limit=limit)
    return {"items": items, "q": (q or "").strip() or None, "count": len(items)}


def local_feed(
    session: Session,
    settings: Settings,
    now: datetime,
    *,
    city: str,
    district: str | None,
    cursor: str | None,
    limit: int,
) -> dict:
    if limit < 1 or limit > 30:
        from app.errors import ApiError

        raise ApiError(400, "limit_invalid", "Sayfa boyutu 1 ile 30 arasında olmalıdır.", retryable=False)

    city_row, district_row = resolve_place(city, district)
    tokens = match_tokens(city_row, district_row)
    rows = session.scalars(
        select(Story)
        .where(*_visible(session, settings, now))
        .order_by(Story.editor_priority.desc(), Story.published_at.desc(), Story.id.desc())
        .limit(400)
    ).all()

    matched: list[tuple[Story, StoryCard, str, str | None]] = []
    for story in rows:
        card = card_for(session, story, now)
        hit = _match_reason(card, tokens)
        if hit is None:
            continue
        sources = _public_sources(session, story, now, settings)
        primary = sources[0] if sources else None
        # Kaynak bağlantısı yoksa kartı gösterme (lisans sınırı).
        if primary is None or not primary.canonical_url:
            continue
        kind = classify_kind(card.editorial_title, card.editorial_summary)
        matched.append((story, card, hit, kind))

    if cursor:
        matched = _after_cursor(matched, cursor)

    page = matched[:limit]
    next_cursor = _encode_cursor(page[-1][0]) if len(matched) > limit and page else None
    items = [_local_card(card, hit, kind, session, story, now, settings) for story, card, hit, kind in page]
    empty = not items and cursor is None
    publishers = sorted(
        {
            label
            for label in ((item.get("publisher_name") or "").strip() for item in items)
            if label and label.casefold() != "newsapi"
        }
    )
    return {
        "city": {"slug": city_row["slug"], "name": city_row["name"], "plate": city_row["plate"]},
        "district": district_row,
        "items": items,
        "next_cursor": next_cursor,
        "empty": empty,
        "config_note": CONFIG_NOTE_EMPTY if empty else None,
        "license_note": LICENSE_NOTE,
        "publishers": publishers,
        "match_tokens": tokens,
    }


def classify_kind(title: str, summary: str) -> str:
    """Mümkünse haber/duyuru/servis; bilinmiyorsa haber."""
    text = f"{title} {summary}"
    if KIND_DUYURU.search(text):
        return "duyuru"
    if KIND_SERVIS.search(text):
        return "servis"
    return "haber"


def _fold(value: str) -> str:
    from app.local.catalog import _ascii_tr

    return _ascii_tr(value)


def _match_reason(card: StoryCard, tokens: list[str]) -> str | None:
    """topic_slug=yerel veya başlık/şehir adı. Şehir seçiliyken yer adı zorunlu (karışık il yok)."""
    hay = _fold(f"{card.editorial_title} {card.editorial_summary} {card.authorship_label}")
    place_hit = None
    for token in tokens:
        folded = _fold(token)
        if folded in hay:
            place_hit = "title" if folded in _fold(card.editorial_title) else "place"
            break
    if place_hit is None:
        return None
    if card.topic_slug == "yerel":
        return "topic"
    return place_hit


def _local_card(card, hit, kind, session, story, now, settings) -> dict:
    sources = _public_sources(session, story, now, settings)
    primary = sources[0]
    payload = card.model_dump(mode="json")
    publisher = _publisher_label(primary, card.authorship_label)
    # Spot özeti zaten editöryal; gövde/tam metin eklenmez.
    payload.update(
        {
            "local_kind": kind,
            "matched_on": hit,
            "publisher_name": publisher,
            "canonical_url": primary.canonical_url,
            "source_title": primary.source_title,
        }
    )
    return payload


def _publisher_label(primary, authorship: str) -> str:
    """Toplayıcı adını (NewsAPI) gizle; domain veya authorship tercih et."""
    domain = (primary.domain or "").strip().lower()
    name = (primary.publisher_name or "").strip()
    auth = (authorship or "").strip()
    if domain and domain not in {"newsapi.org", "example.com"}:
        return domain.removeprefix("www.")
    if name and name.casefold() not in {"newsapi", "sentetik demo yayın", "sentetik demo ajans"}:
        return name
    if auth:
        return auth
    return name or domain or "Kaynak"


def _after_cursor(matched, cursor: str):
    priority, moment, story_id = _decode_cursor(cursor)
    out = []
    for story, card, hit, kind in matched:
        published = as_utc(story.published_at)
        if story.editor_priority < priority:
            out.append((story, card, hit, kind))
        elif story.editor_priority == priority and published < moment:
            out.append((story, card, hit, kind))
        elif story.editor_priority == priority and published == moment and story.id < story_id:
            out.append((story, card, hit, kind))
    return out
