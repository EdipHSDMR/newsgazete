"""Türkiye il/ilçe katalogu. Resmî coğrafi isimler; haber içeriği değildir."""

from __future__ import annotations

from functools import lru_cache

from app.local.prefs import LocalPreference


def _ascii_tr(value: str) -> str:
    """Türkçe İ/ı önce düz ASCII'ye; casefold birleşik nokta üretmesin."""
    table = str.maketrans(
        {
            "İ": "i",
            "I": "i",
            "ı": "i",
            "Ğ": "g",
            "ğ": "g",
            "Ü": "u",
            "ü": "u",
            "Ş": "s",
            "ş": "s",
            "Ö": "o",
            "ö": "o",
            "Ç": "c",
            "ç": "c",
        }
    )
    return value.translate(table).casefold()


def _slug(name: str) -> str:
    raw = _ascii_tr(name.strip())
    cleaned = "".join(ch if ch.isalnum() or ch == "-" else "-" for ch in raw)
    return "-".join(part for part in cleaned.split("-") if part)


def _city(plate: str, name: str, districts: tuple[str, ...] = ()) -> dict:
    return {
        "slug": _slug(name),
        "name": name,
        "plate": plate,
        "districts": [{"slug": _slug(d), "name": d} for d in districts],
    }


# İlçeler büyükşehirlerde sık kullanılanlar; diğer illerde merkez/ilçe seçimi boş kalabilir.
_CITIES: tuple[dict, ...] = (
    _city("01", "Adana", ("Seyhan", "Çukurova", "Yüreğir", "Sarıçam", "Ceyhan")),
    _city("02", "Adıyaman", ("Merkez", "Kahta")),
    _city("03", "Afyonkarahisar", ("Merkez", "Sandıklı")),
    _city("04", "Ağrı", ("Merkez", "Doğubayazıt")),
    _city("05", "Amasya", ("Merkez", "Merzifon")),
    _city(
        "06",
        "Ankara",
        ("Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Etimesgut", "Sincan", "Altındağ", "Pursaklar"),
    ),
    _city("07", "Antalya", ("Muratpaşa", "Kepez", "Konyaaltı", "Alanya", "Manavgat", "Serik")),
    _city("08", "Artvin", ("Merkez", "Hopa")),
    _city("09", "Aydın", ("Efeler", "Nazilli", "Söke", "Kuşadası")),
    _city("10", "Balıkesir", ("Altıeylül", "Karesi", "Edremit", "Bandırma")),
    _city("11", "Bilecik", ("Merkez",)),
    _city("12", "Bingöl", ("Merkez",)),
    _city("13", "Bitlis", ("Merkez", "Tatvan")),
    _city("14", "Bolu", ("Merkez",)),
    _city("15", "Burdur", ("Merkez",)),
    _city(
        "16",
        "Bursa",
        ("Osmangazi", "Nilüfer", "Yıldırım", "İnegöl", "Gemlik", "Mudanya"),
    ),
    _city("17", "Çanakkale", ("Merkez", "Biga", "Gelibolu")),
    _city("18", "Çankırı", ("Merkez",)),
    _city("19", "Çorum", ("Merkez",)),
    _city("20", "Denizli", ("Merkezefendi", "Pamukkale", "Çivril")),
    _city("21", "Diyarbakır", ("Bağlar", "Kayapınar", "Yenişehir", "Sur", "Ergani")),
    _city("22", "Edirne", ("Merkez", "Keşan")),
    _city("23", "Elazığ", ("Merkez",)),
    _city("24", "Erzincan", ("Merkez",)),
    _city("25", "Erzurum", ("Yakutiye", "Palandöken", "Aziziye")),
    _city("26", "Eskişehir", ("Odunpazarı", "Tepebaşı")),
    _city("27", "Gaziantep", ("Şahinbey", "Şehitkamil", "Nizip")),
    _city("28", "Giresun", ("Merkez",)),
    _city("29", "Gümüşhane", ("Merkez",)),
    _city("30", "Hakkari", ("Merkez",)),
    _city("31", "Hatay", ("Antakya", "İskenderun", "Defne", "Reyhanlı")),
    _city("32", "Isparta", ("Merkez",)),
    _city("33", "Mersin", ("Yenişehir", "Mezitli", "Toroslar", "Akdeniz", "Tarsus", "Erdemli")),
    _city(
        "34",
        "İstanbul",
        (
            "Kadıköy",
            "Üsküdar",
            "Beşiktaş",
            "Şişli",
            "Fatih",
            "Bakırköy",
            "Başakşehir",
            "Esenyurt",
            "Pendik",
            "Kartal",
            "Maltepe",
            "Ataşehir",
            "Sarıyer",
            "Beylikdüzü",
            "Ümraniye",
            "Gaziosmanpaşa",
            "Kağıthane",
            "Zeytinburnu",
            "Avcılar",
            "Beykoz",
        ),
    ),
    _city(
        "35",
        "İzmir",
        ("Konak", "Karşıyaka", "Bornova", "Buca", "Bayraklı", "Çiğli", "Gaziemir", "Karabağlar"),
    ),
    _city("36", "Kars", ("Merkez",)),
    _city("37", "Kastamonu", ("Merkez",)),
    _city("38", "Kayseri", ("Melikgazi", "Kocasinan", "Talas")),
    _city("39", "Kırklareli", ("Merkez", "Lüleburgaz")),
    _city("40", "Kırşehir", ("Merkez",)),
    _city("41", "Kocaeli", ("İzmit", "Gebze", "Darıca", "Gölcük", "Körfez")),
    _city("42", "Konya", ("Selçuklu", "Meram", "Karatay", "Ereğli")),
    _city("43", "Kütahya", ("Merkez",)),
    _city("44", "Malatya", ("Battalgazi", "Yeşilyurt")),
    _city("45", "Manisa", ("Yunusemre", "Şehzadeler", "Akhisar", "Turgutlu")),
    _city("46", "Kahramanmaraş", ("Onikişubat", "Dulkadiroğlu", "Elbistan")),
    _city("47", "Mardin", ("Artuklu", "Kızıltepe", "Midyat")),
    _city("48", "Muğla", ("Menteşe", "Bodrum", "Fethiye", "Marmaris", "Milas")),
    _city("49", "Muş", ("Merkez",)),
    _city("50", "Nevşehir", ("Merkez", "Ürgüp")),
    _city("51", "Niğde", ("Merkez",)),
    _city("52", "Ordu", ("Altınordu", "Fatsa", "Ünye")),
    _city("53", "Rize", ("Merkez", "Çayeli")),
    _city("54", "Sakarya", ("Adapazarı", "Serdivan", "Erenler", "Hendek")),
    _city("55", "Samsun", ("İlkadım", "Atakum", "Canik", "Bafra")),
    _city("56", "Siirt", ("Merkez",)),
    _city("57", "Sinop", ("Merkez",)),
    _city("58", "Sivas", ("Merkez",)),
    _city("59", "Tekirdağ", ("Süleymanpaşa", "Çorlu", "Çerkezköy")),
    _city("60", "Tokat", ("Merkez",)),
    _city("61", "Trabzon", ("Ortahisar", "Akçaabat", "Yomra")),
    _city("62", "Tunceli", ("Merkez",)),
    _city("63", "Şanlıurfa", ("Haliliye", "Eyyübiye", "Karaköprü", "Siverek")),
    _city("64", "Uşak", ("Merkez",)),
    _city("65", "Van", ("İpekyolu", "Tuşba", "Edremit")),
    _city("66", "Yozgat", ("Merkez",)),
    _city("67", "Zonguldak", ("Merkez", "Ereğli", "Çaycuma")),
    _city("68", "Aksaray", ("Merkez",)),
    _city("69", "Bayburt", ("Merkez",)),
    _city("70", "Karaman", ("Merkez",)),
    _city("71", "Kırıkkale", ("Merkez",)),
    _city("72", "Batman", ("Merkez",)),
    _city("73", "Şırnak", ("Merkez", "Cizre")),
    _city("74", "Bartın", ("Merkez",)),
    _city("75", "Ardahan", ("Merkez",)),
    _city("76", "Iğdır", ("Merkez",)),
    _city("77", "Yalova", ("Merkez", "Çınarcık")),
    _city("78", "Karabük", ("Merkez", "Safranbolu")),
    _city("79", "Kilis", ("Merkez",)),
    _city("80", "Osmaniye", ("Merkez",)),
    _city("81", "Düzce", ("Merkez", "Akçakoca")),
)


@lru_cache(maxsize=1)
def all_cities() -> tuple[dict, ...]:
    return _CITIES


def _fold(value: str) -> str:
    return _ascii_tr(value)


def search_cities(q: str | None = None, *, limit: int = 40) -> list[dict]:
    """İl adı veya plaka ile süz. Boş sorgu tüm illeri döner (limit içinde)."""
    limit = max(1, min(int(limit or 40), 81))
    rows = list(all_cities())
    query = (q or "").strip()
    if query:
        needle = _fold(query)
        rows = [
            row
            for row in rows
            if needle in _fold(row["name"])
            or needle in _fold(row["slug"])
            or needle == row["plate"]
            or needle.lstrip("0") == row["plate"].lstrip("0")
        ]
    return [
        {
            "slug": row["slug"],
            "name": row["name"],
            "plate": row["plate"],
            "districts": list(row["districts"]),
        }
        for row in rows[:limit]
    ]


def resolve_place(city: str, district: str | None = None) -> tuple[dict, dict | None]:
    """city/district slug veya adını katalog satırına çevirir."""
    pref = LocalPreference(city_slug=city, district_slug=district or None)
    city_slug = pref.city_slug
    district_slug = pref.district_slug
    city_row = next((row for row in all_cities() if row["slug"] == city_slug), None)
    if city_row is None:
        needle = _fold(city)
        city_row = next(
            (row for row in all_cities() if _fold(row["name"]) == needle or row["plate"] == city.strip()),
            None,
        )
    if city_row is None:
        from app.errors import ApiError

        raise ApiError(400, "city_invalid", "Şehir katalogda yok.", retryable=False)
    district_row = None
    if district_slug:
        district_row = next((d for d in city_row["districts"] if d["slug"] == district_slug), None)
        if district_row is None:
            needle = _fold(district or "")
            district_row = next((d for d in city_row["districts"] if _fold(d["name"]) == needle), None)
        if district_row is None:
            from app.errors import ApiError

            raise ApiError(400, "district_invalid", "İlçe bu şehirde yok.", retryable=False)
    return (
        {
            "slug": city_row["slug"],
            "name": city_row["name"],
            "plate": city_row["plate"],
            "districts": list(city_row["districts"]),
        },
        district_row,
    )


def match_tokens(city_row: dict, district_row: dict | None) -> list[str]:
    """Başlık/özette aranacak yer adları (kısa ve güvenli)."""
    tokens = [city_row["name"], city_row["slug"].replace("-", " ")]
    if district_row and district_row["name"].casefold() not in {"merkez"}:
        tokens.append(district_row["name"])
        tokens.append(district_row["slug"].replace("-", " "))
    # Tekrarları düşür, en uzundan kısaya (daha spesifik önce).
    seen: set[str] = set()
    ordered: list[str] = []
    for token in sorted({t.strip() for t in tokens if t and t.strip()}, key=len, reverse=True):
        key = _fold(token)
        if key in seen or len(key) < 3:
            continue
        seen.add(key)
        ordered.append(token)
    return ordered
