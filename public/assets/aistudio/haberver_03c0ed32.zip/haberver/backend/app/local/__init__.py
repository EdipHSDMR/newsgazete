"""İl/ilçe yerel gündem. Sahte haber üretmez; yalnızca mevcut izinli özetleri süzer."""

from app.local.router import router

__all__ = ["router"]
