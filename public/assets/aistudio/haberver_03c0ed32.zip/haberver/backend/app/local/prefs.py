"""Yerel tercih modeli. Sunucu doğrular; kalıcılık istemci localStorage'tadır."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator


class LocalPreference(BaseModel):
    """Elle seçilen şehir/ilçe. GPS alanı yoktur."""

    model_config = ConfigDict(extra="forbid")

    city_slug: str = Field(min_length=2, max_length=64)
    district_slug: str | None = Field(default=None, max_length=64)

    @field_validator("city_slug", "district_slug", mode="before")
    @classmethod
    def _normalize_slug(cls, value):
        if value is None or value == "":
            return None
        from app.local.catalog import _slug

        return _slug(str(value)) or None


STORAGE_KEY = "cizgi.local.v1"
