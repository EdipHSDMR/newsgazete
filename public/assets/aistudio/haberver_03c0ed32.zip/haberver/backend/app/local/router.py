"""GET /v1/local/cities ve GET /v1/local/feed."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.local import service as local_service

router = APIRouter(prefix="/v1/local")


def _session(request: Request):
    db: Session = request.app.state.sessions()
    try:
        yield db
    finally:
        db.close()


def _data(payload):
    from app.api import request_id_var

    return {"request_id": request_id_var.get(), "data": payload}


@router.get("/cities")
def get_cities(q: str | None = None, limit: int = 40):
    """İl/ilçe katalogu. GPS yok; elle arama."""
    return _data(local_service.list_cities(q, limit=limit))


@router.get("/feed")
def get_local_feed(
    request: Request,
    city: str,
    district: str | None = None,
    cursor: str | None = None,
    limit: int = 20,
    db: Session = Depends(_session),
):
    """Yalnızca mevcut gerçek feed kayıtlarını süz. Sahte haber yok."""
    from app.services import expire_due

    settings = request.app.state.settings
    now = request.app.state.clock.now()
    expire_due(db, now, request.app.state.metrics)
    return _data(
        local_service.local_feed(
            db,
            settings,
            now,
            city=city,
            district=district,
            cursor=cursor,
            limit=limit,
        )
    )
