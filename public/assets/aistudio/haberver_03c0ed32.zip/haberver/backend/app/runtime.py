from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class _Entry:
    payload: object
    expires_at: datetime


class ResponseCache:
    """Bellek içi yanıt önbelleği.

    get: yalnızca süresi dolmamış yük (hit/miss sayacı).
    get_stale: süresi dolmuş olsa bile son bilinen yük (SWR için).
    set: ttl_seconds <= 0 ise yazmaz.
    """

    def __init__(self) -> None:
        self._store: dict[str, _Entry] = {}
        self.hits = 0
        self.misses = 0

    def get(self, key: str, now: datetime):
        entry = self._store.get(key)
        if entry is None:
            self.misses += 1
            return None
        if entry.expires_at <= now:
            self.misses += 1
            return None
        self.hits += 1
        return entry.payload

    def get_stale(self, key: str):
        """Süresi dolmuş kayıt dahil; yoksa None. Sayacı değiştirmez."""
        entry = self._store.get(key)
        if entry is None:
            return None
        return entry.payload

    def set(self, key: str, payload: object, now: datetime, ttl_seconds: int) -> None:
        if ttl_seconds <= 0:
            return
        self._store[key] = _Entry(payload=payload, expires_at=now + timedelta(seconds=ttl_seconds))

    def purge(self) -> None:
        self._store.clear()

    def prune(self, now: datetime) -> int:
        """Süresi dolmuş anahtarları siler; silinen adedi döner."""
        dead = [key for key, entry in self._store.items() if entry.expires_at <= now]
        for key in dead:
            self._store.pop(key, None)
        return len(dead)


class Metrics:
    def __init__(self) -> None:
        self.ingest_success = 0
        self.parser_errors = 0
        self.parser_alerts = 0
        self.rights_blocks = 0
        self.review_backlog = 0
        self.push_duplicates = 0
        self.cache_purges = 0
        self.empty_feeds = 0

    def snapshot(self) -> dict:
        return {
            "ingest_success": self.ingest_success,
            "parser_errors": self.parser_errors,
            "parser_alerts": self.parser_alerts,
            "rights_blocks": self.rights_blocks,
            "review_backlog": self.review_backlog,
            "push_duplicates": self.push_duplicates,
            "cache_purges": self.cache_purges,
            "empty_feeds": self.empty_feeds,
        }


class RateLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, list[float]] = {}

    def hit(self, key: str, limit: int, now_seconds: float, window: float = 60.0) -> int | None:
        bucket = [stamp for stamp in self._hits.get(key, []) if now_seconds - stamp < window]
        if len(bucket) >= limit:
            self._hits[key] = bucket
            retry = int(window - (now_seconds - bucket[0])) + 1
            return max(retry, 1)
        bucket.append(now_seconds)
        self._hits[key] = bucket
        return None
