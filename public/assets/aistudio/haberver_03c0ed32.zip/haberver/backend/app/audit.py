import uuid
from datetime import datetime

from sqlalchemy.orm import Session

from app.models import AuditEvent, Source
from app.state_machine import transition

SOURCE_TRANSITIONS = {
    "candidate": {"domain_verified", "rejected", "paused"},
    "domain_verified": {"rights_review", "rejected", "paused"},
    "rights_review": {"scope_defined", "rejected", "paused"},
    "scope_defined": {"testing", "approved", "rejected", "paused"},
    "testing": {"approved", "rejected", "paused"},
    "approved": {"canary", "paused", "rejected"},
    "canary": {"active", "paused", "suspended"},
    "active": {"paused", "suspended", "canary"},
    "paused": {"canary", "active", "rejected", "rights_review"},
    "suspended": {"rights_review", "paused"},
    "rejected": set(),
}


def audit(
    session: Session,
    *,
    actor: str,
    role: str,
    action: str,
    entity_type: str,
    entity_id: str,
    reason: str,
    now: datetime,
    metadata: dict | None = None,
) -> None:
    session.add(
        AuditEvent(
            id=str(uuid.uuid4()),
            actor=actor,
            role=role,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            reason=reason[:1000],
            at=now,
            metadata_json=metadata or {},
        )
    )


def move_source(source: Source, target: str) -> None:
    transition(source.status, target, SOURCE_TRANSITIONS)
    source.status = target


def pause_source(session: Session, source: Source, *, actor: str, reason: str, now: datetime) -> None:
    if source.status != "paused":
        if "paused" in SOURCE_TRANSITIONS.get(source.status, set()):
            source.status = "paused"
        else:
            source.status = "paused"
    source.paused_reason = reason[:300]
    source.last_error = reason[:400]
    source.updated_at = now
    audit(
        session,
        actor=actor,
        role="system",
        action="source_paused",
        entity_type="source",
        entity_id=source.id,
        reason=reason,
        now=now,
    )
