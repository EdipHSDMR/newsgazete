NAME = "Çizgi"
PROMISE = "Gündemi bul, bağlamı gör."
STANDARDS = (
    "Bu ekrandaki metin uygulamanın editoryal özetidir. Haberin tam metni yayıncının sitesinde kalır. "
    "Kaynak göstermek yeniden kullanım izni değildir. Yapay zeka metni insan onayı olmadan yayınlanmaz."
)
CORRECTIONS = (
    "Yanlış özet, tarih veya bozuk bağlantı için hikaye ekranından bildirim gönderin. "
    "Düzeltmeler gizlice silinmez; güncelleme zamanı ve gerekçe saklanır."
)
PRIVACY = (
    "Temel okuma hesap istemez. Konu, şehir ve kaydedilenler önce cihazda durur. "
    "Konum izni istenmez. Arama sorgusu analitik kaydına yazılmaz. "
    "Aydınlatma metni ile isteğe bağlı rıza ayrıdır. Bu metin hukuk incelemesi bekler; hukuki görüş değildir."
)
REVENUE = "Gelir modeli TBD. İlk sürümde reklam yok ve sponsor kartı akışa konmaz."
LEGAL = (
    "FSEK, yayıncı koşulları, KVKK ve Google Play kuralları yayın öncesi uzman incelemesi ister. "
    "Bu yazılım hukuki görüş değildir ve hukuki güvence vermez."
)
BRAND = "Çizgi adı seçildi. Ticari marka ve alan adı uygunluğu ayrıca araştırılmalıdır."
