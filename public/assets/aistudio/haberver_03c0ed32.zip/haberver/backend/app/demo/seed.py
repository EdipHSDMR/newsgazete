"""Sentetik demo kurulumu. Bu bir hukuki lisans veya gerçek haber değildir."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.clock import Clock
from app.config import Settings
from app.ingest import ingest_source
from app.models import SourceItem
from app.rights import ENTITLEMENT_KEYS
from app.runtime import Metrics
from app.services import (
    activate_grant,
    add_grant,
    add_member,
    create_source,
    create_story,
    ensure_topics,
    mark_source_live,
    publish_story,
    set_entitlements,
    verify_domain,
)

SUMMARIES = {
    "demo-tramvay": {
        "editorial_title": "Sentetik demo: Örnek hatta planlı bakım seferleri kaydırdı",
        "editorial_summary": "Bu kart gerçek bir haber değildir. Test kurgusunda örnek bir kent içi hat için bakım penceresi açılmış ve seferlerin bir saat ertelendiği belirtilmiştir. Ayrıntı kaynak bağlantısındadır.",
        "topic_slug": "yerel",
        "verification_note": "Sentetik duyuru saati ve bağlantı editörce kontrol edildi.",
        "editor_priority": 0,
        "risk_level": "normal",
    },
    "demo-ekonomi": {
        "editorial_title": "Sentetik demo: Örnek endeks yalnız test verisinde yükseldi",
        "editorial_summary": "Bu kart gerçek bir haber değildir. Kurgusal bir endeks notunda gün içi yönün yukarı olduğu yazılmıştır. Piyasa kararı için kaynak bağlantısına bakılmalıdır.",
        "topic_slug": "ekonomi",
        "verification_note": "Sentetik sayı gerçek borsa verisi değildir.",
        "editor_priority": 0,
        "risk_level": "normal",
    },
    "demo-bilim": {
        "editorial_title": "Sentetik demo: Laboratuvar notu gerçek bir keşif değildir",
        "editorial_summary": "Bu kart gerçek bir haber değildir. Test kaydında örnek bir laboratuvar notunun yalnızca akış denemesi için üretildiği belirtilmiştir. Bilimsel iddia yoktur.",
        "topic_slug": "bilim-teknoloji",
        "verification_note": "Keşif iddiası yok; kayıt sentetik olarak işaretlendi.",
        "editor_priority": 0,
        "risk_level": "normal",
    },
    "demo-spor": {
        "editorial_title": "Sentetik demo: Örnek fikstürde akşam maçı yer değiştirdi",
        "editorial_summary": "Bu kart gerçek bir haber değildir. Kurgusal bir fikstür notunda akşam karşılaşmasının sahasının değiştiği yazılmıştır. Resmi liste kaynak bağlantısındadır.",
        "topic_slug": "spor",
        "verification_note": "Sentetik fikstür; kulüp duyurusu değildir.",
        "editor_priority": 2,
        "risk_level": "normal",
    },
    "demo-saglik": {
        "editorial_title": "Sentetik demo: Sağlık uyarısı incelemede bekliyor",
        "editorial_summary": "Bu kart gerçek bir haber değildir ve yayınlanmamıştır. Yüksek riskli sağlık kurgusu ikinci onay olmadan akışa çıkmaz. Okur bu metni yayında görmemelidir.",
        "topic_slug": "ulusal",
        "verification_note": "Yüksek risk: ikinci göz bekleniyor, otomatik yayın yok.",
        "editor_priority": 0,
        "risk_level": "high",
        "content_warning": "Sağlık konusu. Bu kayıt sentetiktir ve incelemededir.",
        "developing": True,
        "uncertainty_note": "Doğrulama tamamlanmadı.",
    },
}


def load_demo(session, settings: Settings, clock: Clock, metrics: Metrics) -> dict:
    if not settings.synthetic_allowed:
        raise RuntimeError("Sentetik demo bu ortamda kapalı.")
    now = clock.now()
    ensure_topics(session)
    primary = _open_source(
        session,
        clock,
        name="Sentetik Demo Yayın",
        domain="example.com",
        feed_url="fixture://demo-a.xml",
        description="Gerçek bir yayıncı değildir. Yalnız ürün akışını denemek için üretilmiş sentetik kaynaktır.",
    )
    secondary = _open_source(
        session,
        clock,
        name="Sentetik Demo Ajans",
        domain="example.org",
        feed_url="fixture://demo-b.xml",
        description="Gerçek bir ajans değildir. Kümeleme denemesi için ikinci sentetik kaynaktır.",
    )
    ingest_source(session, primary, settings, clock, metrics, actor="kerem")
    ingest_source(session, secondary, settings, clock, metrics, actor="kerem")
    stories = {}
    tramvay_item = _item(session, primary.id, "demo-tramvay")
    for external_id, copy in SUMMARIES.items():
        if external_id == "demo-saglik":
            continue
        item = _item(session, primary.id, external_id)
        story = create_story(session, "ayse", now, _story_payload(item.id, copy), synthetic_allowed=True)
        stories[external_id] = story
    agency_item = _item(session, secondary.id, "demo-tramvay-ajans")
    add_member(session, stories["demo-tramvay"], agency_item.id, "ayse", now, settings)
    for external_id, story in stories.items():
        publish_story(
            session,
            story,
            "ayse",
            now,
            settings,
            metrics,
            send_push=external_id == "demo-spor",
        )
    health = _item(session, primary.id, "demo-saglik")
    health_story = create_story(
        session,
        "ayse",
        now,
        _story_payload(health.id, SUMMARIES["demo-saglik"]),
        synthetic_allowed=True,
    )
    return {"primary_source_id": primary.id, "secondary_source_id": secondary.id, "health_story_id": health_story.id, "tramvay_item_id": tramvay_item.id}


def _open_source(session, clock: Clock, *, name: str, domain: str, feed_url: str, description: str):
    now = clock.now()
    source = create_source(
        session,
        "kerem",
        now,
        {
            "name": name,
            "domain": domain,
            "allowed_host": domain,
            "feed_url": feed_url,
            "source_type": "synthetic_fixture",
            "editorial_description": description,
            "user_agent": "HaberKesifDemo/0.1 (+https://haberver.example/bot)",
            "rate_limit_per_minute": 60,
            "timeout_seconds": 10,
            "synthetic": True,
        },
    )
    verify_domain(session, source, "kerem", now)
    grant = add_grant(
        session,
        source,
        "deniz",
        now,
        {
            "kind": "synthetic_demo",
            "document_ref": "private://licenses/synthetic-demo-not-a-legal-grant",
            "rights_holder": "Sentetik demo hak sahibi değildir",
            "starts_at": now - timedelta(days=1),
            "expires_at": now + timedelta(days=30),
            "platform": "android",
            "country": "TR",
            "purpose": "editorial_discovery",
            "attribution_text": name,
        },
        synthetic_allowed=True,
    )
    set_entitlements(
        session,
        grant,
        "deniz",
        now,
        [{"key": key, "allowed": key in {"link", "metadata"}} for key in ENTITLEMENT_KEYS],
    )
    activate_grant(session, grant, "deniz", now)
    mark_source_live(session, source, "kerem", now, mode="active")
    return source


def _item(session, source_id: str, external_id: str) -> SourceItem:
    item = session.scalar(
        select(SourceItem).where(SourceItem.source_id == source_id, SourceItem.external_id == external_id)
    )
    if item is None:
        raise RuntimeError(f"Öğe bulunamadı: {external_id}")
    return item


def _story_payload(item_id: str, copy: dict) -> dict:
    return {
        "source_item_id": item_id,
        "editorial_title": copy["editorial_title"],
        "editorial_summary": copy["editorial_summary"],
        "context_note": "Olayın ayrıntısı yayıncının sayfasındadır. Bu uygulama tam metin tutmaz.",
        "topic_slug": copy["topic_slug"],
        "verification_note": copy["verification_note"],
        "risk_level": copy["risk_level"],
        "content_warning": copy.get("content_warning"),
        "developing": copy.get("developing", False),
        "uncertainty_note": copy.get("uncertainty_note"),
        "editor_priority": copy["editor_priority"],
        "ai_assisted": False,
        "ai_role_note": None,
    }


def main() -> None:
    from app.db import make_engine, make_session_factory
    from app.models import Base

    settings = Settings()
    if not settings.synthetic_allowed:
        raise SystemExit("ALLOW_SYNTHETIC=true ve APP_ENV=dev olmadan demo yüklenmez.")
    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    clock = Clock()
    clock.freeze(datetime(2026, 10, 22, 15, 0, tzinfo=timezone.utc))
    metrics = Metrics()
    session = make_session_factory(engine)()
    try:
        result = load_demo(session, settings, clock, metrics)
    finally:
        session.close()
    print("Sentetik demo yüklendi. Gerçek haber değildir.")
    print(result)


if __name__ == "__main__":
    main()
