"""Press Haber Ajansı bültenleri. Anahtar yalnız sunucuda. Tam HTML saklanmaz."""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

import httpx
from sqlalchemy import select

from app.clock import Clock, as_utc
from app.config import Settings
from app.db import make_engine, make_session_factory
from app.errors import ApiError
from app.models import Asset, Base, Source, SourceItem, Story, StorySource
from app.news.dedupe import HeadlineIndex
from app.urlsec import canonical_hash, canonicalize
from app.runtime import Metrics
from app.services import (
    activate_grant,
    add_grant,
    create_source,
    create_story,
    ensure_topics,
    manual_item,
    mark_source_live,
    publish_story,
    set_entitlements,
    verify_domain,
)
from app.rights import ENTITLEMENT_KEYS

TOPIC_BY_SECTOR = {
    "teknoloji": "bilim-teknoloji",
    "bilim": "bilim-teknoloji",
    "finans": "ekonomi",
    "ekonomi": "ekonomi",
    "spor": "spor",
    "kultur-sanat": "kultur",
    "kultur": "kultur",
    "cevre": "iklim-cevre",
    "enerji": "iklim-cevre",
    "turizm": "kultur",
    "dunya": "dunya",
    "saglik": "ulusal",
    "egitim": "ulusal",
    "kamu-stk": "ulusal",
    "yerel": "yerel",
}


def _plain(value: str) -> str:
    text = re.sub(r"<[^>]+>", " ", value or "")
    return " ".join(text.split())


def _topic(sectors: list) -> str:
    for sector in sectors or []:
        slug = (sector or {}).get("slug") or ""
        if slug in TOPIC_BY_SECTOR:
            return TOPIC_BY_SECTOR[slug]
    return "ulusal"


def _source(session, clock: Clock) -> Source:
    found = session.scalar(select(Source).where(Source.domain == "www.press.org.tr"))
    if found:
        return found
    now = clock.now()
    source = create_source(
        session,
        "kerem",
        now,
        {
            "name": "Press Haber Ajansı",
            "domain": "www.press.org.tr",
            "allowed_host": "www.press.org.tr",
            "feed_url": "https://www.press.org.tr/api/v1/haberler",
            "source_type": "licensed_api",
            "editorial_description": "Kurumların basın bültenlerini dağıtan ajans. Başlık, spot ve izinli görseller PHA'nın yayımladığı kullanım koşullarına ve kaynak gösterme şartına göre sunulur.",
            "user_agent": "CizgiNewsBot/1.0",
            "rate_limit_per_minute": 30,
            "timeout_seconds": 20,
            "synthetic": False,
        },
    )
    verify_domain(session, source, "kerem", now)
    grant = add_grant(
        session,
        source,
        "deniz",
        now,
        {
            "kind": "published_terms",
            "document_ref": "https://www.press.org.tr/ucretsiz-haber-api",
            "rights_holder": "Press Haber Ajansı",
            "starts_at": now - timedelta(days=1),
            "expires_at": now + timedelta(days=365),
            "platform": "android",
            "country": "TR",
            "purpose": "editorial_discovery",
            "attribution_text": "Press Haber Ajansı",
        },
        synthetic_allowed=False,
    )
    allowed = {"link", "metadata", "source_title", "excerpt", "image"}
    set_entitlements(
        session,
        grant,
        "deniz",
        now,
        [{"key": key, "allowed": key in allowed} for key in ENTITLEMENT_KEYS],
    )
    activate_grant(session, grant, "deniz", now)
    mark_source_live(session, source, "kerem", now, mode="active")
    return source


def sync_bulletins(session, settings: Settings, clock: Clock, metrics: Metrics) -> int:
    if not settings.pha_api_key:
        raise RuntimeError("PHA_API_KEY yok. Anahtar Android uygulamasına konmaz.")
    ensure_topics(session)
    source = _source(session, clock)
    source.user_agent = "CizgiNewsBot/1.0"
    source.editorial_description = "Kurumların basın bültenlerini dağıtan ajans. Başlık, spot ve izinli görseller PHA'nın yayımladığı kullanım koşullarına ve kaynak gösterme şartına göre sunulur."
    params: dict[str, str | int] = {"adet": 30}
    if source.last_success_at:
        # Small overlap prevents a just-published bulletin being missed between polls.
        since = as_utc(source.last_success_at) - timedelta(minutes=5)
        params["since"] = since.isoformat(timespec="seconds").replace("+00:00", "Z")
    # Bülten listesi. Madde URL'si indirilmez; tam HTML saklanmaz.
    response = httpx.get(
        "https://www.press.org.tr/api/v1/haberler",
        params=params,
        headers={"Authorization": f"Bearer {settings.pha_api_key}", "Accept": "application/json", "User-Agent": source.user_agent},
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    added = 0
    now = clock.now()
    index = HeadlineIndex.from_session(session)
    for row in payload.get("items") or []:
        external = str(row.get("id") or "")
        url = str(row.get("url") or "")
        title = _plain(str(row.get("title") or ""))
        # Spot yalnız bülten özeti. Etiket atılır; makale sayfası indirilmez.
        summary = _plain(str(row.get("summary") or ""))
        if not external or not url.startswith("https://www.press.org.tr/") or len(title) < 12 or len(summary) < 40:
            continue
        try:
            canonical = canonicalize(url)
            digest = canonical_hash(url)
        except ApiError:
            continue
        if index.contains(external_id=external, canonical_url=canonical, canonical_hash=digest):
            existing = session.scalar(
                select(SourceItem).where(SourceItem.source_id == source.id, SourceItem.external_id == external)
            )
            link = session.scalar(
                select(StorySource).where(StorySource.source_item_id == existing.id, StorySource.removed_at.is_(None))
            ) if existing else None
            if link:
                linked = session.get(Story, link.story_id)
                org = _plain(str(row.get("organization") or "Kurum"))
                byline = f"{org} (PHA)"[:160]
                if linked and linked.authorship_label != byline:
                    linked.authorship_label = byline
                    session.commit()
            continue
        published = datetime.fromisoformat(str(row.get("date_published")).replace("Z", "+00:00"))
        item = manual_item(
            session,
            "ayse",
            now,
            {
                "source_id": source.id,
                "url": url,
                "external_id": external,
                "published_at": published,
                "observed_facts": "Ajans bülteni. Tam HTML saklanmadı.",
            },
            settings,
        )
        index.absorb(
            external_id=item.external_id,
            canonical_url=item.canonical_url,
            canonical_hash=item.canonical_hash,
        )
        story = create_story(
            session,
            "ayse",
            now,
            {
                "source_item_id": item.id,
                "editorial_title": title,
                "editorial_summary": summary[:700],
                "context_note": "Kurumun basın bültenindeki spot esas alındı. Çizgi bağımsız doğrulama yapmadı; tam HTML metin saklanmadı.",
                "topic_slug": _topic(row.get("sectors") or []),
                "verification_note": "Press Haber Ajansı bülteni. Kurum açıklaması bağımsız olarak doğrulanmadı.",
                "risk_level": "normal",
                "developing": False,
                "editor_priority": 3,
                "ai_assisted": False,
            },
            synthetic_allowed=settings.synthetic_allowed,
        )
        org = _plain(str(row.get("organization") or "Kurum"))
        story.authorship_label = f"{org} (PHA)"[:160]
        item.source_title = title[:500]
        session.commit()
        publish_story(session, story, "ayse", now, settings, metrics, send_push=False)
        story.published_at = published
        story.updated_at = published
        image = row.get("image")
        if isinstance(image, str):
            image = image.strip()
        if isinstance(image, str) and image.startswith("https://www.press.org.tr/") and not any(char.isspace() for char in image):
            session.add(
                Asset(
                    id=__import__("uuid").uuid4().__str__(),
                    owner_type="story",
                    owner_id=story.id,
                    kind="remote_image",
                    storage_ref=image,
                    created_at=now,
                )
            )
        session.commit()
        added += 1
    source.last_fetch_at = now
    source.last_success_at = now
    source.last_error = None
    session.commit()
    return added


def main() -> None:
    settings = Settings()
    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = make_session_factory(engine)()
    try:
        count = sync_bulletins(session, settings, Clock(), Metrics())
    finally:
        session.close()
    print(f"Bülten eklendi: {count}. Tam metin saklanmadı.")


if __name__ == "__main__":
    main()
