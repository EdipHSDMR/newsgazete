"""NewsAPI başlıkları. Anahtar sunucuda kalır. Tam makale gövdesi istenmez ve saklanmaz."""

from __future__ import annotations

import hashlib
import re
import uuid
from datetime import datetime, timedelta
from urllib.parse import urlparse

import httpx
from sqlalchemy import select

from app.clock import Clock
from app.config import Settings
from app.db import make_engine, make_session_factory
from app.errors import ApiError
from app.models import Asset, Base, Source, SourceItem, Story, StorySource, Topic
from app.news.dedupe import HeadlineIndex
from app.rights import ENTITLEMENT_KEYS
from app.urlsec import canonical_hash, canonicalize
from app.services import (
    activate_grant,
    add_grant,
    create_source,
    ensure_topics,
    mark_source_live,
    set_entitlements,
    verify_domain,
)

QUERIES = (
    ("Türkiye", "ulusal"),
    ("ekonomi", "ekonomi"),
    ("spor", "spor"),
    ("dünya", "dunya"),
    ("teknoloji", "bilim-teknoloji"),
    ("istanbul", "yerel"),
    ("ankara", "ulusal"),
    ("sağlık", "ulusal"),
    ("siyaset", "ulusal"),
    ("futbol", "spor"),
    ("kültür", "kultur"),
    ("iklim", "iklim-cevre"),
    ("eğitim", "ulusal"),
    ("izmir", "yerel"),
    ("borsa", "ekonomi"),
)


def _source(session, clock: Clock) -> Source:
    found = session.scalar(select(Source).where(Source.domain == "newsapi.org"))
    if found:
        return found
    now = clock.now()
    source = create_source(
        session,
        "kerem",
        now,
        {
            "name": "NewsAPI",
            "domain": "newsapi.org",
            "allowed_host": "newsapi.org",
            "feed_url": "https://newsapi.org/v2/everything",
            "source_type": "licensed_api",
            "editorial_description": "NewsAPI geliştirme servisi. Geliştirici anahtarı yalnızca yerel geliştirme/test içindir; yayıncı içeriği için ayrıca kullanım izni gerekir.",
            "user_agent": "CizgiBot/0.1 (+https://haberver.example/bot)",
            "rate_limit_per_minute": 20,
            "timeout_seconds": 20,
            "synthetic": False,
        },
    )
    verify_domain(session, source, "kerem", now)
    grant = add_grant(
        session,
        source,
        "deniz",
        now,
        {
            "kind": "provider_terms",
            "document_ref": "https://newsapi.org/terms",
            "rights_holder": "NewsAPI",
            "starts_at": now - timedelta(days=1),
            "expires_at": now + timedelta(days=30),
            "platform": "android",
            "country": "TR",
            "purpose": "development_and_testing",
            "attribution_text": "NewsAPI",
        },
        synthetic_allowed=False,
    )
    allowed = {"link", "metadata", "source_title", "excerpt", "image"}
    set_entitlements(session, grant, "deniz", now, [{"key": key, "allowed": key in allowed} for key in ENTITLEMENT_KEYS])
    activate_grant(session, grant, "deniz", now)
    mark_source_live(session, source, "kerem", now, mode="active")
    return session.get(Source, source.id)


def _provider_spot(value: object) -> str:
    """Spot yalnızca kaynak description alanıdır. content, HTML gövde ve AI özeti kullanılmaz."""
    if not isinstance(value, str):
        return ""
    text = re.sub(r"<[^>]+>", " ", value)
    return " ".join(text.split())[:700]


def _developer_page(page: int) -> int:
    """NewsAPI Developer planı /v2/everything için ilk 100 sonucu açar.

    page=2 (ve 1'den büyük her sayfa) HTTP 426 Upgrade Required döndürür
    (maximumResultsReached). Sayfa artırılmaz; 426 sonrası aynı istek yenilenmez.
    """
    if page != 1:
        raise RuntimeError("NewsAPI geliştirici planı everything sayfa 2 için HTTP 426 döndürür; istek gönderilmedi.")
    return page


def _ok_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or not host or host in {"localhost", "newsapi.org"}:
        return False
    if host.endswith(".local") or host.replace(".", "").isdigit():
        return False
    return True


def sync_newsapi(session, settings: Settings, clock: Clock) -> int:
    if settings.app_env != "dev":
        raise RuntimeError("NewsAPI geliştirici anahtarı yalnızca geliştirme ortamında kullanılabilir; yayına çıkış için kaynak içerik izinleri gerekir.")
    if not settings.newsapi_key:
        raise RuntimeError("NEWSAPI_KEY yok.")
    ensure_topics(session)
    source = _source(session, clock)
    topics = {row.slug: row.id for row in session.scalars(select(Topic))}
    index = HeadlineIndex.from_session(session)
    headers = {"X-Api-Key": settings.newsapi_key, "User-Agent": source.user_agent}
    now = clock.now()
    added = 0
    for query, slug in QUERIES:
        # Sayfa 2 istenmez: Developer planı HTTP 426 döndürür. Yalnız sayfa 1.
        response = httpx.get(
            "https://newsapi.org/v2/everything",
            params={
                "q": query,
                "language": "tr",
                "pageSize": 100,
                "page": _developer_page(1),
                "sortBy": "publishedAt",
            },
            headers=headers,
            timeout=30,
        )
        if response.status_code == 426:
            continue
        if response.status_code != 200:
            break
        try:
            data = response.json()
        except ValueError:
            break
        if not isinstance(data, dict) or data.get("status") != "ok":
            break
        topic_id = topics.get(slug) or topics["ulusal"]
        for article in data.get("articles") or []:
            if not isinstance(article, dict):
                continue
            url = article.get("url") if isinstance(article.get("url"), str) else ""
            url = url.strip()
            title = article.get("title") if isinstance(article.get("title"), str) else ""
            title = title.strip()
            if not _ok_url(url) or len(title) < 12 or title.startswith("[Removed]"):
                continue
            try:
                canonical = canonicalize(url)
                digest = canonical_hash(url)
            except ApiError:
                continue
            # Eski satırlar ham URL hash'i taşır; yeni kayıt canonical hash kullanır.
            legacy = hashlib.sha256(url.encode()).hexdigest()
            if index.contains(external_id=digest, canonical_url=canonical, canonical_hash=digest, aliases=(legacy,)):
                continue
            published_raw = article.get("publishedAt") if isinstance(article.get("publishedAt"), str) else ""
            try:
                published = datetime.fromisoformat(published_raw.replace("Z", "+00:00"))
            except ValueError:
                continue
            # article["content"] yok sayılır: tam metin, kazıma ve AI özeti yok.
            spot = _provider_spot(article.get("description"))
            source_meta = article.get("source") if isinstance(article.get("source"), dict) else {}
            publisher_name = source_meta.get("name") if isinstance(source_meta.get("name"), str) else ""
            publisher = (publisher_name.strip() or "Yayıncı")[:160]
            item_id = str(uuid.uuid4())
            story_id = str(uuid.uuid4())
            session.add(
                SourceItem(
                    id=item_id,
                    source_id=source.id,
                    external_id=digest,
                    canonical_url=canonical,
                    original_url=url,
                    canonical_hash=digest,
                    source_title=title[:500],
                    source_description=spot,
                    published_at=published,
                    fetched_at=now,
                    locale="tr",
                    content_hash=digest,
                    status="published",
                    grant_id=None,
                    synthetic=False,
                    created_at=now,
                    updated_at=now,
                )
            )
            session.add(
                Story(
                    id=story_id,
                    editorial_title=title[:300],
                    editorial_summary=spot,
                    context_note="Başlık ve spot NewsAPI description alanındandır. Tam makale istenmez ve saklanmaz.",
                    topic_id=topic_id,
                    authorship_label=publisher,
                    editor_actor="newsapi",
                    verification_note="NewsAPI geliştirici kotası: /v2/everything sayfa 2 HTTP 426 döndürür; yalnız sayfa 1 alındı.",
                    published_at=published,
                    updated_at=published,
                    status="published",
                    synthetic=False,
                    single_source_note="Tek kaynak. Tam metin yayıncıda.",
                    developing=False,
                    last_verified_at=now,
                    risk_level="normal",
                    editor_priority=4,
                    ranking_reason="NewsAPI yayın zamanı",
                    ai_assisted=False,
                    rights_expires_at=now + timedelta(days=30),
                    created_at=now,
                )
            )
            session.add(
                StorySource(
                    id=str(uuid.uuid4()),
                    story_id=story_id,
                    source_item_id=item_id,
                    added_by="newsapi",
                    added_at=now,
                )
            )
            image = article.get("urlToImage")
            if isinstance(image, str):
                image = image.strip()
                if image.startswith("https://") and not any(char.isspace() for char in image):
                    session.add(
                        Asset(
                            id=str(uuid.uuid4()),
                            owner_type="story",
                            owner_id=story_id,
                            kind="remote_image",
                            storage_ref=image[:800],
                            created_at=now,
                        )
                    )
            index.absorb(external_id=digest, canonical_url=canonical, canonical_hash=digest)
            added += 1
            if added % 40 == 0:
                session.commit()
        session.commit()
    return added


def main() -> None:
    settings = Settings()
    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = make_session_factory(engine)()
    try:
        count = sync_newsapi(session, settings, Clock())
    finally:
        session.close()
    print(f"NewsAPI başlık eklendi: {count}")


if __name__ == "__main__":
    main()
