"""KURMACA haber masası. Gerçek kurum, gerçek olay ve başka sitenin metni yoktur."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.clock import Clock
from app.config import Settings
from app.db import make_engine, make_session_factory
from app.models import Base, Source, SourceItem, Story
from app.runtime import Metrics
from app.services import add_member, create_story, ensure_topics, manual_item, publish_story

DESK = [
    ("sahil", "example.com", "ulusal", 1, 5, "Örnek kıyı kenti, sahil düzenlemesi için taslak takvimi askıya çıkardı",
     "KURMACA kayıt. Örnek belediye masası, sahil şeridinde üç etaplık bir düzenleme taslağını duyurdu. Bütçe kalemleri ve başlangıç ayı henüz yazılmadı. Ayrıntı kaynak bağlantısında.",
     "Taslak metin ve iki sentetik yayın notu karşılaştırıldı. Resmî ay bilgisi yok.",
     "Başlangıç ayı yayın notlarında farklı geçiyor. Ortak olan yalnızca taslağın askıya çıktığı.",
     "example.org"),
    ("esnaf", "example.com", "ekonomi", 0, 7, "Örnek esnaf kasası, destek başvurusunu iki pencereye böldü",
     "KURMACA kayıt. Örnek kasa, küçük işletme desteği için başvurunun önce ön kayıt sonra belge kontrolü şeklinde işleyeceğini yazdı. Tarihler örnek metinde, gerçek bir program değildir.",
     "Tek sentetik açıklama. Sayılar uydurma değildir diye sunulmaz; masa verisidir.",
     None, None),
    ("harita", "example.com", "bilim-teknoloji", 0, 9, "Örnek laboratuvar, kent içi ısı ölçümünün ilk haritasını paylaştı",
     "KURMACA kayıt. Örnek bir ekip, ölçüm noktalarının ilk sürümünü açtığını belirtti. Hangi sokakların kapsandığı ve yöntem notu ürün sayfasında duruyor. Bu bir bilimsel keşif duyurusu değildir.",
     "Kurmaca araştırma notu. İnsan onayı olmadan otomatik yayın yok.",
     None, None),
    ("ruzgar", "example.com", "iklim-cevre", 0, 4, "Örnek enerji masası, rüzgâr ölçüm direklerinin yerini görüşe açtı",
     "KURMACA kayıt. Örnek masa, iki sırtta ölçüm direği için yer alternatiflerini listeledi. Kurulum kararı ve çevre notu bekleniyor. Gerçek bir ihale değildir.",
     "Yer listesi örnek metinden alındı, sözleşme yok.",
     "Direk sayısı bir notta iki, diğerinde üç geçiyor. Resmî liste yok.",
     "example.org"),
    ("kitaplik", "example.com", "kultur", 0, 11, "Örnek kent kitaplığı, perşembe akşamı deneme okuma saatini duyurdu",
     "KURMACA kayıt. Örnek kitaplık, bir ay sürecek akşam okuma denemesini açıkladı. Kontenjan ve salon adı sonraki notta. Gerçek bir kültür kurumu değildir.",
     "Tek sentetik duyuru.",
     None, None),
    ("pazar", "example.com", "yerel", 0, 3, "Örnek ilçe, pazar yerinin taşınma taslağını mahalle panosuna astı",
     "KURMACA kayıt. Örnek ilçe, pazar tezgâhlarının iki sokak öteye alınmasına dair taslağı askıya çıkardı. Taşınma haftası yazılmadı. Gerçek bir belediye kararı değildir.",
     "Askı metni ve kısa yayın notu. Hafta bilgisi yok.",
     None, None),
    ("salon", "example.com", "spor", 0, 6, "Örnek salon, akşam karşılaşmasının saatini bir saat erteledi",
     "KURMACA kayıt. Örnek salon işletmesi, bakım nedeniyle karşılaşmanın başlangıcını akşama aldığını yazdı. Resmî fikstür değildir, kulüp duyurusu değildir.",
     "Sentetik saat notu. Önceki fikstür kaydıyla karıştırılmamalı.",
     None, None),
    ("vize", "example.com", "dunya", 0, 8, "Örnek ada yönetimi, liman genişletmesini gelecek yıla bıraktığını bildirdi",
     "KURMACA kayıt. Örnek ada yönetimi, liman mendireğinin bu yıl başlamayacağını duyurdu. Gerekçe olarak dalga ölçümü notu gösterildi. Gerçek bir ülke açıklaması değildir.",
     "İki sentetik not. Yıl bilgisi ortak, ay bilgisi değil.",
     "Bir not bahar diyor, diğeri ay vermiyor. Ortak nokta erteleme.",
     "example.org"),
    ("hat", "example.com", "ulusal", 0, 2, "Örnek hat işletmesi, aktarma noktasındaki bekleme süresini ölçmeye başladı",
     "KURMACA kayıt. Örnek işletme, üç aktarma noktasında bekleme süresini bir hafta sayacağını yazdı. Sonuç tablosu henüz yok. Gerçek bir ulaşım kurumu değildir.",
     "Sayım duyurusu. Sonuç iddiası yok.",
     None, None),
    ("tohum", "example.com", "iklim-cevre", 0, 13, "Örnek fidanlık, kurak yamaç için deneme sırasını açıkladı",
     "KURMACA kayıt. Örnek fidanlık, iki türü küçük bir yamaçta deneyeceğini yazdı. Su planı ve başarı ölçütü sonraki notta. Gerçek bir bakanlık programı değildir.",
     "Deneme duyurusu. Verim iddiası yok.",
     None, None),
    ("pano", "example.com", "kultur", 0, 15, "Örnek okul salonu, kısa film gösterimini ücretsiz oturuma bağladı",
     "KURMACA kayıt. Örnek salon, mahalle gösterimini kayıtsız izleyiciye açtığını duyurdu. Film adı ve saat örnek notta. Gerçek bir festival değildir.",
     "Tek duyuru. Telifli afiş yok.",
     None, None),
    ("vardiya", "example.com", "ekonomi", 0, 10, "Örnek atölye, vardiya çizelgesini çalışan panosunda güncelledi",
     "KURMACA kayıt. Örnek atölye, sabah vardiyasının başlangıcını on beş dakika kaydırdığını panoya yazdı. Ücret etkisi belirtilmedi. Gerçek bir işyeri duyurusu değildir.",
     "Pano metni. Ücret yorumu yok.",
     None, None),
    ("kopru", "example.com", "yerel", 1, 1, "Örnek dere üzerindeki yaya köprüsü, bakım için hafta sonu kapanacak",
     "KURMACA kayıt. Örnek ilçe, yaya köprüsünün cumartesi sabahı kapanıp pazar akşamı açılacağını yazdı. Araç trafiği zaten yok. Gerçek bir kapanma ihbarı değildir.",
     "Saat aralığı iki notta aynı. Yönlendirme levhası ayrıca doğrulanmadı.",
     None, None),
    ("gözlem", "example.com", "bilim-teknoloji", 0, 12, "Örnek gözlemevi, bulutlu geceler için yedek gösterim saatini ilan etti",
     "KURMACA kayıt. Örnek gözlemevi, açık havada yapılamayan gösterimin salona alınacağını duyurdu. Bilet satışı yok. Gerçek bir gözlemevi değildir.",
     "Yedek saat notu.",
     None, None),
    ("secim", "example.com", "dunya", 0, 14, "Örnek belde, sayım provasını sandıksız bir salon çalışmasına indirgedi",
     "KURMACA kayıt. Örnek belde yönetimi, oy sayımını değil, yalnızca tutanak alıştırmasını yaptığını açıkladı. Sonuç, aday veya gerçek seçim yoktur.",
     "Alıştırma duyurusu. Sandık sonucu yok.",
     None, None),
    ("sutopu", "example.com", "spor", 0, 16, "Örnek havuz, su topu maçının tribününü bakıma alıp ayakta izlemeyi kapattı",
     "KURMACA kayıt. Örnek havuz, tribün kaynağı nedeniyle yalnızca oturarak izlemeye izin vereceğini yazdı. Gerçek bir federasyon kararı değildir.",
     "Salon notu.",
     None, None),
]


def ensure_desk(session, settings: Settings, clock: Clock, metrics: Metrics) -> int:
    if not settings.synthetic_allowed:
        return 0
    ensure_topics(session)
    sources = {row.domain: row for row in session.scalars(select(Source).where(Source.status == "active"))}
    if "example.com" not in sources or "example.org" not in sources:
        raise RuntimeError("Önce sentetik kaynak kurulmalı.")
    now = clock.now()
    added = 0
    for external, domain, topic, priority, hours, title, summary, context, uncertainty, partner in DESK:
        if session.scalar(select(SourceItem).where(SourceItem.external_id == external)):
            continue
        source = sources[domain]
        moment = now - timedelta(hours=hours)
        item = manual_item(session, "ayse", now, {
            "source_id": source.id,
            "url": f"https://{domain}/sentetik/{external}",
            "external_id": external,
            "published_at": moment,
            "observed_facts": "KURMACA masa notu. Makale gövdesi yok.",
        }, settings)
        story = create_story(session, "ayse", now, {
            "source_item_id": item.id,
            "editorial_title": title,
            "editorial_summary": summary,
            "context_note": context,
            "topic_slug": topic,
            "verification_note": "KURMACA masa. Gerçek kurum duyurusu değildir.",
            "risk_level": "normal",
            "developing": bool(uncertainty),
            "uncertainty_note": uncertainty,
            "editor_priority": priority,
            "ai_assisted": False,
            "ai_role_note": None,
        }, synthetic_allowed=True)
        if partner and partner in sources:
            other_id = f"{external}-ajans"
            if not session.scalar(select(SourceItem).where(SourceItem.external_id == other_id)):
                other = manual_item(session, "ayse", now, {
                    "source_id": sources[partner].id,
                    "url": f"https://{partner}/sentetik/{external}-not",
                    "external_id": other_id,
                    "published_at": moment + timedelta(minutes=20),
                    "observed_facts": "İkinci kurmaca not. Gövde yok.",
                }, settings)
                add_member(session, story, other.id, "ayse", now, settings)
        publish_story(session, story, "ayse", now, settings, metrics, send_push=False)
        story.published_at = moment
        story.updated_at = moment
        session.commit()
        added += 1
    return added


def main() -> None:
    settings = Settings()
    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = make_session_factory(engine)()
    try:
        count = ensure_desk(session, settings, Clock(), Metrics())
    finally:
        session.close()
    print(f"KURMACA masa eklendi: {count}. Gerçek haber değildir.")


if __name__ == "__main__":
    main()
