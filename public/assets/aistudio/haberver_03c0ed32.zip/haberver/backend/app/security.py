from dataclasses import dataclass

from fastapi.security import HTTPAuthorizationCredentials

from app.config import Settings
from app.errors import ApiError


@dataclass(frozen=True)
class Actor:
    role: str
    name: str


def parse_tokens(raw: str) -> dict[str, Actor]:
    found: dict[str, Actor] = {}
    for part in raw.split(","):
        piece = part.strip()
        if not piece:
            continue
        role, name, secret = piece.split(":", 2)
        if role not in {
            "editor",
            "legal_reviewer",
            "source_admin",
            "support",
            "super_admin",
        }:
            continue
        found[secret] = Actor(role=role, name=name)
    return found


def authenticate(credentials: HTTPAuthorizationCredentials | None, settings: Settings) -> Actor:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise ApiError(401, "unauthorized", "Yönetim işlemi kimlik ister.", retryable=False)
    actor = parse_tokens(settings.admin_tokens).get(credentials.credentials)
    if actor is None:
        raise ApiError(401, "unauthorized", "Kimlik doğrulanamadı.", retryable=False)
    return actor


def authorize(actor: Actor, allowed: set[str]) -> None:
    if actor.role == "super_admin" or actor.role in allowed:
        return
    raise ApiError(403, "forbidden", "Bu işlem için yetkiniz yok.", retryable=False)
