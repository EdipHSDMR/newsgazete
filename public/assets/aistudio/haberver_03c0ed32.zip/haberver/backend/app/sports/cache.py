"""In-process TTL cache. No polling and no credential storage."""

from __future__ import annotations

import threading
import time

MATCH_TTL = 90
STANDINGS_TTL = 20 * 60
TEAMS_TTL = 30 * 60
COMPETITIONS_TTL = 30 * 60
DENIAL_TTL = 15 * 60
BACKOFF_KEY = "fd:backoff_until"


class SportsCache:
    def __init__(self, store: dict, lock: threading.RLock) -> None:
        self._store = store
        self._lock = lock

    def get_fresh(self, key: str, ttl: float) -> dict | None:
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(key)
            if not _has_payload(entry):
                return None
            if now - entry["fetched"] >= ttl:
                return None
            return entry

    def get_stale(self, key: str) -> dict | None:
        with self._lock:
            entry = self._store.get(key)
            if _has_payload(entry):
                return entry
            return None

    def put(self, key: str, data, refreshed_at: str) -> None:
        with self._lock:
            self._store[key] = {"fetched": time.monotonic(), "updated_at": refreshed_at, "data": data}
            self._store.pop(_denial_key(key), None)

    def denial(self, key: str) -> int | None:
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(_denial_key(key))
            if not isinstance(entry, dict):
                return None
            fetched = entry.get("fetched")
            status = entry.get("status")
            if not isinstance(fetched, (int, float)) or not isinstance(status, int):
                return None
            if now - fetched >= DENIAL_TTL:
                return None
            return status

    def remember_denial(self, key: str, status: int) -> None:
        with self._lock:
            self._store[_denial_key(key)] = {"fetched": time.monotonic(), "status": status}

    def cooldown_remaining(self) -> int:
        now = time.monotonic()
        with self._lock:
            until = self._store.get(BACKOFF_KEY)
            if not isinstance(until, (int, float)):
                return 0
            remaining = until - now
            if remaining <= 0:
                return 0
            return max(1, int(remaining) + (1 if remaining > int(remaining) else 0))

    def start_cooldown(self, seconds: int) -> None:
        wait = max(1, min(int(seconds), 180))
        with self._lock:
            self._store[BACKOFF_KEY] = time.monotonic() + wait


def _denial_key(key: str) -> str:
    return f"fd:deny:{key}"


def _has_payload(entry) -> bool:
    return isinstance(entry, dict) and "data" in entry and isinstance(entry.get("fetched"), (int, float))
