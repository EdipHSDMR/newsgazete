"""football-data.org v4 client. The auth header is never logged or returned."""

from __future__ import annotations

import unicodedata
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo

import httpx

from app.sports.cache import SportsCache

BASE_URL = "https://api.football-data.org/v4"
PROVIDER = "football-data.org"
ATTRIBUTION = "Football data provided by the Football-Data.org API. https://www.football-data.org/"
TIMEZONE = "Europe/Istanbul"
ISTANBUL = ZoneInfo(TIMEZONE)
LIMITATION = "bu sağlayıcı bu ligi bu anahtarla sunmuyor"

LIVE_STATUS = {"IN_PLAY", "PAUSED", "EXTRA_TIME", "PENALTY_SHOOTOUT"}
SCHEDULED_STATUS = {"SCHEDULED", "TIMED"}
FINISHED_STATUS = {"FINISHED", "AWARDED"}

_AF_STATUS = {
    "NS": "SCHEDULED",
    "TBD": "TIMED",
    "1H": "IN_PLAY",
    "HT": "PAUSED",
    "2H": "IN_PLAY",
    "ET": "EXTRA_TIME",
    "BT": "PAUSED",
    "P": "PENALTY_SHOOTOUT",
    "LIVE": "IN_PLAY",
    "INT": "SUSPENDED",
    "FT": "FINISHED",
    "AET": "FINISHED",
    "PEN": "FINISHED",
    "PST": "POSTPONED",
    "CANC": "CANCELLED",
    "ABD": "CANCELLED",
    "AWD": "AWARDED",
    "WO": "AWARDED",
    "SUSP": "SUSPENDED",
}


class ProviderRestricted(Exception):
    def __init__(self, status_code: int, *, cached: bool = False) -> None:
        super().__init__("provider restricted")
        self.status_code = status_code
        self.cached = cached


class ProviderThrottle(Exception):
    def __init__(self, retry_after: int) -> None:
        super().__init__("provider rate limit")
        self.retry_after = retry_after


class ProviderUnavailable(Exception):
    def __init__(self) -> None:
        super().__init__("provider unavailable")


def now_iso() -> str:
    return datetime.now(ISTANBUL).isoformat(timespec="seconds")


def today_iso() -> str:
    return datetime.now(ISTANBUL).date().isoformat()


def get_json(token: str, path: str, params: dict | None, cache: SportsCache) -> dict:
    if not token:
        raise ProviderRestricted(401)
    remaining = cache.cooldown_remaining()
    if remaining:
        raise ProviderThrottle(remaining)
    try:
        response = httpx.get(
            f"{BASE_URL}{path}",
            params=params or None,
            headers={"X-Auth-Token": token, "Accept": "application/json"},
            timeout=8.0,
            follow_redirects=False,
        )
    except httpx.HTTPError:
        raise ProviderUnavailable() from None
    if response.status_code in {301, 302, 303, 307, 308}:
        raise ProviderUnavailable()
    if response.status_code == 429:
        wait = _retry_after(response) or 60
        cache.start_cooldown(wait)
        raise ProviderThrottle(min(wait, 3600))
    if response.status_code in {401, 403, 404}:
        raise ProviderRestricted(response.status_code)
    if response.status_code >= 400:
        raise ProviderUnavailable()
    try:
        body = response.json()
    except ValueError:
        raise ProviderUnavailable() from None
    if not isinstance(body, dict):
        raise ProviderUnavailable()
    return body


def date_window(day: str) -> dict[str, str]:
    current = datetime.strptime(day, "%Y-%m-%d").date()
    return {
        "dateFrom": (current - timedelta(days=1)).isoformat(),
        "dateTo": (current + timedelta(days=1)).isoformat(),
    }


def normalize_competition(comp: dict) -> dict:
    area = comp.get("area") if isinstance(comp.get("area"), dict) else {}
    return {
        "id": comp.get("id"),
        "code": comp.get("code"),
        "name": comp.get("name"),
        "area": area.get("name"),
        "area_code": area.get("code"),
        "emblem": comp.get("emblem"),
        "type": comp.get("type"),
        "fallback": False,
    }


def competition_rows(payload: dict) -> list[dict]:
    rows = payload.get("competitions") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return []
    return [normalize_competition(row) for row in rows if isinstance(row, dict)]


def turkish_coverage(competitions: list[dict]) -> dict:
    super_lig = None
    first_lig = None
    turkish: list[dict] = []
    for row in competitions:
        if not isinstance(row, dict) or not _is_turkey(row.get("area"), row.get("area_code")):
            continue
        turkish.append(row)
        name = str(row.get("name") or "")
        if super_lig is None and _is_super_lig(name):
            super_lig = row
        elif first_lig is None and _is_first_lig(name):
            first_lig = row
    return {"super_lig": super_lig, "first_lig": first_lig, "turkish": turkish}


def matches_for_date(payload: dict, day: str) -> list[dict]:
    rows = payload.get("matches") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return []
    selected = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        match = map_match(row)
        if _on_local_date(match.get("utc_date"), day):
            selected.append(match)
    return selected


def map_match(row: dict) -> dict:
    home = row.get("homeTeam") if isinstance(row.get("homeTeam"), dict) else {}
    away = row.get("awayTeam") if isinstance(row.get("awayTeam"), dict) else {}
    competition = row.get("competition") if isinstance(row.get("competition"), dict) else {}
    score = row.get("score") if isinstance(row.get("score"), dict) else None
    utc_date = row.get("utcDate") if isinstance(row.get("utcDate"), str) else None
    return {
        "id": row.get("id"),
        "competition_code": competition.get("code"),
        "competition_name": competition.get("name"),
        "utc_date": utc_date,
        "local_time": _local_time(utc_date),
        "status": row.get("status") if isinstance(row.get("status"), str) else None,
        "minute": _whole_number(row.get("minute")),
        "home": _side(home, score, "home"),
        "away": _side(away, score, "away"),
    }


def table_rows(payload: dict) -> list[dict]:
    blocks = payload.get("standings") if isinstance(payload, dict) else None
    if not isinstance(blocks, list):
        return []
    chosen = [block for block in blocks if isinstance(block, dict) and block.get("type") == "TOTAL"]
    if not chosen:
        chosen = [block for block in blocks if isinstance(block, dict)][:1]
    rows = []
    for block in chosen:
        table = block.get("table") if isinstance(block.get("table"), list) else []
        for row in table:
            if not isinstance(row, dict):
                continue
            team = row.get("team") if isinstance(row.get("team"), dict) else {}
            rows.append(
                {
                    "position": row.get("position"),
                    "team": team.get("name"),
                    "crest": team.get("crest"),
                    "played": row.get("playedGames"),
                    "won": row.get("won"),
                    "draw": row.get("draw"),
                    "lost": row.get("lost"),
                    "goal_difference": row.get("goalDifference"),
                    "points": row.get("points"),
                }
            )
    return rows


def team_rows(payload: dict) -> list[dict]:
    rows = payload.get("teams") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return []
    mapped = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        area = row.get("area") if isinstance(row.get("area"), dict) else {}
        mapped.append(
            {
                "id": row.get("id"),
                "name": row.get("name"),
                "short_name": row.get("shortName"),
                "tla": row.get("tla"),
                "crest": row.get("crest"),
                "venue": row.get("venue"),
                "area": area.get("name"),
            }
        )
    return mapped


def select_bucket(matches: list[dict], bucket: str) -> list[dict]:
    if bucket in {"", "today"}:
        return matches
    allowed = {"live": LIVE_STATUS, "scheduled": SCHEDULED_STATUS, "finished": FINISHED_STATUS}[bucket]
    return [match for match in matches if match.get("status") in allowed]


def map_api_football_status(value) -> str | None:
    if not isinstance(value, str):
        return None
    return _AF_STATUS.get(value, value)


def parse_instant(value: str | None) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=ISTANBUL)
    return parsed


def to_utc_z(value: str | None) -> str | None:
    parsed = parse_instant(value)
    if parsed is None:
        return None
    return parsed.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _local_time(value: str | None) -> str | None:
    parsed = parse_instant(value)
    if parsed is None:
        return None
    return parsed.astimezone(ISTANBUL).isoformat(timespec="minutes")


def _on_local_date(value: str | None, day: str) -> bool:
    parsed = parse_instant(value)
    if parsed is None:
        return False
    return parsed.astimezone(ISTANBUL).date().isoformat() == day


def _side(team: dict, score: dict | None, key: str) -> dict:
    return {
        "name": team.get("name"),
        "short_name": team.get("shortName"),
        "crest": team.get("crest"),
        "score": _score(score, key),
    }


def _score(score: dict | None, key: str):
    if not isinstance(score, dict):
        return None
    full_time = score.get("fullTime")
    if not isinstance(full_time, dict) or key not in full_time:
        return None
    return _whole_number(full_time.get(key))


def _whole_number(value):
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _fold(value) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(char for char in text if not unicodedata.combining(char))
    return text.casefold()


def _is_turkey(area, area_code) -> bool:
    name = _fold(area)
    code = _fold(area_code)
    return name in {"turkey", "turkiye"} or code in {"tur", "turkey", "turkiye"}


def _is_super_lig(name: str) -> bool:
    folded = _fold(name)
    return "super lig" in folded or "superlig" in folded.replace(" ", "")


def _is_first_lig(name: str) -> bool:
    folded = _fold(name)
    return "1. lig" in folded or "1.lig" in folded.replace(" ", "") or "birinci lig" in folded


def _retry_after(response: httpx.Response) -> int | None:
    raw = response.headers.get("Retry-After")
    if raw is None:
        reset = response.headers.get("X-RequestCounter-Reset")
        if isinstance(reset, str) and reset.isdigit():
            return max(1, int(reset))
        return None
    text = raw.strip()
    if text.isdigit():
        return max(1, int(text))
    try:
        when = parsedate_to_datetime(text)
    except (TypeError, ValueError, OverflowError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    seconds = int((when - datetime.now(timezone.utc)).total_seconds())
    return max(1, seconds)
