"""Server-side football-data.org client. Credentials stay in process settings."""
