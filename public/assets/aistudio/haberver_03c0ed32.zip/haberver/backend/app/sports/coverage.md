# Futbol veri kapsamı

Keşif: `GET https://api.football-data.org/v4/competitions` (football-data.org v4). Tarih: 2026-10-23. HTTP 200. Kimlik bilgisi bu nota yazılmadı.

Saat dilimi: Europe/Istanbul. Maç önbelleği 90 saniye, puan durumu 20 dakika, takımlar ve yarışma listesi 30 dakika. Arka planda yoklama yok.

## Erişilen yarışmalar

Bu anahtarın döndürdüğü liste (13). Ülke/ad eşlemesi bu satırların üzerinde yapıldı.

| Kod | Ad | Ülke / bölge |
| --- | --- | --- |
| BSA | Campeonato Brasileiro Série A | Brazil |
| ELC | Championship | England |
| PL | Premier League | England |
| CL | UEFA Champions League | Europe |
| EC | European Championship | Europe |
| FL1 | Ligue 1 | France |
| BL1 | Bundesliga | Germany |
| SA | Serie A | Italy |
| DED | Eredivisie | Netherlands |
| PPL | Primeira Liga | Portugal |
| CLI | Copa Libertadores | South America |
| PD | Primera Division | Spain |
| WC | FIFA World Cup | World |

## Erişilmeyen

Türkiye alanı (`Turkey` / `Türkiye`, alan kodu `TUR`) listede yok. Süper Lig ve 1. Lig için ülke ve ad eşlemesi kod üretmedi. Bu yüzden bu iki ligin football-data kodu yazılmadı ve fikstür üretilmedi.

İstenen lig bu listede değilse yanıt `limited: true` olur ve `limitation` alanı şudur: `bu sağlayıcı bu ligi bu anahtarla sunmuyor`.

## API-Football

Mevcut sunucu adaptörü `app.sports_data.sports_overview` yalnızca Süper Lig içindir; koddaki lig kimliği 203'tür. Bu, football-data kodu değildir. Bu keşifte API-Football sunucu ayarı boştu; adaptör çağrılmadı ve fallback iddiası kurulmadı. Ayar doluysa ve football-data Türkiye Süper Lig'i vermiyorsa maç ve puan durumu istekleri bu adaptöre, `competition=203` ile düşer. 1. Lig için adaptör yoktur; takım listesi de adaptörden üretilmez.
