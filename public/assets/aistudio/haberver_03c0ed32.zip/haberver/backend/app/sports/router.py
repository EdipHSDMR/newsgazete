"""Public football routes. Missing credentials return 503, never invented scores."""

from __future__ import annotations

import re
from datetime import datetime

from fastapi import APIRouter, Request

from app.errors import ApiError
from app.sports.cache import COMPETITIONS_TTL, MATCH_TTL, STANDINGS_TTL, TEAMS_TTL, SportsCache
from app.sports.client import (
    ATTRIBUTION,
    LIMITATION,
    PROVIDER,
    TIMEZONE,
    ISTANBUL,
    ProviderRestricted,
    ProviderThrottle,
    ProviderUnavailable,
    competition_rows,
    date_window,
    get_json,
    map_api_football_status,
    matches_for_date,
    now_iso,
    parse_instant,
    select_bucket,
    table_rows,
    team_rows,
    to_utc_z,
    today_iso,
    turkish_coverage,
)
from app.sports_data import FIXTURES_TTL, STANDINGS_TTL as ADAPTER_STANDINGS_TTL, SUPER_LIG_ID, sports_overview

router = APIRouter(prefix="/v1/sports")
BUCKETS = {"live", "today", "scheduled", "finished"}
FALLBACK_PROVIDER = "API-Football"
FALLBACK_ATTRIBUTION = "Veri mevcut sunucu API-Football adaptöründen. https://www.api-football.com/"
TOKEN_MESSAGE = "Futbol verisi için sunucuda FOOTBALL_DATA_TOKEN tanımlı değil. Skor üretilmedi."
AUTH_MESSAGE = "Futbol veri anahtarı sağlayıcı tarafından kabul edilmedi."
UNAVAILABLE_MESSAGE = "Futbol veri sağlayıcısına şu an ulaşılamıyor."
RATE_MESSAGE = "Futbol veri sağlayıcısı istek sınırına ulaşıldı."
ADAPTER_EMPTY = "Skor servisi şu an yanıt vermedi."
ADAPTER_TODAY_ONLY = "Mevcut sunucu adaptörü yalnızca bugünün Süper Lig karşılaşmalarını sunuyor."


def _data(payload: dict) -> dict:
    from app.api import request_id_var

    return {"request_id": request_id_var.get(), "data": payload}


def _cache(request: Request) -> SportsCache:
    return SportsCache(request.app.state.sports_cache, request.app.state.sports_cache_lock)


def _token(request: Request) -> str:
    token = request.app.state.settings.football_data_token
    if not isinstance(token, str) or not token.strip():
        raise ApiError(503, "sports_unconfigured", TOKEN_MESSAGE, retryable=False)
    return token.strip()


def _parse_date(value: str | None) -> str:
    if value is None or value == "":
        return today_iso()
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise ApiError(422, "validation", "Tarih YYYY-MM-DD olmalıdır.", retryable=False) from None
    return value


def _parse_bucket(value: str | None) -> str:
    if value is None or value == "":
        return "today"
    if value not in BUCKETS:
        raise ApiError(422, "validation", "bucket live, today, scheduled veya finished olmalıdır.", retryable=False)
    return value


def _parse_code(value: str | None, *, required: bool) -> str | None:
    if value is None or not value.strip():
        if required:
            raise ApiError(422, "validation", "Lig kodu gerekli.", retryable=False)
        return None
    code = value.strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{1,16}", code):
        raise ApiError(422, "validation", "Lig kodu geçersiz.", retryable=False)
    return code


def _meta(refreshed_at, from_cache: bool, stale: bool, limited: bool, limitation, provider: str = PROVIDER) -> dict:
    return {
        "provider": provider,
        "attribution": ATTRIBUTION if provider == PROVIDER else FALLBACK_ATTRIBUTION,
        "timezone": TIMEZONE,
        "refreshed_at": refreshed_at,
        "from_cache": from_cache,
        "stale": stale,
        "limited": limited,
        "limitation": limitation,
    }


def _load(cache: SportsCache, key: str, ttl: float, fetch):
    hit = cache.get_fresh(key, ttl)
    if hit is not None:
        return hit, True
    denied = cache.denial(key)
    if denied is not None:
        raise ProviderRestricted(denied, cached=True)
    try:
        data = fetch()
    except ProviderRestricted as exc:
        if exc.status_code in {403, 404}:
            cache.remember_denial(key, exc.status_code)
        raise
    refreshed = now_iso()
    cache.put(key, data, refreshed)
    return {"data": data, "updated_at": refreshed}, False


def _reject_auth(exc: ProviderRestricted) -> None:
    if exc.status_code == 401:
        raise ApiError(503, "sports_rejected", AUTH_MESSAGE, retryable=False)


def _stale_body(cache: SportsCache, key: str, exc: Exception, build):
    if isinstance(exc, ProviderThrottle):
        stale = cache.get_stale(key)
        if stale is not None:
            return _data(build(stale["data"], stale.get("updated_at"), True, True))
        raise ApiError(429, "rate_limited", RATE_MESSAGE, retryable=True, retry_after=exc.retry_after)
    if isinstance(exc, ProviderUnavailable):
        stale = cache.get_stale(key)
        if stale is not None:
            return _data(build(stale["data"], stale.get("updated_at"), True, True))
        raise ApiError(503, "source_unavailable", UNAVAILABLE_MESSAGE, retryable=True, retry_after=60)
    return None


def _catalog(cache: SportsCache, token: str):
    key = "fd:competitions"
    try:
        entry, from_cache = _load(cache, key, COMPETITIONS_TTL, lambda: competition_rows(get_json(token, "/competitions", None, cache)))
    except ProviderRestricted as exc:
        _reject_auth(exc)
        return None, False, now_iso(), False
    except (ProviderThrottle, ProviderUnavailable) as exc:
        stale = cache.get_stale(key)
        if stale is None:
            if isinstance(exc, ProviderThrottle):
                raise ApiError(429, "rate_limited", RATE_MESSAGE, retryable=True, retry_after=exc.retry_after)
            raise ApiError(503, "source_unavailable", UNAVAILABLE_MESSAGE, retryable=True, retry_after=60)
        return stale["data"], True, stale.get("updated_at"), True
    return entry["data"], from_cache, entry.get("updated_at"), False


def _fallback_enabled(settings, code: str | None) -> bool:
    key = settings.api_football_key
    return isinstance(key, str) and bool(key.strip()) and code == str(SUPER_LIG_ID)


def _fallback_competition() -> dict:
    return {
        "id": SUPER_LIG_ID,
        "code": str(SUPER_LIG_ID),
        "name": "Süper Lig",
        "area": "Turkey",
        "area_code": "TUR",
        "emblem": None,
        "type": "LEAGUE",
        "fallback": True,
        "provider": FALLBACK_PROVIDER,
    }


def _has_code(competitions: list[dict], code: str) -> bool:
    return any(str(row.get("code") or "").upper() == code for row in competitions)


def _limited_match_body(day: str, code: str | None, bucket: str, refreshed_at, from_cache: bool) -> dict:
    body = _meta(refreshed_at, from_cache, False, True, LIMITATION)
    body.update({"date": day, "competition": code, "bucket": bucket, "matches": []})
    return body


@router.get("/competitions")
def get_competitions(request: Request):
    token = _token(request)
    cache = _cache(request)
    competitions, from_cache, refreshed_at, stale = _catalog(cache, token)
    rows = list(competitions or [])
    coverage = turkish_coverage(rows)
    settings = request.app.state.settings
    if coverage["super_lig"] is None and isinstance(settings.api_football_key, str) and settings.api_football_key.strip():
        rows.append(_fallback_competition())
    limited = coverage["super_lig"] is None or coverage["first_lig"] is None
    body = _meta(refreshed_at, from_cache, stale, limited, LIMITATION if limited else None)
    body["competitions"] = rows
    return _data(body)


@router.get("/matches")
def get_matches(
    request: Request,
    date: str | None = None,
    competition: str | None = None,
    bucket: str | None = None,
):
    token = _token(request)
    day = _parse_date(date)
    code = _parse_code(competition, required=False)
    chosen = _parse_bucket(bucket)
    cache = _cache(request)
    if code:
        competitions, catalog_cached, catalog_at, _catalog_stale = _catalog(cache, token)
        if competitions is None or not _has_code(competitions, code):
            super_missing = competitions is None or turkish_coverage(competitions)["super_lig"] is None
            if super_missing and _fallback_enabled(request.app.state.settings, code):
                return _data(_fallback_matches(request, cache, day, chosen))
            return _data(_limited_match_body(day, code, chosen, catalog_at, catalog_cached))
    key = f"fd:matches:{code or '*'}:{day}"

    def fetch():
        path = f"/competitions/{code}/matches" if code else "/matches"
        return matches_for_date(get_json(token, path, date_window(day), cache), day)

    def build(rows, refreshed_at, from_cache: bool, stale: bool):
        body = _meta(refreshed_at, from_cache, stale, False, None)
        body.update({"date": day, "competition": code, "bucket": chosen, "matches": select_bucket(rows, chosen)})
        return body

    try:
        entry, from_cache = _load(cache, key, MATCH_TTL, fetch)
    except ProviderRestricted as exc:
        _reject_auth(exc)
        return _data(_limited_match_body(day, code, chosen, now_iso(), exc.cached))
    except (ProviderThrottle, ProviderUnavailable) as exc:
        stale_response = _stale_body(cache, key, exc, build)
        if stale_response is not None:
            return stale_response
        raise
    return _data(build(entry["data"], entry.get("updated_at"), from_cache, False))


@router.get("/standings")
def get_standings(request: Request, competition: str | None = None):
    token = _token(request)
    code = _parse_code(competition, required=True)
    cache = _cache(request)
    competitions, catalog_cached, catalog_at, _catalog_stale = _catalog(cache, token)
    if competitions is None or not _has_code(competitions, code):
        super_missing = competitions is None or turkish_coverage(competitions)["super_lig"] is None
        if super_missing and _fallback_enabled(request.app.state.settings, code):
            return _data(_fallback_standings(request, cache, code))
        body = _meta(catalog_at, catalog_cached, False, True, LIMITATION)
        body.update({"competition": code, "standings": []})
        return _data(body)
    key = f"fd:standings:{code}"

    def fetch():
        return table_rows(get_json(token, f"/competitions/{code}/standings", None, cache))

    def build(rows, refreshed_at, from_cache: bool, stale: bool):
        body = _meta(refreshed_at, from_cache, stale, False, None)
        body.update({"competition": code, "standings": rows})
        return body

    try:
        entry, from_cache = _load(cache, key, STANDINGS_TTL, fetch)
    except ProviderRestricted as exc:
        _reject_auth(exc)
        body = _meta(now_iso(), exc.cached, False, True, LIMITATION)
        body.update({"competition": code, "standings": []})
        return _data(body)
    except (ProviderThrottle, ProviderUnavailable) as exc:
        stale_response = _stale_body(cache, key, exc, build)
        if stale_response is not None:
            return stale_response
        raise
    return _data(build(entry["data"], entry.get("updated_at"), from_cache, False))


@router.get("/teams")
def get_teams(request: Request, competition: str | None = None):
    token = _token(request)
    code = _parse_code(competition, required=True)
    cache = _cache(request)
    competitions, catalog_cached, catalog_at, _catalog_stale = _catalog(cache, token)
    if competitions is None or not _has_code(competitions, code):
        body = _meta(catalog_at, catalog_cached, False, True, LIMITATION)
        body.update({"competition": code, "teams": []})
        return _data(body)
    key = f"fd:teams:{code}"

    def fetch():
        return team_rows(get_json(token, f"/competitions/{code}/teams", None, cache))

    def build(rows, refreshed_at, from_cache: bool, stale: bool):
        body = _meta(refreshed_at, from_cache, stale, False, None)
        body.update({"competition": code, "teams": rows})
        return body

    try:
        entry, from_cache = _load(cache, key, TEAMS_TTL, fetch)
    except ProviderRestricted as exc:
        _reject_auth(exc)
        body = _meta(now_iso(), exc.cached, False, True, LIMITATION)
        body.update({"competition": code, "teams": []})
        return _data(body)
    except (ProviderThrottle, ProviderUnavailable) as exc:
        stale_response = _stale_body(cache, key, exc, build)
        if stale_response is not None:
            return stale_response
        raise
    return _data(build(entry["data"], entry.get("updated_at"), from_cache, False))


def _fallback_matches(request: Request, cache: SportsCache, day: str, bucket: str) -> dict:
    if day != today_iso():
        body = _meta(now_iso(), False, False, True, ADAPTER_TODAY_ONLY, FALLBACK_PROVIDER)
        body.update({"date": day, "competition": str(SUPER_LIG_ID), "bucket": bucket, "matches": []})
        return body
    was_fresh = cache.get_fresh(f"matches:{day}", FIXTURES_TTL) is not None
    overview = sports_overview(request.app.state.settings, request.app.state.sports_cache, request.app.state.sports_cache_lock)
    if not overview.get("matches_available"):
        body = _meta(overview.get("updated_at") or now_iso(), False, bool(overview.get("stale")), True, ADAPTER_EMPTY, FALLBACK_PROVIDER)
        body.update({"date": day, "competition": str(SUPER_LIG_ID), "bucket": bucket, "matches": []})
        return body
    rows = [mapped for row in overview.get("matches") or [] if (mapped := _map_adapter_match(row)) and _adapter_on_day(mapped, day)]
    body = _meta(
        overview.get("updated_at") or now_iso(),
        was_fresh or bool(overview.get("stale")),
        bool(overview.get("stale")),
        False,
        None,
        FALLBACK_PROVIDER,
    )
    body.update({"date": day, "competition": str(SUPER_LIG_ID), "bucket": bucket, "matches": select_bucket(rows, bucket)})
    return body


def _fallback_standings(request: Request, cache: SportsCache, code: str) -> dict:
    now = datetime.now(ISTANBUL)
    season = now.year if now.month >= 7 else now.year - 1
    was_fresh = cache.get_fresh(f"standings:{season}", ADAPTER_STANDINGS_TTL) is not None
    overview = sports_overview(request.app.state.settings, request.app.state.sports_cache, request.app.state.sports_cache_lock)
    if not overview.get("standings_available"):
        body = _meta(overview.get("standings_updated_at") or now_iso(), False, bool(overview.get("stale")), True, ADAPTER_EMPTY, FALLBACK_PROVIDER)
        body.update({"competition": code, "standings": []})
        return body
    rows = [_map_adapter_standing(row) for row in overview.get("standings") or []]
    body = _meta(
        overview.get("standings_updated_at") or overview.get("updated_at") or now_iso(),
        was_fresh or bool(overview.get("stale")),
        bool(overview.get("stale")),
        False,
        None,
        FALLBACK_PROVIDER,
    )
    body.update({"competition": code, "standings": rows})
    return body


def _map_adapter_match(row: dict) -> dict | None:
    if not isinstance(row, dict):
        return None
    kickoff = row.get("kickoff") if isinstance(row.get("kickoff"), str) else None
    return {
        "id": row.get("id"),
        "competition_code": str(SUPER_LIG_ID),
        "competition_name": "Süper Lig" if _plain_name(row.get("competition")) in {None, "Futbol"} else _plain_name(row.get("competition")),
        "utc_date": to_utc_z(kickoff),
        "local_time": _local_from_kickoff(kickoff),
        "status": map_api_football_status(row.get("status")),
        "minute": row.get("minute") if isinstance(row.get("minute"), int) and not isinstance(row.get("minute"), bool) else None,
        "home": _adapter_side(row.get("home"), row.get("home_score"), "Ev sahibi"),
        "away": _adapter_side(row.get("away"), row.get("away_score"), "Deplasman"),
    }


def _map_adapter_standing(row: dict) -> dict:
    team = row.get("team") if isinstance(row, dict) else None
    return {
        "position": row.get("rank") if isinstance(row, dict) else None,
        "team": None if team == "Takım" else team,
        "crest": None,
        "played": row.get("played") if isinstance(row, dict) else None,
        "won": row.get("won") if isinstance(row, dict) else None,
        "draw": row.get("drawn") if isinstance(row, dict) else None,
        "lost": row.get("lost") if isinstance(row, dict) else None,
        "goal_difference": row.get("goals_diff") if isinstance(row, dict) else None,
        "points": row.get("points") if isinstance(row, dict) else None,
    }


def _adapter_side(name, score, placeholder: str) -> dict:
    return {
        "name": None if name in {None, "", placeholder} else name,
        "short_name": None,
        "crest": None,
        "score": score if isinstance(score, int) and not isinstance(score, bool) else None,
    }


def _plain_name(value) -> str | None:
    if isinstance(value, str) and value.strip():
        return value
    return None


def _local_from_kickoff(value: str | None) -> str | None:
    parsed = parse_instant(value)
    if parsed is None:
        return None
    return parsed.astimezone(ISTANBUL).isoformat(timespec="minutes")


def _adapter_on_day(match: dict, day: str) -> bool:
    parsed = parse_instant(match.get("utc_date"))
    if parsed is None:
        return False
    return parsed.astimezone(ISTANBUL).date().isoformat() == day
