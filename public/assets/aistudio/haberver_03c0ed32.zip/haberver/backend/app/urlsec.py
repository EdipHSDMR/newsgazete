"""URL biçimi, kanonikleştirme ve SSRF kontrolleri. HTML tarayıcı yoktur."""

from __future__ import annotations

import hashlib
import ipaddress
import socket
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from app.errors import ApiError

HTML_CRAWLER_ENABLED = False
TRACKING_EXACT = {
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid",
    "igshid",
    "ref_src",
    "yclid",
    "twclid",
    "msclkid",
}


def _fail(code: str, message: str) -> None:
    raise ApiError(400, code, message, retryable=False)


def assert_https_url(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme != "https":
        _fail("url_blocked", "Yalnız https bağlantıları kabul edilir.")
    if parsed.username or parsed.password:
        _fail("url_blocked", "Kimlik bilgisi içeren adres kabul edilmez.")
    if parsed.port not in (None, 443):
        _fail("url_blocked", "Yalnız standart https kapısı kabul edilir.")
    host = parsed.hostname
    if not host:
        _fail("url_blocked", "Adresin ana makinesi yok.")
    try:
        host_ascii = host.encode("idna").decode("ascii").lower()
    except UnicodeError:
        _fail("url_blocked", "Alan adı çözümlenemedi.")
    if host_ascii in {"localhost", "metadata.google.internal"} or host_ascii.endswith(".local"):
        _fail("url_blocked", "Bu ana makine engellendi.")
    try:
        ip = ipaddress.ip_address(host_ascii)
    except ValueError:
        ip = None
    if ip is not None:
        assert_ip_global(ip)
    return host_ascii


def assert_ip_global(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> None:
    mapped = getattr(ip, "ipv4_mapped", None)
    if mapped is not None:
        assert_ip_global(mapped)
        return
    if not ip.is_global:
        _fail("url_blocked", "Özel, döngü veya bağlantı-yerel adres engellendi.")


def resolve_public(host: str, resolver=None) -> None:
    assert_https_url(f"https://{host}/")
    lookup = resolver or socket.getaddrinfo
    try:
        infos = lookup(host, 443, type=socket.SOCK_STREAM)
    except socket.gaierror:
        _fail("url_blocked", "Alan adı çözümlenemedi.")
    if not infos:
        _fail("url_blocked", "Alan adı adres döndürmedi.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        assert_ip_global(ip)


def canonicalize(url: str) -> str:
    host = assert_https_url(url)
    parsed = urlparse(url.strip())
    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path[:-1]
    kept: list[tuple[str, str]] = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        lowered = key.lower()
        if lowered.startswith("utm_") or lowered in TRACKING_EXACT:
            continue
        kept.append((key, value))
    kept.sort()
    return urlunparse(("https", host, path, "", urlencode(kept, doseq=True), ""))


def canonical_hash(url: str) -> str:
    return hashlib.sha256(canonicalize(url).encode("utf-8")).hexdigest()


def host_allowed(url: str, allowed_host: str) -> None:
    host = assert_https_url(url)
    allowed = allowed_host.encode("idna").decode("ascii").lower()
    if host != allowed:
        _fail("url_blocked", "Adres, kaynağın onaylı alan adında değil.")
