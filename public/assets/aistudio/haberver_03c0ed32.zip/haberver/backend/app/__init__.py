"""Haber Keşif API. Marka adı geçicidir; ticari marka TBD."""

__version__ = "0.1.0"
