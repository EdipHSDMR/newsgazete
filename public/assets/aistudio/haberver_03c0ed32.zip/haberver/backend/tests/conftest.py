from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient

from app.api import create_app
from app.config import Settings

TOKENS = "editor:ayse:e,editor:mehmet:m,legal_reviewer:deniz:l,source_admin:kerem:s,support:ece:p,super_admin:admin:u"
NOW = datetime(2026, 10, 22, 15, 0, tzinfo=timezone.utc)


def make_settings(**overrides) -> Settings:
    payload = dict(
        app_env="dev",
        database_url="sqlite://",
        allow_synthetic=True,
        admin_tokens=TOKENS,
        admin_rate_per_minute=10000,
        search_rate_per_minute=10000,
        privacy_rate_per_minute=10000,
        feed_cache_ttl_seconds=30,
    )
    payload.update(overrides)
    return Settings(**payload)


@pytest.fixture
def client():
    app = create_app(make_settings())
    app.state.clock.freeze(NOW)
    with TestClient(app) as test_client:
        yield test_client


def auth(secret: str) -> dict:
    return {"Authorization": f"Bearer {secret}"}
