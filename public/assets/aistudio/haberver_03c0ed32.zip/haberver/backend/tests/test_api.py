from datetime import timedelta

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.demo.seed import load_demo
from app.errors import FatalFetch
from app.ingest import run_ingest
from app.models import LicenseGrant, Source, SourceItem, Story
from app.worker import enqueue_job, lease_next
from tests.conftest import NOW, auth, make_settings


def _load(client: TestClient) -> None:
    session = client.app.state.sessions()
    try:
        load_demo(session, client.app.state.settings, client.app.state.clock, client.app.state.metrics)
    finally:
        session.close()


def test_topics_and_health(client):
    assert client.get("/v1/health").json()["data"]["html_crawler"] is False
    slugs = {row["slug"] for row in client.get("/v1/topics").json()["data"]}
    assert "ulusal" in slugs and "yerel" in slugs


def test_guest_admin_is_rejected(client):
    response = client.get("/v1/admin/review")
    assert response.status_code == 401
    assert "traceback" not in response.text.lower()


def test_vertical_slice_labels_synthetic_and_hides_raw_feed(client):
    _load(client)
    response = client.get("/v1/feed")
    assert response.status_code == 200
    items = response.json()["data"]["items"]
    assert items[0]["editorial_title"].startswith("Sentetik demo: Örnek fikstür")
    assert "HAM_ACIKLAMA_SIZMAMALI" not in response.text
    assert "HAM FEED" not in response.text
    detail = client.get(f"/v1/stories/{items[0]['id']}")
    body = detail.json()["data"]
    assert body["display_label"] == "Sentetik demo — gerçek haber değildir"
    assert body["image"] is None
    assert body["placeholder"] == "no_image_rights"
    assert body["sources"][0]["source_title"] is None
    assert body["sources"][0]["canonical_url"].startswith("https://")


def test_cluster_and_removal(client):
    _load(client)
    feed = client.get("/v1/feed?limit=30").json()["data"]["items"]
    tramvay = next(item for item in feed if "planlı bakım" in item["editorial_title"])
    detail = client.get(f"/v1/stories/{tramvay['id']}").json()["data"]
    assert detail["source_count"] == 2
    removed = detail["sources"][0]["id"]
    assert client.delete(
        f"/v1/admin/stories/{tramvay['id']}/members/{removed}",
        headers=auth("e"),
    ).status_code == 200
    again = client.get(f"/v1/stories/{tramvay['id']}").json()["data"]
    assert again["source_count"] == 1
    audit = client.get("/v1/admin/audit", headers=auth("l")).json()["data"]
    assert any(row["action"] == "cluster_removed" for row in audit)


def test_bad_rows_and_duplicates_stay_out(client):
    _load(client)
    titles = " ".join(item["editorial_title"] for item in client.get("/v1/feed?limit=30").json()["data"]["items"])
    assert "Sağlık uyarısı" not in titles
    session = client.app.state.sessions()
    reasons = {row.quarantine_reason for row in session.query(SourceItem).filter_by(status="quarantined")}
    count = session.query(SourceItem).filter_by(external_id="demo-tramvay").count()
    session.close()
    assert "malformed_date" in reasons
    assert "missing_link" in reasons
    assert count == 1


def test_cursor_pagination(client):
    _load(client)
    assert client.get("/v1/feed?cursor=nope").json()["error"]["code"] == "cursor_invalid"
    assert client.get("/v1/feed?limit=31").status_code == 400
    first = client.get("/v1/feed?limit=2")
    cursor = first.json()["data"]["next_cursor"]
    second = client.get("/v1/feed", params={"limit": 2, "cursor": cursor})
    assert {item["id"] for item in first.json()["data"]["items"]}.isdisjoint(
        {item["id"] for item in second.json()["data"]["items"]}
    )


def test_search_ignores_raw_description(client):
    _load(client)
    assert client.get("/v1/search?q=HAM_ACIKLAMA_SIZMAMALI").json()["data"]["items"] == []
    assert client.get("/v1/search?q=planlı").json()["data"]["items"]


def test_reader_report(client):
    _load(client)
    story_id = client.get("/v1/feed?limit=1").json()["data"]["items"][0]["id"]
    created = client.post("/v1/reports", json={"story_id": story_id, "category": "broken_link"})
    assert created.status_code == 201
    queued = client.get("/v1/admin/reports", headers=auth("p"))
    assert queued.json()["data"][0]["story_id"] == story_id


def test_expired_rights_fail_closed(client):
    _load(client)
    session = client.app.state.sessions()
    for grant in session.query(LicenseGrant).filter_by(status="active"):
        grant.expires_at = NOW - timedelta(minutes=1)
    session.commit()
    session.close()
    assert client.get("/v1/feed").json()["data"]["items"] == []
    story_id = "00000000-0000-0000-0000-000000000000"
    missing = client.get(f"/v1/stories/{story_id}")
    assert missing.status_code == 404
    assert missing.json()["error"]["code"] == "content_unavailable"


def test_takedown_purges_cache(client):
    _load(client)
    first = client.get("/v1/feed?limit=1").json()["data"]["items"][0]
    client.get("/v1/feed?limit=1")
    assert client.post(
        "/v1/admin/takedowns",
        headers=auth("l"),
        json={"story_id": first["id"], "claim": "Test kaydı kaldırıldı."},
    ).status_code == 201
    ids = {item["id"] for item in client.get("/v1/feed?limit=30").json()["data"]["items"]}
    assert first["id"] not in ids


def test_high_risk_second_approval(client):
    _load(client)
    session = client.app.state.sessions()
    story_id = session.query(Story).filter_by(risk_level="high").one().id
    session.close()
    assert client.post(f"/v1/admin/stories/{story_id}/publish", headers=auth("e"), json={"send_push": False}).status_code == 409
    assert client.post(f"/v1/admin/stories/{story_id}/second-approval", headers=auth("e")).status_code == 409
    assert client.post(f"/v1/admin/stories/{story_id}/second-approval", headers=auth("m")).status_code == 200
    assert client.post(f"/v1/admin/stories/{story_id}/publish", headers=auth("e"), json={"send_push": True}).status_code == 200
    assert "HAM FEED" not in client.get(f"/v1/stories/{story_id}").text


def test_role_matrix(client):
    assert client.get("/v1/admin/metrics", headers=auth("e")).status_code == 403
    _load(client)
    story_id = client.get("/v1/feed?limit=1").json()["data"]["items"][0]["id"]
    assert client.post(
        f"/v1/admin/stories/{story_id}/withdraw",
        headers=auth("p"),
        json={"reason": "destek bunu yapamaz"},
    ).status_code == 403


def test_bad_xml_pauses_source(client):
    _load(client)
    session = client.app.state.sessions()
    source = session.query(Source).filter_by(domain="example.com").one()
    source_id = source.id
    client.app.state.clock.freeze(NOW + timedelta(minutes=2))
    with pytest.raises(FatalFetch):
        run_ingest(
            session,
            source,
            client.app.state.settings,
            client.app.state.clock,
            client.app.state.metrics,
            actor="kerem",
            payload=b"<html><article>tam metin kopyasi</article></html>",
        )
    session.close()
    check = client.app.state.sessions()
    assert check.get(Source, source_id).status == "paused"
    check.close()
    assert client.app.state.metrics.parser_alerts >= 1
    assert "tam metin kopyasi" not in client.get("/v1/feed").text


def test_manual_body_rejected(client):
    response = client.post(
        "/v1/admin/manual-items",
        headers=auth("e"),
        json={
            "source_id": "x",
            "url": "https://example.com/a",
            "external_id": "m",
            "published_at": "2026-10-22T12:00:00Z",
            "full_text": "makale",
        },
    )
    assert response.status_code == 422


def test_production_locks_synthetic():
    assert Settings(app_env="production", allow_synthetic=True).synthetic_allowed is False


def test_events_and_deletion(client):
    assert client.post("/v1/events", json={"name": "feed_view", "app_version": "0.1.0", "query": "gizli"}).status_code == 422
    assert client.post(
        "/v1/events",
        json={"name": "story_open", "app_version": "0.1.0", "installation_id": "install-123456"},
    ).status_code == 202
    assert client.delete("/v1/privacy/installations/install-123456").json()["data"]["deleted"] == 1


def test_worker_leases_once(client):
    session = client.app.state.sessions()
    job = enqueue_job(session, "missing-source", "once-key", NOW)
    first = lease_next(session, NOW, "a")
    second = lease_next(session, NOW, "b")
    session.close()
    assert first.id == job.id
    assert second is None


def test_openapi_and_meta(client):
    document = client.get("/v1/openapi.json")
    assert document.status_code == 200
    assert "/v1/feed" in document.text
    assert "full_text" not in document.text
    meta = client.get("/v1/meta").json()["data"]
    assert "TBD" in meta["revenue"]
    assert "hukuki güvence vermez" in meta["legal_notice"]


def test_search_is_rate_limited():
    from app.api import create_app

    app = create_app(make_settings(search_rate_per_minute=1))
    with TestClient(app) as local:
        assert local.get("/v1/search?q=ab").status_code == 200
        limited = local.get("/v1/search?q=ab")
        assert limited.status_code == 429
        assert limited.json()["error"]["retryable"] is True


def test_alembic_upgrade(tmp_path):
    import sqlite3

    from alembic import command
    from alembic.config import Config

    database = tmp_path / "mig.db"
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", f"sqlite:///{database}")
    command.upgrade(config, "head")
    with sqlite3.connect(database) as connection:
        names = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"stories", "license_grants", "source_items", "audit_events"} <= names
