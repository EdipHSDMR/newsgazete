import httpx
from fastapi.testclient import TestClient

from app.api import create_app
from tests.conftest import make_settings

PATHS = (
    "/v1/sports/competitions",
    "/v1/sports/matches",
    "/v1/sports/standings",
    "/v1/sports/teams",
)


def test_sports_without_token_is_unavailable():
    app = create_app(make_settings(football_data_token="", api_football_key=""))
    with TestClient(app) as client:
        for path in PATHS:
            response = client.get(path)
            assert response.status_code == 503 or response.json().get("data", {}).get("limited") is True
            if response.status_code == 503:
                body = response.json()
                assert body["error"]["code"] == "sports_unconfigured"
                assert "FOOTBALL_DATA_TOKEN" in body["error"]["message"]
                assert "data" not in body


def test_match_cache_skips_second_network_call(monkeypatch):
    calls = []

    def fake_get(url, **_kwargs):
        calls.append(url)
        request = httpx.Request("GET", url)
        return httpx.Response(
            200,
            json={
                "matches": [
                    {
                        "id": 11,
                        "utcDate": "2026-10-23T16:00:00Z",
                        "status": "FINISHED",
                        "minute": 90,
                        "competition": {"code": "PL", "name": "Premier League"},
                        "homeTeam": {"name": "Arsenal FC", "shortName": "Arsenal", "crest": "https://example.test/a.png"},
                        "awayTeam": {"name": "Chelsea FC", "shortName": "Chelsea", "crest": "https://example.test/c.png"},
                        "score": {"fullTime": {"home": 2, "away": 1}},
                    },
                    {
                        "id": 12,
                        "utcDate": "2026-10-23T18:00:00Z",
                        "status": "TIMED",
                        "minute": None,
                        "competition": {"code": "PL", "name": "Premier League"},
                        "homeTeam": {"name": "Liverpool FC", "shortName": "Liverpool", "crest": "https://example.test/l.png"},
                        "awayTeam": {"name": "Everton FC", "shortName": "Everton", "crest": "https://example.test/e.png"},
                        "score": {"fullTime": {"home": None, "away": None}},
                    },
                ]
            },
            request=request,
        )

    monkeypatch.setattr("app.sports.client.httpx.get", fake_get)
    app = create_app(make_settings(football_data_token="test-token", api_football_key=""))
    with TestClient(app) as client:
        first = client.get("/v1/sports/matches?date=2026-10-23")
        second = client.get("/v1/sports/matches?date=2026-10-23")
        finished = client.get("/v1/sports/matches?date=2026-10-23&bucket=finished")
    assert first.status_code == 200
    assert second.status_code == 200
    assert len(calls) == 1
    payload = first.json()["data"]
    assert payload["provider"] == "football-data.org"
    assert payload["timezone"] == "Europe/Istanbul"
    assert payload["from_cache"] is False
    assert payload["stale"] is False
    assert second.json()["data"]["from_cache"] is True
    timed = next(match for match in payload["matches"] if match["id"] == 12)
    done = next(match for match in payload["matches"] if match["id"] == 11)
    assert timed["home"]["score"] is None
    assert timed["minute"] is None
    assert done["home"]["score"] == 2
    assert done["away"]["score"] == 1
    assert done["local_time"].startswith("2026-10-23T19:00")
    assert [match["id"] for match in finished.json()["data"]["matches"]] == [11]
    assert "test-token" not in first.text


def test_unknown_competition_is_limited_without_fixtures(monkeypatch):
    calls = []

    def fake_get(url, **_kwargs):
        calls.append(url)
        request = httpx.Request("GET", url)
        return httpx.Response(
            200,
            json={
                "competitions": [
                    {
                        "id": 2021,
                        "name": "Premier League",
                        "code": "PL",
                        "type": "LEAGUE",
                        "emblem": None,
                        "area": {"name": "England", "code": "ENG"},
                    }
                ]
            },
            request=request,
        )

    monkeypatch.setattr("app.sports.client.httpx.get", fake_get)
    app = create_app(make_settings(football_data_token="test-token", api_football_key=""))
    with TestClient(app) as client:
        response = client.get("/v1/sports/matches?date=2026-10-23&competition=ZZZ")
    assert response.status_code == 200
    body = response.json()["data"]
    assert body["limited"] is True
    assert body["limitation"] == "bu sağlayıcı bu ligi bu anahtarla sunmuyor"
    assert body["matches"] == []
    assert calls and all(url.rstrip("/").endswith("/competitions") for url in calls)
    assert "test-token" not in response.text


def test_retry_after_skips_the_next_network_call(monkeypatch):
    calls = {"n": 0}

    def fake_get(url, **_kwargs):
        calls["n"] += 1
        request = httpx.Request("GET", url)
        return httpx.Response(429, headers={"Retry-After": "60"}, json={"message": "limit"}, request=request)

    monkeypatch.setattr("app.sports.client.httpx.get", fake_get)
    app = create_app(make_settings(football_data_token="test-token", api_football_key=""))
    with TestClient(app) as client:
        first = client.get("/v1/sports/matches?date=2026-10-23")
        second = client.get("/v1/sports/matches?date=2026-10-23")
    assert first.status_code == 429
    assert second.status_code == 429
    assert first.headers.get("retry-after") == "60"
    assert calls["n"] == 1
    assert "test-token" not in first.text
