import socket

import httpx
import pytest

from app.errors import ApiError, FatalFetch
from app.ingest import HttpFetcher
from app.logutil import safe_log
from app.models import Source, SourceItem
from app.rss import parse_feed
from app.state_machine import STORY_TRANSITIONS, transition
from app.urlsec import HTML_CRAWLER_ENABLED, canonicalize, resolve_public
from tests.conftest import NOW


def test_xxe_is_rejected():
    payload = b"""<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<rss version="2.0"><channel><item><title>&xxe;</title></item></channel></rss>"""
    with pytest.raises(FatalFetch):
        parse_feed(payload, max_bytes=100000)


def test_html_is_not_a_feed():
    with pytest.raises(FatalFetch):
        parse_feed(b"<html><article>tam metin</article></html>", max_bytes=100000)


def test_state_machine_rejects_skip():
    with pytest.raises(ApiError):
        transition("candidate", "published", STORY_TRANSITIONS)


def test_no_full_text_columns():
    assert "full_text" not in SourceItem.__table__.columns
    assert "body" not in SourceItem.__table__.columns
    assert HTML_CRAWLER_ENABLED is False


def test_canonicalize_and_ssrf():
    assert canonicalize("https://Example.com/a/?utm_source=x&id=1#frag") == "https://example.com/a?id=1"
    with pytest.raises(ApiError):
        canonicalize("http://example.com/a")
    with pytest.raises(ApiError):
        canonicalize("https://user:pass@example.com/a")
    with pytest.raises(ApiError):
        resolve_public("127.0.0.1")

    def resolver(host, *_args, **_kwargs):
        mapping = {
            "example.com": "93.184.216.34",
            "evil.example": "127.0.0.1",
            "meta.example": "169.254.169.254",
        }
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (mapping[host], 443))]

    resolve_public("example.com", resolver)
    with pytest.raises(ApiError):
        resolve_public("evil.example", resolver)
    with pytest.raises(ApiError):
        resolve_public("meta.example", resolver)


def test_redirect_to_other_host_is_blocked():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.host == "example.com":
            return httpx.Response(302, headers={"location": "https://evil.example/secret"})
        return httpx.Response(200, content=b"<rss></rss>")

    def resolver(host, *_args, **_kwargs):
        ip = "93.184.216.34" if host == "example.com" else "127.0.0.1"
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 443))]

    source = Source(
        id="src",
        name="S",
        domain="example.com",
        allowed_host="example.com",
        feed_url="https://example.com/rss.xml",
        source_type="licensed_rss",
        status="active",
        editorial_description="",
        user_agent="HaberKesifDemo/0.1 (+https://haberver.example/bot)",
        rate_limit_per_minute=60,
        timeout_seconds=5,
        synthetic=False,
        created_at=NOW,
        updated_at=NOW,
    )
    fetcher = HttpFetcher(resolver=resolver, transport=httpx.MockTransport(handler))
    with pytest.raises(ApiError):
        fetcher.fetch(source, __import__("app.config", fromlist=["Settings"]).Settings(app_env="dev"))


def test_safe_log_drops_feed_text(caplog):
    with caplog.at_level("INFO"):
        safe_log("ingest_ok", source_id="s", description="HAM_ACIKLAMA_SIZMAMALI")
    assert "HAM_ACIKLAMA_SIZMAMALI" not in caplog.text
