# İşletim

## Kaynak susarsa

1. Yönetim metriklerinde `parser_alerts` ve kaynağın `last_error` alanına bakın.
2. 429 veya 5xx geri çekilerek yeniden dener. Kalıcı ret kaynağı duraklatır.
3. HTML sayfasına geçmeyin. Yazılı izin ve allow-list olmadan tarama açılmaz.

## Kaldırma

Yetkili hukuk rolü `POST /v1/admin/takedowns` ile hikayeyi gizler. Önbellek temizlenir, bildirim kuyruğu iptal edilir, denetim kaydı yazılır.

## Yedek

PostgreSQL için şifreli yedek ve deneme geri yükleme üretim kapısıdır. Bu depoda bulut yedeği kurulmadı; sağlayıcı TBD. Yedek, süresi dolmuş lisanslı gövdeyi süresiz saklamamalıdır. Tam metin zaten tutulmaz.

## SLO

Hedef rakam uydurulmadı. p95 ve açılış süresi gerçek ölçümden sonra yazılacak.

## Geri alma

Şema genişletmesi Alembic ile ileri gider. Bozuk sürümde geri alma yerine ileri düzeltme tercih edilir. Sentetik demo `ALLOW_SYNTHETIC=false` ile kapanır.
