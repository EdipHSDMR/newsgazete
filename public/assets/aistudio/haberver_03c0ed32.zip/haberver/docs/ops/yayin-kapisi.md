# Yayın kapısı

Yayın tarihi gelmeden resmi metinler yeniden okunacak: FSEK, KVKK aydınlatma/rıza ayrımı (Kurul duyurusu 18 Şubat 2026), Google Play fikri mülkiyet, hesap silme, Data Safety ve hedef API.

- [ ] Her yayındaki hikayenin izin kaydı, kaynak URL'si, editörü ve editoryal özeti var
- [ ] Sentetik kayıt üretimde kapalı
- [ ] HTML tarama kapalı, APK'da yayıncı anahtarı yok
- [ ] Gizlilik metni avukat onaylı ve uygulama davranışıyla aynı
- [ ] Mağaza görselleri özgün; yayıncı fotoğrafı ve logosu yok
- [ ] İmza anahtarı gizli depoda
- [ ] Alan adı doğrulanmış App Link (şimdi TBD)
- [ ] Play hedef API'si o günkü zorunlulukla eşit
- [ ] Yedek geri yükleme denenmiş

Bu liste hukuki incelemenin yerine geçmez.
