# Kişisel veri notu

Bu metin KVKK aydınlatması yerine geçmez. Avukat incelemesi yayın kapısıdır. Aydınlatma ile açık rıza ayrı tutulur.

| Veri | Amaç | Karar | Saklama | Silme |
| --- | --- | --- | --- | --- |
| Konu, şehir, sessize alınan yayıncı, son arama | Okuma tercihi | Cihazda, hesap yok | Uygulama silinene kadar | Ayarlardan cihaz verisini sil |
| Kaydedilen hikaye kimliği ve izinli özet | Sonra oku | Cihazda | Uygulama silinene kadar | Aynı silme; izin bitince metin gizlenir |
| Kurulum kimliği | İsteğe bağlı ölçüm | Kapalı başlar, hesap değildir | 90 gün, yalnız rıza varsa | `DELETE /v1/privacy/installations/{id}` |
| Bildirim | Yerel gelişme | Ayarlarda, ilk açılışta sorulmaz | Cihazda görülen hikaye kimliği | Bildirimi kapat |
| Admin kimliği | Yayın ve hak işlemi | Sunucu rol jetonu | Denetim kaydı | Ayrı erişim iptali, TBD OIDC |
| Sözleşme dosyası | Hak | Özel referans, API'ye çıkmaz | Sürüm silinmez | Hukuk kararı |

Toplanmayanlar: ad, koordinat, rehber, mikrofon, reklam kimliği, arama sorgusunun sunucu kaydı, makale gövdesi.

Google Play Data Safety formu yayın gününde APK bağımlılıklarıyla yeniden doldurulacaktır. Reklam SDK'sı yok.
