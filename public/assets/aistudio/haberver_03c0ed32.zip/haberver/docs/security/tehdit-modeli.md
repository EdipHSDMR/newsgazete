# Tehdit modeli

| Tehdit | Etki | Kontrol |
| --- | --- | --- |
| Kötü amaçlı XML / XXE | Dosya veya iç ağ okuma | defusedxml, DOCTYPE reddi, gövde sınırı |
| SSRF | İç ağa veya metadata adresine istek | Onaylı ana makine, yalnız https, genel olmayan IP reddi, yönlendirmede tekrar kontrol |
| Sahte kaynak | İzinsiz içerik | İki aşamalı onay, aktif izin ve link hakkı olmadan iş yok |
| Admin ele geçirme | Yayın ve hak değişimi | Rol jetonu, hız sınırı, denetim. Üretim OIDC ve MFA TBD |
| Önbellek sızıntısı | Kaldırılmış metin | Kaldırma ve süre bitiminde önbellek temizliği, TTL izin bitişini aşmaz |
| İstemciye sır koyma | Yayıncı anahtarı | Anahtar yalnız sunucu ortamında, APK'da yok |
| Prompt enjeksiyonu | Otomatik yayın | Otomatik yapay zeka yayını yok |

Kalan risk: üretim kimliği henüz OIDC değil. Jetonlar ortam değişkenindedir ve depoya yazılmaz. HTML tarama kapalıdır.
