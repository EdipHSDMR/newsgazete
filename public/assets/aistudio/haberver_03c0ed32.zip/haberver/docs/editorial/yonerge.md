# Editör yönergesi

Bu metin hukuki görüş değildir.

- Uygulama haberi kopyalamaz. Editör olguyu kendi cümlesiyle yazar, iddiayı kaynak URL'sine bağlar, bilinen ile bilinmeyeni ayırır.
- Ham akış başlığı ve açıklaması genel API'de gösterilmez. Başlığın kaynak başlığıyla aynı olması yayın kapısında reddedilir.
- Yapay zeka taslağı insan onayı olmadan yayınlanmaz. Otomatik yayın yolu yoktur.
- Tek kaynak varsa bu söylenir. Yüksek risk (afet, sağlık, seçim, güvenlik) ikinci editör ister ve onaysız push almaz.
- Küme üyeliği hak miras etmez. Her kaynak kendi izin kaydıyla açılır. Yanlış üyelik geri alınır ve denetim kaydı oluşur.
- Düzeltme eski sürümü silmez. Geri çekme gerekçe ister.
- Güven puanı ve siyasi etiket üretilmez.
