# Kabul notu — 22 Ekim 2026

Backend testleri bu makinede çalıştı: `python -m pytest` → 27 geçti.

Kanıtlananlar:

- İzinsiz veya süresi dolmuş kaynak kamuya çıkmaz
- Ham akış açıklaması ve başlığı genel JSON'da yoktur
- Bozuk XML kaynağı duraklatır, gövde yayınlanmaz
- XXE ve özel IP / metadata adresi reddedilir
- Aynı akış öğesi ikinci kez satır açmaz
- Yüksek risk ikinci editör olmadan yayınlanmaz
- Misafir yönetim uçlarına giremez
- Kaldırma akıştan ve önbellekten düşer
- Sentetik kart etiketlidir
- Üretim ayarı sentetik izni kapatır
- Arama sorgusu olay şemasına giremez

Yapılamayanlar:

- Android derlemesi ve emülatör. JDK 17 ve Android SDK yok.
- Tarayıcıda uçtan uca tıklama. Aynı nedenle.
- PostgreSQL üzerinde migration. Docker yok. Alembic ilk şemayı SQLite dosyasında kuran test geçti.
- Play ve mevzuatın yayın günü doğrulaması.
