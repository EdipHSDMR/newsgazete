# Karar kayıtları

Tarih: 22 Ekim 2026. Depoda çalışan kod yoktu. Aşağıdaki kararlar bu yüzden yeni kurulumdur; silinecek bir mimari yoktu.

## 0001 Teknoloji

- Android: Kotlin, Jetpack Compose, ViewModel/StateFlow, Room, DataStore, WorkManager, Retrofit.
- Sunucu: FastAPI modüler monolit, SQLAlchemy, Alembic.
- Üretim veritabanı: PostgreSQL. Bu makinede Docker ve PostgreSQL yok. Testler SQLite bellek veritabanında çalışır; kuyrukta PostgreSQL için `FOR UPDATE SKIP LOCKED` yolu vardır.
- Sürümler 22 Ekim 2026 resmi notlarından sabitlendi: FastAPI 0.159.1, SQLAlchemy 2.1.6, Alembic 1.20.1, AGP 9.4.0, Kotlin 2.4.10, Compose BOM 2026.09.00, Room 2.8.5, Navigation 2.10.2.
- Android derlemesi bu makinede yapılamadı: kurulu Java 8, JDK 17 ve Android SDK yok.

## 0002 Haklar

- Bilinmeyen hak kapalıdır.
- Atıf, yeniden kullanım izni değildir. `link`, `metadata`, `source_title`, `excerpt`, `image`, `logo`, `push_quote` ayrı alanlardır.
- Tam metin sütunu yoktur. HTML tarayıcı kapalıdır.
- İzin bitince hikaye kamuya kapanır, önbellek temizlenir, bekleyen bildirim iptal edilir.

## 0003 Sentetik veri

- Gerçek yayıncı sözleşmesi TBD. Demo kaynağı `synthetic_demo` türündedir ve hukuki lisans değildir.
- `APP_ENV=production` bu kayıtları kapatır.
- Kartlarda “Sentetik demo — gerçek haber değildir” etiketi vardır. Ham akış başlığı ve açıklaması genel API'ye çıkmaz.

## 0004 Ölçüm ve gelir

- Analitik varsayılan kapalıdır. Hukuki sebep avukat onayına bırakıldı.
- Arama sorgusu, makale gövdesi ve tam URL olayı toplanmaz.
- Gelir modeli TBD. Akışta reklam veya sahte sponsor kartı yok.

## TBD

Marka, alan adı, bulut, FCM projesi, OIDC/MFA sağlayıcısı, yazılı yayıncı sözleşmesi, mağaza hedef API seviyesi (yayın gününde yeniden doğrulanacak).
